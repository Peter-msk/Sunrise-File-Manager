# Sunrise File Manager v1.7.0 R06 — Windows 실제 실행 검증 키트

## 상태

이 키트는 **Windows 실기 검증의 실행 도구**입니다. Linux 환경에서 만든 것이므로 **Windows 실행 결과가 포함되지 않으며 현재 실기 PASS가 아닙니다.** R06 원본 프로그램 기능 코드는 수정하지 않습니다. 테스트 호스트 파일만 검사 중 임시로 대체하고 마지막에 복원합니다.

## 준비

1. `Sunrise_File_Manager_v1.7.0_R06.zip`을 Windows PC의 작업 폴더에 압축 해제합니다.
2. 그 루트 폴더에 `r06-validation-kit` 폴더를 만들고 키트의 4개 파일을 압축 해제합니다.
3. Windows 10/11 x64, .NET SDK 10 x64, 로그인한 실제 Windows 데스크톱이 필요합니다. 관리자 권한은 기본 WPF UI 감사에는 필요하지 않습니다. 정상적인 회사 Preview 서명 빌드에는 기존 회사 서명 환경이 필요합니다.
4. PowerShell에서 소스 루트로 이동한 다음 실행합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\r06-validation-kit\VERIFY_R06_WINDOWS.ps1
```

회사 서명 구성이 준비되어 있고 설치 없이 실행할 수 있는 Preview도 함께 확인하려면:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\r06-validation-kit\VERIFY_R06_WINDOWS.ps1 -TryPreview -IncludeExtendedUI
```

## 결과

- `validation/windows-r06-visual-YYYYMMDD-HHMMSS/`에 단계별 로그, `R06_WINDOWS_GATE_SUMMARY.json`, 각 UI 시나리오 `UI_RESULT.json`, 라이트·다크 화면 PNG가 저장됩니다.
- `02-R06-THEME-AND-GEOMETRY/`에는 **90% UI 배율**, 1520×930과 1010×650, 2·4분할, 라이트·다크 테마를 이용한 **실제 WPF 렌더 캡처 6장** 및 `R06_VISUAL_RESULT.json`이 저장됩니다.
- 상단 행은 38+42+40=120 DIP, UI 버튼 최소 높이/간격, 테마 브러시, 우측 공용 상세정보·메모·미리보기 각 1개 여부를 확인합니다.
- 분할 배치 메뉴, 우측 패널, 활성 파일 동기화 등 기존 네이티브 검사도 별도로 실행합니다.
- **Windows DPI 100/125/150%**는 OS 디스플레이 설정에서 각각 변경하고 별도 Windows 로그인/실행 세션으로 테스트해야 합니다. 테스트 스크립트가 Windows DPI를 무단 변경하지 않습니다.
- `PASS`는 수행된 검사 범위에만 해당합니다. 검사 실패·실행 못 함·서명 인증서 부재를 성공으로 기록하지 마세요.
- Preview는 실제 파일을 조작할 수 있으므로 업무 원본이 아닌 테스트 폴더에서 실행해야 합니다. 기본 검증 호스트는 임시 테스트 폴더를 사용합니다.

## 호환성 검사 보정

R06 상단 3개 행은 **38/42/40 DIP**로 변경됐으나 기존 `OfficialAShellAudit.cs`에는 **R05의 104 DIP**가 남아 있었습니다. 이 키트는 실기 실행 시 테스트 소스만 R06 기준인 **120 DIP**로 일시 교체하여 거짓 실패를 방지합니다. 원본 제품과 설치용 빌드 스크립트는 수정하지 않습니다.

## 검증 범위의 한계

이 도구는 Windows 런타임에서 앱 UI 호스트를 실제 렌더링하며 스크린샷을 생성하지만, 화면 미관은 자동으로 전부 평가할 수 없습니다. 사용자가 R06 캡처를 제공하면 라이트·다크 버튼, 텍스트 잘림, 4분할 가독성, 패널/팝업 마감에 대한 수동 시각 감사가 필요합니다. 회사 인증서 서명, 완성된 Setup 설치, 운영환경 Sunrise Control 네트워크 응답은 별도 승인 검증입니다.
