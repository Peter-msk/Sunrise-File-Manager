# R06 isolated native Windows WPF execution gate.
# Run from PowerShell in a fresh Windows 10/11 x64 desktop session.
# Prerequisites: .NET SDK 10 x64, latest R06 source extracted, normal desktop session.
# Does NOT publish, install, or overwrite an existing user's File Manager.
param(
    [string]$SourceRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path,
    [switch]$TryPreview,
    [switch]$IncludeExtendedUI
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET 10 SDK not found. Install the .NET SDK on Windows before running this verification.' }
$SourceRoot = [IO.Path]::GetFullPath($SourceRoot)
$harnessDir = Join-Path $SourceRoot 'source/tests/UiSmokeTests'
if (!(Test-Path (Join-Path $harnessDir 'Program.cs'))) { throw "R06 full source root not found: $SourceRoot" }
if (!(Test-Path (Join-Path $SourceRoot 'BUILD_PREVIEW_ON_WINDOWS.cmd'))) { throw 'Incorrect source: no Preview build entrypoint.' }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$evidence = Join-Path $SourceRoot "validation/windows-r06-visual-$stamp"
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
$checks = [System.Collections.Generic.List[object]]::new()
$failed = $false
# Backup original TEST files, never alter production source files.
foreach ($n in @('Program.cs','OfficialAShellAudit.cs')) {
  Copy-Item (Join-Path $harnessDir $n) (Join-Path $evidence ("$n.original"))
}
foreach ($n in @('Program.cs','OfficialAShellAudit.cs','R06VisualAcceptance.cs')) {
  Copy-Item (Join-Path $PSScriptRoot $n) (Join-Path $harnessDir $n) -Force
}
$os = Get-CimInstance Win32_OperatingSystem
$environment = [ordered]@{
  product = 'Sunrise File Manager'; version = '1.7.0'; revision = 'R06';
  osCaption = $os.Caption; osVersion = $os.Version;
  userInteractive = [Environment]::UserInteractive;
  date = (Get-Date).ToString('o');
  dotnet = @( & dotnet --version 2>&1 );
  session = @(cmd /c 'query session' 2>&1);
}
$environment | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $evidence 'ENVIRONMENT.json') -Encoding utf8
function Invoke-Gate([string]$name,[string]$cmd, [string[]]$arguments) {
  $logPath = Join-Path $evidence "$name.log"
  $begin = Get-Date
  Write-Host "[R06] $name" -ForegroundColor Cyan
  & $cmd @arguments *>&1 | Out-File -FilePath $logPath -Encoding utf8
  $exit = $LASTEXITCODE
  $script:checks.Add([ordered]@{ name=$name; exitCode=$exit; status=$(if($exit -eq 0){'PASS'}else{'FAIL'}); durationSeconds=[math]::Round(((Get-Date)-$begin).TotalSeconds,1); log="$name.log" })
  if ($exit -ne 0) { $script:failed = $true; Write-Warning "$name failed: exit code $exit (see $logPath)" }
  return ($exit -eq 0)
}
Push-Location $SourceRoot
try {
  if (!(Invoke-Gate '01-WPF-COMPILE' 'dotnet' @('build','source/tests/UiSmokeTests/UiSmokeTests.csproj','-c','Release','-warnaserror'))) {
    Write-Warning 'UI tests skipped because .NET WPF compile failed.'
  } else {
    $scenarios = @(
      @('02-R06-THEME-AND-GEOMETRY','--r06-visual-only'),
      @('03-OFFICIAL-A-SHELL','--official-a-shell-only'),
      @('04-SPLIT-GALLERY','--split-gallery-only'),
      @('05-RIGHT-DOCK','--right-dock-only'),
      @('06-SHARED-PANELS','--shared-panel-only')
    )
    if($IncludeExtendedUI) {
      $scenarios += ,@('07-FOUR-PANE-DENSITY','--pane-density-only')
      $scenarios += ,@('08-ADAPTIVE-COMMANDS','--compact-shell-only')
      $scenarios += ,@('09-WINDOWS-CONTEXT-MENU','--context-menu-only')
    }
    foreach ($entry in $scenarios) {
      $name = $entry[0]; $flag = $entry[1];
      $outputPath = Join-Path $evidence $name
      New-Item -ItemType Directory -Force -Path $outputPath | Out-Null
      $ok = Invoke-Gate $name 'dotnet' @('run','--project','source/tests/UiSmokeTests/UiSmokeTests.csproj','-c','Release','--no-build','--',$flag,$outputPath)
      $result = Join-Path $outputPath 'UI_RESULT.json'
      if (!$ok -or !(Test-Path $result)) {
        $failed = $true
        Write-Warning "Native WPF scenario has no successful UI_RESULT.json: $name"
      } else {
        try {
          $ui = Get-Content $result -Raw | ConvertFrom-Json
          if($ui.status -ne 'PASS'){ $failed = $true; Write-Warning "UI result was $($ui.status): $name" }
        } catch { $failed = $true; Write-Warning "Cannot parse result for $name: $_" }
      }
    }
  }
  if($TryPreview) {
    # This requires the user's existing company signing prerequisites; never create test certificates.
    $ok = Invoke-Gate '10-COMPANY-PREVIEW-BUILD' 'cmd.exe' @('/d','/c','BUILD_PREVIEW_ON_WINDOWS.cmd')
    if($ok) {
      $preview = Join-Path $SourceRoot 'dist/Sunrise_File_Manager_1.7.0_Preview/Sunrise.FileManager.exe'
      $checks.Add([ordered]@{name='11-PREVIEW-EXECUTABLE-PRESENT';status=$(if(Test-Path $preview){'PASS'}else{'FAIL'}); path=$preview})
      if(!(Test-Path $preview)){ $failed=$true }
    }
  }
} finally {
  $summary = [ordered]@{status=$(if($failed){'FAIL'}else{'PASS'}); scope='Windows WPF native host; noninteractive code signing not inferred';
    sourceRoot=$SourceRoot; evidence=$evidence; environment=$environment; checks=@($checks) }
  $summary | ConvertTo-Json -Depth 9 | Set-Content (Join-Path $evidence 'R06_WINDOWS_GATE_SUMMARY.json') -Encoding utf8
  Write-Host "R06_WINDOWS_GATE: $($summary.status); evidence=$evidence"
  # Remove the temporary test harness changes; the delivered product code is never patched.
  foreach($n in @('Program.cs','OfficialAShellAudit.cs')){
    Copy-Item (Join-Path $evidence ("$n.original")) (Join-Path $harnessDir $n) -Force
  }
  Remove-Item (Join-Path $harnessDir 'R06VisualAcceptance.cs') -ErrorAction SilentlyContinue
  Pop-Location
}
if($failed){ exit 1 } else { exit 0 }
