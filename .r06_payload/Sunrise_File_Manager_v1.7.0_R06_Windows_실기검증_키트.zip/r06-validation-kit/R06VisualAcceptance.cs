using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Sunrise.FileManager;
using Sunrise.FileManager.Controls;
using Sunrise.FileManager.Services;

// Opt-in Windows desktop acceptance. This class does not run during a company release build.
internal static class R06VisualAcceptance
{
    private sealed record Measurement(string Theme, int Scale, int Split, int Width, int Height,
        double HeaderHeight, double FileAreaWidth, double FileAreaHeight, double DpiX,
        int DetailPanels, int MemoPanels, int PreviewPanels, string Screenshot);

    internal static async Task RunAsync(MainWindow window, string output)
    {
        Directory.CreateDirectory(output);
        var readings = new System.Collections.Generic.List<Measurement>();
        var failures = new System.Collections.Generic.List<string>();
        var shell = (Grid)window.FindName("OfficialAShellHeader");
        var workspace = (Grid)window.FindName("WorkspaceShell");
        var fileArea = (Grid)window.FindName("FileAreaShell");
        var rail = workspace.Children.OfType<Border>().SingleOrDefault(x => Grid.GetColumn(x) == 3)
            ?? throw new InvalidOperationException("Right-side utility rail border not found.");
        var modeNames = new[] { "ShellFilesButton", "ShellDocsButton", "ShellAiButton", "ShellToolsButton" };
        var splitNames = new[] { "OneButton", "TwoButton", "ThreeButton", "FourButton" };
        var commandNames = new[] { "새 폴더", "이름 변경", "복사", "붙여넣기", "삭제", "검색 · 필터" };
        if (shell.RowDefinitions.Count != 3) failures.Add("Header must have three rows.");
        else
        {
            double[] expected = { 38, 42, 40 };
            for (int j = 0; j < expected.Length; j++)
                if (Math.Abs(shell.RowDefinitions[j].Height.Value - expected[j]) > .01)
                    failures.Add($"Header row {j} is not {expected[j]} DIP.");
        }
        foreach (string name in modeNames)
        {
            if (window.FindName(name) is not Button b) failures.Add($"Missing {name}.");
            else if (b.MinHeight < 34 || b.FontSize < 13 || b.Margin.Right < 8)
                failures.Add($"{name}: mode button height/font/spacing failed.");
        }
        foreach (string name in splitNames)
        {
            if (window.FindName(name) is not Button b) failures.Add($"Missing {name}.");
            else if (b.MinHeight < 34 || b.MinWidth < 70 || b.FontSize < 13 || b.Margin.Right < 7)
                failures.Add($"{name}: split button height/width/font/spacing failed.");
        }
        if (window.FindName("UiScaleSelector") is not ComboBox scale || scale.MinHeight < 32)
            failures.Add("Scale ComboBox must be at least 32 DIP high.");
        if (window.FindName("HeaderThemeButton") is not Button themeButton || themeButton.MinHeight < 32)
            failures.Add("Theme header button must be at least 32 DIP high.");

        // This is the real UI tree in an isolated WPF desktop host, NOT a static screenshot.
        // Windows OS DPI is read from the launched process; changing OS DPI requires a fresh session.
        foreach (var (theme, expectedBrand, expectedRail) in new[]
        {
            ("Light", "#F5F9FC", "#EFF4F8"),
            ("Dark", "#101D30", "#15344C")
        })
        {
            ThemeManager.Apply(theme);
            await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
            string brand = BrushHex(Application.Current.Resources["ThemeShellBrand"] as Brush);
            string railColor = BrushHex(rail.Background);
            if (!string.Equals(brand, expectedBrand, StringComparison.OrdinalIgnoreCase))
                failures.Add($"{theme} top brand expected {expectedBrand}, got {brand}.");
            if (!string.Equals(railColor, expectedRail, StringComparison.OrdinalIgnoreCase))
                failures.Add($"{theme} right utility rail expected {expectedRail}, got {railColor}.");

            foreach (var (width, height, count, preset) in new[]
            {
                (1520, 930, 2, SplitLayoutPreset.TwoColumns),
                (1010, 650, 2, SplitLayoutPreset.TwoColumns),
                (1520, 930, 4, SplitLayoutPreset.FourGrid2x2),
            })
            {
                window.Width = width;
                window.Height = height;
                SplitLayoutGalleryAudit.SelectPreset(window, count, preset);
                await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                window.UpdateLayout();
                double actualHeader = shell.ActualHeight;
                if (Math.Abs(actualHeader - 120) > 2)
                    failures.Add($"{theme} {width}x{height} header height = {actualHeader:F1}; expected ~120 DIP.");
                if (fileArea.ActualWidth < 150 || fileArea.ActualHeight < 200)
                    failures.Add($"{theme} {width}x{height}: file area clipped.");

                int details = CountVisual<FileDetailsPanel>(workspace);
                int memo = CountVisual<FileMemoPanel>(workspace);
                int preview = CountVisual<FilePreviewPanel>(workspace);
                if (details != 1 || memo != 1 || preview != 1)
                    failures.Add($"{theme} {count} split duplicated common panels: {details}/{memo}/{preview}.");
                if (Grid.GetColumn(rail) != 3)
                    failures.Add("Utility rail moved out of rightmost grid column.");
                if (width >= 1520 && count == 2)
                {
                    var fileActions = (StackPanel)window.FindName("ShellFilesActions");
                    foreach (string action in commandNames)
                        if (!fileActions.Children.OfType<Button>().Any(x => string.Equals(x.Content?.ToString(), action, StringComparison.Ordinal)))
                            failures.Add("Missing file command: " + action);
                }
                string shot = $"R06-{theme.ToLowerInvariant()}-90pct-{width}x{height}-{count}split.png";
                Capture(window, Path.Combine(output, shot));
                readings.Add(new Measurement(theme, 90, count, width, height,
                    actualHeader, fileArea.ActualWidth, fileArea.ActualHeight,
                    VisualTreeHelper.GetDpi(window).DpiScaleX, details, memo, preview, shot));
            }
        }
        // Restore session theme to avoid contaminating other tests.
        ThemeManager.Apply("System");
        var result = new { status = failures.Count == 0 ? "PASS" : "FAIL", platform = Environment.OSVersion.ToString(),
            interactive = Environment.UserInteractive, cases = readings, failures,
            note = "Native Windows WPF render captures; Windows DPI cases require OS-specific sessions." };
        File.WriteAllText(Path.Combine(output, "R06_VISUAL_RESULT.json"), JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
        if (failures.Count != 0) throw new InvalidOperationException(string.Join(Environment.NewLine, failures));
        Console.WriteLine($"R06_WPF_VISUAL_PASS cases={readings.Count}");
    }

    private static string BrushHex(Brush? brush) => brush is SolidColorBrush sb ? $"#{sb.Color.R:X2}{sb.Color.G:X2}{sb.Color.B:X2}" : "<not-solid>";

    private static int CountVisual<T>(DependencyObject root) where T : DependencyObject
    {
        int total = 0;
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            DependencyObject child = VisualTreeHelper.GetChild(root, i);
            if (child is T) total++;
            total += CountVisual<T>(child);
        }
        return total;
    }

    private static void Capture(FrameworkElement element, string target)
    {
        var dpi = VisualTreeHelper.GetDpi(element);
        int w = Math.Max(1, (int)Math.Ceiling(element.ActualWidth * dpi.DpiScaleX));
        int h = Math.Max(1, (int)Math.Ceiling(element.ActualHeight * dpi.DpiScaleY));
        var screenshot = new RenderTargetBitmap(w, h, dpi.PixelsPerInchX, dpi.PixelsPerInchY, PixelFormats.Pbgra32);
        screenshot.Render(element);
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(screenshot));
        using var stream = File.Create(target);
        encoder.Save(stream);
    }
}
