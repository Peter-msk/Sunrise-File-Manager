#!/usr/bin/env python3
"""Optional local payload footprint report; not required by the Windows build."""
import argparse
import os
from pathlib import Path
from collections import defaultdict


def main():
    parser = argparse.ArgumentParser(description="Measure installed/published Sunrise File Manager file footprint (bytes on disk, excluding filesystem allocation slack).")
    parser.add_argument("folder", type=Path, help="Publish app folder or installed application folder")
    args = parser.parse_args()
    root = args.folder.resolve()
    if not root.is_dir():
        parser.error(f"Not a directory: {root}")
    summary = defaultdict(lambda: [0, 0])
    total = 0
    count = 0
    top = []
    for current, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if not (Path(current) / d).is_symlink()]
        for name in files:
            file = Path(current) / name
            if file.is_symlink():
                continue
            try:
                size = file.stat().st_size
            except OSError:
                continue
            relative = file.relative_to(root)
            if relative.parts[0].lower() == "licenses":
                category = "license-notices"
            elif name.lower().endswith(".pdb"):
                category = "debug-symbols"
            elif name.lower().endswith(".xml"):
                category = "xml-or-config"
            elif relative.parts[0].lower() not in {"licenses", "app"} and name.lower().endswith(".resources.dll"):
                category = "localized-resources"
            elif file.suffix.lower() in {".dll", ".exe"}:
                category = "executables-and-runtime"
            else:
                category = "other-runtime-assets"
            summary[category][0] += size
            summary[category][1] += 1
            total += size
            count += 1
            top.append((size, str(relative)))
    print(f"Root: {root}")
    print(f"Total: {total:,} bytes ({total / 1024 / 1024:.2f} MiB), files: {count:,}")
    for category, (size, files) in sorted(summary.items(), key=lambda x: -x[1][0]):
        print(f"{category:26s} {size / 1024 / 1024:9.2f} MiB   {files} files")
    print("Largest 15 files:")
    for size, name in sorted(top, reverse=True)[:15]:
        print(f"  {size / 1024 / 1024:8.2f} MiB  {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
