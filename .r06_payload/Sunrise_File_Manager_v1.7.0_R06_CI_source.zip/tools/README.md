# 개발용 설치 용량 측정 도구

Windows 빌드 결과(스테이징된 WPF 앱) 또는 실제 설치 폴더의 파일 총량을 조사합니다. **사용자 파일을 수정하거나 삭제하지 않습니다.** Python 3.10 이상/Miniconda에서 별도로 실행하는 진단 도구이며 공식 Windows 빌드 과정의 필수 의존성은 아닙니다.

```cmd
python tools\measure_payload_size.py "dist\_R18_installer_payload\app"
python tools\measure_payload_size.py "%LOCALAPPDATA%\Programs\Sunrise File Manager"
```

첫 번째 경로는 빌드 직후에 임시로 생성되는 경우에만 사용할 수 있으며 공식 빌드 완료 시 정리될 수 있습니다. 두 번째 경로는 기본 설치 경로로, 실제 사용자의 설치 위치가 다르면 변경합니다. 재빌드 전후 **동일한 측정 대상**을 비교하십시오. 파일 크기의 단순 합계이므로 NTFS 실제 할당 크기/공유 런타임/사용자 캐시와는 다를 수 있습니다.
