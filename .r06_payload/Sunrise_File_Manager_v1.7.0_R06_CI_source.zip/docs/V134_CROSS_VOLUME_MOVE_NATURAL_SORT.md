# Sunrise File Manager v1.3.4 — 드라이브 간 이동·파일명 정렬 작업인수인계

## 1. 기준 및 버전

- 부모 기준본: `Sunrise_File_Manager_v1.3.3_R00.zip` (SHA256: `b604fd115902c9154ec17991500e31fb1c2e6b5e9f0068a550530cbaa3fb025b`)
- 신규 수정본: `Sunrise_File_Manager_v1.3.4.zip` (기능 오류 수정에 따른 패치 버전)
- 목표: 다른 드라이브 간 잘라내기/붙여넣기·드래그 이동 지원, Windows 파일 탐색기 방식 자연 정렬.
- 기존 설치 AppId, 사용자 설정/메모 파일형식, AI, 테마, 세션, 업데이트 wire 계약은 변경하지 않음.
- `latest.json`은 게시된 데이터 스냅샷이므로 임의 변경하지 않음. 서명 후 실제 배포 SHA256이 확인되어야 공식 게시 가능.

## 2. 원인 분석

**드라이브 간 이동:** `TransferService.BuildPlan()`이 원본·대상의 Path Root 차이를 이유로 이동을 선제 차단했고, `FileActionsService.MoveEntry()`는 `File.Move`/`Directory.Move`(같은 드라이브 빠른 이동)만 사용. 스크린샷의 `Access to the path is denied`는 실제 접근권한·파일 잠금·루트 쓰기 제한 가능성도 있으므로 이 고정 차단과 동일 원인이라고 확정하지 않음.

**숫자 정렬:** `DirectoryScanner`, `FileListView`, `FolderTreeScanner`가 사전식/현재 문화권 문자열 비교를 사용. `1, 10, 11, 2`와 같이 숫자값과 다른 순서가 됨.

## 3. 변경내용

- `Services/TransferService.cs`: 같은 드라이브는 기존 직접 이름 변경, 다른 드라이브는 고유한 staging → 복사 완료 → 대상 최종 이름 공개 → 원본 파일 정보·폴더 목록 재확인 → 원본 삭제. 원본이 바뀌거나 삭제 단계 실패 시 복사본·원본을 명시적으로 보고하고 자동 추가 삭제/재시도를 하지 않음. 링크·접합점 제한, 50,000개 계획 한계, 중복이름 Skip/Rename, 사용자 승인 및 취소 유지.
- `FileMemoStore` 연계: 파일의 기존 메모를 읽기/검증 후 대상 경로에 원래 날짜·작성자·내용으로 저장. 메모 오류가 있으면 원본을 지우지 않음. 하위 폴더 내부의 `#memo`는 디렉터리 복사 대상으로 그대로 포함.
- `Services/FileActionsService.cs`: 실행 취소·다시 실행 및 기타 직접 이동도 공유하는 안전한 드라이브 간 이동 경로를 사용. 같은 드라이브 메모 처리 로직은 그대로 유지.
- `MainWindow.xaml.cs`: Move 결과의 실제 생성 대상 경로(충돌시 자동 이름 포함)를 실행 취소 기록에 사용. 이전의 추정 대상명 기록 오류 방지.
- `Controls/ExplorerPane.xaml.cs`: 긴 이동 실행 취소·다시 실행 중 WPF UI 응답성을 유지하기 위해 백그라운드 실행.
- `Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs`: Windows `Preferred DropEffect`를 `MemoryStream`/`byte[]` 양쪽에서 해석, 스트림 읽기 포지션 의존 제거. Ctrl+C/V, Ctrl+X/V 동작 유지.
- `Services/FileListView.cs`: Windows의 `StrCmpLogicalW` 자연 정렬, 비-Windows 소스 시험용 숫자 구간 비교 fallback. 폴더 우선 정렬 유지. 다른 데이터형 컬럼 정렬은 기존 비교 유지.
- `Services/DirectoryScanner.cs`, `Services/FolderTreeScanner.cs`: 파일 목록 및 트리 폴더명을 동일한 자연 정렬로 정렬. 예: `0,1,2,3,10,11`.
- 버전·테스트 계약: csproj, 창 제목, Control 제품 버전 상수, 설치 버전, 회사 빌드 표시값 1.3.4로 동기화. 게시 URL 및 최신 피드는 미수정.

## 4. 검증 및 남은 Gate

| 확인 항목 | 결과 |
|---|---|
| Python 현행 소스 회귀검사 | 194/194 PASS |
| Python UI 계약검사 | 19/19 PASS |
| 패키징 정적검사 | 15/15 PASS |
| XAML XML 구문 확인 | 아래 자동 검증 결과 참조 |
| Windows .NET 10 C# 컴파일·LogicTests | PENDING (현재 환경에 dotnet SDK 없음) |
| 실제 C:, D:, 이동식·UNC·권한제한 경로 실이동 | PENDING |
| 실행 취소·다시 실행(서로 다른 볼륨), 폴더 + 메모 | PENDING |
| 서명 EXE, 설치형 Setup, Windows DPI/GUI | PENDING |

### Windows 실기 필수 시나리오

1. C: → D:에서 파일과 여러 하위 폴더를 **복사**, 원본 보존·대상 크기·해제 가능 여부 확인.
2. C: → D:에서 파일/폴더를 **잘라내기·붙여넣기**, 성공 시 원본 제거와 대상 완전성 확인. 실행 취소/다시 실행 확인.
3. 드래그 기본 동작: 같은 드라이브는 이동, 다른 드라이브는 복사; Ctrl 드래그는 복사, Shift 드래그는 이동.
4. 메모가 연결된 파일의 서로 다른 드라이브 이동. 날짜·작성자·본문 및 메모 보기 유지.
5. 대상 충돌: 건너뛰기/자동이름 정책; 자동이름 변경 후 정확한 파일 Undo.
6. 파일 잠금·읽기 거부·대상 폴더 쓰기 거부 시 **원본 보존**, 사용자 오류 설명, staging 정리 확인.
7. 복사 중 취소, 복사 직후 원본 변경, 부분 실패에서 불완전 데이터 삭제 금지 확인.
8. 이름 정렬 오름차순/내림차순, 파일/폴더/트리 `0.`, `1.`, `2.`, `10.`, `11.`, `100.` 순서 확인.

## 5. 빌드 및 보존정책

Windows PC에서 기존 `BUILD_ON_WINDOWS_COMPANY.cmd` 실행. 이미 PASS한 소스 검사를 중복 반복하지 않는 회사 빌드 계약 유지. 공식 산출 예상명 `Sunrise_File_Manager_1.3.4_Setup.exe` (생성·서명·실행 검증 완료를 뜻하지 않음). 기준 ZIP·기존 설치·사용자 데이터는 이번 소스 작업에서 수정하지 않음.

## 6. 알려진 한계

- 실제 Windows 권한이 없는 위치에서 나타나는 `Access to the path is denied`는 이번 변경으로 우회하지 않음. 소스가 임의 상승권한을 얻거나 잠긴 파일을 강제로 조작하지 않음.
- 다른 드라이브 이동은 복사 후 삭제 방식이므로, 삭제 실패·사용자 취소·외부 파일 변경이 일어나면 두 위치에 사본이 존재할 수 있음. 이 경우 수동 확인을 요청하며 프로그램은 자동으로 원본을 삭제하지 않음.
- 같은 이름 덮어쓰기는 기존 사용자 승인 없이 추가하지 않음. 기존 건너뛰기/새 이름 정책 유지.
- Windows 파일 관리자 전체 기능과 100% 동등함을 주장하지 않으며, 본 변경은 요청 범위(이동/복사/잘라내기/정렬)에 한정됨.
