# Sunrise File Manager v1.5.1 인수인계

- 기준일: 2026-10-23 (한국시간)
- 기준 소스: `Sunrise_File_Manager_v1.5.0_R05.zip`
- 기준 SHA256: `d2064543dd3bfd9178b754fa3afc0e2cdd5a96fc2ce3f559eb8c36d51f5baa53`
- 요청: 제품을 1.5.1로 변경.
- 전달 파일: `Sunrise_File_Manager_v1.5.1.zip` (새 버전 최초 전달본).

## 변경

| 항목 | 새 값 |
|---|---|
| 설치 버전 원본 `installer/RELEASE_VERSION.txt` | 1.5.1 |
| 프로젝트 Version | 1.5.1 |
| AssemblyVersion / FileVersion | 1.5.1.0 |
| SunriseControlService.Version | 1.5.1 |
| MainWindow 창 제목 | Sunrise File Manager 1.5.1 |
| 공지 템플릿 | release/NOTICE_BODY_1.5.1.txt |
| 목표 설치파일 | dist/Sunrise_File_Manager_1.5.1_Setup.exe |

버전 공지에는 실제 현재 배포방식에 맞춰 실행환경 포함형 기본 설치와 설치 오류 수정을 기재했다.
기존 1.5.0 공지와 과거 보고서·소스 증적은 이력으로 보존했다.
기존 테스트 중 현재 제품 버전을 검사하던 네 파일의 고정값은 기존 `current_contract.CURRENT_VERSION`을 사용하도록 변경했다. 검증 조건은 유지한다.

R05의 설치 스크립트 `[Code]` 주석 오류 수정은 그대로 포함된다.
앱 런타임 소스 변경은 버전 문자열 세 파일로 한정한다. 탐색·검색·메모·미리보기 동작과 설정 형식은 바꾸지 않는다.
모든 CMD 파일과 설치 스크립트는 R05와 바이트 동일하다. 설치 AppId·서명·기본 self-contained 방식·회사 빌드의 문서 테스트 미실행을 유지한다.

## 업데이트 정보

빌드 스크립트와 릴리즈 메타데이터 생성기는 `installer/RELEASE_VERSION.txt`에서 버전을 읽고 버전별 공지 템플릿을 사용하므로, 정상 Windows 빌드 후 생성되는 Setup 이름과 업데이트 메타데이터도 1.5.1을 사용한다.
소스 안의 기존 원격 게시 스냅샷 `latest.json`, `notice.txt`, `release/PUBLISHED_RELEASE.json`은 변경하지 않았다. 새 Setup의 서명·크기·해시가 확정되기 전에는 게시 완료로 표시하지 않는다.
GitHub·Drive 업로드 또는 원격 공지·Control 수정은 수행하지 않았다.

## 검증 결과

- 버전 영향 관련 테스트 및 R05 주석 재발 검사: 10 tests PASS.
- 기존 패키징 검사: 18 checks PASS.
- 제품·Assembly·File·Control·창 제목·설치·공지 버전 일치 PASS.
- 앱 XAML/CSProj XML 파싱 PASS.
- 런타임 앱 소스에 1.5.0 버전 잔존 없음.
- 앱 세 파일의 변경이 버전 문자열 치환으로만 이루어졌음 확인 PASS.
- 이전 정상 수정 설치 스크립트 및 모든 CMD 바이트 동일 PASS.
- Windows C# 컴파일·Setup 컴파일·서명·설치·실행: PENDING.

현재 환경은 Windows/.NET SDK/Inno Setup 실행환경이 없어 실제 설치파일을 생성하지 않았다.
이전 소스 증적과 `BUILD_TEST_ENVIRONMENT.txt`를 새 버전 실기 PASS로 승계하지 않는다.
검사 경로를 Windows 빌드에 추가하지 않았으며 무관한 전체 기능 검사는 재실행하지 않았다.

## Windows 빌드

1. ZIP을 새 폴더에 압축 해제한다.
2. `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다.
3. 성공 시 `dist/Sunrise_File_Manager_1.5.1_Setup.exe`를 확인한다.
4. 새 Setup의 시작·표시 버전·기존 설치본 업그레이드·설정 보존을 실제 Windows에서 확인한다.
5. 실패 시 `build-logs/R15_INSTALLER_BUILD_RESULT.txt`와 해당 단계 로그로 원인을 확인한다.

기존 사용자 설정·메모·정상 배포본은 삭제하지 않는다.
