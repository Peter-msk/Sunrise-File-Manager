# Sunrise File Manager v1.6.0 R05 — 분할 배치 그림 목록 직접 선택

## 개발 기준과 범위
- 부모 `Sunrise_File_Manager_v1.6.0_R04.zip`, SHA-256 `56d061afee30e8d75f9d1cec8aa7ef9aecba18c7b15bf8bf8e05b0c92fe2f73a`.
- 설치형 Windows x64 / WPF .NET 10 / 제품 버전 1.6.0 유지. 개발 수정 리비전만 R05.
- 작업 대상: 상단 2·3·4분할 버튼의 사용자 선택 흐름, 그림형 배치 메뉴, 기존 WPF UI 검증 입력.
- 자격: **SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING**. Linux 작업환경에서 Windows GUI 컴파일·실행·인스톨러·서명 검증 미수행.

## 요구사항과 구현
1. 상단 `2분할 ▾`/`3분할 ▾`/`4분할 ▾` 클릭 시 현재 화면 배치 즉시 변경 금지. 선택 가능한 레이아웃 목록을 연다.
2. 기존 단일/2/3/4분할 **1/2/6/5 = 총 14개**의 정확한 배치 카탈로그 `WorkspaceSplitLayoutEngine.GetPresetsForCount`만 사용. 유사 배치를 임의로 추가하거나 기존 배치를 삭제하지 않음.
3. 각 선택행에는 기존 `BuildBlueprint`의 실제 행·열·RowSpan·ColumnSpan을 활용해 생성한 **번호가 표시된 축소 배치도**, 정확한 기능 이름 및 설명을 표시. 현재 선택한 레이아웃은 체크 표시. 키보드 접근을 위한 접근성 이름 제공.
4. 메뉴 열기/닫기/다른 위치 클릭은 작업 중인 폴더·파일 선택·탭·메모에 영향 없음. 사용자가 한 배치 선택행을 클릭하면 `ArrangePanels(count, preset)` 경로로만 실제 적용.
5. 이전에 선택한 2/3/4분할별 배치 `_lastPresetByCount`와 `SplitLayoutPreset`, `LastSplitPresets` 세션 계약 유지. `Ctrl+1~4`는 메뉴 표시가 아니라 이전에 사용한 해당 개수의 배치로 즉시 전환.
6. 기존 `설정 · 기능`의 단순 순환 항목을 `현재 분할 배치 선택…`으로 변경. 이전 숨은 `SplitPresetSelector`, `CycleSplitPresetButton`은 테스트/호환 경로로 보존하지만 상시 도구 바 공간을 차지하지 않음.
7. 우측 공용 FileDetailsPanel·FileMemoPanel·FilePreviewPanel 각 1개, Workspace의 오른쪽 열, 하단 상태줄 Row3은 불변. 분할 축소 시 미저장 메모 확인, 활성 파일·분할별 탐색 상태 보존 경로 재사용.
8. 새 런타임 의존성·외부 다운로드·네트워크 처리 없음. 파일 관리·EIASS·AI·휴지통·Control·업데이트·그룹 서명·회사 빌드 CMD 불변.

## 수정 코드 소유권
- `source/Sunrise.FileManager/MainWindow.xaml`: 3개 분할 버튼의 펼침 표시, 정확한 도움말, 설정 메뉴 텍스트 변경.
- `source/Sunrise.FileManager/MainWindow.xaml.cs`: 분할 수 클릭시 갤러리 표시, Ctrl+1~4에서 마지막 배치 직접 선택.
- `source/Sunrise.FileManager/Features/Workspace/MainWindow.SplitLayoutGallery.cs` (신규): ContextMenu 구성, 배치도 출력, 명시적 배치 적용, 접근성/스크롤 정책.
- `source/tests/UiSmokeTests/SplitLayoutGalleryAudit.cs` (신규): 2/3/4 개수별 메뉴, 13개의 다중 배치 직접 적용, 메뉴 열기 전후 작업영역 불변, 우측 공용 패널 불변, 기존 배치 복원 테스트.
- `source/tests/UiSmokeTests/{Program,CurrentUiAudit,FileScrollRegression,NativeUiRegression}.cs`: 과거 '버튼 누르면 즉시 배치 변경' 가정을 선택형 UX로 교체. 네이티브 마우스도 메뉴 선택을 직접 클릭하도록 교체.
- `source/tests/test_v160_r05_split_layout_gallery.py` (신규): 정적 계약 8건.

## 검사 결과와 자격 제한
- 신규 R05 정적 계약 **8/8 PASS**.
- R00~R05 A안 및 상세/메모 관련 집중 검사 **38/38 PASS**.
- WPF XAML XML 구조 **15/15 PASS**.
- 전체 Python unittest: R04 **93건, 12 FAIL + 4 ERROR**, R05 **101건, 같은 12 FAIL + 4 ERROR**; **새 실패·오류 0건**. 기존 실패 16건을 해결한 것으로 취급하지 않음.
- 실제 .NET 10 C# 컴파일, ContextMenu 열림, 14개 실제 WPF 레이아웃/마우스 클릭·UI 100/125/150% DPI, 설치형 Setup/Authenticode: **PENDING**.

### Windows 전용 UI 검증 (기존 회사 빌드에 중복 연결하지 않음)
```powershell
dotnet run --project source/tests/SplitLayoutTests/SplitLayoutTests.csproj
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --split-gallery-only validation/windows-split-gallery-r05
```
예상 UI 증적: 2/3/4분할 선택 메뉴 이미지, 13개 다중 레이아웃 적용 결과, 선택 전후 분할 개수 불변·변경, 기존 마지막 배치 복귀, 우측 공용 패널 3종의 유일한 소유권. 실제 Windows 실행 전 이 항목을 PASS로 표기하지 않음.

### 후속 릴리즈 게이트
`BUILD_ON_WINDOWS_COMPANY.cmd` → `dist/Sunrise_File_Manager_1.6.0_Setup.exe`; 공식 컴파일→화면·DPI→설치·서명 검증 후 별도 승인 필요. GitHub/Drive/원격 latest.json/notice.txt 게시 없음. 구 배포 제품, 사용자 파일, 메모 저장소 변경 없음.
