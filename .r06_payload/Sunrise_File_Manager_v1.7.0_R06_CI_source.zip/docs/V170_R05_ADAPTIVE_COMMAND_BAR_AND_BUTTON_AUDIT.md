# Sunrise File Manager v1.7.0 R05 — A안 상단 경량화·반응형 더보기·버튼 가독성

- 기준: `Sunrise_File_Manager_v1.7.0_R04.zip` SHA-256 `2aed8d7d2a5531e2adbeda5248b6020e99858d62da16e6a6ecdc69da21ead714`. 제품·Control·설치 버전 **1.7.0 유지**.
- 사용자 실행 캡처: `image(20261025-131837).png` (다크 UI, 90% 배율), `image(20261025-131935).png` (라이트 UI). 상단 업무/명령 중복, 작은 명령 버튼 글자, 설정 메뉴의 별도 정렬 문제를 확인한 것을 근거로 수정.
- **검증 상태**: 소스 계약/Python **448 PASS**, XAML XML **15 PASS**, 버튼 마크업 **158개 검사 PASS**. 실제 Windows 빌드·실행·DPI·Preview/Setup/서명 **PENDING**.

## 1. 상단 화면 구성 변경

| 영역 | 이전 R04 | 변경 R05 |
|---|---|---|
| 브랜드 헤더 | 34 DIP / 배율·테마 | 32 DIP / 배율·테마·전역 설정 |
| 업무·분할 | 38 DIP | 36 DIP / 파일 관리·문서·EIASS·AI 정리·압축·도구 문맥선택 / 1~4분할 |
| 문맥 명령줄 | 40 DIP / 일렬 버튼 8개 | 36 DIP / 기본 6개 + `⋯ 더보기`; 폭에 따라 추가 자동 수납 |
| 상단 3영역 합계 | **112 DIP** | **104 DIP** (8 DIP 파일 작업공간으로 반환) |

- `파일 관리`: 새 폴더 / 이름 변경 / 복사 / 붙여넣기 / 삭제 / 검색·필터, 나머지 **잘라내기 / 실행 취소 / 다시 실행**은 `⋯ 더보기`로 이동. 기능 삭제 없음.
- `문서·EIASS`, `AI 정리`, `압축·도구`: 기존 실제 명령 및 처리기를 유지하고, 현재 표시 가능한 너비에 맞춰 오른쪽부터 `⋯ 더보기` 수납.
- 메뉴를 닫고 다른 업무 탭으로 전환해도 파일·메모·선택/탭 상태 불변. 화면 너비가 넓어지면 자동 복원. 숨김 항목의 `IsEnabled`가 원래 명령과 연동되어 작업 안전 경계 유지.
- `MenuItem`은 원본 `ButtonBase.ClickEvent`를 호출하며 FileManager 작업 처리기를 복제하지 않음. `Redo`도 기존 `ExplorerPane.Redo_Click` 사용.
- `단일` 즉시 전환, 2~4분할 기존 13개 드롭다운, 총 14개 프리셋, 삭제된 고정 전송 막대 비복원.

## 2. 버튼 전체 점검 / UI 마감

- 대상: 앱 WPF XAML 15개, `Button/ToggleButton/RepeatButton` **158개**. 파일별 감사표는 `docs/V170_R05_BUTTON_AUDIT.json`.
- 주요 명령: 기본 글자 13 DIP, 쉘 명령 버튼 최소 높이 30 DIP, 쉘 업무 모드 32 DIP, 분할 30 DIP, 원본 우측 아이콘 레일 42 DIP 유지.
- 메모 AI 요약·저장·이력 복원·변경 확인 및 상세정보 용량/해시 버튼 최소 30 DIP. 미리보기 이동·확대 28 DIP. 폴더트리 고정·위치 찾기 28 DIP. 하단 일시중지·취소 28 DIP.
- 부모 `Grid.RowDefinition`이 버튼보다 작으면 텍스트가 잘리는 문제도 보완: 상세정보 헤더 두 행 30/30, 메모 헤더·작업행 30, 미리보기 하단 두 행 28/28.
- 내부 보조 캡션과 파일 데이터 열의 폰트는 별도 성격의 표시 텍스트이므로 일괄 확대하지 않음. 4분할 가용 너비와 툴팁 계약 유지.
- UI 캡처의 다크/라이트 동일 항목 대비를 목표로 공통 스타일만 변경; 렌더링상 픽셀 결과는 실기 검증이 필요함.

## 3. 변경하지 않은 계약

- 1~4분할 총 14개 배치, 공용 상세정보·미리보기·메모 각 하나, 위치 우측 유지. 하단은 진행률·취소 전용.
- `#memo/*.sunmemo`, EIASS·AI·검색·압축·휴지통·Windows 우클릭 Shell 통합, 파일 복사/이동/삭제 및 원본 보호.
- `BUILD_PREVIEW_ON_WINDOWS.cmd`, `BUILD_ON_WINDOWS_COMPANY.cmd`, Control·업데이트 공개 매니페스트·그룹 서명 경로, 설치 스키마와 사용자 세션 호환성 모두 유지.
- R04 부모 보호 코드/빌드 파일 SHA 일치: **6/6**.

## 4. 검증 명령 및 결과

```text
cd source && python -m unittest discover -s tests -p 'test_*.py' -q  => 162 PASS
python -m unittest discover -s tests -p 'test_*.py' -q               => 286 PASS
XAML 구조 XML parsing                                                   => 15 PASS
Button/ToggleButton/RepeatButton 명시 값 감사                             => 158 PASS
```

Windows에서 다음 조건부 시각검증을 수행해야 최종 UI 승인 가능:

```powershell
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --official-a-shell-only validation/windows-v170-r05-a-shell
```

- 1520×930 / 1010×560~650, 앱 배율 80·90·100%, OS DPI 100/125/150%, 라이트/다크 확인.
- 기본 파일관리 6개 명령, 1010 DIP에서 `⋯ 더보기` 내 잘라내기·Undo·Redo, 모드별 명령 실행, 설정·분할 접근, 포커스/키보드 메뉴 및 실제 버튼 텍스트 잘림 확인.
- 공용 우측 3개 컨트롤은 분할 수와 무관하게 각 1개. 미저장 메모 시 선택 전환 안전성 확인.
- Windows .NET 10 SDK·WPF 렌더링·코드서명은 이 Linux 환경에서 실행할 수 없어 **PENDING**. 실행 로그/스크린샷을 만들지 않았으며 완료로 주장하지 않음.

## 5. 산출·릴리즈

- 전달 파일: `Sunrise_File_Manager_v1.7.0_R05.zip` (Windows 설치형 전체 소스). `BUILD_PREVIEW_ON_WINDOWS.cmd`로 설치 전 실행 확인용 Preview 생성 가능.
- 공개 `latest.json`·`notice.txt`, GitHub/Drive, 사용자 설치본 변경 없음. **공식 최종 Setup/PASS 아님.**
