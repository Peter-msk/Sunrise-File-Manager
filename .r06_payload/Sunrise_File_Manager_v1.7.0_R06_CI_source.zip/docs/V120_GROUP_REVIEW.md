# Sunrise File Manager 1.2.0 — 그룹 정책 비교·코드 보완 결과

작성일: 2026-10-21(KST) · 판정: **SOURCE_VALIDATED / WINDOWS_RELEASE_PENDING**

## 전달 범위와 기준

사용자가 지정한 1.1.0 R23 전체 소스에서 1.2.0으로 개발하였다. Sunrise Group 공식 프로그램 지정에 따라 첨부 전용 코드개발 v1.3, 범용 코드작성 v1.3, 그룹 v2.8 및 해당 모듈의 우선순위를 적용하였다. 다른 제품·중앙 저장소·원격 운영정책은 변경하지 않았다.

입력 ZIP SHA256: `cdcc00b97388ef4b90a22ad52c616c36bdc0710964e63316e9fd0484f131a765`

원본 ZIP에 포함된 281개 파일의 기존 해시·크기를 대조하여 전부 일치함을 확인하였다. 원본은 보존하고 새 버전 소스를 별도로 생성하였다. 검토 범위는 런타임 C# 64개 파일(12,096줄), XAML 13개, 빌드·설치·배포정보 생성 코드와 관련 시험이다. 전체 컴파일·위험 패턴 검색·호출 관계 검토를 수행하고, 업데이트·공지·Control·파일 보존·작업 종료 경계를 집중 보완하였다. 모든 기능의 Windows 실사용 검증을 완료했다는 의미는 아니다.

## 오류 원인의 구분

| 구분 | 확인 내용 | 1.2.0 처리 |
|---|---|---|
| 다운로드 파일 잠금 | R23의 직접 원인은 다운로드 writer를 열어 둔 상태에서 임시파일을 이동한 것임 | writer 해제 → 크기·해시 확인 → 이동 순서 유지 및 실행 시험 |
| 실행 중 설치 경합 | 기존 UI는 Setup 실행 요청 후 앱 Shutdown을 요청함 | 정상 Closing 승인 → OnExit의 외부 대기 작업 → 현재 PID 종료 확인 → Setup 실행 |
| 공개 배포 경로 | 관측 feed는 1.1.0을 가리키나 해당 태그와 Setup 주소가 404 | 소스 결함과 별도 배포 차단사항으로 기록. 1.2.0 배포정보 활성화 유보 |

## 그룹 기본정책과 변경 결과

| 검토 영역 | 기존 상태·문제 | 반영 결과 |
|---|---|---|
| 공식 제품 식별 | 기존 제품 ID·Control ID·설치 AppId 운영 중 | 기존 값·실행파일명·사용자 데이터 경로 유지. 제품 버전 1.2.0 정합화 |
| 배포 형식 | 공식 installer, 내부 self-contained WPF payload | installer 유지. 자체 EXE/DLL 부분교체·별도 rollback 체계 추가하지 않음 |
| 업데이트 발견 | 일반 시작 시 제품 최신정보 자동 조회가 없음 | 파일 창 복원 전에 최신정보·공지 독립 조회. 새 버전 또는 최소 버전 미충족 시 업데이트/종료 창 |
| 중앙 Control | schema v1, 캐시·fallback 구현 | 현재 원격 schema v1/revision 2와 대조. 조회·다운로드 전·설치 이관 전 정책 재확인 |
| 정책 우선순위 | 다운로드 시 처음 열었던 정책을 계속 사용 | update=block 우선. operation=maintenance/block은 진입 제한. 최소 버전 미달 후보 설치 금지 |
| 통신 실패 | 응답 헤더 이후 본문 읽기에는 명시적 전체 제한 부족 | Control 5초, 제품 metadata 8초, 다운로드 30분의 전체 취소 토큰 적용 |
| 캐시 | 일부 예외가 유효 캐시 사용 전에 상위 fallback으로 빠질 수 있음 | InvalidDataException 등 오류 분류 보완. 온라인 → 유효 TTL 캐시 → global fallback 실행 시험 |
| 업데이트 수명주기 | 닫힌 창의 비동기 작업이 나중에 계속될 수 있음 | 창 종료 시 취소, 이후 UI/설치 이관 억제, 다운로드 중복 실행 보호 |
| 다운로드 staging | 공통 파일명에 작업 중첩 가능 | 작업별 GUID 폴더·임시파일 소유권 분리, 실패·취소 후보 정리 |
| 공지사항 | 수동 창에서 조회, 반복 표시 상태 없음 | 제품 평문 notice.txt 유지, 표시한 본문 SHA256 하나로 중복 방지 |
| 종료·설치 | Shutdown이 정상 창 닫기 검사를 우회할 수 있음 | 메모 확인·진행 중 작업 취소/완료·세션 저장을 거친 정상 Close 경로 사용 |
| 설치 후 실행 | 기존 설치 실행 후 재실행 연결 부족 | 업데이트 승인 경로는 Setup의 설치 완료 단계에서 실행. 수동 설치의 실행 선택 유지 |
| 파일 실행 취소 | 휴지통 실패를 영구 삭제로 전환 | 해당 fallback 제거. 실패 시 파일 보존 |
| 새 파일 | 존재 확인 후 WriteAllText 사이의 덮어쓰기 가능성 | FileMode.CreateNew로 기존 파일 보호 |
| ZIP 해제 | 중간 실패 시 결과 폴더가 노출됨, 용량 상한 부족 | 경로·중복·연결·예약명 확인, 20,000항목/8GiB 한도, staging 완료 후 폴더 공개 |
| ZIP 압축·사본 | UI 스레드 작업, 사본 부분파일 노출 가능 | 작업 스레드·취소 연결. 사본도 staging 후 공개. 수정시간·속성 보존 |
| 불완전한 폴더 통계 | 일부 접근 실패를 완전한 통계처럼 표시 가능 | 제한/불완전 상태 표시 |
| UI/모델 분리 | FileEntry가 WPF ThemeManager에 직접 의존하여 LogicTests 컴파일 실패 | 화면 계층이 테마 상태를 전달. 기존 색상 값과 화면 구조 유지 |
| 릴리스 설명 | 신규 버전의 설명이 최초 출시 문구로 되돌아갈 수 있음 | 버전별 공지 본문을 설명의 기준으로 사용 |
| Windows 빌드 | 기존 단일 CMD 및 사전 검사 생략 운영 | 기존 방식 유지. 소스 시험은 Windows 회사 빌드에 추가하지 않음 |

제품 현행 계약은 `docs/FILE_MANAGER_CURRENT_CONTRACT.md`에 고정하였다. 보완을 위해 기존 정상 탐색·분할·미리보기·메모·AI 화면을 재설계하지 않았다. UI 모델의 테마 입력과 ZIP/사본 작업 경계에 필요한 변경만 수행하였다.

## 업데이트 순서와 실패 처리

1. 중앙 정책과 제품 배포정보를 확인한다.
2. 사용자가 업데이트를 승인하면 설치파일을 다운로드·검증한다.
3. 메모와 진행 중인 작업을 확인한다. 취소 가능한 파일/AI 작업에는 취소를 요청하고, 안전한 종료가 확인되기 전에는 설치를 이관하지 않는다. 휴지통 작업은 완료를 기다린다.
4. 정상 Close가 승인되면 세션·worker·미리보기 정리를 거쳐 OnExit에서 대기 작업을 시작한다.
5. 앱 폴더 밖의 로컬 고정 CMD가 현재 PID 종료를 최대 90회 확인한다. 조회·대기 실패나 시간 초과 시 Setup을 실행하지 않는다. 강제 프로세스 종료는 하지 않는다.
6. PID가 종료된 뒤 검증된 Setup을 실행한다. 파일 교체·설치 복구는 Inno Setup이 담당한다.
7. 설치 완료 경로에서 새 프로그램을 실행한다. 설치 취소·실패 결과는 다음 정상 실행 시 안내한다. 생성한 설치 후보와 일회성 보조파일을 정리한다.

새 버전이 확인된 창은 단순 닫기와 X 모두 종료 경로로 연결된다. 진행 중인 작업 때문에 즉시 닫을 수 없으면 작업 취소·완료 후 다시 선택해야 하며, 파일 작업 중 강제 종료로 원본을 위험하게 만들지 않는다. 제품 조회 장애만으로 정상 실행을 차단하지 않는 그룹 fallback 정책은 유지한다.

## 실행 검증 결과

최종 결과는 `validation/PRE_BUILD_RESULT.json`과 `validation/logs/`가 소유한다. 시험 입력 173개 경로의 SHA256을 기록했고 시험 중 입력이 바뀌지 않았음을 확인하였다.

| Gate | 결과 | 범위 |
|---|---|---|
| Python 계약·회귀 | PASS, 161개 | 제품·버전·빌드·업데이트 및 기존 구조 계약 |
| 패키징 계약 | PASS, 15개 | 단일 공식 빌드 경로, 배포 구성 등 소스 수준 |
| UI 소스 계약 | PASS, 19개 | XAML 연결·기존 스타일·미리보기 구조 |
| 업데이트 실행 시험 | PASS, 33개 | 실제 C# parser, 캐시·fallback, transport stub, 해시/크기 실패, redirect, 중복·취소 |
| 이식 가능한 로직 | PASS, 304개 assertion | 파일 보존·ZIP·사본·세션·AI 계획/복구/검사 등의 해당 환경 시험 |
| WPF C#/XAML | PASS, 경고 0·오류 0 | .NET 10.0.100 Linux에서 Windows 대상 교차 컴파일 |
| 배포정보 생성기 | PASS, 경고 0·오류 0 | DLL 전용 생성기 컴파일 |

불일치하는 과거 literal 검사는 현행 버전·제품 feed 스냅샷·모델/화면 책임 분리에 맞춰 수정하였다. 예를 들어 고정 700px 미리보기 확대 검사는 이미 존재하던 실제 페이지 폭 기반 확대 계약으로 정합화하였다. 확대 코드 자체는 바꾸지 않았다. 과거 `validate_p182.py` 및 `source/tests/verify_source.py`의 unversioned Open Source 계약은 역사 자료로 보존하고 현재 공식 installer Gate로 사용하지 않는다.

Linux 기본 LogicTests의 Windows DPAPI 의존 시험 실패를 숨기기 위해 제품 메모 검증을 약화하지 않았다. 명시적 `--portable` 프로필은 FileMemoTests 및 메모 이동·이름 변경/Windows shell을 포함한 3개 suite를 PENDING으로 표시한다. 나머지 실제 assertion을 실행하였다. 이 제외분은 Windows에서 실행해야 한다.

## 공개 배포 경로의 현재 상태

2026-10-21 관측 결과:

| 대상 | 결과 |
|---|---|
| 중앙 `control.txt` | HTTP 200, schema_version=1, control_revision=2, File Manager 등록 |
| 제품 `latest.json` | HTTP 200, latest_version=1.1.0 |
| 제품 `notice.txt` | HTTP 200, 1.1.0 공지 |
| `releases/tag/v1.1.0` / 해당 release API | 404 |
| `Sunrise_File_Manager_1.1.0_Setup.exe` | 404 |
| 익명 공개 releases/latest | v1.0.0; 자산 크기 51,249,800 bytes, digest d1e496c6f6989912e181ddbe4923c5b0f672cefbe4927287503de48a3bb0548a |

현재 feed가 공지하는 1.1.0 자산은 크기 51,469,576 bytes, digest e4cb0a8367bbbba3abb84b7705d2046eeaafc87d775f08531ed622fbbac5be47이다. 이는 관측된 metadata 값이며 실제 1.1.0 Setup을 내려받아 확인한 값이 아니다. 또한 R23 ZIP의 과거 1.0.0 스냅샷(51,251,864 bytes)도 현재 공개 1.0.0 자산 정보와 다르므로 재사용하면 안 된다.

- 중앙 정책: https://github.com/Peter-msk/Sunrise_Control/blob/main/control.txt
- 제품 배포정보: https://github.com/Peter-msk/Sunrise-File-Manager/blob/main/latest.json
- 공개 릴리스: https://github.com/Peter-msk/Sunrise-File-Manager/releases

루트 metadata는 실제 관측한 1.1.0 내용으로 정리했지만 1.2.0 URL이나 해시를 만들지 않았다. 로컬 PUBLISHED_RELEASE 기록은 `UPSTREAM_FEED_TARGET_UNAVAILABLE`로 구분하였다. 생성기는 `PUBLISHED_ASSET_VERIFIED` 상태와 버전·자산명·해시·크기·URL이 모두 맞아야 활성화된 배포정보를 생성한다. 네트워크 공개 검증은 소스 PASS와 분리하여 **배포 미승인**으로 남긴다.

## Windows에서 남은 확인

- `BUILD_ON_WINDOWS_COMPANY.cmd`로 실제 Windows self-contained payload와 Setup 생성·서명.
- 최종 EXE 시작, 기존 세션·탭·메모 복원 및 100/125/150% DPI 확인.
- 업데이트 창의 X·닫기, 다운로드 중 닫기, 메모 저장 취소, 작업 진행 중 종료 요청.
- 한글·공백·특수문자 사용자 경로에서 PID 종료 대기 후 Setup 실행. 취소·실패·정상 설치·재실행.
- 기존 설치 → 1.2.0 업그레이드·재설치·제거 및 사용자 설정/메모 보존.
- Windows 전용 DPAPI 메모·메모 이동·AI 연계·휴지통·shell 시험.
- ZIP·사본 worker 취소 시 화면 복원, 완료된 결과 보존, 임시파일 정리.
- 새 Setup 게시 후 실제 익명 다운로드의 URL·크기·SHA256을 확인하고 그 결과로 제품 최신정보·공지를 게시.

이 항목들은 **PENDING**이다. Windows용 교차 컴파일과 source 시험을 실제 Windows 설치 성공이나 정식 배포 완료로 승격하지 않았다.

## 사용 방법과 검증 재사용

압축 해제 후 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다. 기대 산출물은 `dist/Sunrise_File_Manager_1.2.0_Setup.exe`이다. 현재 전달 ZIP에 완성 Setup이 들어 있는 것은 아니다.

사전 소스 시험은 현재 체크포인트 입력이 바뀌지 않으면 REUSED_PASS로 승계한다. Windows 빌드는 이를 반복하지 않고 실제 컴파일·서명·설치/실행 확인에 집중한다. 소스가 변경되면 영향받은 최소 Gate를 무효화한다. 재현용 소스 검사 진입점은 다음과 같다.

```text
python validation/run_pre_build.py --dotnet <dotnet 실행파일 경로>
```

이 진입점은 개발 검토용이며 회사 빌드에서 자동 호출하지 않는다. 새 네트워크 credential, OpenAI API key 또는 Ollama 모델 다운로드가 필요하지 않다.
