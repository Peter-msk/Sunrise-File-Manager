# Sunrise File Manager v1.7.0 R01 — A안 UI 실기 스크린샷 기반 보완·인수인계

## 1. 작업 기준 및 목적
- 기준: `Sunrise_File_Manager_v1.7.0_R00.zip`; SHA-256 `3e1c6d7ba7c4d315e3b6232a24d36d5b10a226a92e99659e8de5b69e9da818b3`.
- 제품 버전 `1.7.0` / Assembly `1.7.0.0` 불변, 수정 리비전 **R01**.
- 사용자 실제 실행 캡처 5장을 근거로 작업. 디자인 기준은 이전에 공식 채택한 **A안: 다중 파일 관리 중심형**.
- 이번 변경은 설치 전 Preview 및 회사 서명/Setup 생산 경로를 변경하지 않음. 전체 소스 수정본이며 **Windows 실행 EXE 자체는 포함하지 않음**.

## 2. 확인한 문제와 수정 결과

| 실제 화면 문제 | 소스 원인 | R01 수정 | 검증 |
|---|---|---|---|
| 삭제된 '분할창 간 전송' 도구와 전송 도구 버튼이 다시 나타남 | `MainWindow.xaml`의 고정 두 번째 행 `TransferToolbar` 및 2~4분할 자동 표시가 그대로 남음 | 전송바/버튼/고정 행/콜리전 ComboBox 및 해당 UI 전용 이벤트 제거. 메인 파일 목록 공간 반환. 파일 목록 드래그·붙여넣기·전송 엔진 유지, 창 맞바꾸기와 폴더 동기화는 '설정 · 기능' 메뉴에서 호출 | 소스 계약 PASS; Windows 실행 PENDING |
| 단일 선택이 하나뿐인데 목록을 표시 | `One_Click`이 1분할 갤러리 열기 | 단일 클릭 즉시 `ApplyLastLayoutForCount(1)`; 열려 있는 다른 배치 메뉴 먼저 닫기 | 소스 계약 PASS; 실기 PENDING |
| 2·3·4분할 항목이 장황하며 기호/이름/설명이 반복 | ShortLabel + 중복 Description 두 줄, 52 DIP 행 | **56×32 DIP 축소도 + 짧은 한글 배치명 1줄**; 행 최소 44 DIP. 상세 설명·스크롤 정보는 툴팁과 접근성 이름에만 유지. 기존 2+6+5 선택과 현행 14개 배치 엔진 불변 | 소스 계약 PASS; 실기 PENDING |
| 오른쪽 버튼 글자 위주로 좁고 복잡 | `Rail*Button.Content` 긴 문자열과 68 DIP 레일 | 상세·메모·미리보기·AI·복구·한개씩·작업집중 **각 벡터 아이콘 버튼**. 레일 54 DIP, 텍스트 대신 한국어 ToolTip 및 AutomationProperties.Name 유지 | 7개 아이콘/이벤트/패널 수 계약 PASS; 실기 PENDING |
| A안 공식 스타일 부족 | 우측 rail과 폴더 tree가 같은 색 토큰을 사용 | 우측 레일만 남색/청록 계열 `ThemeUtilityRail*` 색상과 hover/focus/disabled 컴포넌트 스타일. 기존 폴더 트리·테마 토큰 분리 유지, 상단 헤더 밀도 조정 | XAML·정적 테마 계약 PASS; 실기 PENDING |

### 독립성·사용 안전
- 1~4분할 작업공간은 파일 탐색만 각각 독립 소유. 오른쪽 `FileDetailsPanel`, `FileMemoPanel`, `FilePreviewPanel`은 각각 **단 한 개**.
- 현재 활성 분할창의 선택 파일에 연동하고, 미저장 메모 확인, 상태/선택/탭 복원, 기존 앱 배율과 최소 트랙 계약은 유지.
- 삭제한 TransferToolbar의 `TransferSourceIndex`, `TransferDestinationIndex`, `TransferCollisionIndex`, `TransferBarExpanded` 사용자 설정 필드를 현행 `AppSession` 모델에서 제거. 구형 JSON에 남은 추가 필드는 현행 기본 `System.Text.Json` 역직렬화가 무시하며, 현행 필수 표시/분할/메모 값은 계속 이전.
- 실제 복사·이동 기능은 `ExplorerPane`의 드래그·복사/붙여넣기와 공통 `RunTransferAsync`에서 계속 동작. 불필요한 **항상 표시되는 전송 UI만 폐기**.
- 분할창 맞바꾸기는 활성 창↔다음 창, 동기화는 활성 창의 현재 폴더를 대상으로 수행하며 메뉴에서만 접근. 기존 작업·메모 안전확인 경로를 재사용.
- 사용자에게 전달되는 Preview에는 소스/테스트가 포함되지 않으며 원본 빌드 계약 유지.

## 3. 변경 파일 및 게이트
- UI 본체: `source/Sunrise.FileManager/MainWindow.xaml`, `.xaml.cs`, `Features/Workspace/MainWindow.SplitLayoutGallery.cs` 및 `MainWindow.PanelCoordination.cs`.
- 테마 및 세션: `Services/ThemeManager.cs`, `App.xaml`, `Services/SessionStore.cs`, `Features/Workspace/MainWindow.Preferences.cs`, `.MultiWindow.cs`.
- 회귀 검사: v1.6 계열 현행 UI 소스 검사, Windows 네이티브 게이트 `SplitLayoutGalleryAudit.cs`, `NativeUiRegression.cs`, `CurrentUiAudit.cs`, 저장 설정 C# 로직 검사, 신규 `source/tests/test_v170_r01_official_a_ui.py`.
- 릴리즈 문서: `README.md`, `CURRENT_SOURCE.md`, `RELEASE_STATUS.json`, `FULL_SOURCE_SHA256_MANIFEST.json`, `docs/V170_R01_OFFICIAL_A_UI_RECONCILIATION.md`.

### 수행한 검사
| 검사 | 결과 |
|---|---|
| Python source/tests 전체 | 127/127 PASS |
| Python tests 전체 | 286/286 PASS |
| **합계** | **413/413 PASS, 실패 0·오류 0** |
| 신규 R01 화면 계약 | 10/10 PASS (위 소스 검사에 포함) |
| XAML XML 구조 | 15/15 PASS |
| MainWindow XAML Click 이벤트 대상 존재 | 25개, 미연결 0 |
| 원본 중요 빌드·업데이트·메모·전송 소스 보존 | SHA-256/바이트 동일 |
| Windows WPF .NET 10 컴파일, 실제 UI DPI 및 Preview 실행 | **PENDING** |
| Authenticode 그룹서명·Setup 설치·업데이트 | **PENDING** |

**주의:** 정적 회귀와 XML 파싱은 `PresentationFramework` 런타임의 실제 컴파일, UI 렌더링, 클릭·DPI 검증을 대체하지 않음. 새 Setup이나 EXE를 여기서 만들었다고 주장하지 않음.

## 4. 실제 Windows Preview 검수 순서
1. 회사 Windows PC에서 `BUILD_PREVIEW_ON_WINDOWS.cmd` → 출력 폴더 `dist/Sunrise_File_Manager_1.7.0_Preview/`의 실행파일을 설치 없이 실행.
2. 1~4분할 전체로 전환해 **전송 고정 줄이 나타나지 않고**, 중앙 파일 목록이 그 면적을 사용함을 확인.
3. `단일` 클릭 즉시 1분할, `2분할 ▾`/`3분할 ▾`/`4분할 ▾`는 버튼 아래 각각 2/6/5개 단일행 목록 표시, 클릭 전 배치 불변·선택 후 배치 전환 확인.
4. 오른쪽 7개 기능 벡터 아이콘 표시·호버 한국어 툴팁·선택색·Tab/키보드 포커스, 공용 패널 각각 1개, 파일 선택 연동 확인.
5. 1010×560 DIP 및 1520×930 DIP, DPI 100%·125%·150%, 앱 배율 60~125%, 라이트/다크에서 글자/버튼 겹침·경계·스크롤 확인.
6. 두 분할 간 파일 이동·복사(드래그와 복사/붙여넣기), 설정 메뉴의 창 맞바꾸기/폴더 동기화, 메모 미저장 취소, 분할 중 작업 차단 확인.
7. Windows 실제 컴파일/실기/서명 PASS 뒤에만 회사 `BUILD_ON_WINDOWS_COMPANY.cmd`로 설치형 확정.

## 5. 배포 및 인수인계
- 이 ZIP은 전체 소스. **Preview EXE·Setup EXE는 이 환경에서 만들지 않았음**.
- 기존 `latest.json`/`notice.txt` 및 GitHub/Drive/공식 배포 경로 갱신 없음.
- 회사 코드서명·Sunrise Control·업데이트·공지·설치 빌드 원본 보존.
- 부모 R00 보존, 제품 버전 **1.7.0** 유지. UI 리비전만 R01.
