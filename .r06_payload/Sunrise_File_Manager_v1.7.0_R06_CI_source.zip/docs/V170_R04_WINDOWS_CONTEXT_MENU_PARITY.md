# Sunrise File Manager v1.7.0 R04 — Windows 기본 우클릭 메뉴 보완

## 기준 및 결과
- 직접 부모: `Sunrise_File_Manager_v1.7.0_R03.zip` / SHA-256 `9e8cf358c3b7856fbe87db4dd9dbb39b29127dc2a21af5f40a7d3f9f2bd039c4`
- Windows x64 설치형 `.NET 10 WPF`, 제품/Control/설치 버전 **1.7.0 불변**. 기존 공식 A안 화면, 14가지 분할 배치, 메모·상세·미리보기 공용 각 1개 유지.
- 상태: **SOURCE_CONTRACT_PASS / WINDOWS_SHELL_NATIVE_PENDING**. Windows COM·실제 우클릭·Preview·설치 실행 검증을 수행하지 않았으므로 공식 런타임 PASS 아님.

## 확인한 누락 원인
`ExplorerPane.xaml` 파일목록의 일반 우클릭 ContextMenu에서 원래 있던 잘라내기·복사·붙여넣기·이름 바꾸기·삭제·실행 취소·다시 실행을 과거 간결 UI로 만들며 직접 명령에서 제외했음. `RELEASE_STATUS.json`에도 `basic_commands=REMOVED`로 기록됨. 해당 기능 엔진과 상단 Edit 메뉴/단축키는 계속 존재했으므로 복구는 기존 핸들러를 **그대로 재사용**함.

## R04 문맥별 기능 표

| 대상 | 1차 우클릭 메뉴 | 고급/주의 |
|---|---|---|
| 일반 단일 파일 | 열기, 연결 프로그램, 잘라내기, 복사, 이름 변경, 삭제, Sunrise EIASS/AI, 파일 작업, Windows 공유/확장 메뉴, 속성 | EIASS는 PDF일 때만 활성. 연결 프로그램은 단일 파일 한정. 영구 삭제는 파일 작업 하위에 유지. |
| 일반 단일 폴더 | 열기, 새 탭에서 열기, 잘라내기, 복사, 폴더 안에 붙여넣기, 이름 변경, 삭제, 파일 작업, Windows 확장 메뉴, 속성 | 폴더 안 붙여넣기는 선택한 폴더가 실제 대상. |
| 다중 선택 | 잘라내기, 복사, 삭제 및 안전한 일괄 작업, Windows 메뉴, 다중 선택 속성 | 선택되지 않은 항목을 새로 우클릭하면 오래된 페이지 선택도 지우고 해당 항목만 선택. 서로 다른 상위 폴더의 항목은 네이티브 확장·다중 속성 사용 제한. |
| 파일 목록 빈 공간 | 붙여넣기, 바로가기 붙여넣기, 새로 만들기(폴더·빈 파일·Windows 등록 문서), 정렬, 그룹, 보기, Undo/Redo, 새로 고침, 모두 선택, 탐색기에서 열기, 현재 폴더 속성 | 이전 파일 선택을 해제해 의도치 않은 삭제·이름변경을 예방. 파일 선택용 명령과 불필요한 구분선은 숨김. |
| 내 PC 드라이브 목록 | 드라이브 열기, Windows 확장 메뉴, 속성, 새로 고침 | 드라이브 선택 시만 확장/속성 활성. |
| 가상 휴지통 | 원래 위치로 복원, 선택 항목 일괄 영구 삭제, 전체 복원/비우기, 속성, Windows 휴지통에서 열기 | 가상 경로를 일반 파일 복사·삭제·클립보드 작업으로 넘기지 않음. |

## 소유권 및 안전 계약
1. `ExplorerPane.xaml`의 메뉴 정의 + `Features/Explorer/ExplorerPane.WindowsContextMenu.cs`의 문맥 표시/활성화/정렬/붙여넣기 처리를 구분. Windows 메뉴는 별도 `WindowsShellContextMenu`로 위임하고 Windows 11 최신 압축 메뉴와 완전 동일함을 주장하지 않음.
2. `ExplorerPane.ClipboardAndDragDrop.cs`: 기존 붙여넣기 엔진에 **선택 폴더 경로를 인수로 지정**할 수 있도록만 확장. 기존 복사·이동 충돌 정책, 같은 폴더 복제, 사용자 확인, 복구 이력, 선택 상한을 유지.
3. `ExplorerPane.xaml.cs`: 우클릭 대상 행이 기존 다중 선택 중이면 선택을 유지하고, 새 행/빈 공간이면 오래된 페이지 전체 선택을 지워 안전하게 메뉴 대상 설정.
4. `ExplorerPane.ShellNew.cs`: 메인 메뉴와 빈 공간 우클릭의 Windows 문서 템플릿을 동일한 `ShellNewTemplateService`에서 조회. 새 의존성 또는 임의 템플릿 실행 없음.
5. 여러 파일 선택의 속성은 첫 파일만의 속성을 보여주지 않도록 Windows IContextMenu의 `properties` 정식 동사에 위임. 해당 네이티브 COM 실행은 Windows에서 반드시 검증.
6. Windows 확장 메뉴는 선택 항목이 같은 폴더에 있는 실제 파일이고 최대 1000개일 때만 활성. 미지원한 OS 동사를 자체 구현 완료라고 표기하지 않음. OS별 설치된 서드파티 메뉴는 PC 환경에 따라 다름.
7. Sunrise 전용 EIASS·AI 우클릭 진입은 R03처럼 **상위 메뉴에 직접 유지**. 압축·메모·상세정보·미리보기·목록/경로·클라우드 기능은 하위 메뉴로 보존.
8. `ConfigureRecycleBinView()`로 관리되는 휴지통과 내 PC는 일반 우클릭 메뉴를 사용하지 않으므로 휴지통 위험 작업이 일반 경로로 섞이지 않음.

## 소스 및 검증 위치
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`, `.xaml.cs`
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.WindowsContextMenu.cs` (신규)
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs`, `ExplorerPane.ShellNew.cs`, `ExplorerPane.WindowsIntegration.cs`, `ExplorerPane.RecycleBin.cs`
- `source/Sunrise.FileManager/Services/WindowsShellContextMenu.cs` (다중 선택 Windows 속성)
- `source/tests/test_v170_r04_windows_context_menu.py`, `source/tests/UiSmokeTests/ContextMenuAudit.cs`

### 사전 검증
- Python 소스: **152/152 PASS**; 루트 제품/빌드: **286/286 PASS**; 합계 **438/438 PASS**.
- WPF XAML 15개: XML 구조 **PASS** (C# WPF 실제 컴파일이 아님).
- 전체 소스 SHA-256 manifest 및 ZIP 무결성 검사: **PASS**.
- 미변경 확인: 메모 저장소·휴지통 삭제 엔진·AI/EIASS 엔진·Sunrise Control·회사 빌드·Preview 빌드 계약은 수정하지 않음.

### Windows에서 별도 검증해야 할 내용
1. `BUILD_PREVIEW_ON_WINDOWS.cmd`로 서명된 설치 전 Preview 생성/실행 및 C# 컴파일. 실패 시 직접 코드 수정 필요.
2. 파일 단일/다중/폴더/빈 공간을 실제 마우스로 우클릭하여 메뉴 표시·클릭·비활성화 및 DPI 100/125/150%, 라이트/다크 확인. 파일명·한글·공백 경로·권한 오류 포함.
3. **테스트용 폴더**에서 복사·잘라내기·폴더 대상 붙여넣기·Undo/Redo·휴지통 이동/복원·빈 공간 새 파일 만들기 수행; 실제 업무 파일로 파괴적 명령 시험 금지.
4. 같은 폴더의 여러 파일 선택 → `속성`에서 Windows 실제 다중 속성 창 확인. 일부 Shell 확장 제공자의 동사 미지원/다른 폴더 선택은 안전하게 실패하는지 확인.
5. `dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --context-menu-only validation/windows-context-menu-r04` (해당 테스트가 지원하는 기존 실행 인자 확인 필요).
6. 기존 1~4분할 공용 패널 및 14개 배치, 사용자 메모·세션 보존, 설치형 Setup/그룹서명/공지·업데이트 계약 확인.

## 배포 범위
**개발 소스 후보만 생성.** 현재 공식 게시 피드, GitHub, Google Drive, 그룹서명·인증서, 사용자 설치본은 수정하지 않음.
