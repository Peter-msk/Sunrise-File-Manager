# Sunrise File Manager 1.3.3 R00 — 코드 재감사·포니테일 경량화

## 1. 기준 및 허용 변경

- 부모 기준본: `Sunrise_File_Manager_v1.3.3.zip` (SHA256 `1e892ac5615d3b23bd6fffb718aecc39ae60334b9a3834cddda00ac3b3152cd8`).
- 소스/설치 표시 버전: **1.3.3 유지**. R00은 배포 전 소스·빌드 최적화 전달 리비전이며 제품 릴리즈 승격을 의미하지 않음.
- 원본 ZIP 및 현재 사용자의 프로그램·설정·문서 파일은 수정/삭제하지 않음.
- 포니테일 규칙: 재사용 우선 → 소유 모듈의 문제 재현 → 근본 원인에서 변경 → 최소 영향 → 관련 기능 및 무관 대표 경로 회귀.
- 사용자-facing README에 보안·정책 구현 상세를 추가하지 않음.

## 2. 감사 범위 및 실제 점검

| 검사 범위 | 검토 내용 | 결과/잔여 검증 |
|---|---|---|
| 소스 구조 | WPF/.NET 프로젝트, 77개 C# 파일, 핵심 UI·서비스·기능별 로컬 책임 분리 | 소스 구성 확인, .NET 실컴파일 대기 |
| 파일·폴더 조작 | 전송 staging, 원본 보호, 충돌 건너뜀, 취소, ZIP 생성/해제, 경로·접합점 제한 | ZIP 생성 입력 중복 경로 문제 1건 보완 |
| 세션·UI | 4분할, 탐색레일, 테마, 메모/미리보기, 1.3.3 종료 설정패치 | 변경하지 않음, 실제 Windows 재검증 필요 |
| AI·온보딩 | Ollama 선택기능 경계, AI 계획/미리보기·사용자 승인 | 주요 정적 연결 확인, 현장 실행 검증 대기 |
| 빌드·배포 | 공식 CMD → self-contained WPF publish → 서명 → Inno Setup/설치 → 제품별 릴리스 메타데이터 | 진단 PDB 설치 제외, 기존 의존성과 배포 형식 유지 |
| 버전·추적 | 코드, 릴리스 설정, README, 무결성 manifest 및 지난 검증 기록 | v1.3.2 오래된 source manifest와 README 버전을 정정; 과거 증적 불승계 |
| 회귀 | 현행 Python 검증, 패키징, XAML XML/소스구조, 이전의 독립 소스 테스트 | 현행 PASS; Windows 런타임/PDF/Ollama·실제 설치는 대기 |

### 레거시 테스트 분리

`python -m unittest discover -s source/tests -p 'test_*.py'`의 59개 과거 검사에는 **실패 5개·오류 2개**가 남아 있다. 소스 레이아웃 이전 위치, 지금 폐기된 ONEFILE 및 `BUILD_DEV_FULL_SOURCE.cmd` 존재, 과거의 무버전 csproj, WPF UI의 구식 속성 literal을 요구하는 역사 테스트다. 이들을 가짜 PASS로 바꾸거나 삭제하지 않았으며 현행 릴리스의 활동성 Gate는 `tests/` 및 `source/tests/test_ui_contract.py`로 구분한다. R03 기존 `AiViewport` 레이아웃 주장의 타당성을 실제 Windows 화면으로 확인하기 전까지 UI 자체 무결성 PASS로 해석하지 않는다.

### 발견 결함 및 해결

- **ZIP 생성 중복 이름·중첩 선택**: 동일 이름의 파일·폴더 두 개, 같은 파일 중복 선택 또는 상위 폴더와 하위 항목을 함께 선택하면 추후 내부 ZIP 해제 검증에서 거부되는 항목 구성이 생길 수 있었음. 압축 시작 **전에** 검사·거부하도록 기존 ZIP 생성 Local Owner만 수정. 미승인 저장·덮어쓰기나 파일 삭제 없음.
- **1.3.2 잔존 manifest/README**: v1.3.3 전달 기준본에도 `FULL_SOURCE_SHA256_MANIFEST.json`과 README/RELEASE_STATUS에 v1.3.2 항목이 남아 있었음. 새 R00 소스 기준으로 재생성·동기화. 과거 `validation/PRE_BUILD_RESULT.json`은 역사 자료로 보존하고 현재 PASS로 승계하지 않음.
- **배포물 불필요 심볼**: self-contained WPF `dotnet publish`가 릴리스 디버그 기호를 포함할 수 있어, Release 출력 `DebugSymbols=false`, `DebugType=none`을 명시하고 staging 앱 내부에 남은 `.pdb`만 제거. `bin/obj/원본/테스트/라이선스/메모`는 cleanup 대상으로 취급하지 않음.

## 3. 설치 용량 — 무엇을 줄이고 무엇을 보존했는가

- 관찰 기준: 사용자가 보고한 **설치 후 약 175MB**(이 환경에 사용자 설치 폴더 또는 최종 Setup EXE는 제공되지 않았으므로 별도 실측은 불가).
- `--self-contained true`, `net10.0-windows10.0.19041.0`, WPF, win-x64, PdfPig, Inno Setup, 기존 설치 경로·Inno `AppId`, 실행파일명/서명 흐름을 유지.
- 축소: 배포에 필요 없는 PDB 및 생성될 수 있는 컴파일 XML 문서. SDK에 디버그 기호가 없다면 절감량이 **0MB일 수도 있음**. 실제 설치 175MB → xMB 숫자를 검증 없이 주장하지 않음.
- 제외: `PublishTrimmed=true`(WPF/리플렉션·동적 자원에 대한 기능 손실 우려), `InvariantGlobalization=true`(한글/국제화), `SatelliteResourceLanguages=ko`(기존 언어 리소스 제거), `--self-contained false`(대상 PC의 .NET Desktop Runtime 요구), single-file 압축 후 temp 추출(일시 디스크 사용량과 실행 성능/업데이트 영향을 변경).
- 패키지에서 debug PDB를 삭제하는 것과 원본 소스 파일/사용자 데이터 cleanup을 구별.
- 실제 측정: 선택형 `tools/measure_payload_size.py`로 **같은 PC의 빌드 전·후 설치 폴더** 측정. `dotnet publish` 산출물을 확보해야 세부 런타임 점유 항목 확정 가능. 프로그램 설치를 완료한 뒤 Windows '설치된 앱' 용량과 파일 총량을 비교.

## 4. 검증 실적 (이번 수정본)

- `python -m unittest discover -s tests -q` : **189 / 189 PASS** (v1.3.3 이전 184 + 새 5).
- `python -m unittest discover -s source/tests -p 'test_ui_contract.py' -q` : **19 / 19 PASS**.
- `python tests/verify_packaging_contract.py` : **15 / 15 PASS**.
- WPF XAML **13개 XML parse PASS**.
- 릴리스 CMD CRLF·버전·SelfContained/NoTrim·라이선스 비삭제 관련 정적 검사 PASS.
- .NET 10 WPF C# compile, C# LogicTests(신규 압축 시나리오 포함), 윈도우 DPI, 실제 설치/재시작, Control·업데이트 및 Windows 설치 절감량: **PENDING**. 본 프로젝트 컨테이너에 Windows/.NET 10 SDK가 없어 실행하지 않음.

## 5. Windows 빌드 및 릴리즈 마감

공식 빌드 명령은 그대로 `BUILD_ON_WINDOWS_COMPANY.cmd`. 기존처럼 기 검증 소스 검사 중복 자동 재실행하지 않고, Windows 환경/컴파일·서명·설치 패키지 검증만 수행한다. 빌드 성공 후 예상 산출물은 `dist/Sunrise_File_Manager_1.3.3_Setup.exe`.

1. Windows 개발 환경에서 `source/tests/LogicTests/V120SafetyTests.cs` 신규 세 경계 케이스를 포함한 C# LogicTests를 **1회** 검증(회사 빌드의 사전 PASS 재사용 원칙 유지).
2. Windows 공식 빌드를 수행하고 PDB 제외 여부, 최종 서명, exe startup, 파일·압축·압축해제·메모·미리보기·Ollama(사용 시) smoke 확인.
3. 기존 설치본 위 덮어 설치 후 session/me­mo/사용자 파일 불변 여부, 제거·재설치 및 업데이트 round-trip 확인.
4. 설치 전후 동일 조건에서 디스크 사용량을 측정하고 숫자가 실제로 감소했는지 기록. 절감이 없으면 용량 개선 성과는 미확인으로 분류.

**판정:** SOURCE STATIC/AUDIT PASS, WINDOWS C# BUILD + INSTALL + FOOTPRINT QUALIFICATION PENDING. 업로드/게시/서명된 설치파일 생성 미수행.
