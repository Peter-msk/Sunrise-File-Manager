# Sunrise File Manager v1.3.6 — 개발 작업인수인계서

## 1. 기준본과 변경범위

- 제품: Sunrise File Manager
- 제품 버전: **v1.3.6** (기능 보완에 따른 수정버전 승격)
- 부모 소스: `Sunrise_File_Manager_v1.3.5_R01.zip`
- 부모 ZIP SHA256: `98153c0d813916b6414499e93979116573cf2310140d47d614ece441429ef123`
- 실행형태: Windows x64 WPF / .NET 10 self-contained / Inno Setup 공식 설치형
- 작업목적: 사용자가 제공한 실제 Windows 스크린샷 및 작동 오류를 반영한 4개 항목의 UI·탐색 기능 수정
- 제품 ID/설치 AppId/Control 및 공개 업데이트 메타데이터/사용자 설정·메모 포맷은 **그대로 유지**

## 2. 기능별 변경

### A. 주소표시줄 드롭다운의 실제 탐색창화

- 과거 `AddressSuggestions` ListBox가 보여주던 긴 물리 경로의 납작한 나열을 제거했다.
- 기존 `FolderTree` 컨트롤을 처음 팝업을 펼치는 시점에만 생성해 주소 팝업에 탑재한다. `빠른 이동 · 기본 폴더`, 고정 즐겨찾기, 드라이브·하위 폴더의 실제 펼침/접힘을 지원한다.
- 선택된 항목은 기존 `TryNavigate()`를 거쳐 탭 기록/경로 검증/스크롤 규칙을 그대로 따른다.
- 직접 경로 편집 및 Enter/ESC/F4/Alt+Down 단축키를 유지한다.
- 주소 드롭다운은 다른 패널에서 새로 열지 않고 **현재 탐색 패널** 소유로 유지한다.

### B. 빠른 이동 및 기본 폴더의 경로 자동확장 제거

- `FolderTree.QuickPathChosen`을 분리하여 빠른 폴더·고정 즐겨찾기와 실제 트리 폴더 선택을 구분한다.
- 빠른 폴더를 클릭하면 대상 폴더 내용을 탐색 패널에서 열되, 물리 경로의 부모 `C:\Users\...`를 좌측 트리에 자동 펼치지 않는다.
- 이미 진행 중인 과거 하이라이트 작업도 `_navigationVersion`으로 무효화해 늦게 트리를 재확장하지 못하게 한다.
- 폴더 표시명 및 기존 `WindowsKnownLocations` 기반 리디렉션 실제경로 검색을 보존한다. 파일 시스템의 물리 저장 위치는 내부적으로 계속 사용한다.

### C. 드라이브 펼침 버튼 인식 개선

- TreeViewItem 펼침 토글의 실제 클릭 영역을 **26×28 → 40×36 DIP**로 확대한다.
- 화살표 이미지도 11×14 → 14×17로 조정하고 행 높이/하위 항목 들여쓰기를 함께 조정한다.
- 드라이브 제목 부분을 더블클릭하여도 확장·접힘할 수 있도록 보조 조작을 추가한다. 화살표에서 발생한 더블클릭은 중복 토글되지 않게 방지한다.
- 기존 지연 로드·가상 트리 노드·드라이브 용량 표시·마우스 휠 동작은 유지한다.

### D. 파일 목록 빈곳 더블클릭으로 상위 폴더 이동

- 이전 `IsEmptyFileListViewport`는 `OriginalSource`가 특정 스크롤 프리젠터로 올라오는 경우에만 인정하여 클릭 위치에 따라 기능이 누락되었다.
- `FileViewport()` 및 `VisualTreeHelper.HitTest()`를 이용해 실제 마우스 위치가 표시 가능한 빈 배경인지 판단한다.
- WPF 사각형 마우스 선택이 첫 클릭을 소비할 수 있으므로, 두 번째 클릭을 `PreviewMouseLeftButtonDown`에서 감지한다.
- Windows `GetDoubleClickTime` 및 `GetSystemMetrics(SM_CXDOUBLECLK/SM_CYDOUBLECLK)`을 사용하여 설정된 더블클릭 시간과 허용 위치를 따른다. 이동량은 DPI 기준에 맞춘다.
- 마우스 드래그 선택이 시작되면 더블클릭 후보를 초기화한다. 파일/폴더 행, 헤더, 스크롤바, 버튼/체크 요소에서는 상위 이동을 실행하지 않는다.
- 폴더 더블클릭/파일 열기/삭제·파일 복사 등의 정상 동작을 유지하고, 상위 이동은 기존 `Up_Click()`을 재사용한다.

## 3. 공지사항의 외부 경로 비노출

- 사용자 표시 공지 `NOTICE_BODY_1.3.6.txt`에는 다운로드 URL, 저장소 주소, 내부 서버 주소를 기재하지 않는다.
- 과거 공지 템플릿 및 소스 보관용 `notice.txt`의 URL도 사용자 지시에 따라 사용자 표시 텍스트에서 제외했다.
- 실제 업데이트 다운로드에 필요한 기계용 `latest.json` 계약과 Sunrise Control 통신은 임의 변경하지 않는다.
- 배포 전 공지 텍스트에 직접 다운로드 주소가 포함됐는지 검사해야 한다.

## 4. 변경 파일 및 보존 범위

주요 변경: `App.xaml`, `Controls/FolderTree.xaml.cs`, `Features/Navigation/FolderTree.QuickAccessAndDrives.cs`, `Controls/ExplorerPane.xaml`, `Controls/ExplorerPane.xaml.cs`, `Features/Explorer/ExplorerPane.MarqueeSelection.cs`, `Features/Explorer/ExplorerPane.NavigationAndWatcher.cs`, `Features/Explorer/ExplorerPane.NavigationDrawer.cs`.

버전·문서·메타데이터 보완: `Sunrise.FileManager.csproj`, `MainWindow.xaml`, `SunriseControlService.cs`, `installer/RELEASE_VERSION.txt`, `BUILD_ON_WINDOWS_COMPANY.cmd`, `release/NOTICE_BODY_1.3.6.txt`, `README.md`, `CURRENT_SOURCE.md`, 관련 현행 회귀검사 및 무결성 매니페스트.

인수인계 시 기존 정상 동작을 변경하지 않는다: C:↔D:/Z: 복사/이동, 숫자 자연 정렬, 다중 선택, 썸네일·미리보기, AI, 메모 저장·연계, 4분할, 세션, 종료 설정, 업데이트·코드서명·데이터 보호.

## 5. 수행한 검증 / 미수행 Gate

- 현행 Python 소스 계약 회귀: **212/212 PASS**
- 공식 설치·패키징 계약: **15/15 PASS**
- WPF XAML XML 구조: **13/13 PASS**
- 사용자 표시 공지 템플릿 URL 비노출: **10개 PASS**
- 공식 CMD 빌드 스크립트 CRLF: **3개 PASS**
- `dotnet build`, Windows WPF 실제 렌더링·마우스 더블클릭 및 설치/서명 테스트: **PENDING** (해당 SDK 및 Windows GUI 환경 없음)

위 소스·XAML 검사 PASS를 Windows 최종 GUI 동작 PASS로 승격하지 않는다.

## 6. Windows 실기 확인 순서

1. 별도 테스트 폴더에 ZIP 압축 해제 후 `BUILD_ON_WINDOWS_COMPANY.cmd` 실행. 완료 상태·로그·실제 Setup 생성 확인.
2. 파일 목록의 완전한 빈 배경을 두 번 클릭해 상위 폴더로 이동하는지 확인. 파일명/행/헤더/스크롤바 두 번 클릭 시 오동작이 없어야 함.
3. 첫 클릭 후 마우스를 드래그할 때 사각형 다중 선택이 정상 동작하며 상위 폴더로 이동하지 않는지 확인.
4. 빠른 이동의 다운로드·문서·바탕화면·동영상·고정 폴더 선택 시 좌측 `C:\Users` 경로가 자동 펼쳐지지 않고 목록 내용만 표시되는지 확인.
5. 드라이브 펼침 화살표의 확대된 전체 클릭 영역 및 드라이브 이름 더블클릭을 반복하여 확장·접힘을 확인.
6. 주소표시줄 클릭 및 F4/Alt+Down으로 트리 드롭다운이 열리고, 드라이브/하위 폴더를 펼쳐 선택할 수 있는지 확인. ESC와 수동 경로 입력/Enter 회귀 검사.
7. 1~4분할, 라이트·다크 모드, DPI 100/125/150%에서 팝업 경계/클리핑/가로 스크롤/포커스 이동 확인.
8. Control 공지 화면에 내부 다운로드 경로나 링크가 노출되지 않는지 재확인. 실제 업데이트 및 서명 경로 계약은 보존.

## 7. 릴리즈 자격

**SOURCE_STATIC_VALIDATED / WINDOWS_BUILD_AND_DYNAMIC_PENDING**. 공식 Windows 서명 설치파일이 검증되기 전 공식 배포로 승격하지 않는다.
