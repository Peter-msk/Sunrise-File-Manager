# Sunrise File Manager v1.6.0 — 메모/상세정보 기능 독립화

## 기준
- 부모: `Sunrise_File_Manager_v1.5.6.zip` (SHA-256 `9d242d5763f12ffedf2b6a8fe15e9718e94dc7ca401fa24aec876ca5f7785776`)
- Windows x64 / WPF .NET 10 / self-contained Inno Setup. 부모 공식 기준본 보존.
- 배포 자격: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING. Windows 빌드·실기·서명 검증 별도.

## 변경 소유권
- `Controls/FileDetailsPanel.xaml(.cs)`: FileEntry 속성 표시, 읽기전용/숨김 속성, 폴더 크기, SHA-256, 자체 닫기.
- `Controls/FileMemoPanel.xaml(.cs)`: #memo 편집, 작성자, 저장·이력·복원·미저장 확인, 자체 닫기.
- `Features/Inspector/FileMemoPanel.AiSummary.cs`: 파일의 로컬 AI 요약을 메모 편집기에 추가.
- `MainWindow.xaml(.cs)`: 독립 열림/닫힘, 너비, 분리된 스플리터·메뉴, 파일 선택 동기화, 메모 전용 안전확인.
- `Services/SessionStore.cs`: v23 메모/상세정보 패널 설정, 구 v22 통합 InspectorVisible/Width 필드 유지.
- `ExplorerPane.xaml(.cs)`: 파일 우클릭/보기 메뉴에 각각의 표시 명령, Alt+Shift+P(상세정보) 및 Alt+Shift+M(메모).

## 기능과 안전 계약
1. 두 패널은 각각 독립 UI 컨트롤, 이벤트, 상태, 비즈니스 코드에서 실행된다. 표시만 바꾼 편법 구현이 아니다.
2. 메모의 실데이터 형식·경로와 FileMemoStore/암호화 이력/이동·이름변경·복구 엔진은 변경하지 않는다.
3. 상세정보 닫기·해시·파일 속성 조작은 메모 저장/폐기 확인을 직접 호출하지 않는다. 메모 닫기·파일 선택 변경·창 종료는 미저장 상태일 때 기존 Yes/No/Cancel 계약을 유지한다.
4. 파일 선택은 활성 분할창 기준으로 두 패널에 동기화한다. 미저장 메모 전환 취소 시 이전 선택으로 복원한다.
5. 미리보기, EIASS, 휴지통, 업데이트·공지 wire, 그룹 서명 정책 및 회사 기본 빌드 CMD는 수정 범위가 아니다.
6. 이전 버전 세션에서는 통합 InspectorVisible을 두 패널의 최초 표시 상태로 이전한다. 신규 v23 세션에서는 `DetailsPanelVisible`, `MemoPanelVisible`, `DetailsPanelWidth`, `MemoPanelWidth`를 각각 보존한다.
7. (R09 후속 정리) 소비자가 없는 InspectorDetailRatio는 삭제했다. 기존 JSON의 해당 필드는 무시하며, 실제 이전에 필요한 InspectorVisible/InspectorWidth는 계속 유지한다.
8. 좁은 창에서 두 패널과 미리보기를 동시에 켰을 때 파일 목록이 압축될 수 있으므로 Windows 최소창·분할·DPI 실기 검증이 필요하다. 미확인 항목은 PASS로 표기하지 않는다.

## 필수 Windows 후속 게이트
- 빌드: `.NET 10` WPF 및 변경 C# 소스 컴파일, warning/error 확인.
- 1·2·4분할/최소창 및 100%/125% DPI에서 독립 열기·닫기/너비 조절 및 파일 목록 화면 가용성 확인.
- 파일 선택→상세 표시, 다른 파일 선택→메모 데이터 갱신, 메모 저장·재시작→기록 복원, 작성 중 취소/저장 후 이탈.
- AI 요약·메모 로컬 이력 복원·파일 속성 변경·해시/용량계산, 관련 기존 동작 영향검증.
- 설치형 clean build→회사 기존 서명→실제 Setup 설치·실행·제거 및 사용자 session/#memo 보존.

## 검증 성격
- `source/tests/test_v160_memo_details_separation.py` 4건, 갱신한 소스 테스트 및 XAML XML 파싱은 정적 검증.
- Windows WPF 렌더링/키보드/실제 파일 저장/설치 후 기동은 현재 환경에서 미실행, 명시적 PENDING.
