# Sunrise File Manager v1.7.0 R03 — 공식 A안 다중 분할 메뉴 중복 제거

## 1. 개발 범위와 기준

- 직접 부모: `Sunrise_File_Manager_v1.7.0_R02.zip` / SHA-256 `8b1b1e94ffb3e9708aba7214a329844daa9328b60bc587c6c2ce67110bd9f9f2`
- 설치형 Windows x64 / .NET 10 WPF, 제품·Control·설치 버전은 **1.7.0 유지**.
- 공식 A안의 **중앙 파일 작업공간 우선 배분**을 실제 ExplorerPane 내부까지 확장한다.
- 업데이트/공지/인증/서명/Preview/파일 처리/메모/세션/14개 분할 엔진 수정 금지.

## 2. 문제와 수정

R02는 상단에 공식 A안의 업무별 명령 영역을 도입했지만, 각 ExplorerPane에도 36 DIP 구형 파일·편집·보기·즐겨찾기·추가 기능·정보 메뉴가 계속 출력됐다. 2×2 분할에서는 구형 메뉴 행이 두 줄의 작업공간 높이를 사용했다.

R03는 **단일창 메뉴 사용성은 그대로 유지**하고, 2~4분할에서 각 분할창의 메뉴 행을 0 DIP로 만든다. 각 탐색창의 탭 오른쪽에 `⋯` 버튼(접근성 명칭: **이 탐색창의 고급 명령**)을 둔다. 클릭하면 기존 여섯 최상위 메뉴의 **동일한 MenuItem 인스턴스**를 이 탭 아래 ContextMenu에서 펼친다. 같은 항목을 복제하거나 이벤트를 재바인딩하지 않는다.

- 다중 분할 시작: 기존 메뉴 항목을 ContextMenu에 **이동**, 원래 메뉴 비표시, 행 높이 0, `⋯` 표시.
- 분할 변경·사이즈 변경: 이미 이동한 상태면 재이동하지 않음.
- 메뉴 열기: 해당 탐색창의 실제 파일/편집/보기/추가 기능/정보 기능 호출, 단축키와 처리기 유지.
- 단일 복귀: 팝업을 먼저 닫은 뒤 기존 메뉴에 **원래 순서로 반환**, 36 DIP 행 복원, `⋯` 숨김.
- 각 분할창의 독립 폴더/탭/선택/검색/즐겨찾기 상태와 우측 공용 상세정보·메모·미리보기 각 1개는 변경하지 않음.

## 3. 변경 파일

- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`: 메뉴/행 명칭, 탭의 고급 메뉴 버튼·ContextMenu.
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml.cs`: 레이아웃 계산 시 메뉴 배치 적용.
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.ViewAndFiltering.cs`: 분할 전환 즉시 메뉴 상태 변경.
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.OfficialACompactMenu.cs`: 메뉴 인스턴스 이동·복원·팝업 소유자.
- `source/tests/test_v170_r03_compact_advanced_menu.py`: 신규 5건 소스 계약.
- `source/tests/UiSmokeTests/OfficialAShellAudit.cs`: 실제 Windows에서 4분할 메뉴 이동·팝업 열림·단일 복원 및 화면 캡처 검증 추가.
- 문서와 메타데이터: 본 문서, `README.md`, `CURRENT_SOURCE.md`, `RELEASE_STATUS.json`, `FULL_SOURCE_SHA256_MANIFEST.json`.

## 4. 검증 범위

| 구분 | 결과 |
|---|---|
| Python source `unittest discover` | 139/139 PASS |
| Python root `unittest discover` | 286/286 PASS |
| 총계 | **425/425 PASS, FAIL 0, ERROR 0** |
| XAML XML 구조 | 15/15 PASS |
| 부모 대비 파일 엔진·메모·빌드 스크립트 변경 | **없음** (바이트 SHA-256 비교) |
| Windows .NET WPF 실제 컴파일·메뉴 조작·DPI | **PENDING** |
| Preview EXE 실행·Authenticode·Setup 설치 | **PENDING** |

`unittest`는 XAML의 WPF 의미, ContextMenu 네이티브 입력, 실제 픽셀 배치를 확정하지 않는다. **Windows Gate가 PASS되기 전 최종 설치형 UI 승인 불가**.

Windows 공식 A안 화면 검증(일반 회사 빌드와 독립 실행):

```powershell
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --official-a-shell-only validation/windows-official-a-r03
```

설치 없이 수정본을 직접 보려면 Windows에서 `BUILD_PREVIEW_ON_WINDOWS.cmd` 실행 후 `dist/Sunrise_File_Manager_1.7.0_Preview/Sunrise.FileManager.exe`로 확인한다. Preview 실행도 실제 파일에 영향을 줄 수 있으므로 별도 테스트 폴더를 사용한다.

## 5. 남은 사항

- Windows 100%/125%/150% DPI 및 14배치에서 실제 ContextMenu 배치·키보드·ESC 종료·포커스·보조 패널 동작 확인.
- 단일 분할/다중 분할 왕복 시 메뉴 순서·이벤트·파일명 표시·탭 복원 점검.
- 원안 이미지의 전역 탐색 트리 통합은 **이번 R03에서 실시하지 않음**. 분할별 탐색 트리를 현재 업무 호환 계약대로 유지함.
- Github/Drive/업데이트 채널 변경 없음. 공식 Setup·서명 아티팩트 없음.
