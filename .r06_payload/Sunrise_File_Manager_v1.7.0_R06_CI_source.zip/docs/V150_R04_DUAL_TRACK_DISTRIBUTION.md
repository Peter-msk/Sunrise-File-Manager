# Sunrise File Manager v1.5.0 R04 — 설치형/포터블형 투트랙 인수인계

## 기준 및 적용 상태

- 기준 소스: `Sunrise_File_Manager_v1.5.0_R03.zip` (SHA-256 `f3fa5b426a11abd5bcdccb7c222a882e66a65e901b582c303d15b9eb828485b4`). 공식 `v1.5.0` 유지, 소스 리비전 R04.
- **Track A — 이번 소스에 반영:** C# WPF .NET 10 self-contained Windows x64 **설치형**. `BUILD_ON_WINDOWS_COMPANY.cmd`의 기본 `SUNRISE_LIGHTWEIGHT=0` → `BUILD_RELEASE_INSTALLER.cmd` → `BUILD_RELEASE_ONEDIR.cmd --company --no-pause --installer-payload` → SignTool/Inno/배포 메타데이터.
- 최종 사용자에게는 서명된 `Sunrise_File_Manager_1.5.0_Setup.exe`를 제공하는 것이 목표. .NET 10 Desktop Runtime x64 구성요소는 앱 설치 폴더에 묶어 배포하므로 별도 사용자 Runtime 설치 필요 없음. 개발자 Windows 빌드 PC에는 .NET 10 SDK·Inno Setup 6·SignTool·적법한 서명 인증서가 필요함.
- **Track C — 향후 별도 제품 형태:** Windows 네이티브 C++/Win32·Windows Shell 기반 **포터블형(설치 불필요)**. 아직 구현하지 않음. Track A 소스/설치파일을 포터블로 이름만 바꾸거나 현재 WPF를 Native AOT로 변환하지 않음.

## 구현 변경 및 보존 계약

1. 공식 회사 빌드의 기본 경량형(`SUNRISE_LIGHTWEIGHT=1`)을 self-contained(`0`)로 변경. 환경변수를 `1`로 명시하면 구형 framework-dependent 진단 빌드만 별도로 가능(필요 시 기존 Runtime 검사 시행, 10,000,000바이트 상한 적용).
2. 공식 기본 self-contained Setup에 10MB 강제 상한을 **적용하지 않음**. Inno Setup 압축은 유지. 최종 크기는 빌드 후 기록하며 숨기거나 과소 표시하지 않음.
3. R14 컴파일 후 `hostfxr.dll`, `coreclr.dll`, `PresentationFramework.dll` 등 핵심 로컬 Runtime 파일을 확인하고 누락 시 실패. R15는 payload의 self-contained 구성을 재확인한 뒤 Inno 설치파일로 포장. R15 결과에 Runtime 모드와 실제 Setup 크기 기록.
4. Inno `HasDesktopRuntimeInView` 검사는 `SUNRISE_LIGHTWEIGHT=1`에서만 컴파일. Track A(0)에는 Runtime 설치 요구/차단/자동 다운로드가 없음.
5. AppId, 제품버전 1.5.0, 서명자·SDK 탐지, Setup 파일명·게시 feed, 사용자 세션/메모, P1/P2/P3 파일 처리 코드는 변경하지 않음. 배포 피드/공지 서버에 자동 게시하지 않음.

## Track C 별도 개발의 수용 기준 (이번 릴리즈 미실시)

- 컴파일된 사용자 실행파일을 앱 폴더에서 바로 시작할 수 있고 설치 마법사, .NET Runtime/SDK, 자동 다운로드를 요구하지 않을 것. 필요한 C/C++ 런타임은 정적 링크 또는 운영체제 기본 제공 기능으로 해결하고 라이선스·보안 검증.
- 기존 Windows 파일 관리자 핵심 기능(다중 분할/탭/탐색/전송/검색/압축/휴지통/미리보기/메모/기본 옵션)별 동등성 매트릭스 및 파일 데이터 보호 회귀 작성. AI·문서 파서는 크기/속도·외부 의존성 검토 후 별도 대체/계층 결정.
- Track A/C는 제품 식별자, 충돌하는 세션 파일 쓰기, 업데이트 채널, 실행파일 교체 정책을 분리하되 필요한 사용자 설정은 **명시적으로만 마이그레이션**. 동일한 그룹서명 원칙을 각각 적용.
- Windows 실기 실행·DPI/UI·대량 파일·다중 프로세스·권한/네트워크·설치/제거 없는 시작·서명/무결성·디스크 사용량과 실행 속도 검증 완료 후 포터블형 출시. **현재 Track C 결과물·고객 선택 UI 없음.**

## Windows 확인 필요 (미실시)

1. R04 ZIP을 새 폴더에 풀고 `BUILD_ON_WINDOWS_COMPANY.cmd` 실행. `build-logs/R14_BUILD_RESULT.txt`, `R15_INSTALLER_BUILD_RESULT.txt`에서 `SELF_CONTAINED=true`, `LIGHTWEIGHT=0`, `RUNTIME_MODE=SELF_CONTAINED_DOTNET10_DESKTOP_X64`, `STATUS=SUCCESS` 확인.
2. `R14_wpf_publish.log`에서 컴파일 오류 0 확인. SignTool 앱 EXE/DLL 및 서명된 Setup/Uninstaller 검증. 실제 `SETUP_BYTES`와 설치 용량 측정.
3. **.NET 10 Desktop Runtime이 없는 깨끗한 Windows 10/11 x64 환경**에서 설치와 실행(실제 런타임 미설치 확인, 자의적인 시스템 Runtime 변경 금지). WPF 탐색, 파일 조작, 미리보기, 탭, P1/P2/P3, 업데이트·제거·데이터 유지 회귀. 성공 전 정식 배포 승인 금지.
4. 경량 진단 빌드를 별도로 테스트해야 한다면 새 작업 사본에서 `set "SUNRISE_LIGHTWEIGHT=1"` → `BUILD_ON_WINDOWS_COMPANY.cmd` 실행. 기본 Track A 설치파일과 혼동하거나 공개하지 않음.

## 현재 검증 한계

이 작업 환경에는 Windows WPF/.NET SDK/SignTool/Inno 실기 실행 환경이 없으므로 **실제 빌드·서명·설치·실행 미검증**. 원본 R03의 코드 CS0103 수정 역시 Windows 재빌드 확인 대기. 정적 계약 및 파일 무결성만 PASS여도 출시 승인 판정은 PENDING.

## 이번 소스 대상 검증 결과

- Python 전체 테스트(`python -m pytest -q tests`): **280 passed, 106 subtests passed**. 신규 배포계약 검사와 기존 릴리즈/서명/기능 회귀 포함. 소스정적 검사만의 결과임.
- XAML/프로젝트 XML 파서: **19개 파일 모두 파싱 PASS**.
- 변경된 C# 서비스 및 XAML 기능 로직 없음; R03 원본 대비 코드 파일들은 바이트 단위로 그대로 보존.
- 공식 CMD는 ASCII+CRLF 유지, 양 모드의 `--self-contained` 선택과 Runtime 파일 경계, 버전/서명/사용자 설정 불변 조건을 정적 검사.
- Windows 빌드·Setup 서명·실제 Runtime 미설치 PC 실행·업데이트/제거는 **미검증**.
