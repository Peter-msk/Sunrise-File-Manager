# Sunrise File Manager v1.5.1 R02 — 1~4분할 전체 배치 점검

- 기준일: 2026-10-23 (한국시간)
- 기준본: `Sunrise_File_Manager_v1.5.1_R01.zip`
- SHA256: `54cb9eb81ca89f892903ba7bdbf22b0c0509842d90e0131b642c8b6f6c52e409`
- 요청: 4분할까지 모두 점검하고 실제 조작으로 오류를 찾아 보완.
- 제품 버전 1.5.1 유지, 전달 리비전 R02.

## 수행 범위와 명확한 한계

이번에는 소스 문자열 검사에 더해 .NET 10.0.100 SDK로 실제 앱의 Windows 대상 C#/XAML을 교차 컴파일하고, production WorkspaceSplitLayoutEngine/NavigationPanelPolicy를 직접 링크한 C# 프로그램을 실행했다. UI 검증 프로그램도 같은 SDK로 Windows 대상으로 컴파일했다.

호스트는 Linux이며 Windows OS/WPF 실행 환경이나 사용자 Windows PC 조작 연결이 없다. **실제 Windows 앱의 마우스 클릭·키보드·렌더링 검증은 수행하지 못했다.** 아래의 C# 로직 실행과 교차 컴파일은 그 조작을 대체하지 않는다. 이번 사용자 요청 중 Windows 실기 조작/최종 패키지 실행은 미완료다.

## 확인하여 수정한 결함

1. **배치와 작업영역 크기 불일치:** 기존 작업영역 최소값은 창 수 위주였고 실제 3/4열·3/4행 트랙 수와 일치하지 않았다. 여러 트랙이 필요한 배치에서 자식의 최소 크기 합보다 작업영역 extent가 작아질 수 있었다. 모든 배치의 실제 행·열 수로 최소 범위를 계산하도록 변경했다.
2. **컨트롤보다 작은 트랙:** 기존 열 최소는 185/240 DIP, 행은 150/210 DIP인데 ExplorerPane 자체는 최소 330×230 DIP였고 고정 머리글/검색/바닥글도 필요했다. 트랙과 작업영역 계산이 같은 350×340 DIP 및 분할선 11 DIP를 사용하도록 통일했다.
3. **가시 영역 측정:** ScrollViewer의 전체 ActualWidth/Height 대신 실제 ViewportWidth/Height를 우선 사용한다. 막대 표시로 가시 영역 크기가 바뀔 때만 작업영역을 재계산하며 단순 가로/세로 위치 변경에서는 재계산하지 않는다.
4. **고정 탐색창 여백 누락:** 파일 목록 최소 100 DIP 외에 창 테두리 6 DIP와 목록 좌우 여백 10 DIP가 필요했다. NavigationPanelPolicy의 고정 모드 예약량에 16 DIP를 반영해 좁은 창에서 파일 목록 가장자리를 침범하지 않도록 했다.
5. **정의되지 않은 배치 복원:** Enum.TryParse는 숫자 문자열 99도 받아들일 수 있었다. 저장한 배치 및 Normalize에서 Enum.IsDefined를 확인하여 미정의 값은 해당 창 수의 기본 배치로 돌린다.

R00 좌측 트리 가로 스크롤, R01 현재 ScrollViewer 해결·분할 창 가로 위치 보호·행 가상화·파일 가로 막대는 유지한다. 파일 엔진/메모/세션 형식/원격 Control/설치 스크립트는 변경하지 않는다.

## 실행한 검증

| 검증 | 실제 결과 |
|---|---|
| 앱 Windows 대상 교차 컴파일 | PASS, 경고 0·오류 0 |
| 전체 분할 WPF UI 검증 프로젝트 교차 컴파일 | PASS, 경고 0·오류 0 |
| production C# 분할/탐색 폭 로직 실행 | PASS, 2,821 assertions |
| 전체 배치 | 14개 |
| 배치 간 순서 있는 전환 조합 | 196개 |
| 관련 Python 소스 회귀 | 32 tests PASS |
| 앱 XAML·관련 프로젝트 XML | 16개 파싱 PASS |
| 실제 Windows 클릭/키보드/시각/DPI | **미실행/PENDING** |
| Windows Setup 생성·서명·설치·packaged 시작 | **미실행/PENDING** |

실행 로그는 `validation/logs/R02_wpf_cross_build.log`, `R02_wpf_ui_test_cross_build.log`, `R02_split_layout_execution.log`에 보존했다. 실제 소스 링크 실행 프로젝트는 `source/tests/SplitLayoutTests`이다. 분할 배치의 누락/겹침, 최소 영역, 배치 순환, 196개 전환에서 활성 창 보존, 대상 창 선택, 잘못된 저장 배치, 좁은 창의 탐색창 폭을 검사한다.

## 배치별 최소 작업영역 (DIP)

| 배치 | 창 수 | 최소 폭×높이 |
|---|---:|---:|
| Single | 1 | 350×340 |
| TwoColumns | 2 | 711×340 |
| TwoRows | 2 | 350×691 |
| ThreeTop1Bottom2 | 3 | 711×691 |
| ThreeBottom1Top2 | 3 | 711×691 |
| ThreeLeft1Right2 | 3 | 711×691 |
| ThreeRight1Left2 | 3 | 711×691 |
| ThreeColumns | 3 | 1072×340 |
| ThreeRows | 3 | 350×1042 |
| FourGrid2x2 | 4 | 711×691 |
| FourColumns | 4 | 1433×340 |
| FourRows | 4 | 350×1393 |
| FourTop1Bottom3 | 4 | 1072×691 |
| FourLeft1Right3 | 4 | 711×1042 |

작은 창에서 모든 배치를 무조건 한 화면에 압축하는 것이 아니라, 파일 목록의 조작 가능한 최소 공간을 유지하며 바깥 작업영역 스크롤로 접근하는 기존 방식을 적용한다. 이 수치는 로직 계산값이며 실제 DPI 렌더링 측정값은 아니다.

## Windows 실기 조작 준비

선택 실행용 `CHECK_SPLITS_ON_WINDOWS.cmd`를 제공한다. 기본 회사 빌드에는 연결하지 않았다. 이전 결과는 `.previous.json`으로 보존하고 이번 실행 결과가 없으면 실패로 처리한다.

실제 WPF 컨트롤에 대한 자동 검증 경로:

- 14개 배치를 실제 분할 버튼과 배치 선택기로 전환.
- 각 창의 파일 가로 막대·좌우 이동·유휴 위치·실제 파일명 좌표 확인.
- 생성한 폴더 행 더블클릭, 뒤로/앞으로/상위 이동.
- 새 탭 메뉴와 선택된 탭 닫기 버튼 조작.
- GridSplitter의 실제 키보드 이벤트 처리와 최소 크기 제한 확인.
- 1400×850에서 1010×650으로 창 크기 변경, 바깥 작업영역 좌우/상하 이동.
- 1→2→3→4→3→2→1→4→1 전환.
- 각 창에 다른 임시 폴더를 열고 네 번째 창을 활성화한 뒤 4→1 축소 시 경로 보존, 1→4 확장 시 독립 경로 보존.

실제 마우스 드래그와 100/125/150% OS DPI 시각판정은 별도 실기 항목이다. 자동 검증의 이벤트 호출을 물리 마우스 드래그 전체의 대체 증거로 쓰지 않는다.

검증은 임시 폴더/샘플만 생성하며 `MainWindow(initialSession)`의 비저장 세션을 사용한다. 결과는 `validation/windows-split-interaction/UI_RESULT.json`이다. 이 검증 프로그램은 현재 **컴파일만 완료했으며 실행 결과 파일은 생성하지 않았다.**

공식 빌드는 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`, 목표 설치파일은 `dist/Sunrise_File_Manager_1.5.1_Setup.exe`다. 소스 UI 검증과 별도로 최종 설치본의 시작·스크롤·업데이트·설정 보존을 실제 Windows에서 확인해야 한다.
