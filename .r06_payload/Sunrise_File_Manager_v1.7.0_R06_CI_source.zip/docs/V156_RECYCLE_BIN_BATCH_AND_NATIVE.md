# Sunrise File Manager v1.5.6 — 휴지통 기본기능 및 일괄 영구삭제

## 기준본 및 변경 목적

- 부모 기준본: `Sunrise_File_Manager_v1.5.5.zip`
- 부모 SHA-256: `f594cac695bf154215925cdc00f3491108e30ec4636198cfc2c2898c3f4fdb57`
- 변경 수준: v1.5.6 설치형 소스 후보 (기존 v1.5.5 원본 불변)
- 대상: `ExplorerPane.RecycleBin.cs`, `RecycleBinService.cs`, 신규 `RecycleBinNativeDelete.cs`, 상단 버튼의 휴지통 분기

## 원인 및 해결

기존 `RecycleBinService`의 `ExecuteVerbAsync(...,"delete")`는 각 `FolderItem.InvokeVerb("delete")`를 반복 수행한다. Windows Shell이 항목마다 확인창을 띄워 다중 선택에서도 확인을 여러 번 요구하는 것이 직접 원인이다.

v1.5.6에서는 삭제 전 사용자에게 선택 전체에 대한 하나의 확인창을 띄우고, 승인 후 COM STA에서 각 선택 항목을 Shell PIDL로 확인한다. `IFileOperation.DeleteItem`으로 항목을 예약한 뒤 `PerformOperations()`를 정확히 **한 번** 호출한다. FOF_NOCONFIRMATION/FOF_NOERRORUI로 Shell의 개별 추가 확인을 막고, 완료 후 휴지통 재열거로 실제 사라진 선택 식별자 수를 판정한다. 원래 파일명·경로를 일반 파일 삭제로 사용하거나 `$Recycle.Bin`의 `$I/$R` 원본을 직접 제거하지 않는다.

Windows Shell 객체에 대한 정확한 PIDL 취득에 실패한 항목은 안전하게 미삭제로 남긴다. 사용자는 Windows 휴지통에서 직접 열어 관리할 수 있다. 실제 Windows 테스트 전 `PASS`로 선언하지 않는다.

## 기능·UI 계약

| 명령 | 동작 | 보존·안전 |
|---|---|---|
| 선택 항목 영구 삭제 | Delete/Shift+Delete/우클릭 / 일반 파일 메뉴의 삭제 | 전체 목록 1회 확인, 단일 Shell batch, 실제 결과 재조회 |
| 선택 항목 복원 | 우클릭 `원래 위치로 복원` | 1회 사용자 확인, 기존 Windows Shell restore verb 유지 |
| 모든 항목 복원 | 우클릭 | 표시 누락/상한 시 실행 차단; Windows 휴지통 안내 |
| 휴지통 비우기 | 우클릭 | `SHEmptyRecycleBinW` 전체 볼륨, 1회 사용자 확인, 운영체제 파일관리 |
| 속성 | 우클릭 | 크기·이름·형식·삭제일·원래 위치 표시. 고급 속성은 Windows에 위임 |
| 모두 선택·새로 고침 | Ctrl+A/F5/우클릭 | WPF 기존 Grid selection/refresh 재사용 |
| Windows 휴지통에서 열기 | 우클릭 | Windows Shell의 추가 작업 경로 제공 |

일반 탐색기 파일 삭제/휴지통 이동은 기존 `FileActionsService` 경로를 유지한다. 설치 AppId, Settings/메모, Control 제품 ID, 업데이트 wire, 회사 CMD는 변경하지 않는다.

## Windows 실기 최소 검증 — 미실행 / PENDING

1. 시험용 텍스트 3개와 폴더 1개를 사용자 임시 폴더에서 만들어 휴지통으로 이동한다.
2. 항목 3개 선택 후 Delete: 확인 **1회** → 아니오: 3개 모두 보존. 다시 Delete: 확인 **1회** → 예: 3개 영구 삭제, 다른 항목 보존.
3. Shift+Delete 및 우클릭 영구 삭제에서도 1회 확인·부분성공·취소·재조회 확인.
4. 같은 파일명 다른 원래 위치/드라이브 항목을 선택해 별개의 Shell identity로만 삭제되는지 확인.
5. 파일/폴더 선택 복원, 모든 항목 복원, 속성, 전체 비우기, Ctrl+A/F5와 빈 휴지통에서 명령 활성화 상태 확인.
6. 일반 폴더 Delete는 기존 휴지통 이동 유지, 드라이브 첫 접기/우클릭 그룹/메모/업데이트·설치 계약에 회귀 없음.
7. Windows x64 .NET 10 설치형 clean build → Setup 서명 → 설치 EXE 실행 → 실제 휴지통 조작(취소/승인) → 정리.

실사용 데이터로 자동 삭제 테스트하지 않는다. Windows 실기·회사 서명 PASS 전에는 SOURCE CANDIDATE로만 표시한다.
