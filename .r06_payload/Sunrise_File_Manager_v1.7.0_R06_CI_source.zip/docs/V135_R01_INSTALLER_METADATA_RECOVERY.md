# Sunrise File Manager v1.3.5 R01 — Windows 공식 설치 빌드 릴리즈 메타데이터 오류 보완

- 제품 버전: **1.3.5 유지**, 동일 버전 빌드 수정분 **R01**.
- 부모 기준본: `Sunrise_File_Manager_v1.3.5_R00.zip`.
- 사용자 자료: `로그.zip`의 R13~R16 빌드 진단을 분석했으며 R01에는 해당 원본 로그를 패키징하지 않는다.
- 범위: 버전별 공지 본문 입력 누락 + 메타데이터 비정상 종료 상태 오판. 제품 동작, AI, 전송, 자연 정렬, 경로 UX, Control 연동, 업데이트 공개 계약 불변.

## 로그의 관찰 사실

1. `R14_BUILD_RESULT.txt`: `STATUS=SUCCESS; STAGE=INSTALLER_PAYLOAD_READY`.
2. `R15_inno_compile.log`: `Successful compile`, 설치파일 서명 완료.
3. `R15_verify_setup.log`: 로컬 그룹 자체서명 인증서 신뢰 루트 부재로 SignTool `/pa`에서 오류 1. 빌드 스크립트는 해당 경고를 조건부 허용하는 기존 계약을 유지했다. 자체서명 인증서가 공개적으로 신뢰되는 게시자 인증서라는 의미는 아님.
4. `R15_SIGNED_SETUP_SHA256.txt`: 최종 파일 해시가 산출됐으나 해당 로그만으로 현재 `dist`에 파일이 보존돼 있음을 보장하지 않음.
5. `R16_metadata_build.log`: 경고·오류 0으로 도구 DLL 빌드 성공.
6. **`R16_release_metadata.log`: `release/NOTICE_BODY_1.3.5.txt` 누락으로 `System.IO.InvalidDataException`.**
7. `R15_INSTALLER_BUILD_RESULT.txt`: 실패 단계가 `RELEASE_ARTIFACT_VERIFY`로 표기됨. 비정상 .NET 종료의 음수 상태코드를 `if errorlevel 1`이 인지하지 못하는 예외 경로를 함께 수정함.

## R01 코드 변경

- `release/NOTICE_BODY_1.3.5.txt`: 현행 기능에 근거한 제품 공지 본문 신규 편성. 내부 검사·보안·배포 경로 등 민감한 구현 정보는 공지 본문에 기재하지 않음.
- `BUILD_RELEASE_INSTALLER.cmd`: 버전 번호 인식 직후 버전 전용 공지 파일 존재·비어있지 않음 확인. **오류면 .NET 게시/서명/Inno 압축 시작 전에 즉시 실패.** 고비용 빌드 반복 방지.
- `BUILD_RELEASE_INSTALLER.cmd`: 메타데이터 실행기의 성공 판정을 `ERRORLEVEL==0`으로 고정해 음수 비정상 종료를 포함해 모든 비영 종료를 오류로 처리. 실패단계를 정확히 `RELEASE_METADATA`로 남김.
- `Program.cs`: `InvalidDataException`도 사용자용 메타데이터 오류로 정상 출력한 후 종료코드 1 반환. 의도하지 않은 미처리 예외 출력 방지.
- `tests/test_v135_r01_release_notice_gate.py`: 위 불변조건 6개 회귀 확인.

## Windows 빌드 시 조치

1. 기존 `v1.3.5_R00` 소스 폴더와 기존 설치본은 유지하고 R01 ZIP을 별도 폴더에 해제한다.
2. `BUILD_ON_WINDOWS_COMPANY.cmd`로 빌드한다. 별도 .NET/LogicTests/문서 전수검사를 중복 호출하지 않는다.
3. 결과 확인: `build-logs/R15_version_preflight.log`의 `CHECK=PASS`, `build-logs/R16_release_metadata.log`에 `release_metadata`와 `release_artifact_verify` 성공 출력, `R15_INSTALLER_BUILD_RESULT.txt`의 `STATUS=SUCCESS`, `STAGE=COMPLETE`.
4. `dist/Sunrise_File_Manager_1.3.5_Setup.exe`와 `dist/release-metadata`의 최신 버전용 `latest.json`, `notice.txt`, `release_info.json` 등 6개 산출물을 확인한다.
5. Windows 실제 설치·실행·제거 및 제품 기능, 서명 상태를 확인한 뒤에만 배포를 승인한다. 로컬 메타데이터 생성은 GitHub 게시가 아니다.
6. 현재 전달된 R01은 소스 패키지이며 Windows 공식 빌드·실설치 통과는 아직 확인하지 못했다.

## 변경하지 않은 내용

- 기존 그룹 인증서 탐색/재사용, EXE·DLL 및 Setup 서명, 프로그램 설치 형식, 버전, AppId, Control ID, GitHub 공개 와이어 계약.
- 커밋된 `latest.json`과 `notice.txt`, 과거 `PUBLISHED_RELEASE.json`은 변경하지 않음.
- 이전 소스 및 공식 릴리스, 사용자 자료 삭제 금지.
