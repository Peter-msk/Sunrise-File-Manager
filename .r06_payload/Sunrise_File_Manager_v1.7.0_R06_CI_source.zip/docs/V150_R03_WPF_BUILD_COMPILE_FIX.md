# Sunrise File Manager v1.5.0 R03 — Windows WPF 빌드 오류 수정

- 기준 소스: `Sunrise_File_Manager_v1.5.0_R02.zip`
- 부모 SHA-256: `008fcb29bd7caaf99283c375fcd7d54239fe3315bd2e5403f5141ee4b8efbdf3`
- 제품 버전: **1.5.0 유지**, 전달 리비전: **R03**
- 사용자가 제공한 증거: `R14_wpf_publish.log`, `R14_BUILD_RESULT.txt`, `R15_INSTALLER_BUILD_RESULT.txt` 등

## 확인된 원인

Windows `.NET 10.0.301` WPF 컴파일러는 `Features/Explorer/ExplorerPane.PagedSelection.cs(55,42)`에서 **CS0103**을 기록함.
`IOException`의 네임스페이스가 이 컴파일 경로에서 명시되지 않아 오류 발생.

```text
error CS0103: The name 'IOException' does not exist in the current context
```

`R14_BUILD_RESULT.txt`는 `WPF_PUBLISH` 실패, `R15_INSTALLER_BUILD_RESULT.txt`는 이로 인한 `PAYLOAD_BUILD` 실패로 기록됨.
Inno Setup, SignTool, .NET SDK 탐색은 정상. 설치 프로그램 컴파일/서명 단계에는 진입하지 못함.

## 반영한 수정

1. `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.PagedSelection.cs` 맨 위에 `using System.IO;` 추가.
2. 기존 P1/P2/P3 비즈니스 규칙, 화면, 버전 및 그룹 서명정책 수정 없음.
3. `BUILD_RELEASE_ONEDIR.cmd`: dotnet publish의 비영(음수 포함) 종료코드를 FAIL로 처리하고 `R14_compiler_errors.log`로 핵심 진단을 요약하도록 개선.
4. `BUILD_RELEASE_INSTALLER.cmd`: R14 실패 하위 단계를 `R15_payload_build.log`와 `R15_INSTALLER_BUILD_RESULT.txt`에서 추적하도록 개선.
5. `tests/test_v150_r03_wpf_compile_fix.py`: 해당 누락의 재발을 방지하는 소스 검사 추가.

## 검증 결과

- `tests/test_v150*.py`, `tests/test_r19_visible_stage_pipeline_r13.py`, `tests/test_r21_wpf_io_namespace.py`: **31 PASS / 19 subtests PASS**.
- 전체 Python 역사 테스트: R02 **322 PASS, 10 FAIL**; R03 **324 PASS, 10 FAIL**. 실패 10개가 부모 R02에도 동일하게 존재함. UI 구형 literal/과거 onefile 빌드 계약 등으로 신규 리비전의 회귀로 판정하지 않음. 전체 PASS로 주장하지 않음.
- .NET 10 Windows/WPF 실제 빌드: **WINDOWS_BUILD_PENDING** (본 환경에서는 Windows dotnet 빌드 실행 불가).
- 서명 EXE / Windows 설치·실행 / 런타임 기능: **PENDING**.

## Windows 재빌드

1. 원본 R02 작업 폴더와 분리하여 R03 전체 소스 ZIP을 압축 해제한다.
2. 기존 회사 공식 빌드 명령인 **`BUILD_ON_WINDOWS_COMPANY.cmd`**를 실행한다. 외부 서명 인증서·SignTool·Inno Setup 설정 변경은 불필요하다.
3. 실패 시 `build-logs/R14_wpf_publish.log`, `R14_compiler_errors.log`, `R14_BUILD_RESULT.txt`, `R15_payload_build.log`, `R15_INSTALLER_BUILD_RESULT.txt`를 확인한다.
4. 컴파일 성공 후에만 그룹 인증서 서명, Inno Setup, 서명 후 SHA-256 및 실제 Setup 실행 검증을 완료한 후 배포 승인한다.

**이번 패치는 관측된 단일 CS0103 컴파일 오류의 원인을 수정했으며, Windows 실제 재빌드 성공은 아직 검증하지 않았다.**
