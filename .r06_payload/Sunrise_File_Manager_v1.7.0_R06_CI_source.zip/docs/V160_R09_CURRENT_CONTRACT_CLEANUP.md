# Sunrise File Manager v1.6.0 R09 — 현행계약 정리·결함 보완 인수인계

## 입력과 원본 보호
- 부모: `Sunrise_File_Manager_v1.6.0_R08.zip`
- SHA-256: `334173f543bb6c3c9748b6fc10bca52f53e3702fb9fe222c0f7d19f68570f3e4`
- 제품/설치 버전 `1.6.0` 유지. R09는 소스리비전.
- R08 원본 ZIP 별도 보존, 보호 대상 13개 파일(MemoStore/Undo/Transfer/Recycle/Control/빌드/공지 등) 원본과 바이트 동일.

## 원인·조치

| 원인 | 수정/보존 판단 | 적용 |
|---|---|---|
| 구형 FileInspector 통합 컨트롤이 존재해야 한다는 검사 | 실제 메모/상세정보 소유권을 각각 테스트 | 현재 FileMemoPanel/FileDetailsPanel 정밀 검사로 교체 |
| 구 OneFile·옛 개발 CMD 강제 | 제품 기본 Track A 설치형 계약과 충돌 | 현행 CMD 점검으로 교체, retired build contract 스크립트 폴더 제거 |
| 실제 현재 1.6.0인데 제품은 무버전이어야 한다는 과거 검사 | 모순 | 버전·Control 정합성 점검으로 교체 |
| 과거 정적 Undo 호출 요구 | 현재 비동기 Undo/Redo 작업·차단·finally 해제 유지 | 실제 Task.Run 경로를 검증 |
| 메모 이동 중 원본 직접삭제 요구 | 현재 snapshot 검증·commit 뒤 안전한 정리 구현 | 대상 검증·충돌 차단·롤백·출처 불변 점검으로 교체 |
| 세션 v22/UI 통합비율 강제 | v25 및 개별 패널 상태가 활성 계약 | 관련 사용 불가 필드 삭제, 구형 JSON 무시/이전 검사 |
| 새 독립 창의 LayoutVersion=24 | v25 단일 보조패널 설정이 전달되지 않는 실제 기능 결함 | LayoutVersion=25, SingleUtilityPanel/SingleUtilityActive 전달 |
| 분할창별 DetailsVisible/PreviewVisible/PreviewHeight | 현재 MainWindow 공용 패널에 소비자 없음 | 모델·초기화·저장·검사 코드를 정리 |
| InspectorRequested 라우트명 | 실제 상세정보만 호출하는 활성 이벤트 | DetailsRequested로 명칭/모든 소비자 동기화 |
| 공개 버전 1.1.0/과거 notice 문자 완전일치 | 현재 공개 1.5.4이며 소스는 1.6.0; 사실이 달라진 고정 테스트 | 무효화된 과거 공개문구 검사 10건 삭제. 현재 버전·제품 ID·업데이트 경계 검사는 유지 |

## 실행 결과
- `python -m unittest discover -s source/tests -p 'test_*.py'` → **117 tests, OK**
- `python -m unittest discover -s tests -p 'test_*.py'` → **279 tests, OK**
- 합계 **396 tests / FAIL 0 / ERROR 0**. 삭제한 10개의 오래된 스냅샷 검사는 PASS 수에 넣지 않았다.
- XAML XML 파싱 **15/15 PASS**. Windows 대상 WPF XAML compilation 성공을 의미하지 않는다.
- 메모 이동과 Undo/Redo의 C# LogicTests는 코드에 유지되어 있으나 이 환경에서 실행되지 않았다. 실동작 PASS로 간주하지 않는다.
- 실제 Windows .NET 10 WPF 컴파일, 파일/메모 동적 로직, 14개 UI 배치·100/125/150% DPI, signed Setup 설치/제거는 모두 **PENDING**.

## 제거·호환성 경계
- 삭제한 파일/스크립트: `audit/retired_build_contracts/` 아래 이미 폐기된 역사적 테스트 6개, 구형 source 테스트 3개(활성 계약으로 대체), 루트 테스트에서 정확한 과거 버전/공지 내용만 고정한 10개 메서드.
- 이미 사용하지 않는 세션 속성 4개 삭제; `InspectorVisible`/`InspectorWidth`는 과거 사용자 파일을 읽는 데 필요하여 유지.
- 기존 `latest.json`/`notice.txt`/회사 배포물/원격 GitHub·Drive는 **변경하지 않음**.

## Windows 후속 조건
1. `dotnet build source/Sunrise.FileManager/Sunrise.FileManager.csproj -c Release` 및 LogicTests C# 전체 실행.
2. `dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --split-gallery-only validation/windows-r09-splits`; `--shared-panel-only`, `--right-dock-only`, `--compact-shell-only`, `--pane-density-only` 각각 실행.
3. 새 창에서 우측 패널 하나씩 보기·메모 작성자·미저장 확인·이력 복원, 14개 배치·컨트롤 1개 정책 실기 검증.
4. 회사용 `BUILD_ON_WINDOWS_COMPANY.cmd` 실행 후 Signed Setup 설치·실행·종료·제거 및 이전 버전 사용자 설정/메모 보존 검증.

**상태: SOURCE_TESTS_PASS_WINDOWS_BUILD_AND_DYNAMIC_PENDING. 설치형 배포 승인이 아니다.**
