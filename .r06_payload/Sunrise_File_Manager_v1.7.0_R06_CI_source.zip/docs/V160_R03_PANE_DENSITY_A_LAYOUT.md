# Sunrise File Manager v1.6.0 R03 — A안 분할창 내부 밀도·공간 보호

- 기준: `Sunrise_File_Manager_v1.6.0_R02.zip`
- 부모 SHA-256: `f929191f768092d86e128aa32811e5871f432b2ec9240376bcd108939b3aa2a8`
- 프로그램·설치·Control 버전: `1.6.0` 유지. 동일 버전 소스 수정 전달본 `R03`.
- 자격: `SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING`. **Windows WPF 컴파일·실제 화면·Setup 생성·회사 서명은 미수행.**

## 변경 목적·범위

다중 분할의 각 ExplorerPane에 메뉴·탭·주소·경로·상태가 고정 높이로 중첩되어, 특히 좁은 검색창에서 목록이 작아지는 문제를 수정한다. 사용자 기능 삭제 없이 패널별 UI 소유범위 안에서만 밀도를 조정한다. `MainWindow`의 공용 우측 상세정보·미리보기·메모 1개씩, 14개 분할 배치, 작업 엔진과 저장형식은 변경하지 않는다.

## 적용된 분할창 행 높이 (단위: WPF DIP)

| 요소 | R02 2~4분할 좁은 창 | R03 2~4분할 좁은 창 | 단일창(변경 없음) |
|---|---:|---:|---:|
| 메뉴 | 36 | 36 | 36 |
| 폴더 탭 | 36 | 34 | 36 |
| 주소 + 검색 두 행 | 78 | 68 | 폭에 따라 42 또는 80 |
| 경로/브레드크럼 | 28 | 24 | 28 |
| 상태/페이지 | 30 | 26 | 30 |
| **총 고정 높이** | **208** | **188** | 일반 폭에서 **172** |

분할 2~4개의 주소·검색 행은 30-DIP 입력 높이, 30+30-DIP 검색 두 행과 총 8-DIP 바깥 여백/간격으로 구성한다. 넓은 분할창에서는 주소가 한 행(38 DIP)에 유지되며 전체 158 DIP가 된다. 단일창의 넓은 배치는 172 DIP로 원상 복원된다. 현재 창 크기와 OS 배율에 따른 실제 픽셀 크기는 Windows에서 실측해야 한다.

### 세부 변경

1. `ExplorerPane.xaml(.cs)`에 TabRow, FooterRow, PaneFooter, AddressInputRow, AddressCommandHost, BreadcrumbCaption, RefreshNavButton, GoNavButton 이름을 부여하고 이 탐색창 로컬에서 반응형 높이를 결정한다. 공통 테마/그룹 전역 값은 변경하지 않는다.
2. 탭은 버튼 기본 MinHeight와 상단 마진을 고려해 34 DIP로 배치하며, 메뉴 행은 기존 36 DIP를 유지한다. 가로 메뉴/탭 스크롤 및 우클릭 메뉴 진입 경로는 변경하지 않는다.
3. 2~4분할 경로 표시에서 중복된 `폴더 경로:` 라벨만 감추고, 클릭·드래그 가능한 실제 breadcrumb 버튼·경로 탐색 기능은 유지한다. 숨긴 파일·확장자·확인란·색상 표시 명령은 기존 보기 메뉴에서 계속 제공한다.
4. 좁은 분할창(폭 640 DIP 미만)에서는 파일명 열 `MinWidth`만 190→145 DIP로 일시 완화한다. 실제 컬럼 `Width`, 사용자가 저장한 열 너비, 열 순서·보이기/숨김은 변경하지 않고 기존 가로 스크롤을 유지한다.
5. 좁은 탭바에서 PaneStatus 최대폭을 64 DIP로 조절해 파일 탭 표시 폭을 보호한다. 상태 원문은 툴팁으로 유지한다. 상세 경고·페이지는 하단 상태줄을 계속 사용한다.
6. 단일 분할로 복귀할 때 높이·주소입력·최소 파일명 열폭은 기존 값으로 복원한다. 접힌 탐색 트리는 그대로 유지되며, 고정 트리도 사용자가 명시적으로 접지 않는 한 자동으로 삭제·비활성화하지 않는다.

## 변경 소스 및 검증

- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml.cs`
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.ViewAndFiltering.cs`
- `source/tests/test_v160_r03_pane_density.py`: 신규 구조·업무계약 검사 **5 PASS**
- `source/tests/test_r11_scroll_theme_toolbar.py`: 구 버전 고정 XAML 문자열 대신 현재 명명 RowDefinition 의미 검증으로 갱신. 구 기능 동작 요구 보존
- `source/tests/UiSmokeTests/CurrentUiAudit.cs`, `Program.cs`: Windows 전용 `--pane-density-only` 경로 작성
- `RELEASE_STATUS.json`, `README.md`, `CURRENT_SOURCE.md` 및 본 개발 계약과 해시 manifest 갱신

검증: R00~R03 관련 소스 계약 **25/25 PASS**, XAML XML 15/15 PASS. 전체 Python unittest는 부모 R02=83건(12 FAIL/4 ERROR), R03=88건(동일 12 FAIL/4 ERROR)으로 **신규 실패 0**. 과거 테스트 16개 실패·오류를 새 버전 PASS로 표기하지 않는다. WPF 실제 컴파일·터치·포인터·DPI·실시간 UI 렌더링·설치·회사서명 등은 **PENDING**.

### 필수 Windows 검증(공식 회사 빌드와 분리된 선택적 실행)

```powershell
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --pane-density-only validation/windows-pane-density-r03
```

4분할 1010×560 DIP, tab/address/breadcrumb/footer 높이, 파일 목록 최소 높이, 우측 공용 패널 단일 인스턴스, 단일창 복귀 치수 복원과 실제 스크린샷 기록을 확인한다. 반드시 14개 전체 분할과 앱 배율 80%/125%, OS DPI 100%/125%/150%, 한글 긴 이름, 네트워크 경로, 숨긴 열과 이동·선택·메모를 별도 수동 smoke로 확인한다.

공식 소스 빌드: 기존 `BUILD_ON_WINDOWS_COMPANY.cmd` 사용 → 목표 `dist/Sunrise_File_Manager_1.6.0_Setup.exe`. 이미 통과한 동일 소스 readiness를 재실행하지 않고 Windows 컴파일·서명·설치·런타임 등 해당 단계만 수행한다. 실 배포는 Windows Gate 통과 및 회사 서명 후에만 진행한다. 공개 latest.json/notice.txt, 사용자 설정, 실제 파일·`#memo` 데이터 및 installer AppId는 변경하지 않는다.
