# Sunrise File Manager 1.3.0 개발·검증 인수인계

2026-10-21 · 사용자 지정 UI·로컬 AI·Windows 위치 탐색 개선.

## 기준과 변경 범위

직전 전달한 1.2.0 전체 소스 ZIP(SHA256 `f57be11e40fd3ce570e6dd0425cbe5a3facc141bbff6bb8dafb5645e23f2f422`)을 별도 작업본으로 풀고 기존 manifest의 파일을 대조한 뒤 개발했다. 1.2.0 원본 패키지와 과거 개발 기록을 보존했다. 이번 작업에서는 사용자가 지정한 화면·탐색 기능을 변경했다. 컴파일러가 과거에 남긴 `_wpftmp.csproj`는 배포 소스에서 정리했다.

첨부 Sunrise Group v2.8 모듈의 UI·UX/변경영향 격리/제품 계약/검증 구분을 적용했다. 기존 제품 식별자, 중앙 운영 정책, 공지 스키마, 파일 작업 안전 규칙, 서명·설치 경로는 유지했다. 원격 저장소나 중앙 Control을 수정하지 않았다.

## 사용자 요청과 반영

| 요청 | 구현 |
|---|---|
| 탐색 열 정렬 | 이름과 수정한 날짜는 기존 왼쪽 정렬 유지. 유형·크기·메모·만든 날짜와 휴지통 추가 열은 내용·제목 가운데 정렬. 첫 아이콘 열 제목 구분 |
| 우클릭 테마 | ContextMenu 자체 ControlTemplate과 MenuItem 템플릿에서 Windows 기본 아이콘 gutter 제거. 다크/라이트 공통 동적 테마 브러시 |
| 메뉴 앞 아이콘 제거 | 상단·우클릭 실행 메뉴의 장식 아이콘/빈 체크 열 제거. 파일 종류 아이콘 및 하위 메뉴 화살표 유지. 체크 가능한 메뉴는 선택 배경으로 현재 상태 표시 |
| 스크롤 최소화 | 시스템 스크롤바 폭/높이 리소스 및 자체 스타일을 6 DIP로 통일. 가로 Track 방향 수정 |
| 상세정보·메모 닫기 | 우측 상단 × → 기존 SetInspectorVisible(false). 미저장 메모 확인 경로 재사용 |
| AI 설치 제목·모델 선택 | 어두운 제목 배경에 흰색/밝은 보조 글자. 모델 선택을 본문 최상단 전체 너비로 배치. 설명 접기, 본문 스크롤, 하단 버튼 줄바꿈 |
| 전체 UI 배율 | 80% 기본, 60/70/80/90/100/110/125% 즉시 적용·저장. 창 본문과 분리된 메뉴/ComboBox 팝업도 같은 배율 적용 |
| 4분할 가독성 | 상세 보기 행 36→30 DIP, 파일 유형 아이콘 약 25×24 DIP. 배율과 함께 도구/탐색/행의 물리 공간 축소. 창 크기와 운영체제 DPI는 별도 유지 |
| AI 추천 | CPU명/논리 코어, 전체·가용 RAM, GPU별 전용 VRAM, 고정 드라이브 여유·매체 추정. 추천 이유/다운로드 예상량과 사양 부족 표시 |
| 빠른 이동 | SHGetKnownFolderPath의 등록 위치 사용. 다운로드 임의 C 경로 fallback 제거. 문서·사진 등 친숙한 주소/탐색경로 표시, 포커스 시 실제 경로 편집 |
| 휴지통 | 이름 휴지통. 현재 탭의 파일 목록에서 조회·검색·정렬. 삭제 일시/원래 위치 열 및 원래 위치 복원 요청. Explorer 실행 경로 제거 |

## 주요 구현 위치와 경계

- `App.xaml`: 테마 메뉴 전체 표면, 스크롤 시스템 치수, 정렬 스타일. 가운데 헤더 스타일은 기존 테마 헤더 스타일을 상속한다.
- `UiScalePolicy/UiScaleService`, `SessionStore`, `MainWindow`: 배율 정책·Window 본문/팝업 확장·세션 저장. 잘못된 저장값은 80%로 복원한다.
- `WindowsKnownLocations`: Known Folder 조회와 표시 이름. 단일 지원 가상 위치 `shell:RecycleBinFolder` 외 임의 Shell 주소를 허용하지 않는다.
- `RecycleBinService`, `ExplorerPane.RecycleBin`, 탐색/선택/키보드 연결: Shell STA 조회·복원. FullPath에는 가상 키를 사용하고 일반 파일/AI/클립보드 경로에는 빈 선택·null 폴더를 전달한다. 원본 휴지통 파일을 직접 수정하거나 영구 삭제하는 코드를 추가하지 않았다.
- `HardwareModelAdvisor`: 플랫폼과 분리된 추천 정책. `WindowsHardwareProbe`: 로컬 조회, WMI나 새 외부 의존성 추가 없음. GPU 메모리는 64비트 DXGI 크기로 읽어 4GB 초과를 보존한다.
- `OllamaSetupDialog`: 설치 동의/건너뛰기 유지. 이미 선택한 모델과 설치된 사용자 모델 유지, 상태 새로 고침이 선택을 덮지 않음. 하드웨어 확인 8초 후에도 수동 선택 가능.
- `AiOllamaService`: 추천 Qwen3 요청은 think=false, num_ctx=4096. 기존 모델 요청은 기존 호환성 유지. 기존 계획 검증과 실행 전 사용자 검토 경로 유지.

## 추천 정책의 의미

Qwen3 0.6B / 1.7B / 4B Instruct / 8B / 14B를 사양에 따라 정렬한다. RAM 계획 기준은 각각 4/6/12/16/32GB이며 다운로드 크기는 약 0.523/1.4/2.5/5.2/9.3GB다. 다운로드 공간은 모델 크기×1.5 + 2GB의 여유를 확인한다. HDD CPU 환경이나 코어가 적은 PC에서는 작은 모델을 우선하고, 충분한 RAM과 전용 VRAM이 있을 때 큰 모델을 우선한다. 가용 메모리가 부족하면 다른 프로그램을 닫도록 안내한다.

이 숫자는 제품의 보수적인 계획 기준이다. 실측 성능, 최소 실행 요구량, GPU 드라이버 호환 보장을 의미하지 않는다. 통합 GPU의 공유 메모리를 전용 VRAM으로 더하지 않는다. 조회되지 않는 값은 미확인으로 표시한다. SSD/HDD 표시는 저장장치 seek penalty 보고값에 따른 추정이므로 RAID·가상·일부 컨트롤러에서 정확한 물리 매체와 다를 수 있다. 모델 저장 위치는 현재 사용자 OLLAMA_MODELS 환경값 또는 기본 경로를 기준으로 추정하며, 다른 서비스 계정의 Ollama 설정을 읽는 기능은 추가하지 않았다.

## 휴지통의 제공 범위

현재 탭에서 Shell 휴지통 루트 목록을 표시한다. 최대 20,000개와 제한 경고를 제공한다. 휴지통의 파일·삭제 폴더는 복원한 뒤 정상 폴더에서 연다. 삭제 폴더 내부의 가상 탐색, 휴지통 비우기, 휴지통 내 영구 삭제는 제공하지 않는다. 항목의 실제 휴지통 경로를 일반 파일 작업으로 넘기지 않는다.

복원은 사용자 확인 후 단일 STA에서 선택한 Shell 항목을 확보하고 Windows의 undelete verb에 위임한다. 여러 항목에 대해 목록을 반복해서 처음부터 조회하지 않는다. Shell의 비동기 복원 요청과 실제 완료를 구분하여 요청 수·찾지 못한 항목·실패를 알린다. 충돌/권한 처리는 Windows가 소유하며 새로 고침으로 결과를 확인한다. 복원 요청 중에는 기존 진행 작업 보호에 따라 종료·업데이트를 보류한다.

## 소스 검증과 Windows 인수 항목

실행 결과의 기준은 `validation/PRE_BUILD_RESULT.json`과 각 게이트 로그다. Python 계약, 패키지 계약, UI 소스 계약, 업데이트 동작, 플랫폼 독립 로직, WPF C#/XAML 교차 컴파일, 배포정보 도구 컴파일을 수행한다. 1.3.0 전용 추천/설정/요청/가상 위치 시험 25개를 추가했다. 테스트의 미래 업데이트 fixture는 현재 1.3.0보다 높은 1.3.1로 지정하며 실제 공개 채널은 변경하지 않는다.

Windows 실행 환경이 없으므로 다음 항목은 PENDING이다. 소스 컴파일 통과를 화면·설치 완료로 해석하지 않는다.

1. Windows 10/11 실제 화면에서 라이트/다크/PC 테마, OS DPI 100/125/150%, 앱 배율 60~125% 확인. 기본 창 4분할에서 이름 식별, 행 높이, 가로/세로 스크롤 드래그, 팝업 위치와 헤더 대비 확인.
2. Inspector × 닫기에서 미저장 메모 저장/버림/취소와 재열기, 미리보기 독립성 확인.
3. AI 설치 창 최소 크기·작업영역 축소에서 모델 선택/버튼 접근, 사용자 모델 보존, 상태 새로 고침, 닫기 중 조회/설치 취소 확인.
4. CPU 전용·통합 GPU·NVIDIA/AMD/Intel 전용 GPU, 4GB 초과 VRAM, HDD/SSD/컨트롤러 미확인 및 디스크 부족의 실제 조회값 대조. Ollama 실제 드라이버 사용과 선택 모델 설치/한국어 분류·요약 확인.
5. 다운로드/문서/사진을 D 드라이브나 OneDrive로 옮긴 Windows 계정에서 빠른 이동·주소 입력·뒤로/앞으로/탭/세션 재시작 확인.
6. 별도 테스트 파일을 휴지통에 보낸 뒤 내부 목록·정렬·복원·동명 충돌·접근 거부·목록 변경을 확인. 일반 복사/삭제/드래그/AI 경로로 휴지통 항목이 넘어가지 않는지 확인.
7. 기존 Windows 공식 빌드 명령으로 서명된 Setup 생성 후 이전 설치 덮어쓰기, 설정·메모 보존, 정상 종료→PID 대기→설치→재실행 확인. 회사 공식 빌드에 소스/업무 문서 시험을 추가하지 않는다.

## 근거 문서

- Microsoft Known Folders: https://learn.microsoft.com/en-us/windows/win32/shell/known-folders
- SHGetKnownFolderPath: https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shgetknownfolderpath
- Shell namespace: https://learn.microsoft.com/en-us/windows/win32/shell/shell-namespace
- Microsoft Recycle Bin undelete: https://devblogs.microsoft.com/oldnewthing/20110901-00/?p=9753
- DXGI adapter description: https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgiadapter-getdesc
- Storage seek penalty: https://learn.microsoft.com/en-us/windows/win32/api/winioctl/ns-winioctl-device_seek_penalty_descriptor
- Ollama Qwen3 tags: https://ollama.com/library/qwen3/tags
- Ollama thinking: https://docs.ollama.com/capabilities/thinking
- Ollama GPU support: https://docs.ollama.com/gpu


## 1.3.0 R00 배포 JSON 생성 보완 (2026-10-21)

사용자 지시에 따라 **빌드 완료 시 업데이트용 URL과 활성화 플래그가 완성된 JSON**을 생성하도록 수정했다. 프로그램 버전은 1.3.0을 유지하는 빌드·패키징 수정본 R00이다.

이전 생성기는 `release/PUBLISHED_RELEASE.json`의 버전·해시·크기·URL이 새 Setup과 전부 같을 때만 URL과 `update_endpoint_configured=true`를 썼다. 신규 버전과 재빌드에서 이 조건이 맞지 않아 빈 URL/false가 반복되었다. 게시 기록 대조를 URL 구성 조건에서 제거했다.

- 최종 Setup의 버전·파일명으로 `release_url`, `download_url`을 자동 구성한다.
- `latest.json`과 `release_info.json`의 `update_endpoint_configured`는 정상 빌드 시 JSON boolean `true`로 생성한다.
- SHA256/파일 크기는 해당 최종 Setup에서 매번 계산한다. 기존 버전·파일명·공지·설치 빌드 전제조건 검사를 유지한다.
- 생성기는 GitHub 게시를 수행하거나 완료로 판정하지 않는다. `publication_status=LOCAL_SIGNED_BUILD_PENDING_PUBLICATION`과 `public_distribution_validated=false`는 게시 미검증 상태를 뜻하며 업데이트 URL 설정 여부와 별개다.
- 사용할 파일은 `dist/release-metadata/latest.json`, `dist/release-metadata/notice.txt`다. 기존 저장소 루트의 공개 채널 스냅샷은 보존한다.
- 배포 순서: 해당 버전 태그에 빌드된 Setup을 동일 파일명으로 업로드 → 공개 다운로드 확인 → 생성된 notice.txt 게시 → 생성된 latest.json을 마지막으로 게시. JSON 내용 수동 편집이나 과거 게시 기록 갱신은 필요 없다.
- 새 버전을 준비할 때 기존 제품 버전 관리 절차를 따르면 URL의 태그·설치파일명도 함께 갱신된다. 업데이트 비교는 기존대로 현재 버전보다 높은 버전에만 적용한다.

검증: metadata 도구 clean rebuild 경고·오류 0건, 생성기 CLI 동작 12개, 제품·소스 계약 169개, 패키징 계약 15개, 업데이트 동작 33개 PASS. 생성한 현재/미래 버전 feed를 실제 제품 wire adapter로 읽어 호환성과 버전 비교를 확인했다. CLI 시험은 한글·공백 경로와 합성 바이트/전제 로그를 사용했으며 실제 서명된 Setup·Windows 빌드를 실행한 시험은 아니다.

변경하지 않은 UI·로직·WPF 소스와 관련 프로젝트/설정의 해시를 대조하여 기존 검증 결과를 REUSED_PASS로 승계했다. 회사 Windows 공식 빌드에 소스 시험을 추가하지 않았다. Windows 빌드·서명·설치와 GitHub 게시·실제 다운로드 검증은 PENDING이다. 구체적인 구분은 `validation/PRE_BUILD_RESULT.json`에 기록했다.
