# Sunrise File Manager v1.3.6 R00 — UI 상호작용 개선 인수인계

## 1. 기준본과 변경 범위

- 부모: `Sunrise_File_Manager_v1.3.6.zip` (사용자가 이전 턴에 받은 전체 소스).
- 제품/설치 버전: 1.3.6 **유지**, 전달 수정본: R00.
- 변경 범위: 각 탐색창 너비, 자동 숨김 펼침 상태 크기, 폴더 트리 확장 상태 정리, 파일 그리드 Shift+휠 입력, 이에 따른 세션 저장과 targeted tests.
- 제외: 다운로드 URL/공지·Control 공개 형식, 설치 AppId/업데이트 엔진, 파일 복사·이동/삭제, 메모, AI, PDF/이미지 미리보기, 인증/서명 구현 변경 없음.

## 2. 기능 계약

| 기능 | 동작 | 기존 행동 보호 |
|---|---|---|
| 고정 탐색창 조절 | 탐색창 오른쪽 12 DIP 그립 좌우 드래그. 145~520 DIP, 분할창 파일 목록 최소 폭을 우선 | 22 DIP 접기/자동숨김 버튼·트리 선택과 독립 |
| 자동 숨김 탐색창 조절 | 레일 hover로 펼친 패널의 오른쪽 그립 드래그 | 드래그·마우스 캡처 중 접힘 보류, 완료 후 기존 hover 지연 접힘 |
| 설정 복원 | 각 PanelSession.TreeWidth 저장. 기존 JSON에 필드 누락 시 기본 272 DIP | 이전 파일/AI/검색/스크롤 설정 보존 |
| 비활성 폴더 접기 | 실제 경로 변경 시 이전 드라이브/경로의 확장 노드들을 축소. 현재 경로의 조상만 유지 | 동일 폴더 F5/자동새로고침에서 확장 상태 보존, 비동기 이전 highlight/restore 결과 무효화 |
| 빠른 이동 | 기본 폴더·고정 폴더 선택 시 물리 드라이브 경로 자동확장하지 않음 | 현재 내용만 즉시 표시하는 v1.3.6 현행 계약 유지 |
| Shift+휠 | 파일 목록의 가로 스크롤 위치를 휠 한 단계당 64 DIP 이동 (가능 범위에서만) | Ctrl+휠 보기 조절, 일반 휠 세로 이동 유지 |

## 3. 코드 소유자

- `Features/Explorer/ExplorerPane.NavigationDrawer.cs`: 너비·자동 숨김·사용자 드래그 생명주기.
- `Services/NavigationPanelPolicy.cs`: 공통 너비 정규화·응답형 표시한도.
- `Controls/ExplorerPane.xaml`: 실제 WPF Thumb/마우스 그립.
- `Controls/ExplorerPane.xaml.cs`: 복원·저장·파일그리드 휠 입력.
- `Services/SessionStore.cs`: PanelSession 확장 및 안전한 유효성 검사.
- `Controls/FolderTree.xaml.cs` + `Features/Explorer/ExplorerPane.NavigationAndWatcher.cs`: 경로 전환 시 비활성 확장 정리, 낡은 비동기 탐색 결과 차단.
- `tests/test_v136_r00_resizable_navigation.py`, `source/tests/LogicTests/V132FeatureTests.cs`: 회귀 계약.

## 4. 실행한 검증과 잔여 Gate

- 현행 Python 소스 계약 테스트: **217/217 PASS**.
- 패키징 계약 검사: **15/15 PASS**.
- WPF 소스 UI 구조 검사: **19/19 PASS**.
- 실제 XAML XML 파싱: **13개 PASS**.
- .NET 10 실제 C# 컴파일, WPF 100/125/150% DPI에서 drag interaction, Windows Setup 빌드·서명·실행: **PENDING** (현 컨테이너에는 Windows/.NET SDK 실행 환경 없음).
- 기존 `validation/PRE_BUILD_RESULT.json`은 **부모 릴리즈의 과거 증적**이며 R00의 PASS로 재사용하지 않음.

## 5. Windows 실기 확인

1. `BUILD_ON_WINDOWS_COMPANY.cmd`로 설치파일을 빌드하고 서명된 설치본 실행. 초기 너비 272 DIP 확인.
2. 단일 창에서 고정 탐색창 우측 가장자리를 좌우로 드래그, 최소·최대 폭 및 재실행 후 동일 너비 복원 확인.
3. 자동 숨김(◆)을 켜고 레일에 마우스를 올려 펼친 뒤 우측 가장자리를 드래그, 커서가 밖으로 나간 뒤 정상 접힘 확인.
4. 2분할·4분할에서 각 탐색창 너비가 서로 독립이며 파일 목록이 지나치게 압축되지 않는지 확인.
5. 동일 드라이브 내 서로 다른 폴더와 다른 드라이브를 번갈아 이동. 현재 폴더의 조상만 열린 상태이며 이전에 열어둔 가지는 접히는지 확인.
6. 폴더 F5/파일 감시 갱신 때는 확장 상태가 유지되는지 확인. 빠른 이동으로 사용자 폴더를 열 때 C:\Users 아래를 자동으로 확장하지 않는지 확인.
7. 가로 스크롤 필요한 상세보기에서 Shift+휠 좌/우 이동, Ctrl+휠 보기 변경, 일반 휠 세로 이동 확인.
8. 기존 폴더 더블클릭·빈 영역 더블클릭·기본 폴더·드라이브 트리 화살표·주소 팝업·공지 단일 버튼 및 복사/이동 회귀 확인.

## 6. 릴리즈 판단

`SOURCE_STATIC_VALIDATED / WINDOWS_BUILD_AND_DYNAMIC_PENDING`. source 또는 headless 회귀 PASS를 Windows 설치본 UI 최종 승인으로 해석하지 않음.
