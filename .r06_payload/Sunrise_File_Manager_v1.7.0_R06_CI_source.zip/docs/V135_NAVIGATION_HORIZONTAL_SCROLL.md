# Sunrise File Manager v1.3.5 — 폴더 탐색 시 가로 스크롤 비정상 이동 수정

- 공식 입력: `Sunrise_File_Manager_v1.3.4.zip` (사용자 제공 전버전 전체 소스)
- 변경 분류: 기능 오류 수정, 제품·설치 버전 `1.3.4 → 1.3.5`
- 외부 업데이트 wire, installer AppId, 제품 ID, Sunrise Control ID, 설정·메모 저장 형식, 실행파일 내부 명칭 불변
- 결과 패키지: `Sunrise_File_Manager_v1.3.5.zip` (전체 소스)
- 패치 범위: `MainWindow.xaml.cs`, `FolderTree.xaml.cs`, `ExplorerPane.xaml.cs`, `ExplorerPane.NavigationAndWatcher.cs`, `ExplorerPane.ViewAndFiltering.cs`, `UiSmokeTests/Program.cs`, 관련 계약검사 및 버전 메타데이터

## 원인 추적

1. `FolderTree.HighlightPathAsync()`가 선택된 트리 항목에 `node.BringIntoView()`를 호출했다. WPF의 `RequestBringIntoView` 라우팅 이벤트가 중첩 ScrollViewer 바깥의 `WorkspaceViewport`까지 도달하면, 파일 탐색을 수행할 때 분할 작업화면 전체가 수평으로 이동할 수 있다.
2. 파일 목록 `FilesGrid`는 `LoadFolderAsync()`에서 `ItemsSource`를 교체하지만 폴더 이동 시 가로 스크롤 오프셋을 0으로 시작하도록 고정하지 않아, 이전 위치 또는 현재 포커스 셀의 레이아웃 요청에 의해 오른쪽으로 이동할 가능성이 있었다.
3. 뒤로가기 마우스 버튼 `XButton1`과 탐색기 뒤로가기 버튼은 `Back_Click → LoadFolderAsync`를 공통 사용하므로 동일 문제가 반복될 수 있다.
4. `BreadcrumbScroll`의 긴 경로 끝 보기 동작은 현재 폴더 명칭 가시성 확보 목적이므로 변경하지 않았다. 이 패치는 **파일 목록과 분할 작업화면**의 비의도적 가로 이동을 대상으로 한다.

## 수정 사항

- `Workspace` 안쪽 컨트롤의 자동 `RequestBringIntoView` 요청이 상위 작업화면을 자동으로 가로 이동시키지 않도록 라우팅 범위를 격리한다. 사용자가 직접 `WorkspaceViewport` 스크롤바를 움직이는 기능은 유지한다.
- `FolderTree` 강조 항목은 `BringIntoView()` 대신 `NavigationScroll`의 세로 오프셋만 조정한다. 화면에서 선택 노드가 가려졌을 때 세로 방향으로만 보이게 하며 최근 요청 generation 가드를 적용한다.
- `ExplorerPane`은 이전 표시 경로와 새 경로가 다르면 즉시 파일 목록 가로 오프셋을 0으로 초기화하며, 새 `ItemsSource`의 레이아웃 완료 이후에도 한 번만 재설정한다.
- 동일 경로의 변경감시·수동 새로고침은 기존 가로·세로 오프셋을 보존한다.
- 최초 앱 시작 시 저장된 세션 위치 복원 계약을 보존하되 해당 위치를 이후 다른 폴더로 옮겨가지 않는다.
- 비동기 탐색이 교차되는 경우 예전 폴더의 콜백이 새 폴더 스크롤 위치를 변경하지 않도록 listing generation을 확인한다.

## 기존 기능 비침범

- 파일 복사/잘라내기/드라이브 간 이동, 휴지통, 메모 저장, AI, 압축 및 미리보기/썸네일 처리 엔진 불변
- 파일명 자연 정렬, 다중 탭·4분할, 키보드 탐색, 뒤로·앞으로, 창 배율, 자동숨김, 셀 가상화 유지
- 기존 설정 파일의 `FileHorizontalOffset`, `FileVerticalOffset` 필드와 SessionStore schema 유지
- .NET self-contained WPF 설치 및 패키징·서명·업데이트 입력 계약 유지

## 검증 결과

- 현행 소스 `python -m unittest discover -s tests -p 'test_*.py'`: **199 / 199 PASS**. v1.3.5 스크롤 변경 전용 검사 5개 포함.
- XAML XML 파싱: **13개 PASS**.
- `python tests/verify_packaging_contract.py`: **15 / 15 PASS**.
- `source/tests/UiSmokeTests/Program.cs`에 4분할 상태의 자동 가로 이동 방지, 폴더 진입, 뒤로가기 및 오프셋 검사 추가. **Windows 실제 실행 미검증**.
- `source/tests`의 과거 레거시 테스트는 폐기된 open source/build 및 리팩터링 이전 코드가 전제인 실패 6·오류 2가 있어 릴리즈 승인에 전용하지 않는다.
- 현재 실행환경에 Windows/.NET 10 WPF SDK가 없어 C# 컴파일·WPF 이벤트 실제 렌더링·100/125/150% DPI·installer·서명은 **PENDING**.

## Windows 최종 Gate (실제 PC)

1. `BUILD_ON_WINDOWS_COMPANY.cmd` 실행, v1.3.5 Setup 빌드/서명 성공 확인.
2. 자세히 보기에서 열 폭을 좁혀 파일 목록에 **가로 스크롤바가 나타나게** 한 후 오른쪽으로 이동.
3. 폴더 더블클릭 → 새 폴더에서 목록이 왼쪽부터 보이는지 확인.
4. 마우스 측면 뒤로가기(`XButton1`), 화면 뒤로가기, 앞으로, 상위 폴더 이동 각각 반복하여 가로 오프셋이 재차 오른쪽으로 이동하지 않는지 확인.
5. 2분할 및 4분할, 최소 창 크기, 여러 깊이의 트리 선택 및 탭 전환에서 전체 `WorkspaceViewport`이 자동으로 우측으로 밀리지 않는지 확인.
6. 같은 폴더 새로고침(F5) 시 사용자의 가로·세로 스크롤 위치가 복원되는지 확인하고 수동 가로 스크롤은 정상 동작하는지 확인.
7. 기존 v1.3.4 기능인 드라이브 간 이동 및 파일명 숫자 자연 정렬을 대표 케이스로 재확인.
8. 앱 종료 후 재실행하여 세션 복원 및 정상 종료 확인.

릴리즈 상태: `SOURCE_STATIC_TESTS_WINDOWS_DYNAMIC_PENDING`. 실제 Windows 실행 PASS 전에는 최종 기능 수정 완료를 확정하지 않는다.
