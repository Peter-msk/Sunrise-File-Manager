# Sunrise File Manager 1.7.0 R00 — 설치 전 실행본 기본 빌드

## 목적
Windows에 설치하기 전 **완성된 실행파일을 직접 열어 UI·기능을 확인**할 수 있도록, 현행 회사 빌드에서 설치형과 동일한 서명 완료 앱을 설치 불필요 폴더로 함께 산출한다. .NET 10 WPF self-contained OneDir을 그대로 재사용하므로 1개의 EXE만 따로 복사하는 방식은 아니다.

## 실행 경로

| Windows x64 명령 | 결과 |
|---|---|
| `BUILD_PREVIEW_ON_WINDOWS.cmd` | Inno Setup 없이 `Preview` 폴더/ZIP 생성(서명 필수) |
| `BUILD_ON_WINDOWS_COMPANY.cmd` | 기존 공식 Setup + `Preview` 폴더/ZIP 동시 생성(기본값) |

산출 위치:

```text
dist/
  Sunrise_File_Manager_1.7.0_Preview/
    Sunrise.FileManager.exe      <- 더블클릭해 설치 없이 실행
    Sunrise.FileManager.dll
    hostfxr.dll, coreclr.dll, PresentationFramework.dll, ...
    README_PREVIEW.txt
  Sunrise_File_Manager_1.7.0_Preview.zip
  Sunrise_File_Manager_1.7.0_Setup.exe
```

`BUILD_PREVIEW_ON_WINDOWS.cmd` 실행 후에는 Setup이 없어도 Preview 사용 가능. Preview ZIP은 **전체 압축 해제 후** `Sunrise.FileManager.exe` 실행. Windows 탐색기가 ZIP 내부 EXE만 임시 추출하면 의존 DLL이 부족하므로 실행할 수 없다.

## 안정성·보안 정책

- `BUILD_RELEASE_ONEDIR.cmd --company --no-pause --installer-payload`를 그대로 이용해 `.NET 10 self-contained` publish → 기존 그룹 서명 → SignTool 검증을 수행한다. Preview는 검증된 원본을 재컴파일/재서명하지 않고 복사한다.
- 같은 회사 빌드에서는 **한 번의 WPF publish/서명 결과를 Preview와 Inno Setup에 공유**하여 빌드 시간과 실행파일 차이를 줄인다.
- Preview 폴더 루트에 Signed EXE를 직접 둔다. ZIP에는 소스, 테스트, 인증서, 문서 fixtures, SDK 도구, 빌드 로그를 넣지 않는다.
- Preview 패키징 실패 시 공식 기본 Setup 빌드를 실패 처리하고 이전 정상 Preview를 되돌린다. 이미 성공한 Preview는 뒤따르는 Inno 컴파일이 실패해도 확인용으로 사용할 수 있다.
- 임의 관리자 권한 상승, 서명 우회, Sunrise Control/공지·업데이트 로직 우회는 추가하지 않는다.
- `SUNRISE_LIGHTWEIGHT=1`은 기존 진단 경로를 보존한다. 이 옵션에서는 외부 런타임을 요구할 수 있으므로 기본 회사 빌드와 달리 Preview 자동 생성은 하지 않는다. 설치 없는 self-contained Preview는 `BUILD_PREVIEW_ON_WINDOWS.cmd` 사용.
- Preview는 개발용 화면 모의 실행이 아니라 **실제 파일 작업이 가능한 앱**이다. 실제 데이터를 수정·삭제하면 반영되고, `#memo`와 LocalAppData 설정은 설치본과 공유할 수 있다. 테스트용 파일로 먼저 검증하고 설치된 프로그램은 종료한 뒤 Preview 실행.
- Setup/릴리즈 `latest.json` 생성 경로와 인스톨러 AppId, 버전 `1.7.0`은 기존대로 유지한다. Preview ZIP은 공개 업데이터 입력으로 사용하지 않는다.

## 검증과 미검증

- Linux에서 확인할 수 있는 대상: 스크립트 ASCII/CRLF, Preview 소비자·서명 소유권·하나의 publish 경로, 패키징/롤백 로직 소스 검사, 기존 Python 회귀검사, XAML 파싱, 소스 ZIP 무결성.
- Windows 전용 PENDING: .NET WPF publish 실제 성공, SignTool 신뢰 및 서명, preview ZIP 압축 풀기, exe 실행/기본 초기화, 기존 설치본 종료/세션 유지, 14개 레이아웃 및 메모/상세/미리보기, Setup 생성·설치·제거.
- Windows 결과가 없으면 `Preview EXE 생성 완료` 또는 `실행 PASS`라고 주장하지 않는다.
