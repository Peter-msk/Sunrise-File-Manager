# Sunrise File Manager v1.6.0 R08 — A안 UI 소스 마무리 / 승인 전 검증 기준

## 1. 목적과 변경 경계
- 부모: `Sunrise_File_Manager_v1.6.0_R07.zip` (SHA-256 `c48e635b5de79df6087dc021eeadfeb87b429e02634739ce6dbbe829c975d381`). 공식 제품·설치 버전 `1.6.0` 유지, 리비전만 R08.
- A안 파일 관리 중심 UI **기능 및 소스 수정 범위 마무리**. 실제 Windows 최종 시각·설치·서명 승인은 별도 단계(PENDING).
- 기존 14개 기본 배치, 1~4개 개별 파일 탐색창, 우측 공용 상세정보·미리보기·메모 각 1개, 파일 작업 진행 상태 하단 위치, 메모 저장·EIASS·검색·Ollama·휴지통·Control/업데이트 계약 보존.

## 2. R08 결함 보완
1. 상단 명령줄의 단일행 가로 스크롤 콘텐츠 정렬을 왼쪽으로 통일하여 좁은 창에서 가장 먼저 보이는 분할 버튼에 접근성을 높였다. 아래 행을 만들지 않고 스크롤로 명령 접근한다.
2. 분할 프리셋 드롭다운은 하나만 열리도록 관리한다. 다른 `단일/2/3/4분할` 버튼을 누르면 이전 열린 메뉴를 닫는다. 메뉴 종료 시 컨텍스트 메뉴의 앵커 참조를 정리한다.
3. WPF Window `PreviewKeyDown` 터널 이벤트가 내부 문서 미리보기의 `Ctrl+1`(너비 맞춤) 또는 메모·검색 텍스트 편집 도중 분할 단축키를 선점하지 않도록 focus ownership을 명시했다. 파일 작업영역에서는 Ctrl+1~4 및 NumPad 1~4가 마지막 승인 배치를 호출한다.
4. 네 개 배치 버튼에 스크린리더용 명확한 한국어 접근성 이름을 추가했다. 별도 배치/메뉴를 추가하지 않았다.
5. Windows용 SplitLayoutGalleryAudit에 연속적으로 두 배치 버튼을 누를 때 이전 팝업이 닫히는 시험을 추가했다.

## 3. 화면/업무 동작의 고정 계약
| 항목 | 고정된 동작 |
|---|---|
| 분할 메뉴 | 단일 1 · 2분할 2 · 3분할 6 · 4분할 5 / 총 14개 기존 배치 |
| 메뉴 접근 | 버튼 바로 아래 드롭다운, 미리보기 그림+배치 이름+짧은 설명, ESC 취소, 현재 배치 체크 |
| 메뉴 열기 | 현재 분할/탭/파일 선택에 영향 없음. 특정 항목 선택 후만 ArrangePanels |
| 작업 진행 | 전송/AI/휴지통 작업 중 배치 변경 금지, 작업 완료 후 허용 |
| 우측 패널 | FileDetailsPanel 1, FilePreviewPanel 1, FileMemoPanel 1. 분할창 활성 파일에 동기화 |
| 하단 표시 | 작업 상태·진행률·중단·취소. 메모/상세/미리보기 하단 배치 금지 |
| 공간 반환 | 닫힌 패널과 분할선 너비 0. 좁은 분할에서 파일 목록 스크롤·탐색 트리의 임시 너비 제한 |
| 자료 보호 | 미저장 메모 확인, 기존 세션·작업 설정, 메모 포맷·사용자 데이터 보존 |

## 4. 정적 검증과 한계
- R08 신규 현행 UI 계약 6/6 PASS, R00~R08 `test_v160_*.py` 56/56 PASS.
- 프로그램 XAML 15개 XML 파싱 PASS. XML 파싱은 WPF XAML 컴파일/화면 렌더링을 의미하지 않음.
- 전체 `test_*.py`: R07 113건(12 FAIL·4 ERROR), R08 119건(동일 12 FAIL·4 ERROR)로 신규 실패 0. 이력 테스트 중 오래된 통합 Inspector·OneFile·버전 없는 개발 프로젝트 등은 현행 계약과 불일치하나 삭제·은폐하지 않음.
- 기존 파일 이동·삭제·메모 저장·AI·EIASS·휴지통·업데이트 서비스와 설치 빌드 소스 변경 없음 (부모 SHA-256 비교).
- 실제 Windows WPF `.NET 10` 컴파일, 마우스/키보드 동작, DPI 100%/125%/150%, 최소 창·14개 배치, 서명된 Setup 설치·제거 **PENDING**. Windows에서 확인하지 않고 공식 PASS 선언 금지.

## 5. 필수 Windows 최종 승인 게이트
1. `dotnet build source/Sunrise.FileManager/Sunrise.FileManager.csproj -c Release` WPF 실제 컴파일, 경고·오류 기록.
2. `dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --split-gallery-only validation/windows-split-dropdown-r08`: 14개 배치 그림·실제 클릭, 이전 팝업 정리, ESC/메뉴 열기만으로 상태 불변, active item check, 분할별 세션 상태.
3. `--shared-panel-only`, `--compact-shell-only`, `--pane-density-only`, `--right-dock-only`를 별도 실행하여 우측 3공용 패널 각 1개·하단 상태 전용·좁은 4분할·레이아웃 공간 반환 확인.
4. 1010×560 최소창 / 1520×930 기본 / 큰 창, Windows DPI 100/125/150, 라이트/다크 및 앱 배율(80/100/125%), 1~4분할의 파일 목록·가로·세로 스크롤·긴 한글 경로·4개의 pinned 탐색 트리 확인.
5. 메모 작성 중 Ctrl+1~4, 미리보기 파일 선택 후 Ctrl+1(너비 맞춤), 검색 입력 중 Ctrl+1, 파일 목록 활성 중 Ctrl+1~4를 실제 키보드로 확인. 메모 저장/취소/분할 축소 및 AI 작업 중 메뉴 차단 확인.
6. 사용자가 설치형 출하를 지시하는 시점에 기존 회사 빌드 진입점 `BUILD_ON_WINDOWS_COMPANY.cmd`로 서명된 Setup 생성·설치·실행·제거 수행. 회사 기본 빌드에 중복 문서/소스 테스트 추가 금지.

## 6. 상태
**UI_SOURCE_FREEZE_CANDIDATE / WINDOWS_DYNAMIC_PENDING**. R08은 A안 UI 기능 작업의 기준 후보이나, Windows 실제 빌드·시각·설치 확인 전에는 공식 최종 설치형 또는 Windows UI 통과본이 아니다. GitHub/Google Drive/공식 업데이트 피드/공지 게시 변경 없음.
