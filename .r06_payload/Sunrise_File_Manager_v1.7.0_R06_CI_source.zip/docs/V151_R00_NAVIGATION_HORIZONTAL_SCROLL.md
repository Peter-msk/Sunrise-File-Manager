# Sunrise File Manager v1.5.1 R00 — 좌측 탐색창 가로 스크롤

- 기준일: 2026-10-23 (한국시간)
- 기준 ZIP: `Sunrise_File_Manager_v1.5.1.zip`
- 기준 SHA256: `84bc4cd6c81190ca286e010886b2c31807d89ba81f33c2b5c719a7ffd553b05d`
- 요청: 좌측 탐색창에서 긴 하위 폴더명을 사용자가 좌우 이동하여 확인.
- 제품 버전: 1.5.1 유지. 동일 개발 릴리즈 첫 수정본 R00.

## 변경 및 범위

기존에는 외부 NavigationScroll의 가로 스크롤이 Disabled였고 트리 이름 TextBlock에 MaxWidth=198과 CharacterEllipsis가 적용되어 있었다. 스크롤 설정뿐 아니라 원문 너비 제한도 제거했다.

1. FolderTree.xaml: 기존 NavigationScroll 하나를 양축 Auto로 설정. 화면을 넘는 콘텐츠가 있을 때 가로 스크롤바를 표시한다. 내부 TreeView 자체 스크롤바는 비활성으로 유지해 중복 스크롤을 만들지 않는다.
2. 폴더/드라이브명은 NoWrap + TextTrimming.None으로 원래 너비를 사용하며 툴팁도 유지한다. 트리 들여쓰기·큰 확장 화살표·드라이브 용량 표시를 보존한다.
3. Shift+마우스 휠은 가로 이동, 일반 휠은 기존 세로 이동, Ctrl 조합은 기존과 같이 이 처리기가 소비하지 않는다. 가로 이동은 세로로 넘치는 항목이 없어도 동작하도록 세로 overflow 검사보다 먼저 처리한다. 양쪽 끝은 ScrollableWidth 범위로 제한한다.
4. 상단 빠른 이동·즐겨찾기·위치 찾기 영역은 ViewportWidth에 맞추고 HorizontalOffset만큼 렌더 위치를 보정한다. 긴 트리 때문에 조작 버튼이 콘텐츠 오른쪽 끝으로 밀리거나 가로 스크롤과 함께 사라지지 않도록 한다. 세로로는 기존과 같이 함께 스크롤한다.
5. PanningMode=Both로 양축 패닝을 허용한다. 운영체제·장치별 실제 입력은 Windows 실기 확인 대상이다.

런타임 변경 파일은 FolderTree.xaml, FolderTree.xaml.cs와 기존 FolderTree.QuickAccessAndDrives.cs 세 개다. 전역 테마나 파일 목록·분할창 크기·세션 형식은 변경하지 않았다.
폴더 트리 컴포넌트를 재사용하는 주소창 팝업에도 동일한 가로 스크롤이 적용된다.
기존 너비 조절·자동 숨김·독립 탐색창·늦은 폴더 로딩·위치 찾기의 세로 정렬 로직을 유지한다.
가로 위치를 새 설정으로 저장하는 기능은 추가하지 않았다.

## 검증

- 기존 관련 소스 검사 32 tests PASS: compact tree, single scroll, resizable navigation, large/deep tree, single pane, workspace scroll isolation, installer comment.
- 기존 말줄임 기대 검사는 이번 사용자 요청에 맞는 전체 이름 표시 계약으로 갱신했다. 단일 외부 스크롤과 가로 Auto도 기존 검사에서 확인한다.
- 앱 XAML/프로젝트 XML 파싱 PASS.
- 기록 갱신 전 원본 비교로 런타임 세 파일과 관련 검사 두 파일만 변경되었음 확인 PASS.
- 제품·설치 버전 1.5.1 유지. 모든 CMD·설치 스크립트·파일 작업/메모/업데이트 런타임은 기준본 그대로다.
- Windows WPF 컴파일, 실제 가로 extent/스크롤바·휠·자동 숨김·DPI 시각 확인은 PENDING이다. 현재 환경에 .NET SDK/Windows WPF가 없어 실행하지 않았다.
- 검사를 Windows 빌드 경로에 추가하지 않았다. 이전 기능의 전체 검사를 재실행하지 않는다.

참고: https://learn.microsoft.com/en-us/dotnet/api/system.windows.controls.scrollbarvisibility

## 빌드와 Windows 확인

ZIP을 새 폴더에 풀고 `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다.
목표 출력: `dist/Sunrise_File_Manager_1.5.1_Setup.exe`.
기존 R05 설치 스크립트 주석 수정과 실행환경 포함 기본 설치형을 유지한다.

실제 앱에서 긴 한국어 폴더명을 포함한 깊은 경로를 펼친 후 다음을 확인한다.

- 하단 가로 막대를 끝까지 드래그하여 이름의 뒷부분까지 확인.
- Shift+휠은 좌우, 일반 휠은 상하 이동. 세로로 짧은 트리에서도 좌우 이동.
- 상단 빠른 이동·고정·위치 찾기 버튼이 가로 이동 중에도 표시 폭 안에 유지.
- 탐색창을 좁히거나 넓힐 때 스크롤 범위가 맞춰지고 자동 숨김 창의 스크롤 막대 드래그 중 접히지 않음.
- 분할 탐색창과 주소창 팝업, 기존 툴팁·파일 선택·이동·세션 복원이 정상 동작.

기존 원격 게시 latest.json/notice.txt와 GitHub/Drive는 변경하지 않았다.
