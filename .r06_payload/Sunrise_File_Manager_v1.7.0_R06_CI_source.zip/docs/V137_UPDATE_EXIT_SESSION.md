# Sunrise File Manager v1.3.7 — 공식 수정·작업인수인계서

## 1. 기준본

- 입력: Sunrise_File_Manager_v1.3.6_R01.zip
- 출력: Sunrise_File_Manager_v1.3.7.zip
- 소스 변경 목적: v1.3.5 → v1.3.6 업데이트 도중 반복된 세션 저장 경고 재발 방지, 버전 승격 및 결함 장기 기록.
- 보존: 기존 파일 작업·메모·AI·세션 저장 형식·Sunrise Control 업데이트 wire·Installer AppId·서명계약·사용자 로컬 설정.

## 2. 결함 원인과 책임 시점

v1.3.5 R01 프로그램은 설치 이관 시 먼저 실행 중인 자기 자신을 종료하면서 저장을 수행한다. 해당 구버전의 `ExplorerPane.GetSession()`은 미초기화 WPF `DisplayIndex`를 검증 없이 수집하고 `SessionStore.Save()`에서 거부될 수 있다. 따라서 사용자에게 보인 오류가 v1.3.6을 실행해 생긴 문제라고 단정했던 이전 안내는 정정한다. 자세한 근거는 `docs/DEFECT_REGISTRY.md`의 `DEFECT-FM-SESSION-001`.

## 3. 변경

- 앱·컨트롤·설치 버전 1.3.7 일치.
- `SessionStore.SaveUiSnapshot`: UI에서 수집한 임시값만 저장 직전에 한 번 더 정규화. `Save()`는 영속 데이터 검증과 atomic replace 유지.
- `MainWindow.TrySaveSession()`은 새 UI 전용 저장 경계를 호출. 업데이트 전의 `Window_Closing` 오류가 발생하는 경로를 앞으로 만들지 않도록 한다.
- 버전별 `release/NOTICE_BODY_1.3.7.txt` 추가. 사용자 기능·안정화 내용만 포함하며 다운로드 경로 미포함.
- v1.3.5 실행파일 자체는 변경되지 않음. 이전 버전의 종료 차단 현상은 이전 바이너리에 남을 수 있으므로 공식 설치파일에 의한 수동 업그레이드를 별도로 안내.

## 4. 필요 Windows 검증

1. 1.3.7 공식 빌드 `BUILD_ON_WINDOWS_COMPANY.cmd`: Dotnet 10 publish → 서명 → Inno → 메타데이터 → 설치형 종료코드.
2. 1·2·4분할에서 활성/비활성 탐색창, 열 재배열, 탐색창 크기 조절, 자동 숨김을 사용한 뒤 정상 종료와 재실행.
3. 설치 전 1.3.5·1.3.6 사용자 설정·메모·최근 경로를 보존했는지 확인. 기능 실패가 발생하면 기존 원본을 삭제하지 않을 것.
4. 1.3.5→1.3.7 업그레이드는 기존 버전의 종료 오류가 있을 수 있음을 기록. 해당 사용자가 안전하게 작업을 저장한 뒤 프로그램을 종료하고 설치파일을 실행하는 별도 경로 제공.
5. 추후 새 버전으로 업데이트할 때 1.3.7 실행 중 정상 종료 및 설치 이관 여부 확인.
6. 공지사항 UI/notice.txt에 다운로드 URL 및 내부 배포 주소 노출 없음 확인.

## 5. 검증 상태

- 소스 계약 및 ZIP 해시는 검증 수행 후 기록. Windows 실행/서명/설치/업데이트 Gate는 해당 환경에서 실제 수행한 경우만 PASS 인정.
- 테스트 소유권: `tests/test_v137_update_exit_regression.py`, `source/tests/LogicTests/V132FeatureTests.cs`.
