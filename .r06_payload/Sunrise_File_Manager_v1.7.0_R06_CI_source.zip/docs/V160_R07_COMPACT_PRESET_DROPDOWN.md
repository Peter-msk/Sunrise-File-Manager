# Sunrise File Manager v1.6.0 R07 — 기본 분할 배치 드롭다운 목록

## 사용자 요청의 정확한 계약
- 새 배치를 만들거나 분할 적합성 계산 화면을 크게 노출하는 것이 아님.
- 기존에 이미 정의된 배치 `1분할=1개, 2분할=2개, 3분할=6개, 4분할=5개`를 **상단 해당 버튼 바로 아래** 짧은 선택 목록으로 표시.
- 클릭한 분할 수에 속한 배치만 표시하고, 한 항목을 누르면 **즉시 해당 배치 적용**.
- 목록을 여는 것만으로 현재 분할 개수/배치/탭을 변경하지 않음.
- 각 항목은 작은 배치 그림·배치명·짧은 설명 및 선택 표시. 나머지 디스플레이 적합성 설명은 ToolTip에서만 제공.
- `단일 ▾`까지 4개 버튼 동일 방식; Ctrl+1~4 단축키는 기존 마지막 선택 배치 즉시 적용.

## 기준 및 구현
- 부모: `Sunrise_File_Manager_v1.6.0_R06.zip` SHA256 `dc30b440984a7f55b19d65ac8261ca102036a8c248ffc46f5d8a04b741f2bcea`.
- 제품 설치형 버전 `1.6.0` 유지, 변경 리비전 `R07`.
- 메뉴 위치: Windows WPF `ContextMenu.PlacementTarget = anchor`, `Placement = PlacementMode.Bottom`, Offset 0. 공간을 차지하지 않는 임시 팝업 메뉴.
- 메뉴 규모: 항목별 높이 최소 52 DIP, 배치 그림 70×38 DIP, 메뉴 최소 너비 264 DIP. 과거 R06의 배치별 대형 사전 적합성 텍스트를 줄여 스크롤과 과한 메뉴 높이를 억제.
- `WorkspaceSplitLayoutEngine.GetPresetsForCount` 및 `BuildBlueprint`를 재사용하며 중복 프리셋 정의 없음. `ArrangePanels` 엔진/세션/파일 처리 유지.
- 작업 중(전송/AI/휴지통) 배치 변경 금지와 미저장 메모 보호 유지. 화면낭독기 텍스트 및 ToolTip의 공간 안내 유지.
- Windows native UI smoke: `단일` 포함 네 버튼을 모두 실제 목록 경로로 선택하도록 구형 직접클릭 가정 변경.

## 유효한 기존 레이아웃 목록
| 버튼 | 실제 엔진 프리셋 | 갯수 |
|---|---|---:|
| 단일 ▾ | Single | 1 |
| 2분할 ▾ | TwoColumns, TwoRows | 2 |
| 3분할 ▾ | ThreeTop1Bottom2, ThreeBottom1Top2, ThreeLeft1Right2, ThreeRight1Left2, ThreeColumns, ThreeRows | 6 |
| 4분할 ▾ | FourGrid2x2, FourColumns, FourRows, FourTop1Bottom3, FourLeft1Right3 | 5 |

## 유지 계약
- 파일 탐색 1~4분할 엔진, 분할창별 폴더/탭/선택, 상태/세션 기억, 단축키, 복사/이동/압축/AI/EIASS/휴지통/복구 엔진 무변경.
- 우측 상세정보 1개, 미리보기 1개, 스마트 메모 1개. 활성 분할창 파일을 따라가며 하단 Row3로 이동하지 않음.
- 메모 `#memo` 형식, Sunrise Control/업데이트·공지 계약, 회사 서명 및 회사 빌드 CMD 무변경.

## 검증 범위
- R07 신규 소스 계약 6 PASS; 이전 R00-R06 포함 `test_v160_r0*.py` 46 PASS.
- 전체 Python 회귀: R06 107건에서 12 FAIL+4 ERROR, R07 113건에서 **동일 12 FAIL+4 ERROR (신규 0)**. 역사적인 구형 통합 Inspector/OneFile 테스트 등이며 전체 PASS로 해석하지 않음.
- XAML 15개 XML 파싱 PASS 및 전체 ZIP manifest/hash 검증 예정.
- 실제 Windows WPF 컴파일, 팝업 렌더링/물리 마우스·키보드, 최소 창 크기/DPI, 정식 설치형 빌드·서명·설치 **PENDING**.

## 후속 Windows 검증
```
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --split-gallery-only validation/windows-split-dropdown-r07
```
`단일→2→3→4`, 각 목록에서 현재/타 배치 체크, 14개 항목 전환, 선택 없이 닫기, 각 버튼 아래 메뉴 위치, 작업 진행 중 비활성화, 공용 패널 불변, DPI 100/125/150%를 검증한다. 

## 게시
GitHub·Google Drive 공식 배포·원격 latest.json/notice.txt 변경 없음. 회사 Windows 실기/서명 전 소스 후보.
