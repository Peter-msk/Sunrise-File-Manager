# v1.5.1 R03 Windows 분할·가로 스크롤 검증

최종 결과: **PASS (해당 Windows VM UI 시나리오 범위)**.

## 기준과 실행 환경

- 제품 소스: v1.5.1 R02와 동일. 부모 ZIP SHA256: `22ffc34e76ddf2ae68a682a3291b662ba80eafa03aceab0c0e7cf6a9f3f0914e`.
- 검증 코드 commit: `697c6ae8a5fb7c0f785cb3b5991f47431d92a7d5`.
- Windows Server 2025 x64, OS build 26100, 활성 runneradmin 콘솔 세션.
- 1920×1080, Windows DPI 100%, 앱 배율 90%, 기본 시스템 테마.
- 최종 UI 실행: 2026-10-23 16:05:49~16:07:18 KST.
- 실행 URL: https://github.com/Peter-msk/Sunrise-File-Manager/actions/runs/39915493146
- 임시 폴더에 생성한 한글 파일 2개·폴더 및 긴 하위 폴더명으로 검사했다. 회사 문서는 사용하지 않았다.

## 수행 결과

| 검사 | 조작 및 확인 | 결과 |
|---|---|---|
| 전체 배치 | 단일 1종, 2분할 2종, 3분할 6종, 4분할 5종 | PASS |
| 파일 영역 | 각 창의 extent/viewport, 가로 막대, 오른쪽 이동·왼쪽 복귀, 유휴 시 위치 안정성, 파일명 실현·표시 | PASS |
| 이동·탭 | 폴더 더블클릭, 뒤로·앞으로·상위, 새 탭·닫기 | PASS |
| 배치 변경 | 분할 경계 키 이벤트, 1400×850→1010×650 축소·복원, 바깥 스크롤, 활성 창/폴더 상태 보존 | PASS |
| OS 마우스 | 1→2→3→4→1→2→4→1, 실제 클릭 98회·드래그 72회, 18개 창 검사 | PASS |
| 파일/트리 양 끝 | 실제 마우스로 각 가로 thumb를 오른쪽 끝까지 드래그하고 왼쪽 끝으로 복귀; offset과 extent 비교 | PASS |
| 이름 가독성 | 좌측 트리의 긴 이름 끝부분과 첫 번째 분할의 가로 막대를 캡처 화면에서 확인 | PASS |

14종 배치 검사는 실행 중인 WPF 컨트롤과 해당 이벤트를 사용한다. OS 마우스 검사는 `SetCursorPos`/Windows 마우스 입력으로 실제 커서와 thumb를 조작하며, 이벤트를 직접 발생시키는 검사와 구분된다. 모든 14종 배치에 대해 OS 마우스 전체 조작을 수행했다는 의미는 아니다.

## 이번에 보완한 검사 도구

기존 검사 프로그램은 Windows에서 `StartupUri=null` 설정 시 예외가 발생했고, 제품 App 시작 경로를 그대로 실행하면 네트워크/업데이트 창이 개입할 수 있었다. 제품 App.xaml의 실제 리소스를 별도 Application 호스트에 읽고, 비동기 창 초기화 전에 WPF DispatcherSynchronizationContext를 설정했다. 실제 실행 중인 제품 창과 컨트롤을 검사하며, 제품의 운영 시작 코드는 변경하지 않았다.

네이티브 입력 검사, 단계별 로그, WPF 렌더 화면 및 GDI 데스크톱 캡처, 180초 제한 시간 증적을 추가했다. 회사 기본 빌드에는 연결하지 않았다. R01/R02의 스크롤·분할 수정이 검증 범위에서 통과했으며 추가 제품 코드 변경은 하지 않았다.

## 증거와 재실행

- `validation/windows-ui-r03/UI_RESULT.json`: 전체 시나리오 PASS, error null.
- `validation/windows-ui-r03/NATIVE_INPUT_RESULT.json`: 98 clicks, 72 drags, 8 transitions, 18 paneChecks.
- `validation/windows-ui-r03/github-job.log`: Windows 환경·빌드·실행·종료 기록.
- `validation/windows-ui-r03/stages.log`, `execution.log`: 배치별 진행.
- `native-tree-4-3-right-end.png`: 네 번째 창에서 긴 하위 폴더명의 끝부분을 확인한 데스크톱 화면.
- `native-files-2-0-right-end.png`: 2분할의 첫 번째 파일 목록을 오른쪽 끝으로 이동한 화면.
- `native-4pane-3.png`: 왼쪽으로 복귀해 네 창의 파일명이 표시되는 화면.
- Windows에서 `CHECK_SPLITS_ON_WINDOWS.cmd`를 선택 실행한다. 기본 빌드에서 중복 실행하지 않는다.

이것은 Windows 가상 머신에서 소스 빌드한 WPF 창의 자동 입력 검증이다. 사용자의 물리 PC, 다른 DPI/앱 배율·테마 전체, 장시간 부하, 서명된 설치파일 생성·설치·업데이트 검증을 수행한 것으로 간주하지 않는다. 이 항목들은 **PENDING**이다.
