# Sunrise File Manager v1.6.0 R01 — 1~4분할 공용 우측 패널 계약

- 작성일: 2026-10-24 (KST)
- 부모 기준본: `Sunrise_File_Manager_v1.6.0_R00.zip`
- 부모 ZIP SHA-256: `5cfc58d2ba7b2013f797dceb93a7bb1912bb5d8675d259f296fecf8a402a8a2d`
- 배포 자격: `SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING`
- 대상: Windows x64 설치형 / WPF .NET 10 / Inno Setup

## 1. 핵심 결정 — 파일탐색창 N개 / 우측 공용기능 각각 1개

`ExplorerPane`은 1~4개의 독립 **파일 탐색·선택 영역**만 제공한다. 우측의 `FileDetailsPanel`, `FilePreviewPanel`, `FileMemoPanel`은 `MainWindow`가 **각각 정확히 하나씩** 소유한다. ExplorerPane 내부에 서브 상세정보, 메모 또는 미리보기를 생성하지 않는다.

- 활성 탐색창(1~4번)에서 **단일 파일/폴더**를 선택하면 해당 탐색창의 `SelectedFile`이 공용 상세정보, 메모, 미리보기에 반영된다.
- 여러 파일 선택 또는 `내 PC`/휴지통 같은 가상 위치에서는 기존 안전계약상 `SelectedFile=null`을 전달한다. 파일별 내용이나 메모를 임의 합산/오인 표시하지 않는다.
- 분할창 포커스를 옮겨도 우측 공용 컨트롤 인스턴스는 증식하지 않으며, 활성 창 번호는 오른쪽 도구 레일에 `창 2/4` 등으로 표시한다. 각 탐색창 제목은 활성 시 Accent로 강조한다.
- 메모의 미저장 변경 확인에서 취소하면 이전 파일의 메모를 보호한다. 4→2/1분할로 축소하여 활성 창의 작업 상태가 다른 슬롯으로 옮겨질 수 있는 경우 **이동 전에** 확인한다. 분할창 간 작업상태 교환에도 동일하게 확인한다.
- 상세정보·메모·미리보기는 기능·저장·너비가 각각 독립이며 필요한 경우 동시에 표시할 수 있다. 닫힌 패널의 열과 splitter는 0 DIP로 반환된다.

## 2. 실제 변경 소유자

| 경로 | 변경 내용 |
|---|---|
| `source/Sunrise.FileManager/Controls/ExplorerPane.xaml` | 과거 미사용 로컬 상세정보 패널과 열·분할선 제거. 메뉴의 상세정보·메모·미리보기 명령은 유지하고 MainWindow에 위임 |
| `source/Sunrise.FileManager/Controls/ExplorerPane.xaml.cs` | 과거 로컬 상세정보 선호·복제 UI 소유 제거. 이전 `PanelSession.DetailsVisible` 직렬화 필드만 `false`로 남김. 활성 창 제목 강조 구현 |
| `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.ViewAndFiltering.cs` | 표시되지 않는 로컬 상세정보 업데이트·레이아웃 경로 제거. 파일 목록, 탐색·필터·상태 표시 유지 |
| `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.NavigationAndWatcher.cs` 및 `ExplorerPane.PagedSelection.cs` | 폐기된 상세정보 텍스트 변경 호출 제거. 기존 상태/오류 경로 유지 |
| `source/Sunrise.FileManager/MainWindow.xaml` | 공용 도구 레일에 활성 탐색창 지시자 추가; 3개 공용 패널은 기존 MainWindow의 단일 인스턴스 유지 |
| `source/Sunrise.FileManager/MainWindow.xaml.cs` | 선택에 따른 지시자 갱신, 분할 배치 변경 후 공용 상세정보 재동기화, 축소 시 미저장 메모 보호 |
| `source/Sunrise.FileManager/Features/Workspace/MainWindow.PanelCoordination.cs` | 탐색창 전환·상태 교환 시 공용 패널 소유 정보 표시 및 메모 보호 |
| `source/tests/test_v160_r01_shared_right_panel.py` | 4개 ExplorerPane/각 공용 패널 1개, 선택 동기화, 미저장 보호, UI 진입 경로 검증 |
| `source/tests/UiSmokeTests/CurrentUiAudit.cs`, `Program.cs` | Windows 선택 실행 `--shared-panel-only`에서 4분할·2개 파일 전환·3개 공용 패널 단일성 검사, 실제 실행 전 PENDING |
| `source/tests/test_ui_contract.py`, `source/tests/UiSmokeTests/Program.cs` | 과거의 로컬 상세정보 컨트롤 참조를 현재 공용 패널 및 파일 메뉴 계약으로 변경 |

## 3. 레이아웃과 안전 경계

- v1.6.0 R00의 1~4분할, 14개 배치, 분할별 트리/탭/검색/선택/전송, 68 DIP 도구 레일, 전송바 유지.
- 우측 독립 컨트롤 3개를 분할창 수만큼 생성하는 구조는 금지한다.
- 사용자가 세 패널을 동시에 열면 기존의 가로 작업영역 스크롤이 필요할 수 있다. 자동으로 사용자 선택을 숨기거나 미저장 메모를 폐기하지 않는다. 최소창 + 4분할 + 3패널 동시 보기의 실제 가용성과 시각 마감은 Windows 동적 검증 대상으로 유지한다.
- 파일/폴더 연산, 메모 저장 형식 `#memo/*.sunmemo`, 파일 속성·SHA256 엔진, AI/Ollama, EIASS, 휴지통, 압축, Control, 업데이트 wire, 그룹서명, 빌드 CMD는 이번 수정 범위 밖이며 유지한다.
- 기존 세션 `LayoutVersion=24` 및 설치 버전 1.6.0 유지. 새 버전 표시 변경 없이 `R01` 소스 전달본으로 구분한다.

## 4. 검증 및 Windows 인수 기준

**수행된 검사 — Linux 소스 수준:**

- R01 공용 패널 계약 6 PASS, 기존 v1.6.0 계약 9 PASS, 휴지통 계약 4 PASS, UI 현재 계약 19 PASS.
- XAML 15개 XML 파싱 PASS.
- 구형 전체 Python 검사는 부모 R00과 동일 조건 비교: 부모 72개 중 16개(FAIL 12/ERROR 4) 구형 테스트, R01은 신규 6개를 포함한 78개 중 동일한 16개. **R01 신규 실패 0개**. 과거 고정 문자열/폐기된 빌드 파일 가정과 현재 분리 구조 사이의 역사적 차이이며 전체 PASS 아님.
- 파일 작업·메모·휴지통·설치/업데이트 코드의 원본 대비 비변경 확인. 최종 ZIP과 소스 파일 해시 검증.

**Windows 실행 미수행 / PENDING:**

```powershell
# 기준 ZIP 압축 해제 후 Windows .NET 10 SDK에서 독립 실행
# 패키지 위치를 기준으로 실행하며, 실제 사용자 자료 대신 격리된 테스트 파일을 사용
# (회사 공식 BUILD.cmd에 중복 소스 검사를 추가하지 않음)
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --shared-panel-only validation/windows-shared-r01
```

- `1→4→1` 및 기존 14개 분할 배치, 한 창/다른 창 파일 선택 시 3개 공용 패널이 모두 같은 선택 파일을 표시하는지 검사.
- 패널 개수가 언제나 상세정보 1·미리보기 1·메모 1인지 확인. 1개 패널만/전체 동시에 열어 독립 토글 및 0 DIP 공간 반환 확인.
- 메모 미저장 상태에서 탐색창 전환, 4→1 축소, 창 교환 시 확인(Yes/No/Cancel) 동작 검사.
- 1520×930·최소 1010×560 DIP 및 OS DPI 100/125/150%, 앱 배율 80/125%, 라이트·다크에서 화면·가로 스크롤·레이아웃 확인.
- Windows .NET 10 경고/오류, 회사 그룹서명, Inno Setup 생성/설치·업데이트·메모 보존은 별도 릴리즈 게이트.

**주의:** 이 문서는 설치형 소스 후보의 작업 인수인계입니다. Windows 컴파일·실제 실행·서명된 Setup PASS 또는 원격 게시 완료를 의미하지 않습니다.
