# Sunrise File Manager v1.3.5 R00 — 탐색 편의 기능·Control 진입 버튼 통합

## 기준본 / 변경 범위

- 부모 기준본: `Sunrise_File_Manager_v1.3.5.zip`
- 부모 ZIP SHA256: `53c9ffed776280dabe3e0e3067e8e196f3528bd10a87301a65528e0c5bc26ca5`
- 결과 소스 전달본: `Sunrise_File_Manager_v1.3.5_R00.zip`
- 제품 버전: **1.3.5 유지**. 동일 버전의 소규모 UI·탐색 기능 수정으로 R00를 사용한다.
- 변경 목적: 폴더 목록 빈곳 더블클릭 시 상위 폴더, 주소표시줄 드롭다운, 우하단 공지사항/업데이트 버튼 통합.
- 배포사양/기존 설정/메모/업데이트 공개 스키마, AI·전송·휴지통·미리보기 엔진 및 분할 레이아웃은 변경하지 않는다.

## A. 파일 목록 빈곳 더블클릭 → 상위 폴더

- `ExplorerPane.xaml.cs`의 `FilesGrid_PreviewMouseLeftButtonDown`에서 **두 번째 왼쪽 클릭**이고 `IsEmptyFileListViewport`에 해당할 때 기존 `Up_Click` 호출.
- 기존 사각형(마키) 다중선택이 빈곳 첫 클릭의 Preview 이벤트를 처리하므로 `MouseDoubleClick`만으로는 새 기능이 실행되지 않는 문제를 고려했다.
- 파일/폴더 `DataGridRow`의 더블클릭, 헤더, 스크롤바, 스크롤바 Thumb, 반복 버튼은 대상에서 제외. 실제 파일·폴더 항목은 기존 열기 동작 그대로 처리한다.
- 상위 폴더가 없는 위치에서는 기존 `Up_Click` 정책에 따라 이동하지 않는다. 메모 이탈 확인·내 PC/휴지통 가상 위치 정책도 기존 탐색경로를 재사용한다.

## B. 주소표시줄 클릭 → 경로 목록 드롭다운

- 각 ExplorerPane의 기존 `AddressBox`를 **편집 가능한 TextBox 그대로 유지**하고, 오른쪽 펼침 버튼과 메뉴 `Popup/ListBox`를 로컬 UI에 추가.
- 주소표시줄 클릭 또는 화살표 버튼으로 드롭다운을 열 수 있다. 현재 폴더, 상위 경로, 이 패널에서 최근 방문한 경로, 열린 탭, 내 PC·주요 Known Folder·드라이브 목록을 중복 없이 묶어 최대 24개 노출한다.
- 최근 경로는 패널 내부에 최대 12개만 메모리에 보관하며 설정·세션 형식에 신규 키를 추가하지 않는다. 디스크 탐색/네트워크 다운로드 없음.
- 가상 경로는 사용자용 표시명(예: `내 PC`)으로 보여주되 선택 시 실제 가상 경로를 기존 `TryNavigate()`에 넘긴다.
- **직접 경로 타이핑 후 Enter/이동 버튼** 유지. 주소표시줄 포커스 상태의 F4 또는 Alt+아래 방향키로 펼침, 목록 Enter 선택, Esc 닫기 가능.
- 새 경로로 이동했을 때 v1.3.5의 가로 스크롤 초기화와 탐색 기록을 기존 흐름으로 유지.

## C. 우측 하단 Control 버튼 통합

- `MainWindow.xaml` 하단의 `공지사항` + `업데이트` 2개를 **`공지사항 및 업데이트` 1개**로 교체.
- 두 버튼은 원래 동일한 `SunriseControlWindow`를 실행했으므로 기존 `Notice_Click`을 그대로 사용한다.
- 설정 메뉴의 `공지사항 · 버전 정보`와 `업데이트 확인`은 기존 키보드·메뉴 진입 경로의 호환성을 위해 그대로 보존. 실제 동일한 Control 창에서 공지/버전/업데이트를 모두 확인.
- 원격 Control 정책, 설치 이관, 업데이트 로직·URL·JSON·서명 코드는 변경하지 않음.

## 소스 검증 (2026-10-22)

- `python -m unittest discover -s tests -p 'test_*.py' -q` → **205 / 205 PASS** (기존 현행 검사 199개 + R00 전용 6개).
- `python tests/verify_packaging_contract.py` → **15 / 15 PASS**.
- `source/Sunrise.FileManager` 내 모든 `*.xaml` → **13개 XML 파싱 PASS**.
- 기존 하단 두 버튼을 강제한 현행 UI 테스트 1개는 사용자 명시 지시의 단일 버튼 계약으로 수정.
- 수정 여부가 사용자 화면에서 최종 확인되는 것은 **Windows .NET 10 WPF 컴파일/설치 및 실제 mouse/keyboard 이벤트 검증 이후**다. 환경상 해당 실기는 **PENDING**이며 소스 검사 PASS와 구분한다.

## Windows 동작 최종 확인

1. `BUILD_ON_WINDOWS_COMPANY.cmd` 실행, `Sunrise_File_Manager_1.3.5_Setup.exe` 생성·서명/설치 확인.
2. 파일 목록의 **실제 빈곳** 더블클릭 → 상위 폴더. 파일/폴더 항목 더블클릭은 각 열기, 헤더·스크롤바 더블클릭은 상위 이동이 없는지 확인.
3. 빈곳에서 **드래그 사각형 선택**, 클릭으로 선택 해제, Ctrl/Shift 다중선택 유지 확인.
4. 주소창 클릭/화살표/F4/Alt+↓로 경로 목록 확인. 최근 위치 선택 → 경로 이동, 직접 경로 입력 후 Enter, Esc, 뒤로·앞으로 버튼 시험.
5. 1/2/4분할과 밝은/어두운 테마에서 주소 드롭다운 너비·색상·포커스·가로 스크롤 위치가 정상인지 확인.
6. 우측 하단 버튼 1개만 표시되고, 창 안의 공지사항/버전 정보/업데이트 확인 및 설정 메뉴의 기존 진입 경로 확인.
7. 종료·재실행 후 설정/메모가 유지되며, 드라이브 간 이동과 숫자 자연 정렬이 영향을 받지 않았는지 대표 확인.

## 배포 상태

- SOURCE_STATIC_TESTS_PASS
- WINDOWS_CSHARP_COMPILE_PENDING
- WINDOWS_WPF_INTERACTION_PENDING
- SIGNED_INSTALLER_PENDING
- 해당 패키지는 **전체 소스 ZIP**으로, 설치파일이나 Windows 실기 인증 릴리즈가 아님.
