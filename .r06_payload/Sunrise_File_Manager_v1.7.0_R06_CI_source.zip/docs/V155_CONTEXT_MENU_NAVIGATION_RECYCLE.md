# Sunrise File Manager 1.5.5 — 우클릭·탐색 접기·휴지통 Delete

- 기준일: 2026-10-24 (한국시간)
- 부모: `Sunrise_File_Manager_v1.5.4_R00.zip`
- 부모 SHA256: `c174920af12f730cf72c0f757e2257bb5affbb1307fbcafa7321a5479f81bc64`
- 대상: Windows x64 설치형. Portable은 별도 제품이다.
- 현행 결과: `RELEASE_STATUS.json`과 `validation/v155/`를 따른다.

## 요구사항과 구현

### R1. 우클릭 메뉴 간소화·그룹화

일반 파일 목록의 긴 단일 메뉴를 첫 화면 명령 9개·구분선 2개로 정리했다. EIASS 문서명 설정과 AI 정리·요약은 직접 실행하고, 나머지는 열기 / 보기 / 파일 정리 / 압축 / 목록·경로 / 공유·클라우드 / 속성·태그의 7개 하위 그룹으로 묶는다. 명령 설명을 짧게 다듬고 하위 메뉴의 기존 핸들러를 재사용한다.

복사·잘라내기·붙여넣기·일반/영구 삭제·Undo/Redo·기본 선택·새로 만들기는 일반 파일 목록 우클릭에서 제외했다. 상단 메뉴·단축키·파일 작업 구현은 유지한다. 휴지통/내 PC는 가상 위치 전용 메뉴 owner를 유지한다. 이 변경 때문에 그룹 공통 테마나 다른 제품 메뉴를 수정하지 않는다.

### R2. 드라이브 첫 접기 시 현재 폴더로 스크롤되는 오류

기존 펼침 버튼은 버블링 Click에서 처리했다. 그 전에 TreeView의 포커스가 선택된 하위 노드를 표시하려 하면 스크롤과 마우스 해제 대상이 달라질 수 있었다. 또 같은 폴더의 watcher/F5 새로고침에서도 무조건 HighlightPathAsync를 호출해 수동으로 접은 경로를 다시 펼칠 수 있었다.

펼침 화살표의 PreviewMouseLeftButtonDown을 먼저 처리해 TreeView 기본 포커스가 개입하기 전에 상태를 한 번만 바꾼다. 키보드/프로그램 Click은 같은 toggle owner를 재사용한다. 수동 펼침/접기 동안 selection navigation과 RequestBringIntoView를 억제하고, 대기 중 HighlightPath와 큐의 스크롤 callback을 무효화하며 가용 범위 내의 기존 스크롤 위치를 복원한다.

같은 위치의 새로고침은 자동 위치 찾기를 다시 실행하지 않는다. 새 경로 탐색과 명시적인 '위치 찾기'는 유지한다. 따라서 접기만으로 현재 열린 폴더가 드라이브 루트로 바뀌어서는 안 된다.

### R3. 휴지통 Delete

기존 단축키 dispatcher는 휴지통과 내 PC에서 파일 변경 키를 일괄 차단했다. 휴지통의 Delete/Shift+Delete만 이 차단 전에 분기해 기존 PermanentDeleteRecycle_Click 확인·Shell 요청 경로로 연결했다. 일반 파일 경로 삭제에 가상 휴지통 identity를 전달하지 않는다.

휴지통 Delete는 선택 항목의 영구 삭제이며 기존 사용자 확인창을 유지한다. 취소하면 보존하고, 다른 휴지통 항목이나 휴지통 전체를 비우지 않는다. 우클릭 영구 삭제 항목에도 Delete 단축키를 표시한다. 내 PC의 삭제 차단은 유지한다.

## 변경 위치

- `Controls/ExplorerPane.xaml`: 일반 우클릭 메뉴 계층·문구.
- `Controls/FolderTree.xaml.cs`: 첫 마우스 누름, 단일 toggle owner, 일시적인 selection/scroll 억제.
- `Features/Explorer/ExplorerPane.NavigationAndWatcher.cs`: 같은 위치 새로고침의 자동 reveal 제외.
- `Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs`: 휴지통 Delete/Shift+Delete 분기.
- `Features/Explorer/ExplorerPane.RecycleBin.cs`: Delete 단축키 안내.
- 제품 프로젝트·창 제목·Control 버전·설치 버전: 1.5.5 / 1.5.5.0 동기화.

앱 상대경로는 `source/Sunrise.FileManager/` 아래를 기준으로 한다. 파일 처리 엔진·메모 형식·업데이트 wire·설치 AppId·회사 기본 빌드 CMD는 유지한다.

## 검증 방법과 증적 범위

소스 검사에서 XAML 파싱, 연결된 handler, 일반 우클릭의 기본 명령 제외와 상단 편집 메뉴 보존, 버전 동기화를 확인했다.

선택형 Windows UI 실행기는 실제 production 리소스/컨트롤을 로드한다. 우클릭은 native mouse로 열고 7개 하위 메뉴의 표시·화면 내 접근성, 라이트/다크·앱 80/125% 배율을 확인한다. 이동한 미리보기 명령과 EIASS 진입도 실제 마우스로 실행한다.

탐색 회귀는 깊은 현재 폴더와 선택 노드를 유지한 상태에서 파일 목록에 포커스를 두고 드라이브 화살표를 한 번 누른다. 접힘·현재 경로 보존·대기 작업 후 재펼침 방지·같은 폴더 새로고침 후 유지·재펼침을 반복 확인한다. 휴지통 회귀는 GUID가 포함된 임시 파일 하나만 생성/휴지통 이동하고, native Delete의 취소와 승인 경로를 확인한다. 삭제 요청 성공만으로 실제 항목 소멸을 단정하지 않고 Shell 재조회 결과를 확인한다.

기존 회사 CMD에는 테스트를 추가하지 않는다. Windows source UI와 실제 Setup 설치 EXE의 startup 검증은 구분한다. 전체 corpus·NAS/OneDrive·실제 회사 인증서·다른 Windows DPI 또는 상용 자격은 이 targeted 시험으로 자동 승계하지 않는다.

## 인수 및 빌드

최신 소스 ZIP을 별도 폴더에 풀고 `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다. 목표는 `dist/Sunrise_File_Manager_1.5.5_Setup.exe`, 기본은 .NET Desktop Runtime 포함 self-contained 설치형이다. 이전 기준본과 사용자 session/#memo는 보존한다. 공개 feed/notice의 새 버전 게시와 배포는 별도 단계다.


## 최종 결과

- 최종 Windows 실행: https://github.com/Peter-msk/Sunrise-File-Manager/actions/runs/40074723491 — job success.
- 최종 source commit: 23de1a93eaca44c97afc41a579ce7514ebb5381d. 로컬 프로그램·빌드·설치·버전별 공지 입력 150개 모두 동일.
- 경고 0/오류 0, 회사 CMD Setup 생성 성공, 설치 EXE 1.5.5 확인, native Ctrl+2/4/1 입력 및 정상 종료 0, 제거 프로세스 종료 0.
- 메뉴: 실행 40073498262의 메뉴 step 성공 증적을 재사용. 라이트/다크·앱 80/125%, 7개 submenu, 미리보기·EIASS 실제 입력 PASS.
- 드라이브: 같은 실행의 완료된 native 3회 subscenario만 재사용. 그 실행은 이후 별개 휴지통 fixture의 표시 이름 비교에서 실패했으므로 전체 run을 PASS라고 기록하지 않는다. 스크린샷과 drive/SCOPE_RESULT.json을 참조한다.
- 휴지통: 실행 40074523906 step 5 성공 증적 재사용. native Delete 확인, 취소 보존, 승인 후 선택 fixture의 실제 소멸 확인. 그 실행의 뒤따른 설치 preflight는 버전별 공지 누락으로 실패했고, NOTICE_BODY_1.5.5.txt를 추가한 뒤 최종 실행에서 패키징을 통과했다.
- focused source UI host는 modal message loop 내에서 제품 Closing을 재진입하지 않는 전용 종료를 사용한다. 앱 정상 종료는 실제 설치 EXE smoke에서 별도 검증했다.
- 새 버전 공지 본문은 release/NOTICE_BODY_1.5.5.txt에 준비했다. 상단 업데이트/하단 편의 기능이며 실제 공개 공지는 이번 소스 작업에서 게시하지 않았다.
- 최종 Windows artifact 원본 ZIP의 SHA256를 다운로드 후 재확인했다. VM 시험 인증서와 회사 기존 인증서의 신뢰를 구분한다.
