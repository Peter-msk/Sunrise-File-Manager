# Sunrise File Manager v1.5.4 R00 감사 재개 결과

작성일: 2026-10-24 (한국시간)

## 결과와 재개 위치

설치형의 최신 기준본은 `Sunrise_File_Manager_v1.5.4.zip`이다. 중단된 작업을 복구한 결과, 실행 코드 수정과 Windows VM의 빌드·대표 기능·설치 수명주기 검증은 이미 완료되어 있었다. 이번 작업은 해당 실행 결과를 원격 기록에서 확인하고, 최종 전달 소스와 검증 입력의 동일성을 확인한 뒤 현재 상태를 정리하는 단계에서 재개했다.

이번 R00에서 새 Windows VM 실행·컴파일·설치 또는 새로운 실행 코드 수정을 수행하지 않았다. 유효한 기존 결과를 재사용하며, 실제 회사 PC와 회사 인증서에 대한 검증으로 확대하지 않는다. Portable은 별도 제품으로 유지한다.

## 기준본과 무결성

- 기준 ZIP SHA256: `96efba04def611928444b55d5ee2dc8b6621a59e092331d8d25ee40401011053`
- ZIP 620개 항목 CRC 정상, 절대경로 및 상위 경로 이탈 없음.
- 기존 `FULL_SOURCE_SHA256_MANIFEST.json`의 619개 파일에 대해 SHA256와 크기 모두 일치. 해당 목록 자체를 제외한 전체 파일을 검사했다.
- Windows 검증 커밋: `372da5dece1803a17f232ee54521dee440878c83`.
- Git tree의 파일 179개를 로컬 파일의 Git blob SHA1로 비교: 동일 175개, 누락 0개, 차이 4개.
- 차이: `LICENSE`, `README.md`, `latest.json`, `notice.txt`. 프로그램·리소스·빌드·설치 관련 149개 입력은 전부 동일하며 테스트 코드도 동일하다.
- 공지·업데이트 파일의 차이는 전달 ZIP이 보존한 과거 공개본과 감사 브랜치의 공개본 차이다. 이 두 파일은 앱 프로젝트의 패키지 리소스가 아니고, 공식 빌드는 최종 Setup에서 별도 metadata를 생성하며 보존본을 덮어쓰지 않는다. 원격 피드의 현재 유효성이나 실제 업데이트 성공을 의미하지 않는다.

## 원격 실행 기록 재확인

- 실행: [Windows final code and package audit](https://github.com/Peter-msk/Sunrise-File-Manager/actions/runs/39966890560)
- Job ID: `120458967621`. Job과 모든 표시된 단계의 결론은 `success`.
- artifact ID: `12507088374`, 이름 `windows-final-audit`.
- artifact SHA256: `b137b3eff9b143de1d2e0fbd489a8e70b1bb89c094cc27b6e6cf50d120ccc155`. GitHub 기록과 기존 상태 문서가 일치한다. 이번에 artifact ZIP을 다시 다운로드하여 해시를 계산한 것은 아니다.
- 실행 환경: Windows Server 2025 x64 VM 활성 데스크톱, 1920×1080, Windows DPI 100%, 앱 배율 80/90/125%, .NET SDK 10.0.402, Inno Setup 6.7.1.

| 검증 | 확인한 기존 결과 | 범위 |
|---|---|---|
| WPF 컴파일 | 경고 0, 오류 0 | Windows source build |
| EIASS 문서명·복구 | 117 assertions PASS | 임시 fixture, 목차·순서·미리보기·적용·Undo/Redo·종료 보호 |
| 현행 UI | 22 assertions PASS | 메모 선택 유지, 검색, 인라인 이름 변경, WIC 이미지 미리보기, 테마, 앱 배율, AI 팝업 |
| 기본 네이티브 파일 작업 | 5 checks PASS | DPAPI/journal, 이름 변경, Undo, 사본 바이트 보존 |
| 분할·스크롤 | 14개 배치 PASS | 실제 클릭 98회, 드래그 72회, 창 검사 18회 |
| 공식 회사 CMD | Setup 생성 성공 | self-contained 설치형, 회사 문서 테스트 미실행 |
| 설치된 앱 | 설치·시작·정상 종료·제거 PASS | 설치 종료 0, 앱 종료 0, 제거 종료 0, 주 EXE 제거 |
| 배포자 서명 신뢰 | PENDING | VM 시험 인증서로 서명 생성 성공, 자체서명 루트 신뢰 실패, 기존 회사 인증서 미시험 |

설치된 앱 검사는 실제 설치 EXE의 창 제목·시작·레이아웃 단축키 입력·종료를 확인한 smoke이다. 위 EIASS·일반 UI의 전체 검사를 설치된 EXE에서 다시 수행했다는 의미는 아니다. 앱 배율 125% 확인을 Windows DPI 125% 확인으로 해석하지 않는다.

검증 Setup의 기록된 SHA256는 `490ed83c56b33b8361d2580206fd06f3d3b629291f0cffd6b34b7ce24d8b5ddd`이다. 이번 전달 ZIP에는 해당 VM Setup 바이너리가 없으며 회사 CMD로 생성하는 소스 전달본이다.

## 이미 수정되어 있는 결함

1. 일반 일괄 이름 변경이 중간 실패할 때 선행 파일의 이름과 메모를 복구하도록 보완되어 있다. 혼합 파일·폴더는 전체 계획을 먼저 검사한다.
2. Undo/Redo 진행 중 종료·업데이트 이관·경쟁 파일 변경을 제한하고 작업이 끝나면 상태를 복원한다.
3. 실패한 일반 Undo/Redo 항목은 이력을 보존하여 다시 시도할 수 있다.
4. 같은 위치의 메모 저장·감시자 새로고침에서 선택과 미리보기를 유지한다.
5. 파일 위치 찾기 시 첫 페이지 앞부분이 생략되던 문제를 수정했다. 2,005개 fixture로 2,000행 경계와 페이지 밖 대상·이전 위치 커서를 검증했다.

이번 재개 작업에서 위 결함을 새로 수정한 것으로 기록하지 않는다.

## R00 변경과 증적 재사용

`CURRENT_SOURCE.md`, `RELEASE_STATUS.json`, `docs/FILE_MANAGER_CURRENT_CONTRACT.md`, 본 감사 결과 및 무결성 목록만 변경했다. 실행 코드·테스트·리소스·회사 CMD·설치 스크립트·의존성·버전·업데이트 wire는 동일하다. README는 변경하지 않았다.

상태 문서에서 과거 packaging PENDING을 현재 검증 결과와 구분했다. 과거 경량 payload 수치는 현행 self-contained Setup 측정치가 아님을 명시했다. `validation/PRE_BUILD_RESULT.json`은 v1.5.0의 역사 증거로 보존하고 v1.5.4의 사전 PASS로 사용하지 않는다.

이번은 문서와 상태 정합 변경이므로 Windows 테스트·컴파일·설치를 중복 실행하지 않는다. 원 실행 결과의 범위 안에서 `REUSED_PASS`로 참조한다. 프로그램 버전은 1.5.4, 전달 리비전만 R00이다.

## 남은 항목과 후속 기준

- 실제 회사 PC에서 기존 회사 인증서로 빌드·검증한 결과는 없다. 같은 `CN=Sunrise Group` 이름만으로 인증서 동일성이나 신뢰를 확정하지 않는다.
- 실제 업무 HWP corpus, NAS/UNC/OneDrive 공급자, 외부 앱 연동 및 모든 형식·권한·오류 조합은 미검증이다.
- 게시된 업데이트를 이전 설치본에서 다운로드·설치하는 round-trip은 미검증이다. 이번에 원격 공지·피드·릴리즈를 게시하거나 변경하지 않았다.
- 현재 판정은 `WINDOWS_DYNAMIC_VM_TARGETED_PASS_NOT_COMMERCIAL_QUALIFIED`이다. 모든 기능과 모든 환경의 무오류를 보증하지 않는다.

다음 Windows 빌드는 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`를 사용한다. 기본 self-contained Setup은 `dist/Sunrise_File_Manager_1.5.4_Setup.exe`로 생성된다. 회사 빌드에 이미 유효한 소스 테스트를 반복 추가하지 않고, 빌드 후에만 가능한 패키지·시작·치명 로그 검증을 유지한다.
