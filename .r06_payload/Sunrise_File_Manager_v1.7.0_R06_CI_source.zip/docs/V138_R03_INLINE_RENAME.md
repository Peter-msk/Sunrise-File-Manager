# Sunrise File Manager v1.3.8 R03 — 목록 내 이름 변경 UX / 확장자 설정 연동

## 기준본 및 변경 범위

- 부모 소스: `Sunrise_File_Manager_v1.3.8_R02.zip`
- 부모 SHA256: `ce915d5e0e0fd151b59f559e18a926c9f93a6dac9f1927c539befd2649380f26`
- 제품/설치 버전 **1.3.8 유지**. 동일 버전 소스 수정본 **R03**.
- 수정 범위: `ExplorerPane`의 단일 항목 이름 편집 UI, `FileEntry`의 비영속 편집 상태, `FileRenameNamePolicy`, 관련 LogicTests/정적 회귀검사.
- 기존 복수 항목 `BatchRenameDialog` 및 새 폴더/새 파일 생성 팝업은 동작 그대로 유지.

## 확정 UX 계약

1. 파일·폴더 **한 개**를 선택하고 F2, 이름 변경 메뉴 또는 도구 버튼을 실행하면 파일 목록 이름 셀에서 즉시 입력한다. 별도 `NameInputDialog`는 사용하지 않는다.
2. Enter는 저장, Esc는 취소, 편집창에서 포커스가 벗어나면 저장을 시도한다. 공백·Windows 금지문자·동명 충돌·권한 오류는 기존 검증을 우회하지 않는다.
3. **확장자 표시 OFF**(탐색창 `ShowExtensions=false`)일 때 이름 편집에 보이는 텍스트는 파일명 본체이며, 실제 파일 이름을 변경할 때 기존 확장자를 자동 결합하여 보존한다. 폴더/무확장 파일에는 가상 확장자를 추가하지 않는다.
4. **확장자 표시 ON**일 때 전체 이름을 편집란에 보이고 최초 선택은 본체만 선택한다. 사용자가 확장자를 직접 변경한 경우에만 기존 경고·확인을 유지한다.
5. 편집 시작 때 확장자 표시 설정을 스냅샷으로 고정하여 편집 도중 다른 UI 설정 변경으로 이름 의미가 변하지 않도록 한다.
6. 기존 저장 위치·메모 연결 변경·실행취소·그룹 Control·업데이트/공지 wire·서명/설치 파일명·사용자 세션 형식은 변경하지 않는다. 공지에는 다운로드 주소·배포 경로·보안 구현을 노출하지 않는다.

## 변경 파일

- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`: 이름 열을 인라인 TextBox가 있는 DataGridTemplateColumn으로 변경. 자연 정렬 키 `Name` 유지.
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml.cs`: 단일 이름 변경 팝업 제거, 편집 진입 및 편집 중 단축키 충돌 방지, 기존 일괄 이름 변경 보존.
- `source/Sunrise.FileManager/Models/FileEntry.cs`: `IsRenaming`, `RenameDraft` 런타임 UI 상태 추가(영속 저장 없음).
- `source/Sunrise.FileManager/Features/Explorer/ExplorerPane.InlineRename.cs`: 이름 편집·완료·취소·확장자 변경 경고·기존 FileActionsService/Undo 연결.
- `source/Sunrise.FileManager/Services/FileRenameNamePolicy.cs`: 확장명 숨김/표시 상태에 따른 편집 문자열 및 최종 파일명 안전 판정.
- `source/tests/LogicTests/LogicTests.csproj`, `source/tests/LogicTests/Program.cs`: 실제 C# 확장자/무확장/폴더/잘못된 입력 회귀시험 **추가(미실행)**.
- `tests/test_v138_r03_inline_rename.py`: 이벤트·단일 편집·확장자 보존·공개 계약 정적 검사 추가.

## 검증 한계

- Linux 정적 검사: Python 소스 계약/패키징/UI 소스 검사, XAML XML 파싱.
- **Windows .NET 10 컴파일, C# LogicTests, WPF F2/Enter/Esc/포커스 잃음, 1~4분할·DPI 화면, 설치/코드서명: PENDING.**
- 최종 EXE 실기 검사 전에는 'Windows에서 완전히 해결'로 판정하지 않는다.

## Windows 사용자 확인

1. 확장자 숨김: `보고서.pdf`를 선택, 화면에는 `보고서` 표시, F2에서도 `보고서`만 편집, `수정본`으로 입력하면 실제 파일 `수정본.pdf`.
2. 확장자 표시: `보고서.pdf` 전체 표시, F2 시 `보고서`만 선택되고 `.pdf`는 유지. 확장자를 `.txt`로 바꾸면 확인 경고.
3. 폴더·무확장 파일·이름에 마침표 여러 개인 파일, 우클릭 메뉴/상단 버튼, Enter/Esc/포커스 이탈, 중복 이름·권한 거부·메모 연결 파일·실행 취소.
4. 1·2·4분할, 다크/라이트, 100/125/150% DPI, 파일명 자연 정렬, Ctrl+C/X/V, 드라이브 간 이동, AI/미리보기/세션 저장 비영향.
