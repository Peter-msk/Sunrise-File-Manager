# Sunrise File Manager v1.5.1 R01 — 파일 목록 밀림·분할 후 스크롤

- 기준일: 2026-10-23 (한국시간)
- 기준본: `Sunrise_File_Manager_v1.5.1_R00.zip`
- 기준 SHA256: `59cb9b76586cd0b42b1941b0d568f59725a680ca07d9c1b92f44a2f0cc8f5850`
- 사용자 증거: `image(20261023-035608).png`, `Sunrise_20261023_125634.mp4`(약 51.8초).
- 제품 버전 1.5.1 유지, 수정 리비전 R01.

## 관찰과 원인 확인의 경계

영상에서 단일 화면→2분할 후 첫 창에 가로 막대가 보이지 않고, 중앙 파일 목록의 이름·열 내용이 표시 영역에서 사라지는 현상을 확인했다. 두 번째 창에서는 가로 이동이 가능하다. 이는 직전 요청의 좌측 폴더 트리와 다른 파일 목록(DataGrid) 영역이다.

소스에서 확인한 결함/위험 경로:

1. 포인터 선택 시 가로 위치 보호를 `!_compactMode`에서만 적용하여 분할 창은 제외되어 있었다.
2. 내부 ScrollViewer를 `??=`로 장기 캐시하여 재부착/템플릿 갱신 뒤 분리된 인스턴스를 참조할 수 있었다.
3. 분할 전환 시 기존 ExplorerPane을 제거 후 재부착하지만 파일 목록의 스크롤 범위를 새 크기에서 다시 확인하는 경로가 없었다.
4. 파일 목록은 열 가상화를 사용하고 가로 막대는 Auto여서, 재측정·열 실현 상태가 잘못된 경우 빈 내용/막대 부재를 관찰하기 어렵다.

위 코드는 소스에서 확인했다. 다만 이 환경에서 실제 Windows 재현을 실행하지 못했으므로 어느 경로가 영상의 지속 이동을 최초 유발했는지 단일 원인으로 확정하거나 수정 후 실기 해결을 주장하지 않는다.

## 수정

- 파일 목록 포인터 선택의 compact-mode 제외 조건 제거. 단일/분할 모두 현재 가로 위치 보호.
- 내부 ScrollViewer는 현재 visual tree에서 매번 해결. 오래된 객체의 장기 캐시 제거.
- FilesGrid의 Loaded/SizeChanged와 SetCompactMode에서 한 번으로 합쳐진 Loaded-priority 재측정 수행. 현재 ScrollViewer의 범위를 갱신하고 실제 단일↔분할 모드 변경 때 가로 시작점을 맞춘다. 초기 세션 복원이 대기 중이면 세션 위치가 우선한다.
- 재부착/모드 전환에서 이전 포인터 지연 작업을 무효화하고 진행 중 marquee와 가장자리 자동 스크롤을 종료.
- 파일 목록 가로 막대 Visible로 표시 공간 확보. 콘텐츠가 폭 안에 들어오면 이동 범위는 0이다.
- 파일 목록의 열 가상화만 해제. 열 수가 제한된 목록이므로 모든 열을 실현하고 행 가상화/재활용은 유지한다. 전역 DataGrid/AI 테이블 설정은 바꾸지 않았다.
- 새 재측정은 ScrollChanged/주기 타이머에 연결하지 않는다. 수동 가로 스크롤마다 0으로 되돌리거나 전역 레이아웃을 반복 재작성하지 않는다.

변경 production 파일: ExplorerPane.xaml, ExplorerPane.xaml.cs, ExplorerPane.MarqueeSelection.cs, ExplorerPane.ViewAndFiltering.cs 및 새 local partial ExplorerPane.FileViewport.cs.
R00의 FolderTree 세 파일은 바이트 그대로 유지한다. 파일 IO·메모·사용자 설정 형식·설치·업데이트 런타임도 바꾸지 않았다.

## 검증

| 항목 | 결과 |
|---|---|
| 변경 관련 Python 소스/회귀 | 30 tests PASS |
| 앱 XAML/CSProj 파싱 | 14개 PASS |
| 기본 빌드 CMD·설치 스크립트·버전·기존 게시 스냅샷 보존 | PASS |
| Windows 대상 C#/WPF 컴파일 | PENDING |
| 실제 영상 재현 및 수동 클릭/Shift+휠 | PENDING |
| 새 실제 WPF 자동 재현 시나리오 | 작성, 실행 PENDING |

실제 WPF 시나리오는 한 창→두 창→한 창→두 창을 반복하며 기존 첫 창의 재사용, 각 파일 목록의 viewport/extent, 가로 막대, 좌우 이동, 유휴 상태에서의 위치 안정성, x=0에서 실제 파일명 TextBlock 좌표를 검사한다. 임시 폴더와 생성한 세 항목만 사용하며 사용자 문서를 읽지 않는다.

필요 시 Windows에서 관련 동작만 선택 실행한다(전체 UI 테스트가 아님):

```bat
dotnet run --project source\tests\UiSmokeTests\UiSmokeTests.csproj --configuration Release -- --file-scroll-only validation\windows-file-scroll-r01
```

이 경로는 `BUILD_ON_WINDOWS_COMPANY.cmd`에 연결하지 않았다. 이미 유효한 사전 PASS를 Windows 기본 빌드에서 반복하지 않는다.

## 전달과 확인

일반 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`.
목표 출력: `dist/Sunrise_File_Manager_1.5.1_Setup.exe`.

새 설치본에서 ① 기존 단일 창의 파일 목록 표시 ② 2분할 후 첫째/둘째 창 가로 막대와 좌우 이동 ③ 행 클릭·폴더 열기·뒤로 이동 후 이름 표시 ④ 무입력 상태의 지속 밀림 없음 ⑤ 좌측 폴더 트리 가로 스크롤을 확인한다.

정적 소스 검사는 이 Windows 실기 확인을 대신하지 않는다. 원격 게시 또는 새 Windows 설치파일 생성은 수행하지 않았다.
