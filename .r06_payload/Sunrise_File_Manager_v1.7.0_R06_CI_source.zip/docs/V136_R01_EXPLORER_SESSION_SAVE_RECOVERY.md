# Sunrise File Manager v1.3.6 R01 — 탐색기 화면 설정 저장 재발 방지

## 1. 기준본 및 범위

- 부모 기준본: `Sunrise_File_Manager_v1.3.6_R00.zip`
- 제품 및 설치 버전: **1.3.6 유지**. 배포용 동일버전 수정 리비전: **R01**.
- 사용자 오류: 종료 시 `화면 설정을 저장하지 못했습니다. 탐색기 설정 값이 올바르지 않습니다.`
- 원본·사용자 설정·메모·AI 데이터·업데이트·Control·설치 식별자는 변경/삭제하지 않음.

## 2. 코드 분석 및 수정

- 경고는 `MainWindow.TrySaveSession()`에서 `SessionStore.Save()`의 탐색기 설정값 검증 예외가 전달되어 표시됨.
- 이전 `ExplorerPane.GetSession()`은 `FilesGrid.Columns.Select(column => column.DisplayIndex).ToList()` 값을 가공하지 않고 기록함.
- WPF 비활성/아직 초기화되지 않은 `DataGrid`는 열의 `DisplayIndex=-1` 또는 임시 중복 순서를 보고할 수 있으며, 기존 `Validate()`는 이를 거부함. AI 결과표에는 이미 `CaptureDisplayOrder()` 보호가 적용되었으나 탐색기에는 누락되었음.
- 수정: 탐색기에도 공통 `SessionStore.CaptureDisplayOrder()`를 적용하여 정상 사용자 재배열은 보존하고 초기화되지 않은 상태에만 기본 순서를 사용함.
- 탐색기 열 너비에는 기존 `CaptureColumnWidth()`를 동일하게 적용하여 WPF가 잠시 내놓는 비정상/과대 너비를 저장 전 정규화함.
- 탐색창 너비는 `NavigationPanelPolicy.NormalizeWidth()`로, 트리/파일목록 스크롤은 새 `CaptureScrollOffset()`으로 정규화함. 유효한 사용자 설정값은 바꾸지 않음.
- 검색 입력 TextBox에 기존 저장 계약의 최대 1000자 제한을 반영하여 수집/저장 불일치 방지.
- `SessionStore.Validate()`는 여전히 잘못된 영구 데이터/열 중복을 거부함. 다만 향후 오류 원인 추적을 위해 검색·트리·너비·스크롤·열 너비·열 순서 등 필드별 메시지로 구분함.

## 3. 변경 파일

- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml.cs`
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`
- `source/Sunrise.FileManager/Services/SessionStore.cs`
- `source/tests/LogicTests/V132FeatureTests.cs`
- `tests/test_v136_r01_session_exit.py` (추가)
- `tests/test_v132_navigation_session_contracts.py` (구현 변경에 맞는 현행 판정으로 갱신)
- `tests/test_v136_r00_resizable_navigation.py` (가변 너비 저장 판정 갱신)
- `CURRENT_SOURCE.md` 및 본 인수인계 문서

## 4. 소스 검증

- Python 소스 계약 회귀: **221/221 PASS**.
- 패키징 계약: **15/15 PASS**.
- XAML 13개 파일 XML 파싱: **PASS**.
- C# `LogicTests`에는 분할창 4개 중 3개 비활성 그리드의 DisplayIndex=-1 상황과 사용자 재배열 보존/열 너비/스크롤 정규화 후 세션 저장·재열기 검사를 추가함.
- Windows .NET 10 컴파일, WPF 실제 UI 종료 및 재실행, 실제 설치파일 테스트는 수행하지 않았으므로 **PENDING**. C# 테스트도 Windows 빌드 환경에서 실행할 것.

## 5. Windows 재확인 (최소 Gate)

1. 기존 설치본 사용자 설정은 삭제하거나 초기화하지 않는다. R01 소스로 `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다.
2. 1/2/4분할 각각에서 탐색창 너비를 변경하고 자동 숨김 모드도 조작한다.
3. 비활성 분할창을 펼치지 않거나 탭을 전환한 직후 정상 종료한다. **경고창이 나타나면 실패**.
4. 재실행 후 탐색창 너비, 기존 파일열 순서·너비, 정렬·탭·스크롤이 정상 복원되는지 확인한다.
5. 사용자가 직접 변경한 열 배치가 초기화되지 않는지 별도로 확인한다.
6. 여전히 실패하면 `화면 설정을 저장하지 못했습니다` 이하의 구체화된 필드 메시지와 `session.json`의 민감 경로를 제거한 진단 정보를 비교한다. 오류를 무조건 숨기지 않는다.

## 6. 변경영향 및 미수행 사항

- 파일 복사·이동·삭제·AI·PDF 미리보기·탐색/드롭다운·테마·Sunrise Control·원격 wire·서명 파이프라인 수정 없음.
- `release/NOTICE_BODY_1.3.6.txt`와 공개 공지 내용 변경 없음. 공지사항에 다운로드 경로 또는 보안·배포 내부정보를 노출하지 않음.
- 빌드에서 이미 PASS한 독립 소스 검사를 중복 실행하도록 빌드 게이트를 확장하지 않음.
- 실행 결과 부재로 최종 Windows 릴리즈 승인/문제 완전 해소를 주장하지 않음.
