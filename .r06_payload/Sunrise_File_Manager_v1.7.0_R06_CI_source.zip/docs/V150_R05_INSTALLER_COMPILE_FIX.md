# Sunrise File Manager v1.5.0 R05 — 설치 스크립트 오류 수정

- 기준일: 2026-10-23 (한국시간)
- 기준 소스: `Sunrise_File_Manager_v1.5.0_R04(2).zip`
- 기준 SHA256: `2104c1712c753632a7121ecfdbb06e552db8087928fc44e522a646d29da393b1`
- 진단 로그: `Sunrise_File_Manager_v1.5.0_R04(1).zip`
- 제품 버전: `1.5.0` 유지. 수정 전달 리비전: `R05`.

## 실제 실패 원인

`R14_BUILD_RESULT.txt`는 `STATUS=SUCCESS`, `STAGE=INSTALLER_PAYLOAD_READY`이며,
`R15_payload_build.log`도 `STATUS=SUCCESS`이다. 본체 게시·서명 후
`R15_INSTALLER_BUILD_RESULT.txt`의 `STAGE=INSTALLER_COMPILE`에서 실패했다.

`R15_inno_compile.log`의 직접 오류:

```text
Error on line 86 ... installer\SunriseFileManager.iss: Column 1:
'BEGIN' expected.
Compile aborted.
```

`[Code]`는 Pascal 영역인데 86행이 INI 구역의 `;` 주석으로 작성되어 있었다.
이 주석은 `#if Lightweight == "1"` 바로 앞에 있어 기본 빌드에서도 컴파일된다.

```diff
-; Only the optional legacy lightweight build may require a shared runtime.
+// Only the optional legacy lightweight build may require a shared runtime.
```

공식 문서: https://jrsoftware.org/ishelp/topic_scriptcreating.htm

## PDF·문서 파일 확인

- 소스의 `source/tests/LogicTests/Fixtures/`에는 PDF/HWP/HWPX/DOCX 개발용 샘플이 있다.
- 기본 진입점은 `BUILD_ON_WINDOWS_COMPANY.cmd` → `BUILD_RELEASE_INSTALLER.cmd` → `BUILD_RELEASE_ONEDIR.cmd --company --no-pause --installer-payload`이다.
- 본체의 `source/Sunrise.FileManager/Sunrise.FileManager.csproj`만 publish한다. 테스트 프로젝트 참조가 없고 형제 폴더의 Fixtures는 앱 프로젝트 입력이 아니다.
- 기본 Windows 빌드에서 LogicTests나 문서 열기·변환 테스트를 실행하지 않는다. 기존 `PublishDocumentationFiles=false` 설정도 유지한다.
- 설치 스크립트는 게시된 app 디렉터리와 라이선스 고지만 포함한다. 개발 문서·샘플을 설치파일에 추가하지 않았다.
- 소스 샘플 삭제나 PDF 검색·미리보기 기능 제거는 하지 않았다. PdfPig DLL은 앱 기능에 필요한 의존성으로 유지한다.

## 수정·검증 범위

기능 코드 변경은 없고 설치 스크립트 주석 1행만 수정했다.
추가 파일은 재발 검사와 본 인수인계 기록이며, 현재 소스 표기·릴리즈 상태·소스 해시 목록을 갱신했다.

실행 결과:

| 검증 | 결과 |
|---|---|
| 신규 주석 재발 검사 | 3 tests PASS |
| R04 배포구조 관련 검사 | 6 tests PASS |
| 설치파일 계약 검사 | 11 tests PASS |
| 기존 패키징 계약 | 18 checks PASS |
| 기존 잘못된 주석을 메모리에서 재삽입 | 86행 결함 검출 PASS |
| C#/XAML/CSProj/CMD 원본 비교 | 모두 바이트 동일 |
| 새 R05 Windows Setup 컴파일·서명·설치·실행 | PENDING |

회귀 검사는 개발자가 사전에 실행하는 Python 검사이며 Windows 빌드 경로에 연결하지 않았다.
수정과 무관한 전체 기능 검사는 재실행하지 않았다. `validation/PRE_BUILD_RESULT.json` 및 이전 보고서는 과거 체크포인트 증적이며 R05 전체 검증 완료를 의미하지 않는다.

## Windows 재빌드

1. R05 ZIP을 새 폴더에 압축 해제한다.
2. `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행한다.
3. 성공 시 `dist/Sunrise_File_Manager_1.5.0_Setup.exe`를 확인한다.
4. 실패 시 `build-logs/R15_INSTALLER_BUILD_RESULT.txt`와 `build-logs/R15_inno_compile.log`의 새 결과를 확인한다.

기존 R04 작업폴더에서 최소 수정으로 적용하려면 `installer/SunriseFileManager.iss`만 교체해도 동일한 실행 코드 수정이 적용된다.
신규 검사와 기록까지 포함한 기준본 관리에는 전체 R05 소스를 사용한다.
기존 정상 배포 Setup과 사용자 설정·메모·문서는 삭제하지 않는다.
