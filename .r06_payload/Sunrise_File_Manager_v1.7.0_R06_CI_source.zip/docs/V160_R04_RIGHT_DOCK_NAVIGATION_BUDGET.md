# Sunrise File Manager v1.6.0 R04 — 우측 공용 패널 재확인 및 좁은 분할창 탐색 영역 최적화

- 작업 기준: `Sunrise_File_Manager_v1.6.0_R03.zip` (SHA-256 `4e0193882babe9c139fa0eeb7d47fbd71743fcbdeda9165c7c9e07c753007ded`)
- 제품 버전: **1.6.0 유지**, 동일 버전 후속 코드 수정본 **R04**
- 배포 방식: Windows x64 WPF .NET 10 self-contained 설치형
- 상태: **SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING**. Windows WPF 컴파일, 실제 렌더링, Setup 및 그룹서명은 이 환경에서 수행하지 않음.

## 1. 요청 확인 — 우측 공용 패널, 하단 배치 금지

소스 `MainWindow.xaml` 구조를 직접 감사했다. 화면 최상위 Grid는 **0=상단 명령, 1=전송 도구, 2=파일 작업공간 + 우측 유틸리티, 3=작업 상태줄**로 구분된다.

- `WorkspaceShell`: `Grid.Row=2`.
- 작업공간 `FileAreaShell`: `Grid.Column=0`.
- 상세정보 `FileDetailsPanel`: `FileAreaShell`의 `Grid.Column=2` (**오른쪽**).
- 메모 `FileMemoPanel`: `FileAreaShell`의 `Grid.Column=4` (**오른쪽**).
- 미리보기 `FilePreviewPanel`: 외부 `WorkspaceShell`의 `Grid.Column=2` (**오른쪽**).
- 도구 레일: `WorkspaceShell`의 `Grid.Column=3`, 최우측.
- `Grid.Row=3`은 진행 상태·일시 중지·취소 표시 영역으로, 상세정보/메모/미리보기 UI 컨트롤이 없음.

1~4분할에서 이 세 보조패널 컨트롤 인스턴스는 종류별 **각 1개**이며 활성 분할창의 선택 파일에 연결된다. 화면 하단에 생성하는 변경 없음. 단독/동시 보기의 사용자 선택도 유지한다.

## 2. 실제 UI 개선 — 좁은 분할에서 트리보다 파일 목록 우선

`Services/NavigationPanelPolicy.cs`의 고정 탐색 트리 표시 폭 상한을 개선했다.

- 기존 고정 트리 최대폭 공식: `paneWidth - RailWidth(22) - 116`.
- R04 고정 트리 최대폭 공식: `paneWidth - RailWidth(22) - MinimumFileAreaBudget(176)`.
- 최소 탐색 트리 표시 폭 145 DIP, 넓은 화면 최대 520 DIP, 기본 설정 272 DIP는 모두 유지.
- 자동 숨김 트리는 화면 위로 표시되는 오버레이이므로 종전 `35 DIP` 제한식을 유지.
- 예시: 탐색창 350 DIP, 저장 트리 272 DIP인 경우 기존 고정 표시 트리 212 DIP → R04 표시 트리 152 DIP. 이때 확보하는 파일 목록 측 너비는 약 60 DIP.
- `NavigationPanelPolicy.FitWidth`는 표시 계산만 수행하므로 저장된 `TreeWidth`, `TreeVisible`, `TreeAutoHide`를 바꾸지 않는다. 창 또는 분할 폭이 넓어지면 설정된 트리 폭을 다시 표시한다.
- `ExplorerPane`의 `SizeChanged → ApplyResponsiveLayout → ApplyNavigationState` 기존 경로를 재사용하므로 별도 타이머/전역 상태 추가 없음.
- 파일 목록이 차지하는 실제 픽셀 폭은 WPF border/grid/OS DPI 등에 영향받으므로 Windows 실기 검증 대상으로 둔다.

## 3. 변경 격리

수정 런타임: `source/Sunrise.FileManager/Services/NavigationPanelPolicy.cs` 1개.

검증 보완: `source/tests/SplitLayoutTests/Program.cs`, `source/tests/UiSmokeTests/CurrentUiAudit.cs`, `source/tests/UiSmokeTests/Program.cs`, `source/tests/test_v160_r04_right_dock_navigation.py`.

기존 `MainWindow.xaml(.cs)`·`ExplorerPane.xaml(.cs)`·NavigationDrawer·SessionStore·FileMemoStore·RecycleBinService·빌드 CMD 등은 R03과 해시 동일함을 확인. 기존 14개 분할 배치·파일 복사/이동·Undo/Redo·EIASS·AI·압축·메모 보호와 업데이트/서명 wire 계약 비침범.

## 4. 검증 결과

- R00~R04 전용 Python 소스 검사 **26/26 PASS** (R04 신규 5건 포함).
- 모든 XAML XML 구조 파싱 **15/15 PASS**.
- 동일 전체 Python unittest 비교: 부모 R03 **88 tests, 12 FAIL + 4 ERROR**, R04 **93 tests, 같은 12 FAIL + 4 ERROR**. **신규 실패·오류 0**. 이전 실패 16건은 해결했다고 기록하지 않는다.
- R04 실제 C# `SplitLayoutTests` 및 WPF UI runtime은 현 환경에 dotnet/Windows가 없어 실행하지 못했음. Windows 검증용 경로만 추가함.
- ZIP 완전성·파일별 SHA-256은 패키징 후 검사.

### 필수 Windows 실기 검증

```powershell
dotnet run --project source/tests/SplitLayoutTests/SplitLayoutTests.csproj
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --right-dock-only validation/windows-right-dock-r04
```

최소창 1010×560, 1/2/4분할 및 전체 14개 배치, 고정 트리/자동 숨김, 열 너비/가로 스크롤, 공용 오른쪽 패널 각 1개, 메모 미저장 취소, 패널 열기/닫기 후 공간 반환, 100/125/150% Windows DPI, 80/125% 앱 배율을 직접 확인한다. Windows 실행 결과가 없으면 승인 상태는 PENDING.

공식 빌드는 변경 없는 `BUILD_ON_WINDOWS_COMPANY.cmd`를 사용한다. 예정 설치파일은 `dist/Sunrise_File_Manager_1.6.0_Setup.exe`이며, 회사 그룹서명과 실제 설치·실행·메모·세션 보존 확인이 끝나기 전 배포하지 않는다. 원격 latest.json/notice.txt, GitHub와 Google Drive 공식 릴리즈 자산을 자동으로 갱신하지 않는다.
