# Sunrise File Manager v1.3.3 — UI·종료 오류 패치 인수인계

## 기준 및 범위
- 부모: 사용자가 제공한 `Sunrise_File_Manager_v1.3.2.zip`. 기존 ZIP을 직접 변경하지 않고 작업본에서 수정.
- 버전: 코드·Control·Inno Setup의 제품 버전 및 배포 템플릿을 1.3.3으로 일치시킴.
- 변경: 다음 4건 이외의 파일 조작/검색/전송/메모/보안/Control/업데이트 규칙 미변경.

## 변경 사항과 원인
1. **라이트 탐색 레일**: `ThemeSplitter`를 레일에 재사용해 밝은 테마에서도 짙은 회색/푸른 레일이 보임. 레일 소유의 `ThemeNavigationRail`/`ThemeNavigationRailText` 리소스를 만들어 라이트 색을 조정하고 다크색은 이전과 동일하게 고정. 자동 숨김·열고 닫기 UI 22 DIP 레일 및 272 DIP 고정 폭 유지.
2. **드라이브 화살표 조작성**: 이전 트리 토글이 15×22 DIP, 글리프 12포인트여서 클릭이 어려움. 클릭 타깃 26×28 DIP, Path 글리프와 hover 상태를 적용. `IsExpanded` 양방향 바인딩과 실제 디렉터리 지연 로딩은 유지.
3. **모든 메뉴 구분선**: WPF 메뉴/하위 메뉴/우클릭 공통 `SunriseMenuSeparator`를 12 DIP 행과 2 DIP의 앨리어싱 없는 선으로 조정. 양쪽 여백 7 DIP, 수평 Stretch, 80% 메뉴 배율에서도 선이 잘리지 않도록 조정. 과거 9/1 픽셀값을 강제하던 소스 테스트는 새 계약으로 갱신.
4. **종료 시 화면 설정 경고**: 종료 경로는 `Window_Closing → TrySaveSession → AiPanel.GetPreferences → SessionStore.Save/Validate`. 미표시 DataGrid의 `DisplayIndex`가 -1일 수 있고 초기 로딩이나 임시 재배열 중 중복일 수 있어 세션 검증에서 `AI 결과 열 설정이 올바르지 않습니다` 오류가 날 수 있음. UI 캡처에서 유효 순서면 보존, 아니면 자연 순서(0...N-1)로 정상화. 비정상 열 너비도 값 범위에 맞춰 정상화. 유효하지 않은 외부 세션을 엄격하게 검증하는 SessionStore 규칙은 유지. 실제 디스크 쓰기 실패는 계속 오류로 취급(조용히 무시하지 않음).

## 영향 파일
- `source/Sunrise.FileManager/App.xaml`
- `source/Sunrise.FileManager/Controls/ExplorerPane.xaml`
- `source/Sunrise.FileManager/Services/ThemeManager.cs`
- `source/Sunrise.FileManager/Controls/AiCommandPanel.xaml.cs`
- `source/Sunrise.FileManager/Services/SessionStore.cs`
- 기존 테스트 `source/tests/LogicTests/V132FeatureTests.cs`, `tests/test_v132_navigation_session_contracts.py`, 신규 `tests/test_v133_ui_exit_fixes.py`
- 버전 관련 `.csproj`, Control version, MainWindow 제목, 빌드 배치, 인스톨 버전, 릴리스 공지 템플릿과 버전 계약 테스트

## 수행한 검사
- Python 소스계약 184개: **PASS**
- 소스 UI 구조계약 19개: **PASS**
- 패키징 정적계약 15개: **PASS**
- 모든 WPF XAML XML 파싱: **PASS**
- Windows 빌드 배치 CRLF 확인: **PASS**

## 미수행/릴리즈 대기
- 이 런타임에는 .NET 10 SDK 및 Windows/WPF 실기가 없으므로 .NET compile/LogicTests 실행, 메뉴 렌더링·드라이브 클릭 테스트, 100/125/150% DPI, 종료 후 재시작/설정 roundtrip, 설치파일 빌드/서명은 **PENDING**. 이전 v1.3.2의 PRE_BUILD 검증 결과를 v1.3.3 PASS로 승계하지 않음.
- Windows에서 `BUILD_ON_WINDOWS_COMPANY.cmd`로 실제 signed Setup 생성 후 확인. 예상 아티팩트: `dist/Sunrise_File_Manager_1.3.3_Setup.exe`.
- `latest.json`, `notice.txt`, `release/PUBLISHED_RELEASE.json`은 기존 공개 게시 스냅샷을 보존. 업로드/게시/원격 정책 변경 수행하지 않음. 릴리스 승인 전 공개 최신 버전으로 승격하지 않음.
- 추천 실기: 라이트/다크에서 탐색창 최소화 → 드라이브 펼침 클릭 → 파일/편집/보기/설정/우클릭 메뉴 구분선 → AI 미사용 및 사용 후 종료와 설정 복원 → 4분할 파일 선택/드래그 회귀.
