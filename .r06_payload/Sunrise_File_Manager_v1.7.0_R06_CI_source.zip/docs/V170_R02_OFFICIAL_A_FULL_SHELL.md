# Sunrise File Manager v1.7.0 R02 — 공식 A안 셸 UI 실제 코드 반영

## 기준·설계 소유권

- 직접 부모: `Sunrise_File_Manager_v1.7.0_R01.zip` / SHA-256 `8ce0804a9adf5095379c8a588dbf2f58de859648c0eba578d7306a6a10a13d5d`.
- A안 원안: `Sunrise_File_Manager_v1.6.0_UI_A_multi_pane.png`, `Sunrise_File_Manager_v1.6.0_UI_3안_정밀설계서.md`.
- 최신 사용자 결정 우선: **분할 전송 상시 막대 삭제 유지**, 단일 즉시 적용, 2·3·4분할 2/6/5개 목록 드롭다운, 오른쪽 공용 상세정보·미리보기·메모 각각 1개, 기존 기능 보존.
- 버전 `1.7.0` 및 세션 포맷, 설치/Preview/Control, 업데이터와 서명 체인은 변경하지 않는다. 소스 리비전만 R02.

## 기존 R01과 다른 실제 구현

| 영역 | R01 | R02 |
|---|---|---|
| 상단 제품 식별 | 흰색 헤더와 명령 한 줄 | Sunrise 남색 브랜드 리본(34 DIP), 작업 선택 줄(38 DIP), 업무별 명령 한 줄(40 DIP) |
| 주요 업무 | AI 버튼과 설정 메뉴 위주 | `파일 관리` / `문서·EIASS` / `AI 정리` / `압축·도구` 4개 **동작하는 업무 도구 모드** |
| 주요 명령 | 각 분할창의 메뉴까지 이동 | 파일 관리: 새 폴더, 이름 변경, 복사, 잘라내기, 붙여넣기, 삭제, 실행 취소, 검색·필터 |
| 전문 문서 | 하위 메뉴를 거쳐 EIASS | 문서 도구: EIASS 제출용 이름, 미리보기, 스마트 메모, 상세정보, 본문 검색·필터 |
| AI | 상단 AI 버튼/오른쪽 레일 | AI 도구: AI 정리, AI 연결·설치, 스마트 메모, 복구 기록. 사용자 승인 전 파일 작업 금지 계약 그대로 |
| 압축·관리 | 각 분할창 메뉴 | 도구: ZIP 압축, 압축 풀기, 분할창 맞바꾸기, 폴더 동기화, 복구 기록 |
| 분할 | R01의 14개 배치 메뉴 | 동일 엔진과 메뉴, 업무 모드와 분리된 상단 오른쪽 위치 |
| 주 작업공간 | 공용 패널 소유 | 동일. 단일 메모·상세정보·미리보기와 활성 창 동기화 유지 |
| 기능의 소비 경로 | 각 ExplorerPane 개인 메뉴 | 기존 개인 메뉴 + 공용 문맥 명령. 공용 명령은 **활성 ExplorerPane의 기존 구현**만 호출 |

새 독립 파일 작업 엔진이나 새 메모 저장소를 만들지 않았다. 화면 업무 모드는 단순한 명령바 노출 상태이므로 모드 전환이 분할창·파일 목록·선택·저장 상태를 건드리지 않는다. 기존 UI를 대량 삭제/복원하지 않고 `MainWindow.xaml`의 상단과 테마만 집중 개선한다.

### 공간 정책

- 상단은 정확히 34+38+40 = **112 DIP** 세 줄이다. 4분할에서는 스크롤바가 필요한 명령을 가로로 찾되 **줄바꿈하지 않는다**.
- 기존 54 DIP 오른쪽 아이콘 전용 레일/공용 패널의 열과 닫힘 시 0 DIP 분할선/패널 폭을 유지한다.
- 하단은 **진행 상태·일시중지·취소 전용**이다. 메모·상세정보·미리보기를 하단에 생성하지 않는다.
- 중앙 탐색창의 탭/폴더 트리/주소/세부 목록·모든 14개 배치·분할 트랙 최소 크기·사용자 저장 열 너비는 그대로 보존한다.
- `분할창 간 전송` 고정 막대는 **재도입하지 않는다**. 파일 복사·이동은 기존 잘라내기/붙여넣기·드래그·기존 메뉴 경로를 사용한다.
- Native Window chrome(닫기/최소화/최대화)를 유지하여 임의로 커스텀 캡션 버튼을 만들지 않는다.

### 모듈별 변경 범위

- `MainWindow.xaml`: 셸 세 구역과 문맥 명령 버튼, 기존 패널 위치 유지.
- `Features/Workspace/MainWindow.OfficialAShell.cs` (신규): 모드 표시/활성 분할창 명령 라우팅. 빈 상태·작업 중 guard 적용.
- `Features/Explorer/ExplorerPane.OfficialAShell.cs` (신규): 새 작업 처리기를 만들지 않고 기존 클릭 핸들러를 공유.
- `App.xaml`, `Services/ThemeManager.cs`: 라이트/다크용 셸 전용 색상 6개 및 버튼 스타일. 폴더 트리/기존 콘텐츠 팔레트의 하위 계약 침범 없음.
- `MainWindow.xaml.cs`: 기본 파일 관리 도구 모드 초기화.
- 현행 정적 UI 테스트 중 R01의 **상단 한 줄 구조를 강제했던 2개 검사**를 새로운 고정 3단 셸의 공간·스크롤·분할 버튼 접근성 검사로 갱신. 그 외 구형 검사를 삭제하지 않음.
- `source/tests/UiSmokeTests/OfficialAShellAudit.cs` (신규), `Program.cs`: Windows 실제 렌더링·업무 모드 버튼 클릭·4분할/공용 패널/화면 캡처 테스트 플래그.

## 검증 / 통과 범위

| 검증 | 상태 |
|---|---|
| 현행 source Python | **134/134 PASS** (신규 공식 A 셸 계약 7건 포함) |
| 루트 제품·빌드 Python | **286/286 PASS** |
| 합계 | **420/420 PASS / 0 FAIL / 0 ERROR** |
| XAML 파일 파싱 | **15/15 PASS** |
| MainWindow.Click 실제 선언 / C# 처리기 존재 | **30개 함수 연결 확인** (정적) |
| `BUILD_PREVIEW_ON_WINDOWS.cmd`, 설치 빌드 CMD, Control/메모/파일 엔진 | **부모 원본 바이트 유지** |
| Windows WPF C# 컴파일·렌더링·DPI·키보드·마우스 | **PENDING** |
| Preview 실제 EXE/ZIP, Authenticode/Setup | **PENDING** |

**중요:** Windows 실제 빌드/GUI 캡처가 없으므로 공식 이미지와 픽셀 단위로 동일하다는 주장이나 Windows UI `PASS` 판정을 하지 않는다. 특히 기존 1~4분할별 내부 메뉴 반복은 사용자 기능 삭제 위험이 있어 보존했으며, 스펙 원안의 **하나의 전역 폴더 트리 구조로 전환한 것은 아니다**. 본 R02는 공식 A안의 공통 메인 셸과 업무별 명령 체계를 실제 구현한 판본으로 한정한다.

## Windows Preview 검증

```bat
BUILD_PREVIEW_ON_WINDOWS.cmd
```

설치 전 EXE 확인 후 Windows native audit:

```powershell
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --official-a-shell-only validation/windows-official-a-r02
```

검증 대상: `official-a-files.png`, `official-a-documents.png`, `official-a-ai.png`, `official-a-tools.png`, `official-a-four-pane.png` 스크린샷 및 `UI_RESULT.json`.
라이트/다크, 1520×930과 최소 1010×560, OS DPI 100/125/150%, UI 배율 60~125% 추가 점검. 메모 이탈 취소·활성 분할창 동기화·EIASS 확인창·파일 변경은 테스트용 사본으로만 실행.

공식 설치형은 `BUILD_ON_WINDOWS_COMPANY.cmd`; 그룹서명·실기·설치 테스트 완료 전 원격 feed와 GitHub/Drive 공개본은 변경하지 않는다.
