# Sunrise File Manager v1.5.0 R01 — P1/P2/P3 개발 인수인계

- 작업 기준: `Sunrise_File_Manager_v1.5.0_R00.zip` 전체 소스, **R00 보존**
- 작업 후 후보: `Sunrise_File_Manager_v1.5.0_R01.zip` (소스 전체)
- 제품 실행 버전: **1.5.0 유지** (동일 버전 소스 수정 리비전 R01)
- 외부 런타임/EXE/NuGet 신규 추가: 없음
- 빌드 자격: **SOURCE_STATIC_VALIDATED / CSHARP_EXECUTION_PENDING / WINDOWS_RELEASE_PENDING**
- 범위: 사용자 요청의 P1, P2, P3 모두 개발 착수 및 최초 구현. 이 문서는 전체 Windows 탐색기 기능 구현 완료를 뜻하지 않음.

## 개발 적용 사항 및 현행 제한

| 우선순위 | 기능 | 구현 연결 | 남은 제한/Windows 검증 |
|---|---|---|---|
| P1 | Windows ShellNew 새 파일 템플릿 | 파일 메뉴 → `Windows 등록 문서 만들기`; HKCR ShellNew의 `NullFile`, `Data`, `FileName`만 인식. 임의 `Command`/`Handler` 실행 금지, 파일 이름 충돌 시 다른 이름 사용, 작업 취소/실패 시 생성 중인 대상만 정리 | 특정 응용프로그램의 Shell extension/COM 생성기, 외부 실행형 템플릿 미지원. PC별 등록 항목 확인 필요 |
| P1 | 독립 다중 창 | 설정·기능 → `새 독립 창 열기`, Ctrl+Shift+W. 같은 프로세스 안에서 최대 4개 창, 창별 ExplorerPane/선택/일시 작업 분리, 부모 창 종료 시 다른 창 계속 사용, 최종 창 종료 시 종료 | **보조 창은 현재 세션 중에만 유지**. 독립 창 다중 세션의 재시작 자동 복원은 미구현. 테마/화면 배율 등 제품 기반 설정은 공유될 수 있음 |
| P2 | 휴지통 고급 | 휴지통 목록 우클릭 → `선택 항목 영구 삭제…`. Windows Shell에서 항목 ID 재일치 확인 후 `delete` 동사로 요청, 명시적 경고/승인, 최대 100개, 강제 원본 경로 삭제 없음 | Shell 동사는 Windows 환경 차이가 있을 수 있음. **요청 건수는 삭제 완료 보증이 아님**. 삭제 후 목록 변화 확인, 실패·예외 시험 필요. 휴지통 전체 비우기는 미구현 |
| P2 | 속성 검색 확장 | 공통 ExplorerQuery에 `extension:`, `filename:`, `path:`, `folder:`, `type:`, `datemodified:`, `datecreated:`, `date:`, `is:hidden/readonly/memo/file/folder` 추가. 하위 폴더 순차 검색에도 동일 파서 적용 | Windows AQS 전체 구문이 아닌 **명시한 일부 속성 필터**. Windows 인덱스는 일반 검색어만 지원하며 속성 식은 하위 폴더 범위로 유도. 특성별 실제 검색 smoke 필요 |
| P3 | ZIP 내부 파일 편집 | 기존 압축 내용 창에서 파일 추가/선택 교체/선택 삭제. ZIP만 대상, 512MiB 상한, 20,000개 항목/8GiB 확장 제한, 링크·경로이탈 검사, 임시 ZIP → 재열기 → 원본 SHA 재확인 → `File.Replace` 백업 교체 → 결과 재열기. UI 승인 필수 | 문서의 **내용을 직접 타이핑하여 편집하는 편집기**는 아님(로컬 파일을 ZIP 항목으로 교체). 암호 ZIP, 7z/RAR/TAR의 내부 쓰기는 제외. 공유/잠금/코드페이지/장기 작업 Windows 시험 필요 |
| P3 | 강제 종료 후 전송 복구 | 파일 전송 전 `%LOCALAPPDATA%/Sunrise/FileManager/transfer-recovery/`에 원본·대상/크기/수정시각을 JSON으로 보존. 완료 시 기록 정리; 중단·부분실패는 보존. 설정 메뉴에서 검토 후 안전 조건의 **일반 파일 복사만 명시적 재요청**, 덮어쓰기 없음. 기록 최대 20건, 단일 작업 상위 항목 1,000개 | 바이트 중단 지점에서 이어쓰기/폴더·이동 자동 복원은 미지원. 변경된 원본·대상 존재·폴더·이동은 재실행 금지. 기록 자동 완전복구 판정 대신 사용자 검토를 유지 |

## 안전·호환 정책

1. R00 기준본의 정규 파일과 설정·공지·업데이트 wire contract는 변경하지 않음. 새로운 기능별 코드만 추가하거나 필요한 호출 부분만 국소 수정함.
2. 휴지통 영구 삭제는 **반드시 사용자 선택과 Yes/No 확인**이 있어야 함. Windows Shell 결과의 `InvokeVerb` 호출 완료를 실제 삭제 완료로 혼동하지 않음.
3. ZIP 편집은 원본 해시가 중간에 변경되면 커밋 금지. 검증 실패 시 기존 ZIP을 보존하고 교체 후 이상 시 백업으로 복구 시도. 원본 복구 불확실 상황의 백업 파일 자동 삭제 금지.
4. 전송 복구 기록은 실제 원본 경로가 들어갈 수 있는 **사용자 로컬 비공개 자료**. 네트워크 업로드나 로그 본문으로 노출하지 않음.
5. 본체 설치본의 10,000,000바이트 이하 목표는 배포 빌드에서 별도로 측정해야 하며 소스 ZIP 크기와 동일하지 않음. .NET/WPF 기본 런타임 패키징 방식의 크기 영향을 검토해야 함.
6. 이 수정에는 외부 프로그램 다운로드·설치·서비스 등록·Shell 명령 자동 실행을 추가하지 않음.

## 테스트 실행과 미검증 범위

- Python 소스계약 회귀: `python -m pytest -q tests` (R01 작성 환경에서 PASS)
- WPF XAML과 C# 프로젝트 XML 정적 파싱: PASS
- 신규 C# 로직 테스트 작성: `dotnet run --project source/tests/LogicTests/LogicTests.csproj -- --v150-r01`
- C# 신규 테스트 내용: Windows 속성필터 별칭, ZIP 생성→추가→교체→삭제→중복 거부→취소, 격리 테스트 폴더의 전송 복구 원본 변경 감지, 등록 템플릿 Windows 의존성 확인
- **작성 환경에 .NET SDK가 없어 C# 신규 테스트는 실행하지 못함.** 정적 소스 검사 결과와 실제 컴파일/기능 작동을 구분할 것.
- 기존 장기 역사 테스트의 일부는 v1.5.0부터 정식 버전 `<Version>` 선언을 하는 데도 이를 금지한 선행 계약으로, 현행 테스트 결과와 별도 취급.

### Windows에서 필수로 수행할 테스트

1. .NET 10 SDK 환경에서 프로젝트 **실제 컴파일**, 기존 전체 LogicTests + `--v150-r01` 실행.
2. 프로그램 시작/종료 및 최대 네 창 개설, 주 창 먼저 종료 후 보조 창 작업 지속, 세션 저장 확인.
3. 한글·공백 폴더에서 ShellNew NullFile/Data/FileName 템플릿별 정상 생성과 이름 충돌/링크/권한 실패 확인.
4. 테스트용 휴지통 파일을 만들고 복원, **삭제는 별도 테스트 계정/테스트 항목만** 사용. 삭제 동사 실제 효과와 데이터 보존 확인.
5. 크기·확장명·경로·숨김·날짜 구조 필터의 현재/하위 폴더 결과와 취소 확인.
6. 예시 ZIP을 복사한 작업본에서 추가·교체·삭제, 실패·취소·원본 외부 변경·백업/재열기 검증.
7. 테스트용 파일 복사 중 강제 종료 → 기록 남음 → 변경 없는 누락 일반 파일만 수동 재시도. **이동과 폴더는 자동 재시도 금지** 확인.
8. Windows 서명·설치본 실제 실행·한글 UI·DPI 100/125/150%·업데이트 호환·최종 크기 확인.

## 작업 파일과 기준본 보존

- `Services/ShellNewTemplateService.cs`, `Services/ZipEditService.cs`, `Services/TransferRecoveryJournal.cs` 추가
- `Features/Explorer/ExplorerPane.ShellNew.cs`, `Features/Workspace/MainWindow.MultiWindow.cs`, `Features/Workspace/MainWindow.RecoveryJournal.cs` 추가
- `MainWindow.xaml`, `App.xaml.cs`, `MainWindow.xaml.cs`, `ExplorerPane.xaml`, `ExplorerPane.RecycleBin.cs`, `ArchiveContentsWindow.cs`, 관련 Explorer 서비스·검색·테스트 진입점 국소 수정
- `source/tests/LogicTests/V150R01Tests.cs` 및 `tests/test_v150_r01_p123_contract.py` 추가
- `samples/v150_r01` 안전한 소형 예시 자료 추가

### 개발 단계의 명확한 다음 보완점

- 보조 창별 독립 세션의 재시작 복원/권한·작업간 경합 시험
- Windows 휴지통 동사 `delete`의 실제 완료 여부를 조회·확정하는 후속 판정
- 전체 Windows AQS와의 구문·색인 차이 명시 UI, 오검색 방지
- ZIP 긴 경로·암호화 제한 및 Windows 파일 잠금 실패 주입
- 디렉터리/이동 작업 복구를 사용자 검토 중심으로 확장할지 별도 결정(자동 재실행은 안전검증 전 금지)
- 빌드 결과 10MB 이하 목표에 따른 .NET 런타임 의존성/배포방식 실측
