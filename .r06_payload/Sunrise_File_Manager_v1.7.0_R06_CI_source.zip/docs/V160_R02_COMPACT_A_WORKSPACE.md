# Sunrise File Manager v1.6.0 R02 — A안 UI 공간 최적화 및 공용 보조 패널 표시 정책

- 작성일: 2026-10-24 (KST)
- 부모: `Sunrise_File_Manager_v1.6.0_R01.zip`, SHA-256 `02232e72e9ebef5499662395cefbd2e7b70f8fea028d5b9effb88c43430d7199` (읽기 전용 보존)
- 산출물: `Sunrise_File_Manager_v1.6.0_R02.zip` / 설치형 전체 소스
- 제품·Control·Installer 버전: **1.6.0 그대로**, 전달 수정본만 R02
- 현재 자격: `SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING`

## 1. 변경 개요

이번 개정은 A안의 **파일 작업면적 보호**를 위한 두 번째 소규모 UI 보완이다. 화면 공간 절약은 기능 삭제나 타 패널 확대가 아니라, 불필요한 여러 줄 도구 모음과 열린 보조 패널 개수를 사용자가 선택적으로 줄이는 방식으로 달성한다.

| 변경 주제 | 기존 R01 | 변경 R02 |
|---|---|---|
| 상단 명령 | `WrapPanel`: 작은 창/큰 앱 배율에서 여러 줄로 늘어날 수 있음 | `HeaderCommandViewport`: **한 행 유지**, 필요한 경우 가로 스크롤 |
| 2~4분할 전송줄 | `WrapPanel`: 폭 부족 시 줄바꿈 | `TransferCommandViewport`: **한 행 유지**, 버튼·충돌정책 그대로 |
| 우측 세로 도구 레일 | 고정 StackPanel | `UtilityRailViewport`: 높이 부족 시 세로 스크롤 |
| 우측 상세·메모·미리보기 | 세 개 공용 인스턴스를 독립적으로 동시 표시 | 기존 동시 표시 **유지** + 사용자 선택 `한개씩` 모드 추가 |
| 새 사용자 선택 모드 | 없음 | 상세/메모/미리보기 중 **하나만** 펼쳐 가로 작업공간 반환 |
| 미저장 메모 | 창 변경 전 보호 | `한개씩` 모드에서 메모→상세/미리보기 전환에도 보호 |
| 세션 | LayoutVersion 24 | LayoutVersion 25; 표시 모드와 마지막 사용 패널 저장 |

## 2. 사용자 동작 계약

1. 기본은 R01과 동일한 **동시 표시 허용**이다. 이전 세션(v24 이하)은 신규 단일 모드가 자동 적용되지 않는다.
2. 오른쪽 `한개씩` 또는 `설정 · 기능 → 우측 패널 하나씩 보기`를 선택하면, 이미 메모가 열려 있으면 **메모를 우선 유지**하고 상세/미리보기만 닫는다. 메모가 없으면 상세정보, 다음은 미리보기를 유지한다.
3. 단일 모드에서 상세정보/미리보기로 바꿀 때 미저장 메모가 있으면 기존 Yes/No/Cancel 확인을 먼저 실행한다. **취소 시 원래 메모를 그대로 표시**한다.
4. 단일 모드에서 다른 패널 버튼을 선택하면 기존 패널을 닫고 선택한 것만 연다. 이미 열려 있는 동일 패널을 다시 선택하면 기존처럼 닫힌다.
5. `한개씩`을 다시 누르면 동시 표시 모드로 복귀한다. **다른 패널을 무조건 재개방하지 않는다.** 이후 사용자가 필요할 때 각 패널을 연다.
6. 선택한 파일은 활성된 1~4번 분할창의 단일 `SelectedFile`만 사용한다. MainWindow의 FileDetailsPanel, FileMemoPanel, FilePreviewPanel은 **각각 한 인스턴스**만 유지한다.
7. 닫힌 패널의 너비 및 분할선은 0 DIP, 독립 선호 너비는 세션에 보존된다. 자동 닫기는 새로운 단일 모드를 직접 켜거나 그 모드에서 다른 패널을 선택한 경우에 한한다.

## 3. 실제 변경 파일과 경계

- `source/Sunrise.FileManager/MainWindow.xaml`: 명령행/전송행 스크롤, 우측 도구 레일, 단일 모드 버튼과 설정 메뉴.
- `source/Sunrise.FileManager/MainWindow.xaml.cs`: 단일 모드 상태전환, 미저장 메모 보호, 현재 패널·창 너비·표시 상태 저장/복원.
- `source/Sunrise.FileManager/Services/SessionStore.cs`: 단일 모드 설정 2개 추가와 허용값 정규화. 기존 JSON 키·경로 변경 없음.
- `source/tests/test_v160_r02_compact_shell.py`: 새 소스 계약 5건.
- `source/tests/test_v160_r00_a_layout.py`, `test_v160_memo_details_separation.py`, `test_ui_contract.py`: 현재 세션 v25 일치 검증으로 갱신. 구형 표시 테스트의 업무 의미는 유지.
- `source/tests/UiSmokeTests/CurrentUiAudit.cs`, `Program.cs`: 선택적으로 실행하는 Windows 실기 `--compact-shell-only` 추가. **회사 기본 빌드에서 미실행**.
- `RELEASE_STATUS.json`, `CURRENT_SOURCE.md`, `README.md`, `docs/V160_R02_COMPACT_A_WORKSPACE.md`, 최종 해시 manifest: 현행 상태 갱신.

관련 파일 엔진, 메모 저장소(`#memo/*.sunmemo`), 암호화 이력, AI/EIASS, 휴지통, 압축, 네트워크, Sunrise Control, 회사 서명기, 공개 latest.json/notice.txt 및 installer AppId에는 변경 없음. 기존 14가지 1~4분할 배치를 유지한다.

## 4. 수행한 소스 검증

| 검사 | 결과 |
|---|---|
| R00/R01/R02 UI 계약 (`test_v160*.py`) | 20/20 PASS |
| WPF XAML XML 파싱 | 15/15 PASS (문법/컴파일 검사가 아님) |
| 전체 Python 소스 검사, 부모 대비 | R01 78건 12 FAIL/4 ERROR; R02 83건 12 FAIL/4 ERROR — **신규 실패 0** |
| 구형 실패 내용 | 오래된 UI literal 및 폐기된 빌드 경로 가정; 반드시 별도 정리해야 하며 전체 PASS로 표시하지 않음 |
| 전체 패키지 해시·ZIP CRC | 출하 ZIP 생성 후 점검 |
| Windows WPF / .NET 10 컴파일 / 실기 / Setup 서명·설치 | **PENDING** |

## 5. 반드시 필요한 Windows UI 후속 게이트

```powershell
dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --compact-shell-only validation/windows-compact-r02
```

위 테스트는 Windows WPF 실제 창을 최소 1010×560 DIP로 축소하고 4분할을 연 다음, 단일행 툴바 높이, 스크롤 방향, 우측 단일 패널 모드 전환, 닫힌 너비 0 DIP, 다시 동시 패널 열기, 공용 컨트롤 개수 1개씩을 검사하도록 **작성**했다. 실제 실행하지 않았으므로 PASS가 아니다.

함께 진행할 현장 확인:
- 14개 분할 배치 및 1/2/4분할, DPI 100/125/150%, 앱 배율 80/125%, 라이트/다크에서 메뉴와 전송 도구의 가로 스크롤 조작성.
- `한개씩` 전환 중 미저장 메모 [취소] 선택 시 원문·파일선택·열림상태 보존, 승인 시 저장/폐기 정상 처리.
- 패널 동시보기 모드에서 독립 너비 조정, 다시 닫을 때 남는 빈 여백 없음.
- 기존 사용자 v24 세션의 분할/패널 상태 유지 및 v25 세션 재시작 상태 복원.
- .NET 10 빌드, 그룹 인증서 서명된 EXE/Setup, 설치/업데이트/제거 및 원본·#memo 자료 보존.

### 공식 회사 빌드

기존 `BUILD_ON_WINDOWS_COMPANY.cmd` 사용. Windows 승인 전에는 signed installer 완성으로 표시하지 않는다. 예정 Setup 이름은 `dist/Sunrise_File_Manager_1.6.0_Setup.exe`. 신규 UI 테스트는 회사 기본 빌드에 포함하지 않는다.

### 산출물 무결성

최종 ZIP·SHA-256과 파일 수는 외부 전달 인수인계서에도 기록한다. 본 소스 ZIP 내 `FULL_SOURCE_SHA256_MANIFEST.json`은 모든 내용 파일 해시를 담고, manifest 자기 해시는 포함하지 않는다.
