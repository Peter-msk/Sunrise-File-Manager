# Sunrise File Manager v1.6.0 R06 — 분할 배치 사전 공간 안내 및 작업 중 전환 보호

## 기준본과 변경 범위
- 부모: `Sunrise_File_Manager_v1.6.0_R05.zip` SHA-256 `d7016f1ac43013d58c645b2fc9d22281362b1cf0b435cc48fa403f6aadf36097`.
- 제품 버전: **1.6.0 유지**, 개발 리비전 **R06**. 설치형 Windows x64 / WPF .NET 10 / `BUILD_ON_WINDOWS_COMPANY.cmd` 유지.
- 변경 소유자: `WorkspaceSplitLayoutEngine`, `MainWindow.SplitLayoutGallery.cs`, `MainWindow.xaml.cs` 및 해당 개발 테스트·문서.
- 기존 14개 배치(1/2/6/5), 창별 폴더·탭·세션, 우측 **상세정보/미리보기/메모 각각 1개**, 1~4분할, 휴지통·AI·EIASS 엔진, 메모 `#memo` 원본 형식, 파일 엔진 변경 없음.

## R06 UI 동작 계약
1. 분할 선택 메뉴의 각 행은 **실제 WorkspaceViewport의 가용 너비/높이**와 canonical `GetMinimumWorkspaceSize`를 비교한다. 전체 앱 창의 너비가 아니라 오른쪽 공용 패널을 제외한 실제 파일 작업공간이다.
2. 해당 배치가 들어가면 `현재 파일 작업영역에 배치 가능`; 부족하면 `가로 스크롤 필요`, `세로 스크롤 필요`, `가로·세로 스크롤 필요`를 분할 도면과 설명 아래 표시한다. 필요한 최소 너비/높이는 DIP 단위로 안내한다.
3. 아직 실측되지 않았거나 측정값이 비정상적이면 `창 크기 확인 전`으로 안내한다. **미측정 공간을 적합이라고 주장하지 않는다.**
4. 스크롤이 필요하더라도 기존 배치 14개는 모두 직접 선택 가능하다. 사용자 설정·다른 패널을 자동으로 닫거나 분할 비율을 임의 조절하지 않는다.
5. 파일 전송(`_working`), AI 실행(`_aiBusy`), 휴지통 작업(`_activeRecycleJobs`) 중에는 메뉴에서 배치 항목을 비활성화한다. 메뉴를 연 이후 작업이 시작되더라도 적용 직전 조건을 재검사한다.
6. **단일 버튼·숨은 이전 콤보/순환 명령·Ctrl+1~4** 모두 공통 `ArrangePanels` 경계에서 동일 조건으로 차단된다. 초기 세션 복원은 예외적으로 허용한다.
7. 메뉴 Opened 시 이미 선택된 항목 또는 첫 활성 항목에 키보드 포커스를 보내며, 단순 포커스나 메뉴 열림으로 배치를 변경하지 않는다. 화면낭독기 설명에는 공간 적합 안내를 포함한다.
8. 편집 중인 메모로 인한 분할 수 축소 취소, 오른쪽 공용 컨트롤 3개의 유일 소유권, Footer는 작업 상태 전용 등 이전 계약은 불변이다.

## 구조적 공간 판단 예시
| 배치 | canonical 최소 크기(DIP) | 의미 |
|---|---:|---|
| 2열 | 711 × 340 | 파일목록의 최소 350 + 구분선 11 + 350 |
| 3열 | 1072 × 340 | 좁은 작업공간에서는 가로 스크롤 안내 |
| 4열 | 1433 × 340 | 4개 파일목록 각각 최소 350 보호 |
| 4행 | 350 × 1393 | 세로 스크롤로 전체 접근 |
| 2×2 격자 | 711 × 691 | 너비·높이 모두 비교 |

화면 배율과 사용자 DPI가 적용된 실제 표시 픽셀 및 실제 스크롤바 생성은 **Windows 실기 검증이 필요**하다. 위 표는 코드 정책의 WPF DIP 계산값으로 실제 Windows 측정 결과가 아니다.

## 테스트·검증 이력
- R06 신규 Python 소스 계약 **6/6 PASS**.
- `test_v160*.py` 계열 집중 계약 **44/44 PASS**.
- 전체 Python regression: R05 **101건 / 12 FAIL + 4 ERROR**, R06 **107건 / 동일 12 FAIL + 4 ERROR**, 새 실패/오류 **0건**. 기존 역사적 테스트들은 obsolete onefile 스크립트·통합 Inspector 문자열 등을 요구한다. R06 기능의 PASS로 승격하거나 무조건 빌드 차단조건으로 두지 않는다.
- XAML XML **15/15 PASS**. 최종 ZIP 및 파일별 해시는 패키징 후 추가 검증.
- C# 실제 컴파일, Windows WPF 메뉴·마우스·키보드, 100/125/150% DPI, 네이티브 UI 스크롤, 설치형 Setup/Authenticode **PENDING**.
- 변경 전 작업 관련 Windows 선택 검증: `dotnet run --project source/tests/SplitLayoutTests/SplitLayoutTests.csproj` 및 `dotnet run --project source/tests/UiSmokeTests/UiSmokeTests.csproj -- --split-gallery-only validation/windows-split-gallery-r06`.
- C# SplitLayoutTests에는 14개 배치 각각 `적합/가로초과/세로초과/양축초과/미측정` 총 70개 판정 경로를 추가했다. UI Smoke에는 표시 문구·작업 중 배치 변경 억제 검사를 추가했다. 현재 미실행.

## 배포 및 인수 안전경계
- 공식 공개 배포가 아니다. `SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING`.
- 회사 공식 빌드 진입점에 동일 정적 검증 재실행을 추가하지 않는다. 소스 변경 Gate 완료 후 빌드에는 Windows 전용 게이트만 수행한다.
- GitHub/Drive 업로드, 원격 `latest.json`/`notice.txt`, 실제 회사 프로그램/사용자 파일 및 계정 데이터는 변경하지 않음.
- 다음 릴리즈 전 확인: .NET10 Windows WPF 컴파일 → 14개 배치 선택 스크롤 안내와 좁은 화면 시각 비교 → 4분할 우측 공용 패널 유일성 → 실제 Setup·서명·설치/제거.
