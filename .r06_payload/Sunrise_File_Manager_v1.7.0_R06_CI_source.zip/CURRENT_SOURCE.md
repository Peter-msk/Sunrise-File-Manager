# Sunrise File Manager v1.7.0 R06 — 라이트 테마·상단 버튼 마감 (2026-10-25)

라이트 모드에서 지나치게 어둡던 브랜드 헤더와 우측 공용 아이콘 레일을 밝은 청회색으로 조정하고 다크 모드의 남색 체계는 유지했습니다. 상단 3행은 **38/42/40 DIP**, 업무·명령·분할 버튼은 각각 **34/32/34 DIP**로 정리하고 버튼 간 간격과 텍스트 패딩을 확보했습니다. 활성 업무·분할·공용 패널 버튼은 hover에서도 대비가 유지되도록 선택 상태 템플릿을 보완했습니다.

**소스 검증 PASS, Windows WPF/Preview 실행 및 서명 Setup 검증 PENDING.** 기존 14개 분할 배치·오른쪽 공용 패널 3개·Preview 빌드·사용자 메모/설정/업데이트 계약은 유지합니다. 상세: `docs/V170_R06_LIGHT_THEME_SHELL_BUTTON_FINISH.md`.

---
이하 R05 및 과거 리비전 이력입니다.

# Sunrise File Manager v1.7.0 R05 — 공식 A안 적응형 상단 명령·버튼 품질 (2026-10-25)

상단 헤더의 설정 위치와 높이를 정리하고 파일관리 기본 6개 명령 이외의 작업을 `⋯ 더보기`로 수납했습니다. 너비 부족 시 업무별 명령은 자동으로 More 메뉴로 이동하며, 원래 실행 처리기를 그대로 호출합니다. 라이트/다크 캡처를 바탕으로 앱 XAML 15개/버튼 158개를 전수 감사해 크기·폰트 균형과 패널 행 클리핑을 보완했습니다.

**상태: Python 448/448 PASS, XAML 15/15 PASS, Windows WPF/Preview/Setup/서명 PENDING.** 메모·파일 엔진·공용 우측 3패널·14분할·Preview 빌드 보존. 상세: `docs/V170_R05_ADAPTIVE_COMMAND_BAR_AND_BUTTON_AUDIT.md`. 공개 업데이트 및 GitHub/Drive 변경 없음.

---
이하 이전 R04 기록입니다.

# Sunrise File Manager v1.7.0 R04 — 일반 파일 우클릭 메뉴 Windows 명령 복구 (2026-10-25)

- 직접 부모: `Sunrise_File_Manager_v1.7.0_R03.zip`, SHA256 `9e8cf358c3b7856fbe87db4dd9dbb39b29127dc2a21af5f40a7d3f9f2bd039c4`.
- R03의 기본 파일·폴더 우클릭에서 제거됐던 잘라내기/복사/붙여넣기/이름변경/삭제 등 Windows 표준 진입점 복원. 빈 공간·실제 드라이브·휴지통을 분리하고 셸 확장 메뉴 유지.
- 기본 UI/메모·상세정보·미리보기 공용 패널/14배치, 회사 빌드/Preview 및 제품 버전 1.7.0 유지.
- Python 검사 438/438 PASS, XAML XML 15/15 PASS, Windows 컴파일·WPF/UI·COM·서명/설치 PENDING.
- 인수인계 `docs/V170_R04_WINDOWS_CONTEXT_MENU_PARITY.md`.

---
이하 이전 R03 이력입니다.

# Sunrise File Manager v1.7.0 R03 — 공식 A안 다중 분할 메뉴 공간 확보 (2026-10-25)

2~4분할에서 중복되던 탐색창별 36 DIP 클래식 메뉴 행을 접고, **각 탭 오른쪽의 `⋯ 고급 명령` 버튼으로 동일 메뉴를 재사용**합니다. 단일 화면에서는 기존 메뉴가 그대로 보입니다. 원래 File/Edit/View/Favorites/Extras/Info 메뉴 항목과 클릭 처리기는 삭제하거나 복제하지 않으며, 분할 변경 시에도 독립 탐색·파일 작업/메모/Preview/Control/설치 빌드를 유지합니다.

**검증:** Python 425/425 PASS, XAML 15/15 구조 PASS. Windows 실제 WPF 컴파일·ContextMenu 조작·DPI/Preview/서명/Setup **PENDING**. `docs/V170_R03_OFFICIAL_A_COMPACT_EXPERT_MENUS.md` 참고.

---

# Sunrise File Manager v1.7.0 R02 — 공식 A안 메인 셸 및 업무별 도구 구현 (2026-10-25)

공식 A안의 **남색 브랜드 헤더 / 파일 관리·문서/EIASS·AI·압축/도구 모드 / 업무별 명령 한 행 / 상단 분할 제어 / 중앙 파일 작업공간 / 우측 공용 패널 / 하단 작업 상태**를 실제 WPF 소스에 반영했습니다. 모드 단축 명령은 활성 ExplorerPane의 기존 작업 처리기에 연결되며, 14개 분할 배치, 고정 전송 막대 제거, 공용 상세/미리보기/메모 각 1개, Preview 전용/설치형 빌드 계약은 유지합니다.

**검증 범위:** Python 420/420 PASS, XAML 15개 구조 검사 PASS. Windows WPF 실제 빌드/렌더링/Preview·서명/Setup **PENDING**. 기존 분할창별 탐색 메뉴를 단일 전역 트리로 이전하는 작업은 기능 보존 위험으로 진행하지 않았습니다. `docs/V170_R02_OFFICIAL_A_FULL_SHELL.md` 참고.

---

# v1.7.0 R01 — Screenshot-based official A-layout correction

**Source candidate, Windows compiled UI/Preview/Setup PENDING.** Removed duplicate transfer bar; immediate single; concise 2/3/4 layout galleries; isolated icon-only right utility rail. Shared memo/details/preview controls remain each exactly once. Source 127 + root 286 Python tests PASS. See `docs/V170_R01_OFFICIAL_A_UI_RECONCILIATION.md`.

---

# Sunrise File Manager v1.7.0 R00 — 설치 전 Preview 자동 생성 (2026-10-25)

v1.7.0 프로그램 기능과 UI는 변경하지 않았습니다. Windows 회사 빌드에서 정식 Setup과 함께 설치 없이 실행 가능한 **서명된 Preview 폴더·ZIP**을 기본 생성합니다. 또한 `BUILD_PREVIEW_ON_WINDOWS.cmd`로 Setup을 빌드하지 않고 실행용 Preview만 생성할 수 있습니다.

- 기본 회사 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`
  - `dist/Sunrise_File_Manager_1.7.0_Preview/Sunrise.FileManager.exe`
  - `dist/Sunrise_File_Manager_1.7.0_Preview.zip`
  - `dist/Sunrise_File_Manager_1.7.0_Setup.exe`
- 미리실행 전용 빌드: `BUILD_PREVIEW_ON_WINDOWS.cmd` (Inno Setup 불필요, 그룹서명과 .NET 10 SDK 필요).
- Preview는 self-contained Windows x64 OneDir입니다. EXE 하나만 복사해서는 실행할 수 없으며 폴더 전체를 유지해야 합니다. 런타임 설치는 요구하지 않습니다.
- 회사 서명 및 기존 Sunrise Control/업데이트 정책 유지; Preview와 설치형에 쓰이는 앱 바이너리는 동일합니다.
- 설치 없이 실행은 가능하지만 **선택한 실제 파일에 대한 작업은 실제로 적용**됩니다. 설치본과 설정 데이터가 공유될 수 있어 테스트 파일로 먼저 확인해야 합니다.
- 버전은 **1.7.0 유지**, 릴리즈 리비전만 `R00`. 원격 공개 feed와 기존 Setup 배포는 변경하지 않았습니다.
- **Windows 동적 빌드·서명·Preview 실행 검증 PENDING**. 현재 전달물은 빌드 경로를 반영한 소스 후보입니다.

---
이하 이전 릴리즈 이력입니다.

# Sunrise File Manager v1.7.0 — 기존 R09 동일 기능 버전 승격 (2026-10-25)

- **부모 기준본**: `Sunrise_File_Manager_v1.6.0_R09.zip` / SHA-256 `ff757ccfba4fe763da527269a93e395e847e88ec63397c061925eb3f57b548fa`.
- Windows x64 설치형 기존 기능·UI·세션 스키마(`LayoutVersion=25`)·파일/메모 처리 코드 보존. 제품/설치/Control/어셈블리/창 제목 버전만 **1.7.0**으로 동기화.
- 기본 회사 빌드 `BUILD_ON_WINDOWS_COMPANY.cmd`, 예정 산출물 `dist/Sunrise_File_Manager_1.7.0_Setup.exe`.
- `release/NOTICE_BODY_1.7.0.txt`는 신규 버전의 로컬 릴리즈 문구 원본. 공개 `latest.json`, `notice.txt`, `release/PUBLISHED_RELEASE.json` 및 GitHub·Drive 게시 내용은 변경하지 않음.
- **Windows WPF 빌드·설치·서명·실기 UI 확인은 PENDING**. 아래 1.6.0 문단은 해당 버전의 역사적 기록임.

---

## v1.6.0 R09 — 구형 계약·사용되지 않는 상태 정리 및 현재 기능 회귀 복구 (2026-10-25)

- 부모: `Sunrise_File_Manager_v1.6.0_R08.zip` (SHA-256 `334173f543bb6c3c9748b6fc10bca52f53e3702fb9fe222c0f7d19f68570f3e4`). 설치형 제품 버전 `1.6.0`은 유지하며 R09는 소스 정리 리비전이다.
- 12 FAIL/4 ERROR 원인이 된 과거 통합 Inspector·OneFile·버전 미지정·과거 패널 geometry 검사를 현재의 **파일/메모 무결성·시각 구조·현행 회사 빌드·세션 안전성** 검증으로 대체했다.
- 오래된 개별 화면 미리보기/상세정보 설정, 사용하지 않는 InspectorDetailRatio와 관련 코드 및 폐기된 빌드 계약 스크립트를 제거했다. 이전 `InspectorVisible`, `InspectorWidth`는 기존 사용자 세션 이전에 실제 필요하여 유지한다. JSON의 삭제된 필드는 로드 시 무시하여 사용자 세션 자체는 보존한다.
- 코드 결함 보완: 새 독립 창 생성 시 `LayoutVersion=25`, `SingleUtilityPanel`, `SingleUtilityActive`를 전달하여 기존 우측 패널 표시 선호를 유지한다. 상세정보 요청 이벤트도 `DetailsRequested`로 소유권을 바로잡았다.
- 전체 Python 실행: `source/tests` **117/117 PASS**, 루트 `tests` **279/279 PASS**, **합계 396/396 PASS**. 루트의 과거 1.1.0 릴리즈·공지 문자열 등 무효화된 검사 10개는 삭제했고 PASS 숫자에 포함하지 않는다. 기존 R08 루트 289건/34 FAIL+4 ERROR는 정리 전 이력이다.
- 기존 메모 이동·Undo/Redo 동작은 이미 C# LogicTests에 시나리오가 존재하며 제품 엔진 원본 바이트를 그대로 보존했다. 이번 환경에서는 .NET SDK/Windows가 없어 **C# 컴파일·C# 로직 실행·Windows UI/Setup/서명 PENDING**. Source PASS를 Windows PASS로 승격하지 않는다.
- 세부: `docs/V160_R09_CURRENT_CONTRACT_CLEANUP.md`. GitHub/Drive/원격 업데이트 피드·기존 공개 배포본은 수정하지 않았다.

## v1.6.0 R08 — A안 UI 소스 마무리 (2026-10-25)

- R07의 기존 14개 프리셋·우측 공용 패널 각 1개를 유지하며 메뉴 중복 표시, 명령줄 접근성, 미리보기/메모 편집 중 Ctrl+1~4 충돌을 보완.
- 신규 6 PASS, A안 누적 56 PASS, XAML 15 PASS, 전체 회귀는 기존 12 FAIL+4 ERROR 동일; Windows 컴파일·시각·서명/설치 PENDING.
- 상세: `docs/V160_R08_UI_FINAL_HARDENING.md`.

## v1.6.0 R07 — 기존 분할 배치별 하단 드롭다운 목록 (2026-10-25)

- 사용자 요청: 상단 `단일 ▾`, `2분할 ▾`, `3분할 ▾`, `4분할 ▾`을 누르면 해당 버튼 바로 아래 기존 배치만 1/2/6/5개 목록으로 표시, 선택한 항목 적용.
- R06 대형 공간 안내를 목록에서 제거하고 작은 배치 그림·이름·한 줄 설명으로 구성. 공간 적합성 정보는 Tooltip에만 남김.
- 기존 프리셋 14개, Ctrl+1~4, 우측 공용 3패널/파일 엔진/메모/Control/회사 빌드 유지.
- 집중 source tests 46 PASS, 전체 113건 중 역사적 12 FAIL+4 ERROR 동일. Windows 빌드/시각·DPI·설치/서명 PENDING.
- 상세 `docs/V160_R07_COMPACT_PRESET_DROPDOWN.md`.

## v1.6.0 R06 — 분할 배치 가용공간 사전 안내·작업 중 UI 보호 (2026-10-25)

- 기준 `Sunrise_File_Manager_v1.6.0_R05.zip` SHA-256 `d7016f1ac43013d58c645b2fc9d22281362b1cf0b435cc48fa403f6aadf36097`. 제품/설치 버전 1.6.0 유지.
- 14개 배치 메뉴에 실제 **파일 작업공간의 viewport** 기반 `스크롤 필요 여부 / 최소 DIP 크기` 표시. 미측정 상태는 판단 유보, 레이아웃 선택 자체는 유지.
- 전송·AI·휴지통 작업 도중 분할 이동 금지, 직접 메뉴/단일 버튼/단축키/호환 경로 동일 안전경계. 키보드 메뉴 포커스 및 접근성 안내 보완.
- 집중 Python **44/44 PASS**, XAML **15/15 PASS**. R05/R06 전체 테스트 비교 새 실패 0(기존 12 FAIL+4 ERROR 유지). Windows 컴파일/실기/설치/서명 PENDING.
- 우측 상세/메모/미리보기 공용 패널 각 한 개, 파일·메모·AI/EIASS·업데이트 엔진 및 회사 빌드 불변. 상세 `docs/V160_R06_GALLERY_FIT_AND_TRANSACTION_SAFETY.md`.

## v1.6.0 R05 — 현재 설치형 소스 후보

- 부모 ZIP `Sunrise_File_Manager_v1.6.0_R04.zip`, SHA-256 `56d061afee30e8d75f9d1cec8aa7ef9aecba18c7b15bf8bf8e05b0c92fe2f73a`.
- 2/3/4분할 버튼에서 그림형 배치 목록(2/6/5개) 선택. 기존 14개 배치 엔진 그대로 사용하며 메뉴 열기만으로 화면 변경 없음. Ctrl+1~4는 해당 분할 수에 마지막 선택했던 배치로 즉시 전환.
- R05 신규 정적 계약 8 PASS, A안 관련 38 PASS, XAML 15 PASS. 전체 Python 신규 실패 0(기존 실패·오류 16건 유지). Windows 실제 WPF/설치/서명 PENDING.
- 우측 공용 상세정보/미리보기/메모 3종 각각 1개 고정, 원본 파일/설정/메모/전송/Control/업데이트 공개 피드 변경 없음.
- 상세 `docs/V160_R05_SPLIT_LAYOUT_GALLERY.md`.

## v1.6.0 R04 — 현재 설치형 소스 후보

- 기준 ZIP: `Sunrise_File_Manager_v1.6.0_R03.zip`, 부모 SHA256 `4e0193882babe9c139fa0eeb7d47fbd71743fcbdeda9165c7c9e07c753007ded`.
- 우측 공용 FileDetails/Memo/Preview 각 하나, 전체 Workspace Grid Row2의 오른쪽 Column 배치 재확인. Footer(Row3)는 상태 전용.
- 좁은 고정 트리: 파일 영역 176 DIP 표시 폭 예산 적용. 저장값/원본 데이터 불변.
- R04 신규 5 source-contract PASS, R00-R04 통합 26 PASS, 전체 Python 신규 실패 0. WPF 실컴파일·DPI·Setup·서명은 PENDING.
- 후속 근거: `docs/V160_R04_RIGHT_DOCK_NAVIGATION_BUDGET.md`.

## v1.6.0 R03 — 현재 개발 기준 (2026-10-24)

- 부모 `Sunrise_File_Manager_v1.6.0_R02.zip` SHA-256 `f929191f768092d86e128aa32811e5871f432b2ec9240376bcd108939b3aa2a8` 보존.
- A안 분할창 내부 고정 행 밀도 수정, 검색·탭·브레드크럼·상태줄·파일명 보존. 2~4분할 좁은 배치에서는 기존 208 DIP→188 DIP, 단일창 복원.
- 신규 소스 검사 5 PASS, 누적 A안 검사 25 PASS; 전체 Python R02/R03 비교에서 신규 실패 0 (기존 실패·오류 16건 유지).
- Windows WPF 컴파일·실제 14개 배치·DPI·설치·서명은 PENDING. 세부: `docs/V160_R03_PANE_DENSITY_A_LAYOUT.md`.

# Sunrise File Manager v1.6.0 R02 — A안 UI 밀도·보조 패널 개선 (2026-10-24)

- 기준 소스 `Sunrise_File_Manager_v1.6.0_R01.zip`의 부모 해시 검증 후 R02 수정본 생성. 1~4분할·14개 배치 및 MainWindow 공용 상세/메모/미리보기 각각 1개 유지.
- 상단/전송 도구 단일 행 스크롤, 우측 도구 레일 높이 대응, 사용자 명시 `한개씩` 패널 모드 추가. 기존 동시 보기 모드, 사용자 저장된 너비와 미저장 메모 보호 유지.
- 세션 LayoutVersion 25; v24 이하 세션은 동시보기 유지. 회사 빌드 중복 소스검사 추가 없음.
- SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING: 문법 계약 20 PASS, XAML 15 PASS, 전체 이전 실패 16건 그대로, 신규 실패 0; Windows 실제 렌더링/빌드/서명은 미실행. 상세 `docs/V160_R02_COMPACT_A_WORKSPACE.md`.

---

# Sunrise File Manager v1.6.0 R01 — 4분할 공용 우측 패널 (2026-10-24)

- 부모 기준: `Sunrise_File_Manager_v1.6.0_R00.zip` / SHA-256 `5cfc58d2ba7b2013f797dceb93a7bb1912bb5d8675d259f296fecf8a402a8a2d`.
- `1~4개 ExplorerPane` + MainWindow의 **FileDetailsPanel 1개 / FilePreviewPanel 1개 / FileMemoPanel 1개**. 분할창별 숨은 상세정보 패널 코드를 제거하고 선택한 활성 창에 공용 패널을 동기화했습니다.
- 활성 분할창 표시(`창 N/4`) 및 분할별 제목 강조, 4→1 축소 또는 상태 교환 전 미저장 메모 확인, 구버전 패널 상태 필드 직렬화만 유지.
- 문서/AI/EIASS/파일엔진/휴지통/업데이트/서명/설치 형식은 기존 버전 그대로. 공식 회사 빌드의 소스 테스트 중복 수행 금지 유지.
- **현재 자격: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING**. Windows 실기 검증을 통과했다고 주장하지 않습니다. 상세 내용은 `docs/V160_R01_SHARED_RIGHT_PANELS.md`, `RELEASE_STATUS.json`을 확인하십시오.

---

# v1.6.0_R00 현재 소스 기준 — A안 파일 관리 중심 UI

소스 부모: `Sunrise_File_Manager_v1.6.0.zip` (`25d3b1ad459ea38ab44651fe2ed8adaa2f19a6a3978bd4069bb1bdae23f48eb7`). UI/세션 레이아웃 변경이며 제품의 버전, 공개 업데이트 wire 및 회사 설치형 빌드 경로는 유지합니다. 오른쪽 도구 레일, 동적 분할 전송 바, 새 설치 기본 보조 패널 접기 및 레거시 세션 보존을 포함합니다. 최종 승인: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING. 자세한 변경 소유자·검증은 `docs/V160_R00_A_WORKSPACE_UI.md`를 참고하십시오.

---

# Sunrise File Manager v1.6.0 — 메모/상세정보 독립 시스템 (2026-10-24)

- 부모 기준 ZIP: `Sunrise_File_Manager_v1.5.6.zip` / SHA-256 `9d242d5763f12ffedf2b6a8fe15e9718e94dc7ca401fa24aec876ca5f7785776`.
- 상세정보는 `FileDetailsPanel` 독립 UI/상태/속성/해시. 스마트 메모는 `FileMemoPanel` 독립 UI/저장/이력/AI 요약.
- `LayoutVersion=23`에서 별도 표시/너비 저장, 이전 v22 Inspector 세션 호환, `#memo/*.sunmemo` 불변.
- 회사 빌드·업데이트 wire·Control 서명정책·기존 파일 엔진은 보존. 신규 제품·설치 버전 1.6.0.
- **SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING**: 소스 정적 검증 완료, Windows WPF 빌드/실기/서명된 설치파일 미검증.
- 최신 작업 상세는 `docs/V160_MEMO_DETAILS_SEPARATION.md` 및 `RELEASE_STATUS.json`에 한정. 이전 버전 증적은 기록으로만 유지.

---

# Sunrise File Manager v1.5.6 — 휴지통 일괄 삭제·Windows 기본 명령 (2026-10-24)

- 공식 부모 소스: `Sunrise_File_Manager_v1.5.5.zip` / SHA-256 `f594cac695bf154215925cdc00f3491108e30ec4636198cfc2c2898c3f4fdb57` (원본 미변경).
- 수정 내용: 선택 항목은 전체 1회 확인 후 Windows Shell `IFileOperation`으로 영구 삭제를 묶어 실행한다. 완료 후 휴지통 재조회로 삭제 결과를 확인한다.
- 휴지통 메뉴: 선택 복원, 전체 복원, 선택 영구 삭제, 전체 비우기, 속성, 모두 선택, 새로 고침, Windows 휴지통 열기.
- 일반 파일 영역, 우클릭 7개 기능 그룹, 드라이브 첫 접기, EIASS/메모, 설치 AppId, Control 및 업데이트 wire는 유지한다.
- 제품·설치 버전은 `1.5.6`, Assembly/FileVersion은 `1.5.6.0`. 회사 기본 빌드 진입점은 `BUILD_ON_WINDOWS_COMPANY.cmd`로 유지한다.
- 이 파일은 **SOURCE CANDIDATE**다. 코드 계약 검사 4 PASS. Windows 빌드·실제 3개 항목 삭제 상호작용·Setup 서명·설치 실행·회사 인증서 검증은 아직 **PENDING**이며 v1.5.5 증적을 승계하지 않는다.
- 상세: `docs/V156_RECYCLE_BIN_BATCH_AND_NATIVE.md`, `RELEASE_STATUS.json`.
- 공개 원격 latest.json 및 notice.txt는 게시하지 않았고 ZIP의 기존 공개 피드 스냅샷도 유지한다.

---
이하 이전 버전의 역사 기록이다.

# Sunrise File Manager v1.5.5 — 우클릭 메뉴 정리 (2026-10-24)

- 기준본: Sunrise_File_Manager_v1.5.4_R00.zip / SHA256 c174920af12f730cf72c0f757e2257bb5affbb1307fbcafa7321a5479f81bc64.
- 추가 수정: 드라이브 첫 접기에서 선택 폴더로 스크롤되는 포커스/BringIntoView와 같은 폴더 새로고침 재펼침 경로를 보완했다. 휴지통 Delete/Shift+Delete는 기존 확인 후 Shell 영구 삭제로 연결했다.
- 일반 파일 목록 우클릭 첫 화면을 명령 9개·구분선 2개로 정리하고, EIASS·AI 외 명령은 7개 기능 그룹으로 분류했다.
- 기본 복사/잘라내기/붙여넣기/삭제/Undo/Redo/선택/새로 만들기는 우클릭에서 제외하며 상단 메뉴·단축키·기존 동작을 유지한다.
- 제품·Control·창 제목·Setup 버전은 1.5.5, Assembly/FileVersion은 1.5.5.0.
- 검증 상태의 유일한 현행 기준은 RELEASE_STATUS.json이며 이전 v1.5.4 결과는 당시 범위의 역사 기록이다.
- Windows VM 메뉴·첫 접기·휴지통 Delete 검증 PASS. 회사 CMD로 새 self-contained Setup 생성·설치 EXE 시작·정상 종료·제거 명령 종료 0을 확인했다. 회사 기본 CMD에는 테스트를 추가하지 않았다.
- 최종 실행 40074723491 / commit 23de1a93eaca44c97afc41a579ce7514ebb5381d. 소스/빌드 입력 150개 동일. 메뉴·드라이브와 휴지통의 유효한 완료 범위는 RELEASE_STATUS.json의 명시된 증적을 재사용했다.
- 회사의 기존 인증서 신뢰·물리 PC·업무 corpus/NAS/OneDrive·전체 업데이트는 별도 PENDING.

---
이하 이전 릴리즈 이력이다.

# Sunrise File Manager v1.5.4 R00 — 중단 감사 재개·증적 정합 (2026-10-24)

- 기준본: `Sunrise_File_Manager_v1.5.4.zip`, SHA256 `96efba04def611928444b55d5ee2dc8b6621a59e092331d8d25ee40401011053`.
- 프로그램 버전은 1.5.4 유지. 실행 코드·리소스·설치 스크립트·회사 CMD 변경 없음. 이번 전달본은 상태 문서·감사 결과·무결성 목록만 갱신한다.
- 기존 Windows 실행 39966890560의 전체 job/steps 성공 및 artifact digest를 GitHub에서 다시 확인했다. 새 Windows 실행을 수행했다는 의미가 아니다.
- 기준본 무결성 619/619 일치. 실행 커밋의 179개 파일 중 175개 동일, 4개 차이는 LICENSE/README와 보존된 latest.json/notice.txt이다. 프로그램·리소스·빌드·설치 관련 149개 입력은 모두 동일하다.
- v1.5.4의 유효한 Windows VM 결과만 REUSED_PASS로 재사용한다. 과거 v1.5.0 `validation/PRE_BUILD_RESULT.json`은 현재 사전검사 증적이 아니다.
- 현재 검증 범위와 잔여 항목의 기준은 `RELEASE_STATUS.json:final_audit_verification`, 상세는 `docs/V154_R00_AUDIT_RESUME.md`이다. 하위 이전 버전의 PENDING은 해당 시점 이력이며 현재 결과를 덮어쓰지 않는다.
- 회사 기본 빌드에 테스트를 추가하지 않았다. 공개 공지·업데이트 파일과 원격 배포를 변경하지 않았다.

---
이하 v1.5.4 최초 감사와 이전 버전 이력이다.

# Sunrise File Manager v1.5.4 — 최종 코드 감사·안정화 (2026-10-23)

- 감사 기준: 이 대화에서 최종 전달한 `Sunrise_File_Manager_v1.5.3.zip`.
- 일반 파일 일괄 이름 변경의 중간 실패 시 원래 이름과 메모를 복구한다. 파일/폴더 혼합 변경은 전체 계획을 먼저 검사한다.
- 실행 취소·다시 실행 중 창 종료와 추가 파일 변경을 제한하고, 처리 완료 후 정상 종료할 수 있도록 한다.
- 이름 충돌 등으로 실패한 일반 Undo/Redo 항목은 이력을 보존하여 재시도한다.
- 같은 폴더의 메모 저장·감시자 새로고침에서 선택을 복원하며, 필터·탭·위치 변경과 구분한다. 선택한 문서의 미리보기를 유지한다.
- 파일 위치 찾기로 목록 앞부분이 생략되는 문제를 수정했다. 첫 2,000행 안에서는 전체 첫 페이지를 유지하고, 그 밖의 파일은 이전 위치로 돌아갈 수 있는 커서로 표시한다. 2,005개 파일 경계 사례와 작은 폴더 전체 목록을 검증했다.
- 제품·Control·창 제목·설치 버전은 1.5.4, Assembly/FileVersion은 1.5.4.0이다.
- 기존 회사 빌드 진입점은 `BUILD_ON_WINDOWS_COMPANY.cmd`이며, 회사 빌드에 문서 테스트를 추가하지 않았다.
- Windows VM에서 컴파일 0 경고/0 오류, EIASS·복구 117개·현행 UI 22개·기본 파일 작업 5개 항목 및 14개 분할 배치가 통과했다. 회사용 CMD로 Setup 생성 후 실제 설치·실행·종료·제거도 확인했다.
- Windows 실행 검증의 최종 결과와 범위는 `RELEASE_STATUS.json` 및 `validation/v154`를 따른다.

---
이하 이전 버전의 개발·검증 기록이다.

# Sunrise File Manager v1.5.3 — EIASS 제출용 문서명 설정 (2026-10-23)

- PDF 선택 → **편집 → EIASS 제출용 문서명 설정…** (우클릭 메뉴에서도 사용).
- 평가 구분·말머리, 4/5자리 목차번호, 시작 번호·간격, 제목 직접 수정, 위·아래 순서 조정, 금지 문자 정리, 변경 전 미리보기를 지원한다.
- 목차 파일(PDF/DOCX/HWPX/HWP/TXT) 또는 한 줄에 제목 하나씩 직접 입력하여 순서를 맞출 수 있다. 번호 없는 목차도 지원하며 유일하게 일치하는 제목만 자동 연결한다. 미일치·중복은 수동 확인 후 적용한다. 스캔 목차 OCR은 제공하지 않는다.
- 사후환경영향조사·약식평가 최종보고서는 말머리를 생략하고, 기후변화영향평가는 이름을 유지한다. PDF 외 선택 항목은 제외하며 확장자와 내용은 보존한다.
- 이름 교환과 메모 동반 이동을 지원하는 2단계 변경, 실패 시 원래 이름 복구, Ctrl+Z 실행 취소·Ctrl+Y 다시 실행을 연결했다. 중복 번호·중복 대상·기존 파일 덮어쓰기는 차단한다.
- 제품·Control·창 제목·설치 버전: **1.5.3** / Assembly·FileVersion: **1.5.3.0**. 기본 빌드에서 문서 검증을 실행하지 않는다.
- 목표 출력: `dist/Sunrise_File_Manager_1.5.3_Setup.exe`. 빌드 진입점: `BUILD_ON_WINDOWS_COMPANY.cmd`.
- Windows VM에서 Release 빌드 0 경고/0 오류, 새 기능 검증 100개 항목이 통과했다. 900×640 최소 창 크기와 말머리 편집·실제 마우스 조작도 확인했다. 변경 기능 검증 결과는 `validation/v153` 및 `RELEASE_STATUS.json`을 참조한다. 서명된 Setup 설치 검증은 대기 중이다.

---
이하 이전 버전의 개발·검증 기록이다.

# Sunrise File Manager v1.5.2 — 버전 승격 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R03.zip`, SHA256 `2706b3f21195ab7ff5be14b9aa587e54cd04d66d4abb527c25e967ac5bccc64a`.
- Windows VM에서 통과한 1.5.1 R03의 동작을 유지하고 제품·Control·창 제목·설치 버전을 1.5.2, Assembly/FileVersion을 1.5.2.0으로 동기화했다.
- 기존 14개 배치·실제 마우스 98회 클릭/72회 드래그 검증은 동작 코드가 같으므로 REUSED_PASS로 승계한다. 첨부 화면과 로그는 당시 1.5.1 실행 기록이다.
- 이번 검증: 버전 소유자 일치 PASS, 설치 버전 계약 검사 7개 PASS, Windows 대상 WPF 교차 컴파일 경고 0·오류 0.
- 목표 출력: `dist/Sunrise_File_Manager_1.5.2_Setup.exe`. 회사 빌드 진입점은 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`.
- 설치파일 생성·서명·설치·업데이트는 미검증/PENDING이다. 공개 latest.json/notice.txt와 원격 배포는 갱신하지 않았다.

---

# Sunrise File Manager v1.5.1 R03 — Windows 분할·스크롤 실행 검증 (2026-10-23)

- Windows Server 2025 가상 머신의 활성 데스크톱에서 WPF 화면을 실제 실행했다. 해상도 1920×1080, Windows DPI 100%, 앱 배율 90%.
- 1~4분할 14가지 배치의 표시·스크롤·폴더 이동·탭·크기 변경·분할 경계 검사 PASS.
- 실제 OS 마우스 입력 98회 클릭·72회 드래그, 8회 분할 선택·18개 창 검사 PASS. 파일 목록과 좌측 트리의 가로 막대 양 끝 이동, 폴더 더블클릭/뒤로/앞으로/상위 이동 PASS.
- 최종 실행: https://github.com/Peter-msk/Sunrise-File-Manager/actions/runs/39915493146 / commit `697c6ae8a5fb7c0f785cb3b5991f47431d92a7d5`.
- 제품 소스는 R02와 동일하다. R03에서는 실제 Windows 실행을 막던 검사 호스트 초기화 문제를 수정하고 네이티브 입력·화면 증적을 추가했다.
- 회사 기본 빌드에는 검사·문서 읽기를 추가하지 않았다. 기존 `CHECK_SPLITS_ON_WINDOWS.cmd`로 선택 실행한다.
- 범위: Windows VM의 해당 UI 시나리오 PASS. 설치형 Setup 생성·서명·설치·업데이트 및 사용자 PC/다른 DPI 전체 검증은 별도 PENDING.
- 기록과 화면: `docs/V151_R03_WINDOWS_UI_VERIFICATION.md`, `validation/windows-ui-r03/`.

---

아래는 이전 리비전 시점의 이력이다. 과거의 Windows UI PENDING 표기는 위 R03 검증 범위에 한해 대체된다.

# Sunrise File Manager v1.5.1 R02 — 1~4분할 전체 배치 점검·보완 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R01.zip` / SHA256 `54cb9eb81ca89f892903ba7bdbf22b0c0509842d90e0131b642c8b6f6c52e409`.
- 범위: 단일 1개, 2분할 2개, 3분할 6개, 4분할 5개 = 14개 배치와 196개 배치 간 전환.
- 보완: 350×340 DIP 트랙 최소 크기와 배치별 작업영역 extent를 통일, 실제 viewport 기준 측정, 고정 탐색창의 테두리/여백 16 DIP 누락 반영, 잘못된 숫자 preset 복원 차단.
- 실행 결과: Windows 대상 앱 및 WPF 검증 프로젝트 교차 컴파일 각각 경고 0·오류 0. 실제 production C# 분할/보존 로직 2,821 assertions PASS. 관련 Python 32 tests + XML 16개 PASS.
- **Windows 실제 클릭·키보드·표시·서명·설치·packaged 실행은 미수행/PENDING**. 교차 컴파일과 로직 실행을 Windows 조작 완료로 간주하지 않음.
- 선택 검증: `CHECK_SPLITS_ON_WINDOWS.cmd` (기본 빌드에 연결하지 않음).
- 상세 및 증적: `docs/V151_R02_ALL_SPLIT_AUDIT.md`, `validation/logs/R02_*`.

---

# Sunrise File Manager v1.5.1 R01 — 파일 목록 밀림·분할 후 가로 스크롤 보완 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R00.zip` / SHA256 `59cb9b76586cd0b42b1941b0d568f59725a680ca07d9c1b92f44a2f0cc8f5850`.
- 사용자 첨부 영상·이미지에서 중앙 파일 목록의 열/가로 위치 이탈 및 단일→2분할 후 첫 창 가로 막대 부재 관찰.
- 분할 창도 포인터 선택 가로 위치 보호, 내부 ScrollViewer 장기 캐시 제거, 재부착·크기/분할 변경 후 1회 범위 재계산.
- 파일 목록만 열 가상화 해제(행 가상화 유지), 가로 막대 상시 표시. R00 좌측 폴더 트리 가로 스크롤 및 R05 설치 오류 수정 유지.
- 변경 관련 Python 소스 검사 30 PASS, 앱 XML 14개 파싱 PASS. Windows 실제 재현 검증·WPF 빌드·서명·설치 PENDING.
- 실제 WPF 범위/좌우 이동/유휴 위치 안정성/이름 geometry 검사를 `--file-scroll-only` 선택 경로에 추가. 이 환경에서 실행하지 않았고 기본 빌드에 연결하지 않음.
- 상세: `docs/V151_R01_FILE_VIEWPORT_SPLIT_SCROLL_FIX.md`.

---

# Sunrise File Manager v1.5.1 R00 — 좌측 탐색창 가로 스크롤 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1.zip`, SHA256 `84bc4cd6c81190ca286e010886b2c31807d89ba81f33c2b5c719a7ffd553b05d`.
- 좌측 탐색창: 가로 스크롤바 Auto, 긴 폴더/드라이브명 1줄 전체 너비, Shift+휠 좌우 이동. 일반 휠 세로 이동 및 Ctrl 예약 유지.
- 상단 빠른 이동·고정/위치 찾기 조작부는 표시 폭을 유지. 기존 단일 세로 스크롤·트리 지연 로딩·창 너비 조절·자동 숨김 유지.
- 제품 버전 1.5.1 유지. 동일 버전 첫 수정 전달본 `Sunrise_File_Manager_v1.5.1_R00.zip`.
- 변경 관련 소스 검사 32 tests PASS, 앱 XML 및 변경 범위 확인 PASS. Windows WPF 빌드/서명/실제 스크롤·시각 검증 PENDING.
- R05 설치 주석 수정 유지. 상세: `docs/V151_R00_NAVIGATION_HORIZONTAL_SCROLL.md`.

---

# Sunrise File Manager v1.5.1 — 현재 전달본 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.0_R05.zip` (SHA256 `d2064543dd3bfd9178b754fa3afc0e2cdd5a96fc2ce3f559eb8c36d51f5baa53`).
- 제품/Control/창 제목/설치 버전 `1.5.1`, AssemblyVersion/FileVersion `1.5.1.0`으로 동기화.
- R05의 Inno Setup `[Code]` 86행 주석 수정 포함. 기본 self-contained 설치형 및 회사 빌드 문서 테스트 미실행 유지.
- 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`; 목표 출력 `dist/Sunrise_File_Manager_1.5.1_Setup.exe`.
- 버전 관련 10 tests + 기존 패키징 18 checks PASS; 버전 일치·XML 확인 PASS. Windows 빌드/서명/설치/실행 PENDING.
- 기존 원격 latest.json/notice.txt와 게시 상태를 변경하지 않음. 아래 과거 버전 기록과 `BUILD_TEST_ENVIRONMENT.txt`, `validation/PRE_BUILD_RESULT.json`은 과거 증적.
- 상세 인수인계: `docs/V151_VERSION_HANDOVER.md`.

---

# v1.5.0 R05 설치 스크립트 컴파일 오류 수정 (2026-10-23)

- 기준: 첨부 `Sunrise_File_Manager_v1.5.0_R04(2).zip`, SHA256 `2104c1712c753632a7121ecfdbb06e552db8087928fc44e522a646d29da393b1`.
- 사용자 제공 R04 로그: WPF publish 및 본체 서명 SUCCESS; Inno Setup 6.7.3의 `[Code]` 86행에서 `'BEGIN' expected`로 실패.
- 수정: 해당 주석을 `;`에서 Pascal `//`로 변경. 제품 버전 1.5.0 유지, 전달 리비전 R05.
- 기본 회사 빌드는 앱 프로젝트만 publish하며 문서 테스트를 실행하지 않음. 테스트 샘플은 개발 소스에 보존하고 앱/설치 페이로드에는 추가하지 않음.
- 검증: 관련 Python 20 tests + 패키징 18 checks PASS; 원래 주석으로 되돌리면 재발 검사에서 86행 검출. 앱 C#/XAML/프로젝트·CMD 원본 바이트 동일.
- 새 R05 Setup의 Windows 컴파일·서명·설치·실행은 PENDING. 상세: `docs/V150_R05_INSTALLER_COMPILE_FIX.md`.

---

# v1.5.0 R04 배포구조 변경 (2026-10-23)

- 부모: `Sunrise_File_Manager_v1.5.0_R03.zip` / SHA256 `f3fa5b426a11abd5bcdccb7c222a882e66a65e901b582c303d15b9eb828485b4`.
- 제품 버전 `1.5.0` 유지. 사용자 선택을 위한 장기 투트랙: Track A **self-contained 설치형 이번 반영**, Track C **C++/Win32 네이티브 포터블형 별도 향후 개발**.
- 현재 공식 `BUILD_ON_WINDOWS_COMPANY.cmd` 기본 `SUNRISE_LIGHTWEIGHT=0`. C# WPF 앱의 .NET 10 Desktop Runtime x64를 패키지 안에 번들. 대상 PC는 별도 Runtime/SDK 설치 필요 없음.
- `SUNRISE_LIGHTWEIGHT=1`은 이전 호환/진단용 framework-dependent 빌드를 계속 지원하며, 이 경우 Runtime 사전검사 및 10MB Setup 상한 유지. 기본 self-contained Setup에는 10MB 강제 상한 적용하지 않음.
- 그룹서명·Inno AppId·업데이트 매니페스트/파일명·사용자 설정/메모/파일 접근 규칙은 수정하지 않음. 실행환경 구성요소 호환성 및 크기는 Windows 빌드/설치 검증 필요.
- 이번 환경에서 검증한 것은 정적 빌드 계약과 소스 보존이며 Windows 실제 C# 컴파일·Setup 빌드/서명·설치/업데이트 **PENDING**. 관련 문서: `docs/V150_R04_DUAL_TRACK_DISTRIBUTION.md`.

---

# v1.5.0 R02 재감사 현재 상태 (2026-10-23)

- 직접 부모: `Sunrise_File_Manager_v1.5.0_R01.zip`, SHA-256 `e3c381cf2429ac5e0d9cdf027467bc349e07cab3d142fafb702fa7423fd4a943`. 이전 ZIP 보존.
- R01의 P1/P2/P3 최초 연결은 유지하고, ZIP 경로·암호 항목·내용 해시·확장 후 한도, 복구 기록 컴파일 선언 충돌·JSON 복원·링크 경계, ShellNew 출력 부모 링크, 따옴표가 닫히지 않은 조건 검색 입력을 수정.
- R01 산출물 검토 과정에서 `docs/WINDOWS_EXPLORER_GAP_MATRIX.md`의 일부 상태가 오래된 미구현 표기로 남아 있던 점과 `RELEASE_STATUS.json`의 휴지통 상태가 실제 소스와 다른 점을 정리.
- 검증: Python 소스 계약/회귀 **272 passed, 106 subtests**, XML 파싱. 신규 C# targeted tests `--v150-r02` 작성. 이번 환경에 .NET SDK/Windows가 없어 **C# 컴파일, 로직 실행 및 Windows 패키지 검증 PENDING**.
- `R02`는 Windows용 공식 출하 승인/Full File Explorer parity가 아니다. 상세 문서: `docs/V150_R02_FINAL_AUDIT.md`.

---

# R01 구현 델타 (2026-10-23)

최신 전달 소스 후보: `Sunrise_File_Manager_v1.5.0_R01.zip`. 부모 체크포인트 `Sunrise_File_Manager_v1.5.0_R00.zip`. 개발 구현: Windows ShellNew/독립 다중 창(P1), 휴지통 선택 영구삭제와 일부 속성검색(P2), ZIP 항목 편집/중단 전송 검토·제한적 재복사(P3).

**검증 자격:** Python 소스계약/회귀 및 XML 구조 검증 PASS; C# 컴파일·Windows UI/파일/서명/설치 검증 **PENDING**. 정식 제품 승격 전 반드시 `docs/V150_R01_P1_P2_P3_IMPLEMENTATION_HANDOVER.md`의 Windows Gate를 수행해야 한다.

---

# Sunrise File Manager v1.5.0 — 현재 소스 인수인계

## v1.5.0 R00 — 2026-10-23 중단 작업 재개

- 부모: `Sunrise_File_Manager_v1.5.0.zip` / SHA256 `a2d93ed0f32e1ef4bf588be55c4f489cd57d10abadb4388ca9addbcb2b4fb303`. 원본은 수정·삭제하지 않음.
- 범위: 페이지를 넘는 조건 일치 전체 결과 선택(최대 20,000개), 현재 페이지에서 선택 제외 후 다른 페이지 선택 유지, 기본 상세 열 6개의 보기/숨기기 및 세션 복원, 상태 표시 개수 정확성. 새 외부 실행파일·NuGet 패키지·런타임 추가 없음.
- 소스 검사: Python 회귀검사 및 XAML/프로젝트 XML 파싱. C#/.NET 로직 테스트 `--v150-r00` 작성, 이번 Linux 환경에 SDK가 없어 **실행 PENDING**.
- Windows 빌드/서명/설치/GUI/DPI, 10MB Setup 실측: **PENDING**. 부모 v1.5.0의 이전 교차 컴파일 PASS를 R00의 신규 컴파일 PASS로 승계하지 않음.
- 상세 결과·검증 명령: `docs/V150_R00_PAGED_SELECTION_COLUMN_SETTINGS.md`.

---

- 기준일: 2026-10-22 / 부모: `Sunrise_File_Manager_v1.4.1.zip`
- 부모 SHA256: `688741298ca5b17cd3c7a6d5638bd906ad83911f1cbc3f39be13eee37c607d28`
- 산출물: `Sunrise_File_Manager_v1.5.0.zip` — 전체 소스·기존 빌드 진입점·가상 예시 파일 포함. 이전 ZIP/이력 보존.
- 목적: 높은 우선순위 1~4 구현, 외부 프로그램 추가 보류, 예시 파일 기반 기능 점검·보완, Windows 탐색기 기능 비교 및 경량 배포 경로 마련.
- 버전: 주요 검색 형식·사용 흐름 추가로 부버전 1.5.0. 공개 feed/공지/게시 자산은 변경하지 않음.
- 자격: **SOURCE_VALIDATED / Linux .NET 10.0.100 교차 컴파일 경고 0·오류 0 / Windows UI·네이티브·서명·설치 PENDING.**

## 높은 우선순위 구현

| 항목 | 이번 반영 | 확인 범위 |
|---|---|---|
| AI 본문 검색·규칙 분류 | 승인·파일수·바이트 상한을 유지하고 일반 탐색기와 공통 전체 순차 파서 사용. 규칙은 한 번 읽으며 여러 키워드 추적. 요약 모델의 문맥 제한은 별개 | 뒤쪽 DOCX/PDF/HWPX·여러 규칙 충돌·승인 필수·원본 바이트 보존 실행 PASS |
| XLSX/PPTX | XLSX inline/shared 문자열·실제 셀 참조·저장 값, PPTX 슬라이드/노트. 수식·매크로·외부 연결을 실행하지 않음 | 실제 개발 라이브러리로 만든 2시트/3슬라이드 예시·rich text·미참조 shared string 제외 PASS |
| 일반 HWP 5 | 자체 읽기 전용 MS-CFB FAT/DIFAT/mini-stream 및 BodyText record/Deflate 읽기. 새 DLL·Hancom·변환기 없이 처리 | 합성 uncompressed/Deflate·mini/regular stream·뒤쪽 텍스트·순환 FAT·보호문서 제외 PASS. 실제 업무 HWP corpus/한컴 페이지 재현은 미검증 |
| 암호 압축 해제 | 기존 SharpCompress에 입력 암호 연결, 암호 재시도·취소, staging 후 공개. 암호 ZIP 별도 실행파일 없음 | 독립 생성 ZipCrypto/AES-256 ZIP의 무암호·오암호·정상 암호·원본 보존·부정 경로 PASS. 암호 7z/RAR 대표 fixture는 PENDING |

## 추가 탐색 기능과 보완

- 현재 폴더 이름 wildcard 및 `name:`, `ext:pdf,docx`, `size:>=1MiB`, `modified:>=2026-01-01`, `created:`, `kind:file/folder` 조건. Windows AQS 전체를 구현한 것은 아니다.
- Windows 바로가기 만들기·클립보드 항목의 바로가기 붙여넣기. STA worker·부분 완료/취소 안내·생성 이력. 기존 Windows COM만 사용.
- 숨김/읽기 전용 파일 속성 설정·해제. 다른 속성 비트 보존. 폴더 ReadOnly를 쓰기 차단으로 오표시하지 않음.
- 압축 내용 읽기 전용 목록과 선택 파일만 새 폴더에 해제. 없는 선택 키는 결과를 공개하지 않음.
- 현재 필터·정렬 전체 결과 CSV 내보내기. 전체 결과 수집 100,000개 상한/읽기 실패면 미완전한 결과를 전체로 저장하지 않음. 페이지 전체 선택은 여전히 현재 페이지 단위.
- 별도 엔진 없이 **Windows에 설치된 OCR 언어/기능만** 사용. 이미지 또는 지정 PDF 범위 최대 20쪽을 명시적으로 읽고 텍스트 복사. 자동 다운로드·OCR 색인 없음. 실행은 Windows PENDING.
- 기존 클라우드 상태 열의 가운데 정렬 스타일 누락 수정. 과거 버전 핀·보편 전송 승인 테스트를 현행 계약으로 갱신, 검증 assertion 자체는 유지. 업데이트 fixture는 실행 버전의 다음 패치로 만들어 버전 변경에 따른 오판 제거.

## 용량과 외부 프로그램 계약

신규 외부 실행파일·OCR 엔진·Office/Hancom·7-Zip·새 NuGet runtime package를 추가하지 않았다. 기존 선택형 AI 구성은 배포 앱에 포함하지 않으며 이번 점검에서 설치/실행하지 않았다.

기존 공식 단일 진입점 `BUILD_ON_WINDOWS_COMPANY.cmd`는 기본 `SUNRISE_LIGHTWEIGHT=1`로 빌드한다. 경량 Setup은 기존 **.NET 10 Desktop Runtime x64**를 사용하고, 없으면 설치 전에 안내 후 중단한다. 자동 다운로드하지 않는다. `set SUNRISE_LIGHTWEIGHT=0` 후 같은 CMD를 실행하면 종전 실행환경 포함 모드를 유지한다. 두 모드 모두 기존 제품 EXE/DLL·Setup/Uninstaller 서명 계약을 유지한다. 경량 Setup은 **10,000,000바이트 초과 시 빌드를 실패**시킨다.

현재 최종 소스의 Windows x64 framework-dependent publish 실측:

- 앱/필수 DLL 원본 합계: **34,807,368 bytes (약 34.81MB)**.
- 그 폴더의 ZIP 실측: **9,712,830 bytes (약 9.71MB)**, 별도 실행환경·라이선스/Setup·서명 미포함 측정용 ZIP.
- 실제 서명 Setup 크기·설치 후 잔여 파일·업데이트 전환 결과: **WINDOWS_BUILD_PENDING**.
- 설치 후 전체 파일과 공유 실행환경까지 합쳐 10MB 이하인 상태는 **아니다**. Windows SDK API 연결 DLL 약 24MB와 기존 문서 파서 의존성을 유지한다. WPF 호환성/기능을 손상시키는 임의 trimming이나 필수 DLL 삭제는 하지 않음.

SDK 시험에서 framework-dependent 단일 파일 압축은 지원되지 않았으므로 채택하지 않았다. 자립형 단일 파일은 실행환경 때문에 더 커져 채택하지 않았다. 최종 경량 경로는 framework-dependent OneDir를 Setup으로 압축하는 방식이다.

## 예시 파일과 전체 점검

`source/tests/LogicTests/Fixtures/ExplorerSamples/`에 **19개 합성 예시**와 README·생성기·해시 목록을 포함한다. DOCX/XLSX/PPTX, parser용 HWP/HWPX, PDF 6쪽/이미지 PDF, OCR 이미지, 일반/암호 ZIP, 손상 PDF/부정 경로 ZIP, 한글·공백·빈 파일 등을 포함한다. 실제 사용자·업무 자료 없음. 회사 Windows 빌드는 이 fixture를 읽거나 앱에 복사하지 않는다. HWP/HWPX 합성 fixture는 한컴 화면 호환성 표본으로 표현하지 않는다.

현행 `validation/PRE_BUILD_RESULT.json`은 입력 해시 안정성 확인과 아래 실행 결과를 기록한다.

| 검사 | 결과 |
|---|---:|
| 신규 v1.5.0 실제 파일·문서·압축·검색·필터 검증 | **72/72 PASS** |
| 기존 휴대형 통합 로직 | **393 assertions PASS** |
| v1.4.1 메모/검색/페이지/클라우드 태그 보완 | **30/30 PASS** |
| v1.4.0 전송/병합/압축/검색 인접 기능 | **42/42 PASS** |
| Python 현행 소스 계약 | **253/253 PASS** |
| UI 소스·테마·연결 계약 | **19/19 PASS** |
| 업데이트 처리 실제 로직(합성 transport) | **33/33 PASS** |
| 릴리즈 메타데이터 생성·wire adapter | **12/12 PASS** |
| 현행 패키징·서명 경로 소스 계약 | **17/17 PASS** |
| Windows 대상 C#·WPF XAML 전체 컴파일 | **PASS, 경고 0·오류 0** |

휴대형 실행은 Windows DPAPI 메모 통합 및 관련 AI/셸 사례를 명시적으로 제외한다. 검사 수를 더해 전체 제품의 모든 동작이 PASS라고 표현하지 않는다. 소스 계약·교차 컴파일은 Windows GUI/Setup 실행 증거가 아니다. 회사 빌드에서는 통과한 소스 검사를 재실행하지 않는 기존 정책 유지.

## Windows 비교와 남은 일

현행 전체 비교표: `docs/WINDOWS_EXPLORER_GAP_MATRIX.md`. 기존 R04 표는 역사 기록으로만 보존한다. 이 전달본이 Windows 탐색기의 모든 기능과 동일해진 것은 아니다.

미구현: 독립 다중 창·창별 세션, Windows ShellNew 템플릿 전체, 페이지를 넘는 전체 선택/선택 제외, 임의 속성 열 전체, 휴지통 내부 탐색/비우기/내부 영구 삭제, Windows AQS 전체, 최신 축약 메뉴 전체, 압축 내부 직접 편집·암호 생성, 일반 전송의 강제 종료 후 자동 재개/복구, 자체 장치 관리. 클라우드 계정·서버 권한·Office 통합 추천과 RAR 생성에 필요한 외부 확장은 보류한다. Windows 속성·공유·기존 확장 메뉴로 연결한 기능은 자체 엔진 구현과 구분한다.

실기 PENDING: 실제 HWP corpus, OCR 언어·인식, 바로가기·속성·압축 창·고급 필터 입력, 1/2/4분할·DPI·테마·클립보드·가상화, 실제 메모 이동/복구, Windows Search/OneDrive/셸/공유/속성 처리기/네트워크/라이브러리, 실제 경량 Setup 서명·설치·시작·업데이트와 크기. 누락된 기능·실기 확인을 완료 처리하지 않는다.

---

아래는 이전 버전의 보존 이력이며 현행 판정은 위 v1.5.0을 우선한다.

# Sunrise File Manager v1.4.1 — 현재 소스 인수인계

- 기준일: 2026-10-22 / 부모: `Sunrise_File_Manager_v1.4.0.zip`
- 부모 SHA256: `5c633a8189225dd4c995d64d468a94a372e2b1b4de2573700963b9a2f708e91c`
- 산출물: `Sunrise_File_Manager_v1.4.1.zip` 전체 소스. 기존 Windows 빌드 진입점과 이전 이력 보존.
- 버전: 검토에서 확인된 제한·결함 보완이므로 패치 1.4.1. 제품/설치/화면/Control 로컬 버전 동기화. 공개 feed·게시 자산은 변경하지 않음.
- 자격: **Linux .NET 10.0.100 Windows 대상 C#·XAML 컴파일 PASS(경고 0·오류 0). Windows 실행·공급자 동작·서명·설치는 PENDING.**

## 이번 검토의 보완 결과

| 영역 | 현행 동작 | 검증과 남은 범위 |
|---|---|---|
| 메모 동반 이동·바꾸기 | 사전 메모 목록·내용·원본 바이트 지문을 캡처하고 게시 후 재검증. 원본 메모는 고유 임시명으로 옮겨 검증한 소유 사본만 정리. 취소/실패는 복원하며 동시에 생긴 메모는 덮어쓰지 않고 보존 경로 안내. 같은 볼륨 이동 실패의 대상 정리도 게시한 지문과 일치하는 사본에만 적용 | 실제 파일 기반 변경·취소·동시 생성·롤백 로직 PASS. DPAPI·실제 Windows 메모 이동 통합 PENDING |
| 직접 문서 본문 검색 | 미리보기 제한과 분리. PDF 전체 페이지, DOCX 본문·머리말·꼬리말·각주·미주, HWPX 전체 section 순차 읽기. 미지원/크기·일부 미검색/텍스트 없음/읽기 불가 별도 집계 | PDF 5쪽·16,000자 뒤 DOCX·서식 run 경계·머리말·HWPX 11번째 section·손상 PDF PASS |
| 일반 대량 폴더 | 전체 폴더에 필터·정렬을 적용한 2,000행 단위 커서 페이지. 이전/다음 및 페이지 밖 위치 찾기. 현재 페이지의 전체 선택·목록 내보내기 | 실제 5,005개 파일 3페이지·중복/누락·전체 정렬·페이지 밖 검색/위치 찾기 PASS. WPF 조작·DPI PENDING |
| 클라우드 경로 | 태그 조회로 문서화된 16종 Cloud Files reparse tag만 일반 연결 경로와 구분. 심볼릭 링크·접합점·알 수 없는 태그 계속 차단. 다운로드는 OVERLAPPED 및 CancelIoEx로 취소 요청 | 순수 태그 분류·실제 휴대형 symlink 제외 PASS. Windows 태그 조회·동기화 공급자·다운로드/취소 PENDING |
| 검색·속성 응답성 | 검색 worker 동시 실행 최대 2개. UI 취소는 대기 해제, 인덱스 Command 취소 요청·timeout. 속성 COM 읽기/저장 STA worker 분리 | 취소 로직·컴파일 PASS. native COM 중단·속성 처리기 실행 PENDING |
| 전송 속도 | 처리 완료 바이트와 실제 복사 바이트 분리. 건너뛰기·같은 볼륨 이름 이동을 복사 속도에 더하지 않음 | 실제 복사/건너뛰기 바이트 PASS. UI·드라이버 성능 PENDING |
| 사진 모음 | 모든 대상 폴더를 훑어 전역 최신 20,000개 유지. 겹치는 루트 중복 제거, 페이지당 80개 | 상한보다 많은 후보의 최신 선정·중복 제거 PASS. 실제 이미지 디코더·창 PENDING |
| 최근 관련 폴더 | 사용 횟수로 오인하는 N회 대신 현재 Recent에 남은 관련 파일 N개로 표시 | 소스·컴파일 확인. 실제 Recent 데이터 PENDING |

## 유지되는 한계와 사용 계약

1. 검색은 텍스트 계열·PDF·DOCX·HWPX에 한정한다. OCR, 구형 HWP, XLSX/PPTX 직접 본문 검색, 암호 문서 입력 UI는 추가하지 않았다. PDF도 추출 가능한 텍스트만 검색한다. 문서 128MiB, 텍스트 16MiB, XML 한 항목 64MiB·누적 256MiB·문서 내부 10,000개, 검색 결과 100,000개 제한을 유지한다. 제한·예외는 검색어 없음과 구분해 표시한다.
2. 일반 폴더 UI는 2,000행만 보유하지만 페이지를 바꿀 때 폴더를 다시 열거하므로 큰 폴더·UNC는 시간이 걸릴 수 있다. 폴더 변경 중 페이지는 고정 시점 스냅샷이 아니므로 새로고침이 필요할 수 있다. 메모 이름 조회·최대 100,000개 검색 결과·다른 호출자의 전체 목록은 별도 메모리를 사용한다. 앱 전체의 일정 메모리나 무제한 파일 수는 보장하지 않는다.
3. Ctrl+A와 목록 내보내기는 **현재 페이지**에 적용하며 UI 문구로 구분한다. 전송 최상위 선택 1,000개·계획 50,000항목, 압축 20,000항목/해제 8GiB, 사진 최신 20,000개/80개씩, Windows 위치 컨테이너 2,000개 제한은 유지한다.
4. 네이티브 작업은 취소를 요청해도 드라이버/공급자가 반환할 때까지 내부 종료가 지연될 수 있다. 강제 프로세스 종료나 전원 손실의 자동 복구는 이번 변경에서 보장하지 않는다. 메모 복원 충돌이나 정리 실패 시 임시 보존 경로를 안내하므로 확인 전 삭제하지 않는다.
5. 클라우드 기능은 이미 연결된 Windows 계정·공급자를 사용한다. 공간 확보는 고정 해제 요청이며 실제 온라인 전용 전환은 공급자가 결정한다. AI 경로의 별도 제한은 넓히지 않는다.
6. v1.4.0의 명시적 충돌 선택·바꾸기 전 대상 보존, 폴더 병합, 압축 형식, 셸 확장 메뉴·공유 및 기존 설정/업데이트 계약은 유지한다. Windows 11 최신 축약 메뉴 전체 구현, RAR 생성, 암호화 아카이브 해제는 지원 계약에 추가하지 않는다.

## 이번 소스 검증

- 전체 앱 Windows 대상 C#·WPF XAML 교차 컴파일: **PASS / 경고 0·오류 0**.
- `LogicTests.dll --v141-corrective`: **30/30 PASS**, 실제 임시 파일·문서·페이지·메모 변화·사진 후보·바이트를 판정.
- 인접 기능 `--v140-priority`: **42/42 PASS**. 전송/병합/취소, 20,050개 full-snapshot API, 검색, 압축 형식·CRC·부정 경로 확인.
- 기존 직접 전송·이동·자연 정렬 Python 계약: **11/11 PASS**. 기존 Windows 패키징 소스 계약 **15/15 PASS**.
- 전체 과거 회귀 PASS를 승계하지 않는다. 교차 컴파일 및 패키징 소스 계약은 Windows 설치 EXE 생성·서명·시작 결과가 아니다.

## Windows 인수와 구현 소유자

전체 ZIP을 별도 폴더에 해제하고 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`를 사용한다. 이번에 PASS한 소스/로직 검사를 Windows 빌드에 중복 추가하지 않는다. 남은 실기 범위는 메모 실제 이동·실패 복구, 1/2/4분할·테마·DPI·페이지 선택/스크롤, 검색 취소와 Windows 인덱스, OneDrive 태그/다운로드/취소, 속성 쓰기 후 재조회, 셸 확장·공유·네트워크·라이브러리, Setup 서명·설치·시작이다.

- 메모: `MemoTransferSnapshot.cs`, `FileMemoStore.cs`, `TransferService.cs`.
- 검색: `DocumentContentSearch.cs`, `ExplorerSearchService.cs` (미리보기 소유자는 그대로 유지).
- 목록: `DirectoryScanner.cs`, `FileListView.cs`, ExplorerPane Navigation/View partials.
- 클라우드/속성: `ReparsePointPolicy.cs`, `WindowsCloudFilesService.cs`, `WindowsMetadataService.cs`와 대응 창.
- 사진: `PhotoCollectionScanner.cs`, `PhotoGalleryWindow.cs`.
- 검증: `source/tests/LogicTests/V141CorrectiveTests.cs` 및 기존 관련 검사.

---

아래는 이전 버전의 보존 이력이다. 현행 판정은 위 v1.4.1을 우선한다.

# Sunrise File Manager v1.4.0 — 현재 소스 인수인계

- 기준일: 2026-10-22 (한국 시간)
- 부모 기준본: `Sunrise_File_Manager_v1.3.8_R04.zip`
- 부모 SHA256: `2152a2e326cfd6e066939a4d110394ede0450e95b9e4cb0b205fb3587e2fb915`
- 산출물: `Sunrise_File_Manager_v1.4.0.zip` — 전체 소스 및 기존 Windows 빌드 진입점 포함
- 버전 결정: 주요 기능 추가로 제품/설치/화면/Control 로컬 버전을 **1.4.0**으로 동기화. 외부 게시정보는 실제 게시 증적과 구분.
- 적용 기준: 첨부 Sunrise Group v2.8 모듈, 그룹 전용 v1.3, 범용 v1.3. 기존 기준 ZIP과 과거 이력은 보존.
- 자격: **Linux .NET 10.0.100에서 Windows 대상 C#·XAML 컴파일 및 변경영향 로직 검증 완료. Windows 실행·서명·설치는 PENDING.**

## R04 차이표의 우선순위별 반영 결과

아래의 ‘소스 반영’은 코드와 메뉴 연결이 존재하고 컴파일되었다는 뜻이다. Windows 기능의 사용자 관찰 결과는 실기 확인 전 PASS로 선언하지 않는다.

| R04 번호 | 중요도 | 기능 | 소스 반영 내용 / 사용 경로 | 실제 검증 범위 |
|---:|---|---|---|---|
| 1 | 높음 | 파일 충돌 비교·바꾸기 | 일반 복사·이동은 바로 시작. 실제 충돌 때만 경로·크기·수정일 비교, 건너뛰기/새 이름/바꾸기/작업 중단 및 남은 충돌에 적용 | 실제 파일 바이트·기존 대상 보존·취소 로직 PASS; 대화상자 Windows PENDING |
| 2 | 높음 | 같은 이름 폴더 병합 | 대화형 전송에서 동일 폴더를 자식별 병합. 충돌하지 않은 항목과 건너뛴 항목 구분. 메모는 소유 파일과 함께 처리 | 재귀 병합·부분 이동·실행 취소·건너뛴 원본 메타데이터 보존 PASS; 실제 Windows 메모 경로 PENDING |
| 3 | 높음 | 하위 폴더·본문·인덱스 검색 | 보기 → 검색 범위. 현재 폴더 필터 / 하위 이름 / 하위 이름+본문 / Windows 인덱스. Esc로 취소 | 이름·본문·청크 경계·SQL escaping·설정 보존 PASS; Windows Search 서비스 PENDING |
| 8 | 높음 | Windows 확장 메뉴 | 파일 메뉴 또는 우클릭 → Windows 확장 메뉴. IContextMenu2/3의 소유자 그리기·하위 메뉴 메시지 전달 | C#·XAML 컴파일 PASS; 등록된 셸 확장·메모 보호·다중선택 Windows PENDING |
| 15 | 높음 | 20,000개 초과 일반 목록 | 일반 DirectoryScanner의 고정 제한 제거. 백그라운드 열거·취소·DataGrid 가상화 유지 | **20,050개 실제 파일 생성·전체 표시 대상 조회 PASS**; WPF 응답성 Windows PENDING |
| 4 | 보통 | Windows 공유 | 파일 메뉴 또는 우클릭 → Windows 공유. 창 HWND에 연결된 DataTransferManager 및 파일/폴더 DataPackage | 컴파일 PASS; 공유 대상 앱/근거리 공유는 Windows PENDING |
| 5 | 보통 | 여러 압축 형식 | 추가 기능 → ZIP/TAR/7z 생성, ZIP·7z·RAR·TAR 및 지원 압축 TAR 해제 | ZIP/TAR/7z 왕복·RAR/RAR5 CRC·tar.gz·부정 경로·링크·중복 이름·일반 TAR ./ 경로 PASS |
| 6 | 보통 | 그룹화 | 보기 → 그룹 기준 → 종류/수정일/크기/상위 폴더/없음. 그룹 사용 중 가상화 유지 | 설정 roundtrip·C#·XAML 컴파일 PASS; 그룹 행·정렬·선택 Windows PENDING |
| 10 | 보통 | OneDrive·클라우드 파일 | 추가 기능 → OneDrive 계정 폴더. 클라우드 상태 열, 항상 이 장치에 유지, 공간 확보 요청, Windows 공유·확장 메뉴 | 속성 비트 분류 PASS; 계정 경로·Cloud Files API·공급자 동작 Windows PENDING |
| 12 | 보통 | 네트워크 탐색·드라이브 | 추가 기능 → 네트워크 장치·공유 / 드라이브 연결·끊기. OS 대화상자 종료 후 드라이브 트리 갱신 | 컴파일 PASS; 실제 UNC·네트워크 검색·연결/끊기 Windows PENDING |
| 13 | 보통 | 전송 일시 중지·속도·잔여시간 | 하단 작업 영역의 일시 중지/다시 시작/취소, 평균 처리 속도·예상 잔여시간 | worker pause/resume·일시 중지 중 취소 PASS; UI 업데이트 Windows PENDING |
| 7 | 낮음 | 사진 모아보기 | 추가 기능 → 사진 모아보기. 현재 폴더·사진 폴더·추가 폴더 통합, 수정일 내림차순, 쪽당 80개 썸네일 | 컴파일 PASS; 실제 디코더·페이지 전환·사진 열기 Windows PENDING |
| 9 | 낮음 | 최근 파일·자주 사용한 폴더 | 추가 기능 → 최근 파일·자주 사용한 폴더. Windows Recent 바로가기의 실제 대상 및 부모 폴더 빈도 | 컴파일 PASS; 실제 Windows Recent 데이터 PENDING |
| 11 | 낮음 | Windows 라이브러리 | 추가 기능 → Windows 라이브러리. Shell Namespace 컨테이너 탐색과 실제 파일/폴더 열기 | 컴파일 PASS; 실제 .library-ms 및 가상 집계 Windows PENDING |
| 14 | 낮음 | 태그·작성자·평점 편집 | 정보 메뉴 또는 우클릭 → 태그·작성자·평점 편집. Windows Property Store로 변경한 필드만 Commit | 컴파일 PASS; 파일 형식별 속성 처리기 쓰기·다시 읽기 Windows PENDING |

## 동작 범위와 데이터 보존

1. 자동 덮어쓰기는 하지 않는다. 바꾸기는 사용자가 충돌 처리에서 명시적으로 선택한 경우에만 허용한다. 기존 파일은 대상 옆 `.sunrise-before-…` 경로에 남기며 완료창에서 안내한다. 필요 여부를 확인한 뒤 사용자가 정리한다.
2. 기존 대상에 메모가 있거나 원본/대상의 메모를 안전하게 읽을 수 없으면 바꾸기를 실패로 보고하고 원본을 유지한다. 새 이름 전송을 사용할 수 있다. 바꾸기 이동은 일반 이름 변경 기반 실행 취소 이력에 넣지 않는다. 기존 대상 복구본과 전송 결과는 별도로 확인한다.
3. 병합 이동은 완료된 자식의 실제 경로로 실행 취소한다. 원본의 빈 폴더와 남은 메모 폴더는 복원 경로 보존을 위해 남을 수 있다. 건너뛴 파일의 메모를 독립적으로 대상에 옮기지 않는다. 비대화형 AI·기존 exact destination 호출의 Skip/Rename 정책은 보존한다.
4. 직접 본문 검색은 텍스트 계열·PDF·DOCX·HWPX를 지원하고, 문서의 실제 읽기 범위는 기존 미리보기 파서 제한을 따른다. 대형 텍스트는 16MiB 제한, 검색 결과는 100,000개 제한이다. 제한과 읽기 불가/미지원 건수를 표시하며 링크·접합점은 따라가지 않는다. Windows 인덱스 모드는 인덱스에 등록된 파일만 검색한다.
5. 일반 폴더 목록의 20,000개 제한 해제는 다른 기능의 제한 해제를 뜻하지 않는다. 전송 계획 50,000항목, 압축 20,000항목·해제 8GiB, 사진 모음 20,000개·쪽당 80개, Windows 위치 컨테이너당 2,000개 제한은 별도로 유지한다. 무한한 파일 수나 메모리 사용을 보장하지 않는다.
6. Windows 확장 메뉴는 같은 폴더에서 고른 1~1,000개 항목의 **기존 IContextMenu 확장**을 지원한다. Windows 11 최신 축약 메뉴의 모든 IExplorerCommand를 재현하는 계약은 아니다. 앱 공유·근거리 공유는 Windows 설정과 설치된 공유 대상에 따른다.
7. OneDrive는 Windows에 이미 연결된 계정 폴더와 공급자 파일을 사용한다. 새 계정 로그인·서버 측 공유 권한 편집·Office 클라우드 추천 엔진은 추가하지 않는다. ‘공간 확보’는 고정 해제 요청이며 실제 온라인 전용 전환 시점은 공급자가 결정한다. 미동기화 로컬 데이터를 강제로 비우지 않는다. 원격 작업 진행 중 취소는 네이티브 호출 반환까지 지연될 수 있다.
8. 사진은 파일의 수정일을 기준으로 정렬한다. Windows Recent 기반 자주 사용한 폴더는 현재 Recent 대상의 빈도로 계산하며 Office/클라우드 전체 이력과 동일하지 않다. 네트워크 장치 자동 표시 범위는 OS 검색·공유 설정에 따른다.
9. 압축은 고정 버전 **SharpCompress 0.50.6 (MIT)**를 추가했다. ZIP/TAR/7z 생성, 지원 형식 해제 경로를 제공한다. RAR 생성, 암호 입력 UI·암호화 아카이브 해제는 제공하지 않는다. 압축의 경로 이탈·링크·중복 경로와 미완성 결과 공개를 차단한다. 배포 시 해당 라이선스를 기존 licenses 폴더에 포함한다.
10. 태그·평점·작성자 편집은 설치된 Windows 속성 처리기가 쓰기를 지원하는 형식에 한한다. 지원하지 않는 속성은 오류를 표시한다. 색상·배율·분할·이름 변경·삭제 확인·기존 업데이트 흐름은 기존 제품 소유 계약을 유지한다.

## 검증 결과

- .NET SDK 10.0.100 / Linux x64에서 `net10.0-windows10.0.19041.0`, win-x64 대상 **C#·WPF XAML 전체 컴파일**: PASS, 경고 0·오류 0. 실제 Windows GUI 실행 증거가 아니다.
- `V140PriorityTests` 변경영향 실행 로직: **42/42 PASS**. 테스트 자체의 임시 폴더에 파일을 생성하고 실제 바이트·CRC·목록 수·삭제 여부를 판정함. 사용자 설정을 사용하지 않음.
- 기존 직접 전송·삭제 보호 회귀: **6/6 PASS**. 기존 다른 볼륨 이동·자연 정렬 관련 소스 계약: **5/5 PASS**. 새 충돌 선택·버전에 맞춰 obsolete literal만 현행화함.
- 기존 패키징 계약: **15/15 PASS**. 신규 외부 의존성 DLL의 Windows 실제 설치 패키지 포함·시작은 별도 PENDING.
- 전체 과거 회귀검사를 반복 실행하지 않았고, 과거의 전수 PASS를 이번 버전 전체 기능 PASS로 승계하지 않음.
- Windows packaged startup / 서명 / Setup 설치 / 셸 확장·Windows Search·공유·Cloud Files·속성 처리기 / 실제 메모 무결성 경로: **WINDOWS_DYNAMIC_PENDING**.

## Windows 인수 단계

기존처럼 전체 ZIP을 별도 폴더에 해제하고 **`BUILD_ON_WINDOWS_COMPANY.cmd`**를 실행한다. 이번 체크포인트에서 PASS한 로직·정적검사를 빌드마다 다시 실행하지 않는다. 네이티브 기능의 결과만 실제 Windows에서 확인한다.

- 충돌 대화상자 선택별 결과, 동일 폴더·하위 폴더 병합, 메모 파일 동반 이동/복원, 일시 중지·취소와 작업 후 재사용을 확인한다.
- 일반 20,000개 초과 목록·그룹 헤더·검색 결과에서 선택·정렬·스크롤·1~4분할과 100/125/150% DPI의 메뉴/새 창 잘림을 확인한다.
- 실제 Windows Search 인덱스 결과, 등록된 제3자 셸 메뉴·하위 메뉴, 공유창을 직접 연다.
- Windows에 연결된 OneDrive 계정의 온라인 파일 다운로드와 공간 확보 요청 결과, 네트워크 드라이브 연결/끊기, 라이브러리·Recent 위치를 확인한다.
- 실제 JPG/DOCX 등 지원 형식의 속성 변경 후 다시 읽기, 생성 ZIP/TAR/7z와 RAR 해제, Setup 시작·종료 로그와 새 의존성 포함을 확인한다.

## 주요 구현 소유자

- 전송/무결성: `Services/TransferService.cs`, `Controls/TransferConflictWindow.cs`, MainWindow의 기존 작업 조립 경로.
- 검색·그룹: `Services/ExplorerSearchService.cs`, `ExplorerPane.ViewAndFiltering.cs`, `FileEntry.cs`, 기존 SessionStore.
- OS 경계: `WindowsShellContextMenu.cs`, `WindowsShareService.cs`, `WindowsCollectionsService.cs`, `WindowsCloudFilesService.cs`, `WindowsMetadataService.cs`.
- 메뉴 연결: `Features/Explorer/ExplorerPane.WindowsIntegration.cs`; 사진/위치/속성 창은 각각의 Controls 파일 소유.
- 압축: `Services/ArchiveService.cs`. 기존 ZIP 생성·복제의 소유 경로는 유지.
- 검증: `source/tests/LogicTests/V140PriorityTests.cs`, 기존 관련 Python 회귀검사.

---

아래는 부모 버전의 보존 이력이며 현재 판정은 위 v1.4.0 기록을 우선한다.

# Sunrise File Manager — v1.3.8 R04 CURRENT SOURCE CHECKPOINT

- 직접 부모: `Sunrise_File_Manager_v1.3.8_R03.zip` SHA256 `f1d1f2ed8f6828959caed446ee450ffd4b6bb00a1f4000f8360b8723db2a39fb`.
- 제품·설치 버전 1.3.8 유지, 소스 리비전 R04.
- 일반 복사/이동(툴바, Ctrl+C/X/V, 내부·외부 드래그)은 선행 Yes/No 확인 없이 즉시 시작. 진행률·취소·실패 메시지 보존.
- 휴지통 이동 및 영구 삭제 확인, 미저장 메모 보호, 파일명 충돌 Skip/Rename(자동 덮어쓰기 없음) 그대로.
- `DEFECT-FM-TRANSFER-006`, `docs/V138_R04_DIRECT_FILE_TRANSFER.md`, `docs/WINDOWS_EXPLORER_GAP_MATRIX_V138_R04.md` 참조.
- Windows .NET/C# LogicTests/WPF 빌드·설치·서명·실기검증 PENDING. 외부 업데이트 wire·공개 공지의 다운로드 URL 비노출 계약 보존.

---

# Sunrise File Manager — v1.3.8 R03 CURRENT SOURCE CHECKPOINT

- 부모: `Sunrise_File_Manager_v1.3.8_R02.zip` SHA256 `ce915d5e0e0fd151b59f559e18a926c9f93a6dac9f1927c539befd2649380f26`.
- 제품/설치 버전 **1.3.8 유지**, 소스 리비전 **R03**.
- 단일 항목 이름 변경: 팝업 대신 파일 이름 셀에서 F2/메뉴 인라인 편집, Enter 완료·Esc 취소·포커스 이탈 완료.
- 표시 확장자 OFF 시 실제 확장자 자동 보존; ON 시 전체 표시·본체 부분 선택·확장자 변경 확인. 배치 이름변경은 기존 팝업 유지.
- 결함 `DEFECT-FM-RENAME-005`와 상세 `docs/V138_R03_INLINE_RENAME.md` 참조.
- 단일 좌측 스크롤, 파일 탐색 및 Control/공지 보안 계약 보존. Windows C# WPF/설치·서명 게이트 **PENDING**.

---

# Sunrise File Manager — v1.3.8 R02 CURRENT SOURCE CHECKPOINT

- 부모 기준본: `Sunrise_File_Manager_v1.3.8_R01.zip` SHA256 `b3ef37551acdc1f89d76fbcab0722096e5ccca1ad724cb40ba210700c6fd0523`.
- 제품/설치 버전 **1.3.8 유지**, 소스 전달 리비전 **R02**. 단일 `NavigationScroll` 유지.
- 3차 핵심: 하위 폴더 350개 표시 상한의 기능 누락을 페이지 단위 탐색으로 개선. 자연 정렬·커서·더 보기, 첫 페이지 외부 위치 찾기, 비활성 분기 메모리 해제.
- 1~4분할·AI·메모·세션·업데이트 및 공개 공지 비노출 계약 비침범.
- 세부 `docs/V138_R02_STAGE3_LARGE_TREE.md`; 실제 Windows WPF 빌드·UI/DPI·설치·서명 Gate PENDING.

---

# Sunrise File Manager — v1.3.8 R01 CURRENT SOURCE CHECKPOINT

- 공식 부모: `Sunrise_File_Manager_v1.3.8_R00.zip` (SHA256 `f6207a272a713c74434876e03401c0bd1f0c1ef51ed9c3e2546c21c983408c84`). 제품/설치 버전 1.3.8 유지.
- 사용자의 최신 지시: **좌측 탐색창 스크롤을 분리하지 않는다.** 빠른 이동·즐겨찾기·폴더 트리 단일 `NavigationScroll` 유지.
- 2차 보완: 명시적 `위치 찾기` 버튼, 트리 헤더 행 기반 세로 스크롤 보정, 기존 빠른 이동 자동 트리 펼침 방지·과거 분기 자동 접기 유지.
- 변경 범위: `FolderTree.xaml`, `FolderTree.xaml.cs`, 관련 소스 검사·문서. UI 외부 엔진·설치·세션 wire 계약 미변경.
- 상세: `docs/V138_R01_SINGLE_SCROLL_STAGE2.md`. Windows WPF 동적 검증 및 설치·서명은 PENDING.

---

# Sunrise File Manager — v1.3.8 R00 CURRENT SOURCE CHECKPOINT

- 부모 기준본: `Sunrise_File_Manager_v1.3.8.zip` (SHA256 `440a72baeeef4b1ddc4b59239c494e5e6fb0da54de62b86b0159590462b3472b`). 제품/설치/외부 wire 버전 1.3.8 유지, 소스 전달 R00.
- 1차 UI 밀도 개선: 폴더 트리 단계별 들여쓰기 42→16 DIP; 폴더명 1줄/말줄임/툴팁; 선택 항목 Accent 표시선; 펼침 클릭 영역 40×36 DIP 유지.
- `TreeViewItem` 조합 스타일은 유일한 소비자 `FolderTree.xaml` 로컬 리소스로 이동. `App.xaml` 전역 기본 색/의미 토큰 유지.
- 기존 NAV-002 / SCROLL-003, 저장 오류 SESSION-001의 수정과 모든 사용자 기능·세션·배포 계약 보호.
- 검증 상세: `docs/V138_R00_COMPACT_FOLDER_TREE_UI.md`. Windows 실기 렌더링·빌드·설치·서명은 PENDING.

---

# Sunrise File Manager — v1.3.8 CURRENT BASELINE

- 공식 부모 기준본: `Sunrise_File_Manager_v1.3.7.zip` (SHA256 `66b0bbe8d057e346131f248871a2e04ea3149a03ee2e23cf093f96d67e89106d`).
- 제품/설치 버전: `1.3.8`. 이전 v1.3.7 전체 기능과 설정·업데이트 계약 유지.
- 드라이브 트리 펼침 상태의 단일 소유자는 `TreeViewItem.IsExpanded`; 테마 토글은 단방향 표시용으로 변경. 첫 클릭에 접힘, 비동기 자동 재펼침 방지, 드라이브 제목 두 번 클릭의 중복 토글 방지.
- 단일 화면에서 파일 행을 포인터로 선택할 때 DataGrid의 WPF 자동 가로 스크롤을 방지. Shift+휠·스크롤바 수동 조작, 키보드 탐색, 폴더/탭 이동의 별도 동작은 유지.
- 재발 방지 결함 ID: `DEFECT-FM-NAV-002`, `DEFECT-FM-SCROLL-003` (`docs/DEFECT_REGISTRY.md`).
- Windows 실제 WPF/빌드·설치·마우스 반복 조작 검증은 PENDING. 소스 테스트만으로 동적 검증 PASS 선언 금지.
- 공지사항에는 다운로드/배포 주소, 업데이트 내부 경로, 보안 구현 정보를 노출하지 않는다.

---

# Sunrise File Manager — v1.3.7 prior baseline (historical)

- 공식 부모 기준본: `Sunrise_File_Manager_v1.3.6_R01.zip`.
- 제품 / 설치 버전: `1.3.7` (기능 복구·업데이트 종료 안정화).
- 원인 책임: v1.3.5 실행본이 1.3.6 업데이트 직전 종료될 때 세션 저장 실패 가능. v1.3.6의 설치 완료 후 생긴 오류로 단정하지 않는다.
- 신규 실행본에서는 UI 캡처/저장 경계 모두에서 임시 WPF 열 순서·너비·스크롤을 정규화하고 `Save()`의 검증/atomic replace는 유지.
- 이전 실행본 v1.3.5를 신버전 소스로 자동 패치할 수는 없다. 실제 Windows 업데이트/수동설치 검증은 PENDING.
- 회귀 누적 기록: `docs/DEFECT_REGISTRY.md`.
- 공지사항에는 다운로드·배포 경로를 공개하지 않는다.
- 다음 내용은 이전 개발 이력이며 버전/계약의 활성 근거가 아님.

---

# Sunrise File Manager — 1.3.6 현재 소스 기준본

- 기준 입력: 사용자가 제공한 `Sunrise_File_Manager_v1.3.2.zip` 전체 소스.
- 입력 ZIP SHA256: `01abefab6336caeca17d7b8d21fb060e0a64a151fc78ab8f63c326e07342396c`.
- 제품·설치 버전: **1.3.6**. 기존 파일 이동·자연 정렬 및 탐색·Control 기능을 유지한다.
- 제품 ID, Control ID, Inno AppId, 실행파일명, 메모·설정 데이터 위치, 공지·Control·정상 종료 후 설치 이관 계약을 유지한다.
- 최신 사용자 지시: 4개 표시 옵션은 신규/미설정 환경에서만 OFF. 이미 저장된 true/false는 그대로 복원한다.
- 고정 너비 탐색 서랍·자동 숨김·빠른 이동 아이콘·사각형 선택·내 PC 새 탭·상위 이동·세션 저장을 보완했다.
- 바탕화면은 Windows Known Folder의 실제 등록 경로를 사용한다. Windows의 전체 가상 Desktop Namespace를 새로 구현한 것은 아니다.
- 휴지통과 내 PC는 지원하는 가상 위치다. 가상 화면에서 실제 파일 작업이나 AI 대상으로 드라이브 루트/휴지통 물리 항목을 잘못 전달하지 않는다.
- 설정은 기존 session.json과 기능별 기존 설정 저장소가 소유한다. 미실행 AI 계획·실행 승인·일시 선택은 재시작 후 자동 실행하지 않는다.
- R00의 배포 JSON 보완을 유지한다. 최종 Setup 버전/파일명으로 URL과 update_endpoint_configured=true를 생성한다. 게시 기록 일치 여부는 생성 조건이 아니다.
- 루트 latest.json·notice.txt·release/PUBLISHED_RELEASE.json은 과거 공개 채널 스냅샷을 보존한다. 사용 파일은 최종 빌드의 dist/release-metadata 결과다.
- 현재 패치 검사: Python 소스 계약 184개 PASS, WPF XAML 구조 19개 PASS, 패키징 계약 15개 PASS, XAML XML 파싱 PASS. C# .NET 10 빌드/LogicTests 및 Windows 실제 UI·DPI·설치·서명·갱신은 **PENDING**. 기존 validation/PRE_BUILD_RESULT.json은 v1.3.2 과거 기록이므로 신규 PASS 증적이 아니다.
- Windows 공식 빌드: BUILD_ON_WINDOWS_COMPANY.cmd → dist/Sunrise_File_Manager_1.3.5_Setup.exe.
- 공개 게시·원격 Control 수정·회사 문서 접근은 수행하지 않았다.
- 현재 변경 인수인계: docs/V133_UI_EXIT_HOTFIX.md. v1.3.2는 docs/V132_NAVIGATION_AND_SESSION.md에 보존한다.

## R00 소스 감사·용량 최적화 (후속 수정 기준)

- 공식 입력: `Sunrise_File_Manager_v1.3.3_R00.zip` SHA256 `b604fd115902c9154ec17991500e31fb1c2e6b5e9f0068a550530cbaa3fb025b`.
- v1.3.4 코드 기준본. 설치 AppId·원격 업데이트 wire·사용자 설정/메모 형식은 유지.
- ZIP 입력의 동명/중복/중첩 항목을 사전 차단하고, self-contained WPF publish의 PDB만 배포 임시 스테이징에서 제외.
- 현행 소스검증 189 + UI 19 + 패키징 15 PASS, XAML 13개 XML PASS. 역사 `source/tests/test_*.py` 전체에는 구버전 계약 실패 7개가 별도 존재.
- 실제 Windows .NET 10 컴파일·실행/설치/용량 측정은 아직 PENDING.
- 현재 감사인수인계: `docs/V133_R00_FULL_AUDIT_FOOTPRINT.md`. 과거 `validation/PRE_BUILD_RESULT.json`은 현행 R00 승인 증적이 아님.

## v1.3.5 가로 스크롤 이동 안정화

- 부모 소스: `Sunrise_File_Manager_v1.3.4.zip`; 기능 및 wire format 유지.
- `Workspace.RequestBringIntoView`가 파일 목록/트리에서 외부 workspace viewport까지 전달되어 분할창을 밀어내는 경로를 차단. 사용자의 직접 가로 스크롤은 유지.
- 폴더 트리의 `TreeViewItem.BringIntoView()`를 로컬 세로 스크롤로 교체하여 선택 노드의 세로 위치만 보정.
- `LoadFolderAsync`의 실제 폴더 변경과 같은 폴더 refresh 구분; 변경 시 파일 목록 가로 오프셋 0, refresh 시 현재 오프셋 보존. dispatcher 레이아웃 후 초기화와 listingGeneration 가드 추가.
- Windows `UiSmokeTests`에 폴더 진입·뒤로가기 및 outer viewport 자동 이동 방지 검사 추가. Windows 실행·DPI·설치 경로는 여전히 PENDING.
- 검증/인수인계: `docs/V135_NAVIGATION_HORIZONTAL_SCROLL.md`.

## v1.3.5 R00 — 탐색 빈곳·주소 목록·우측 하단 버튼

- 부모 ZIP: `Sunrise_File_Manager_v1.3.5.zip` SHA256 `53c9ffed776280dabe3e0e3067e8e196f3528bd10a87301a65528e0c5bc26ca5`.
- 사용자 요청 3개 반영: 목록 빈곳 더블클릭 상위 이동, 주소표시줄 드롭다운, 우측 하단 단일 `공지사항 및 업데이트` 버튼.
- 제품/설치 버전 **1.3.5 유지**, 전달본 리비전 **R00**. 기존 설정·Control 정책·업데이트 원격 형식·메모·파일 전송·AI 엔진 변경 없음.
- 현행 Python 소스 검사 **205 PASS**, 설치/패키징 검사 **15 PASS**, XAML **13개 XML PASS**. Windows WPF 실제 컴파일/이벤트/설치 검증은 **PENDING**.
- 작업인수인계: `docs/V135_R00_NAVIGATION_ADDRESS_CONTROL.md`.

## v1.3.5 R01 — 릴리즈 공지 누락 및 메타데이터 오류코드 패치

- 입력 기준본: `Sunrise_File_Manager_v1.3.5_R00.zip` (사용자 제공) SHA256 `e5128821dc70ae7c7bed01283b341d04c6aa93b36246cad0dfc3d044e8831356`.
- 사용자 빌드 로그 분석에서 `NOTICE_BODY_1.3.5.txt` 누락이 원인으로 확인됨. 누락 버전 전용 공지 추가.
- Windows 공식 설치 빌드에서 버전 공지 파일 존재·크기를 **고비용 게시/서명 전** 확인하여 조기 중단.
- ReleaseMetadata의 InvalidDataException을 명시 처리하여 종료코드 1 반환; CMD는 모든 비영 종료코드 판정.
- 실제 Windows 리빌드·생성된 latest.json/notice.txt/Setup 실동작 검증은 아직 PENDING.
- 인수인계: `docs/V135_R01_INSTALLER_METADATA_RECOVERY.md`.

## v1.3.6 — 주소 탐색 트리·빠른 이동·드라이브·빈 공간 더블클릭

- 부모 공식 소스: `Sunrise_File_Manager_v1.3.5_R01.zip` (제품 버전은 1.3.6으로 증가).
- 주소표시줄 Popup의 긴 물리 경로 ListBox 제거; 기존 FolderTree 탐색 컨트롤을 최초 사용 시에만 생성해 Popup에 표시. 직접 입력·F4·위치 선택 보존.
- 빠른 이동/즐겨찾기는 `QuickPathChosen`으로 분리. 이동 시 실경로 폴더의 내용만 표시하고 좌측 드라이브 하위 경로 자동확장은 억제, 취소되지 않은 과거 하이라이트도 무효화.
- 드라이브 확장 토글의 실제 히트영역 및 아이콘 확대, 이름 더블클릭으로 확장/축소 가능. 폴더 트리 로딩 구조 재사용.
- 파일 목록 빈 공간은 물리 위치 기반으로 HitTest하고, 사각형 선택에 가로막힌 2회 입력을 더블클릭 시간·위치로 인식. 행·컬럼헤더·스크롤바·마우스 드래그와 분리.
- `release/NOTICE_BODY_1.3.6.txt` 추가. 사용자 공지 템플릿에서 다운로드 URL을 제거하고, 원격 latest.json/Control wire 계약은 변경하지 않음.
- 기존 기능 및 사용자 설정·Control·설치 AppId 유지, 업데이트 메타데이터는 공식 Windows 서명 완료 뒤에만 생성.
- Windows .NET 10 빌드·실제 UI·설치 실행 Gate는 PENDING.

## v1.3.6 R00 — 탐색창 사용자 너비·비활성 트리 접기·Shift+휠

- 부모 ZIP: `Sunrise_File_Manager_v1.3.6.zip` (직전 승인 소스), 제품/설치 버전은 **1.3.6 그대로 유지**.
- 고정 272 DIP 탐색창을 각 분할 탐색기 독립 가변폭(145~520 DIP)으로 변경. 최소창에서도 파일 목록 폭을 확보하도록 표시 너비 자동 제한.
- 고정 탐색창 및 자동 숨김 상태에서 펼쳐진 탐색창 모두 오른쪽 가장자리 Thumb 드래그로 폭 조절. 자동 숨김/호버/세션 저장 계약 유지.
- PanelSession.TreeWidth 설정을 기존 session.json에 선택 속성으로 추가. 구 세션은 272 DIP 기본으로 복원.
- 폴더 변경 때 현재 경로 이외의 트리 확장 노드를 접고, F5·watcher 동일 경로 새로고침은 트리 유지. Quick 이동 때는 자동 폴더 계층 펼침 금지.
- Shift+마우스 휠은 파일 목록 가로 ScrollViewer 오프셋 이동. Ctrl+휠 보기 전환·기본 세로 휠 유지.
- 기존 메뉴/공지/원격 Control/파일 IO 계약·메모·AI·설치 AppId·업데이트 URL 변경 없음.
- source/Python 및 Windows WPF 테스트 결과는 인수인계서에서 분리 표기.

## v1.3.6 R01 — 일반 탐색기 세션 저장 실패 재발 방지

- 부모: `Sunrise_File_Manager_v1.3.6_R00.zip`. 제품 버전 1.3.6 유지, 수정 전달 리비전 R01.
- 저장 오류에서 일반 탐색기 열 DisplayIndex 원시값(-1/중복)이 검증에 실패할 수 있는 경로 수정.
- 탐색기 GetSession()에 UI 임시값 정규화(열 순서/열 너비/탐색창 너비/스크롤)를 적용. 기존 사용자 유효 설정 보존.
- 검색 입력 최대 길이를 저장 계약과 맞춤, 검증 오류 메시지를 필드별로 세분화.
- 변경 대상 최소화, 공지·원격 업데이트·다운로드 경로·Control·설치 계약 비침범.
- 상세 내역: `docs/V136_R01_EXPLORER_SESSION_SAVE_RECOVERY.md`.
- Python 소스 검사 221 PASS, 패키징 15 PASS, XAML 13 PASS. C# .NET 10 빌드 및 Windows 종료·재실행 UI 검증 PENDING.


## v1.5.0 R03 — WPF CS0103 컴파일 오류 수정

- 부모: `Sunrise_File_Manager_v1.5.0_R02.zip` (원본 비침범), 제품 버전 1.5.0 유지.
- 사용자 Windows 빌드 로그에서 `ExplorerPane.PagedSelection.cs(55,42)`의 `IOException` CS0103 확인. 해당 파일에 `using System.IO;` 추가.
- R14/R15 CMD의 실패 정보 전달 개선, 빌드 진단 검사 추가.
- Windows WPF 재빌드·Setup 서명·실기 검증은 **미완료**. `docs/V150_R03_WPF_BUILD_COMPILE_FIX.md` 참조.
