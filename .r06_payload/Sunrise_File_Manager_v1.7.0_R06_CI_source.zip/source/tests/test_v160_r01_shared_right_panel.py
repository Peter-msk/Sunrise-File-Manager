"""R01 static contract: 1..4 independent explorer views, one shared right-side consumer per feature.
The structural contract does not substitute for a Windows WPF interactive smoke run.
"""
from pathlib import Path
import re
import unittest
from xml.etree import ElementTree as ET

SOURCE = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'
XNAME = '{http://schemas.microsoft.com/winfx/2006/xaml}Name'


class SharedRightPanelContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shell_x = (SOURCE/'MainWindow.xaml').read_text(encoding='utf-8')
        cls.pane_x = (SOURCE/'Controls/ExplorerPane.xaml').read_text(encoding='utf-8')
        cls.shell_c = (SOURCE/'MainWindow.xaml.cs').read_text(encoding='utf-8')
        cls.coord_c = (SOURCE/'Features/Workspace/MainWindow.PanelCoordination.cs').read_text(encoding='utf-8')
        cls.pane_c = (SOURCE/'Controls/ExplorerPane.xaml.cs').read_text(encoding='utf-8')
        cls.pane_features = (SOURCE/'Features/Explorer/ExplorerPane.ViewAndFiltering.cs').read_text(encoding='utf-8')
        cls.shell_tree = ET.fromstring(cls.shell_x)
        cls.pane_tree = ET.fromstring(cls.pane_x)

    def test_exactly_one_global_control_of_each_type(self):
        global_types = ['FileDetailsPanel', 'FileMemoPanel', 'FilePreviewPanel']
        for kind in global_types:
            self.assertEqual(sum(e.tag.endswith('}'+kind) for e in self.shell_tree.iter()), 1, kind)
            self.assertEqual(sum(e.tag.endswith('}'+kind) for e in self.pane_tree.iter()), 0, kind)
        self.assertEqual(sum(e.attrib.get(XNAME)=='DetailsPanel' for e in self.pane_tree.iter()), 0)
        self.assertEqual(sum(e.attrib.get(XNAME)=='DetailsDivider' for e in self.pane_tree.iter()), 0)
        self.assertIn('<!-- Detail/preview/memo appear ONLY', self.pane_x)

    def test_four_split_hosts_only_explorer_files(self):
        self.assertIn('private readonly ExplorerPane[] _panes = new ExplorerPane[4]', self.shell_c)
        self.assertIn('host.Children.Add(_panes[index]);', self.coord_c)
        for name in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertNotIn('new '+name+'(', self.coord_c)
        self.assertNotIn('SetDetailsVisible(', self.pane_features)
        self.assertNotIn('DetailsVisible = false', self.pane_c)
        self.assertNotIn('PreviewVisible = false', self.pane_c)

    def test_active_selection_routes_to_one_shared_target(self):
        handlers = self.shell_c.split('pane.SelectionContextChanged += source =>',1)[1].split('pane.BlockingFileActionChanged',1)[0]
        for method in ('SyncMemo();','SyncDetailsPanel();','SyncDockPreview();'):
            self.assertIn(method,handlers)
        activation = self.coord_c.split('private void ActivatePane(ExplorerPane pane)',1)[1]
        self.assertIn('MemoPanel.SelectFile(pane.SelectedFile)',activation)
        self.assertIn('_activePane = index;',activation)
        self.assertIn('SyncDetailsPanel();',activation)
        self.assertIn('SyncDockPreview();',activation)
        self.assertIn('UpdateActivePaneIndicator();',activation)
        self.assertIn('SetActivePaneIndicator(i == _activePane && i < _visiblePanels)', self.shell_c)
        for panel in ('MemoPanel','FileDetails','PreviewPane'):
            self.assertIn(panel+'.SelectFile(_panes[_activePane].SelectedFile)',self.shell_c)

    def test_split_change_updates_details_and_keeps_unsaved_memo(self):
        body=self.shell_c.split('private void ArrangePanels(int count, SplitLayoutPreset? explicitPreset)',1)[1].split('private void AddPane(',1)[0]
        self.assertIn('count < _visiblePanels && _memoOpen && !MemoPanel.ConfirmLeavingMemo()',body)
        self.assertIn('SyncMemo();',body)
        self.assertIn('SyncDetailsPanel();',body)
        self.assertIn('SyncDockPreview();',body)
        self.assertIn('if (_memoOpen && !MemoPanel.ConfirmLeavingMemo()) return;', self.coord_c)
        self.assertIn('UpdateActivePaneIndicator();',body)

    def test_visible_owner_and_per_control_independent_widths(self):
        self.assertIn('x:Name="ActivePaneIndicator"',self.shell_x)
        self.assertIn('ActivePaneIndicator.Text = $"{_activePane + 1}/{_visiblePanels}"',self.shell_c)
        self.assertIn('MemoDividerColumn.Width = visible ? new GridLength(11) : new GridLength(0)',self.shell_c)
        self.assertIn('DetailsPanelDividerColumn.Width = visible ? new GridLength(11) : new GridLength(0)',self.shell_c)
        self.assertIn('PreviewDividerColumn.Width = visible ? new GridLength(11) : new GridLength(0)',self.shell_c)

    def test_windows_native_test_declares_four_pane_shared_check(self):
        prog=(SOURCE.parent/'tests/UiSmokeTests/Program.cs').read_text(encoding='utf-8')
        audit=(SOURCE.parent/'tests/UiSmokeTests/CurrentUiAudit.cs').read_text(encoding='utf-8')
        self.assertIn('--shared-panel-only',prog)
        self.assertIn('RunSharedPanelsAsync(window, root, output)',prog)
        self.assertIn('Descendants<FileDetailsPanel>(window).Count() == 1',audit)
        self.assertIn('Descendants<FileMemoPanel>(window).Count() == 1',audit)
        self.assertIn('Descendants<FilePreviewPanel>(window).Count() == 1',audit)


if __name__ == '__main__':unittest.main()
