using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Sunrise.FileManager.Services;

// Exercise the real wire adapter against output produced by the metadata CLI.
if (args is ["--read-generated-release", var generatedFeedPath])
{
    var generated = SunriseReleaseService.Parse(File.ReadAllBytes(generatedFeedPath));
    if (!generated.UpdateConfigured || !SunriseReleaseService.IsApprovedDownload(generated))
        throw new InvalidDataException("Generated installer feed is not configured or violates the product wire contract.");
    Console.WriteLine(JsonSerializer.Serialize(new { generated.Version, generated.CanDownload }));
    return;
}

int count = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception("FAIL: " + name);
    count++;
    Console.WriteLine("PASS: " + name);
}
void Reject(Action action, string name)
{
    try { action(); } catch (Exception ex) when (ex is InvalidDataException or JsonException or ArgumentException)
    { Check(true, name); return; }
    throw new Exception("Accepted invalid input: " + name);
}
async Task RejectAsync(Func<Task> action, string name)
{
    try { await action(); } catch (Exception ex) when (ex is IOException or InvalidDataException or OperationCanceledException or HttpRequestException)
    { Check(true, name); return; }
    throw new Exception("Accepted invalid operation: " + name);
}
var currentVersion = System.Version.Parse(SunriseControlService.Version);
string requiredVersion = new System.Version(currentVersion.Major, currentVersion.Minor, currentVersion.Build + 1).ToString();
string control = "[global]\nschema_version=1\ncache_ttl_seconds=600\ndefault_operation=allow\ndefault_update=allow\n[product.sunrise_file_manager]\noperation=allow\nupdate=required\nminimum_version={REQUIRED_VERSION}\nmessage=업데이트 필요\n".Replace("{REQUIRED_VERSION}", requiredVersion);
var policy = SunriseControlService.Parse(control, "fixture", out int ttl);
Check(ttl == 600 && policy.RequiresUpdate && !policy.BlocksEntry, "Control required minimum and TTL");
Check(SunriseControlService.Parse(control.Replace("operation=allow\nupdate=", "operation=maintenance\nupdate="), "fixture", out _).BlocksEntry, "Control maintenance blocks entry");
Check(!SunriseControlService.VersionIsOlder("1.3.2", "1.3.2") && SunriseControlService.VersionIsOlder("1.2.9", "1.10.0"), "numeric version order");
Reject(() => SunriseControlService.Parse(control + "update=block\n", "fixture", out _), "duplicate Control keys rejected");
Reject(() => SunriseControlService.Parse(control.Replace("schema_version=1", "schema_version=9"), "fixture", out _), "unknown Control schema rejected");
Reject(() => SunriseControlService.Parse(control.Replace("operation=allow\nupdate=", "operation=unknown\nupdate="), "fixture", out _), "unknown operation rejected");

string cacheFolder = Path.Combine(Path.GetTempPath(), "SunriseControlTest_" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(cacheFolder);
try
{
    string cache = Path.Combine(cacheFolder, "control.json");
    var clock = new DateTimeOffset(2026, 10, 21, 0, 0, 0, TimeSpan.Zero);
    string body = control.Replace("operation=allow\nupdate=", "operation=maintenance\nupdate=")
        .Replace("schema_version=1", "schema_version=1\nfallback_operation=block\nfallback_update=allow");
    using var online = new HttpClient(new Stub(_ => new(HttpStatusCode.OK) { Content = new StringContent(body) }));
    var live = await SunriseControlService.CheckAsync(online, cache, clock);
    Check(live.Source == "online" && live.BlocksEntry && File.Exists(cache), "online policy persists valid cache");
    using var offline = new HttpClient(new Stub(_ => new(HttpStatusCode.ServiceUnavailable)));
    var fresh = await SunriseControlService.CheckAsync(offline, cache, clock.AddSeconds(30));
    Check(fresh.Source == "cache" && fresh.Operation == "maintenance", "offline uses unexpired product cache");
    using var malformed = new HttpClient(new Stub(_ => new(HttpStatusCode.OK) { Content = new StringContent("invalid control") }));
    var invalidRemote = await SunriseControlService.CheckAsync(malformed, cache, clock.AddSeconds(30));
    Check(invalidRemote.Source == "cache" && invalidRemote.Operation == "maintenance", "malformed remote preserves valid cached policy");
    var expired = await SunriseControlService.CheckAsync(offline, cache, clock.AddSeconds(601));
    Check(expired.Source == "fallback" && expired.Operation == "block", "expired cache uses global fallback instead of stale product state");
    File.WriteAllText(cache, "{bad");
    var corrupted = await SunriseControlService.CheckAsync(offline, cache, clock);
    Check(corrupted.Source == "fallback" && corrupted.Operation == "allow", "corrupt cache does not escape fallback handler");
    var missing = await SunriseControlService.CheckAsync(offline, cache + ".missing", clock);
    Check(missing.Source == "fallback" && missing.Update == "allow", "first offline start uses built-in fallback");
    Check(SunriseControlService.Parse("\uFEFF" + control, "fixture", out _).RequiresUpdate, "UTF-8 BOM control accepted");
}
finally { Directory.Delete(cacheFolder, true); }

byte[] payload = Encoding.UTF8.GetBytes(new string('x', 4096));
string digest = Convert.ToHexString(SHA256.HashData(payload));
var fields = new Dictionary<string, object>
{
    ["schema_version"] = "1.1", ["app_id"] = "sunrise_file_manager", ["product_id"] = "SUNRISE-FILE-MANAGER-WIN-DESKTOP",
    ["channel"] = "stable", ["platform"] = "windows-x64", ["package_kind"] = "installer", ["official_release"] = true,
    ["version"] = requiredVersion, ["latest_version"] = requiredVersion, ["sha256"] = digest, ["file_size_bytes"] = payload.Length,
    ["download_file_name"] = $"Sunrise_File_Manager_{requiredVersion}_Setup.exe",
    ["download_url"] = $"https://github.com/Peter-msk/Sunrise-File-Manager/releases/download/v{requiredVersion}/Sunrise_File_Manager_{requiredVersion}_Setup.exe",
    ["release_url"] = $"https://github.com/Peter-msk/Sunrise-File-Manager/releases/tag/v{requiredVersion}", ["update_endpoint_configured"] = true
};
byte[] Json() => JsonSerializer.SerializeToUtf8Bytes(fields);
var release = SunriseReleaseService.Parse(Json());
Check(release.CanDownload, "published installer wire accepted without changing schema");
fields["app_id"] = "sunrise_cleaner";
Reject(() => SunriseReleaseService.Parse(Json()), "wrong product rejected");
fields["app_id"] = "sunrise_file_manager";
fields["version"] = "1.1.0";
Reject(() => SunriseReleaseService.Parse(Json()), "conflicting versions rejected");
fields["version"] = requiredVersion;
fields["package_kind"] = "onedir";
Reject(() => SunriseReleaseService.Parse(Json()), "cross-package update rejected");
fields["package_kind"] = "installer";
string duplicate = Encoding.UTF8.GetString(Json()).TrimEnd('}') + ",\"app_id\":\"sunrise_file_manager\"}";
Reject(() => SunriseReleaseService.Parse(Encoding.UTF8.GetBytes(duplicate)), "duplicate release fields rejected");
Check(!SunriseReleaseService.IsApprovedDownload(release with { Sha256 = "bad" }) &&
    !SunriseReleaseService.IsApprovedDownload(release with { FileSize = 900L * 1024 * 1024 }), "hash and download size bounds");
Check(SunriseReleaseService.IsApprovedRedirect(new Uri("https://release-assets.githubusercontent.com/asset")) &&
    !SunriseReleaseService.IsApprovedRedirect(new Uri("https://evil.githubusercontent.com/asset")) &&
    !SunriseReleaseService.IsApprovedRedirect(new Uri("http://github.com/asset")) &&
    !SunriseReleaseService.IsApprovedRedirect(new Uri("https://github.com:444/asset")), "redirect endpoint allowlist");
Check(SunriseReleaseService.NoticeHash("공지 A") == SunriseReleaseService.NoticeHash("공지 A") &&
    SunriseReleaseService.NoticeHash("공지 A") != SunriseReleaseService.NoticeHash("공지 B"), "plain notice digest stable and content-sensitive");
var previousJobs = Directory.Exists(SunriseReleaseService.UpdatesRoot)
    ? Directory.EnumerateDirectories(SunriseReleaseService.UpdatesRoot, "job-*").ToHashSet() : [];
string? job = null;
try
{
    using var good = new HttpClient(new Stub(_ => new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(payload) }));
    string downloaded = await SunriseReleaseService.DownloadAsync(release, null, CancellationToken.None, good);
    job = Path.GetDirectoryName(downloaded)!;
    Check(File.ReadAllBytes(downloaded).SequenceEqual(payload) && !File.Exists(downloaded + ".download"), "verified download published after writer closed");
    using (new FileStream(downloaded, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        Check(true, "published artifact has no open download handles");
    var handoff = InstallerUpdateHandoff.Prepare(downloaded, release);
    Check(File.Exists(Path.Combine(job, "install-after-exit.cmd")), "handoff prepared outside installation");
    handoff.Cancel();
    Check(!Directory.Exists(job), "unaccepted shutdown removes owned setup and helper");
    job = null;

    using var wrong = new HttpClient(new Stub(_ => new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(payload) }));
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release with { Sha256 = new string('0', 64) }, null, CancellationToken.None, wrong), "hash mismatch cannot publish candidate");
    using var shortFile = new HttpClient(new Stub(_ => new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent([1, 2, 3]) }));
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release, null, CancellationToken.None, shortFile), "declared size mismatch rejected");
    using var redirect = new HttpClient(new Stub(_ => new HttpResponseMessage(HttpStatusCode.Redirect)
        { Headers = { Location = new Uri("https://evil.example/installer.exe") } }));
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release, null, CancellationToken.None, redirect), "unapproved redirect cannot download");
    using var endless = new HttpClient(new Stub(_ => new HttpResponseMessage(HttpStatusCode.Redirect)
        { Headers = { Location = new Uri(release.DownloadUrl) } }));
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release, null, CancellationToken.None, endless), "redirect count bounded");
    using var cancel = new CancellationTokenSource(); cancel.Cancel();
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release, null, cancel.Token, good), "pre-cancel does not download");
    var started = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    using var stop = new CancellationTokenSource();
    using var stalled = new HttpClient(new Stub(async (_, token) => { started.SetResult(); await Task.Delay(Timeout.Infinite, token); return new(HttpStatusCode.OK); }));
    Task<string> first = SunriseReleaseService.DownloadAsync(release, null, stop.Token, stalled);
    await started.Task;
    await RejectAsync(() => SunriseReleaseService.DownloadAsync(release, null, CancellationToken.None, good), "overlapping update downloads refused");
    stop.Cancel();
    await RejectAsync(() => first, "in-flight cancellation reaches transport");
    Check(!Directory.EnumerateDirectories(SunriseReleaseService.UpdatesRoot, "job-*").Except(previousJobs).Any(), "failed/cancelled operations leave no staged candidates");
}
finally { if (job is not null && Directory.Exists(job)) Directory.Delete(job, true); }
Console.WriteLine($"PASS: {count} update behavior checks; Windows helper execution PENDING");

sealed class Stub : HttpMessageHandler
{
    private readonly Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> _send;
    public Stub(Func<HttpRequestMessage, HttpResponseMessage> send) => _send = (request, _) => Task.FromResult(send(request));
    public Stub(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> send) => _send = send;
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken token) => _send(request, token);
}
