"""Focused source-contract checks only; not a replacement for Windows WPF runtime validation."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1] / "Sunrise.FileManager"

class MemoDetailsSeparation(unittest.TestCase):
    def code(self, relative):
        return (ROOT / relative).read_text('utf-8')

    def test_independent_controls_and_event_handlers(self):
        memo_x = self.code('Controls/FileMemoPanel.xaml')
        detail_x = self.code('Controls/FileDetailsPanel.xaml')
        ET.fromstring(memo_x); ET.fromstring(detail_x)
        self.assertIn('x:Class="Sunrise.FileManager.Controls.FileMemoPanel"', memo_x)
        self.assertIn('x:Class="Sunrise.FileManager.Controls.FileDetailsPanel"', detail_x)
        self.assertIn('x:Name="MemoEditor"', memo_x)
        self.assertNotIn('DetailHash', memo_x)
        self.assertNotIn('MemoEditor', detail_x)
        self.assertIn('x:Name="DetailHash"', detail_x)
        self.assertIn('CloseMemo_Click', self.code('Controls/FileMemoPanel.xaml.cs'))
        self.assertIn('CloseDetails_Click', self.code('Controls/FileDetailsPanel.xaml.cs'))

    def test_memo_does_not_mutate_file_attributes_or_detail_state(self):
        memo = self.code('Controls/FileMemoPanel.xaml.cs') + self.code('Features/Inspector/FileMemoPanel.AiSummary.cs')
        details = self.code('Controls/FileDetailsPanel.xaml.cs')
        self.assertIn('FileMemoStore.Save(', memo)
        self.assertIn('MemoLocalSnapshots.Restore(', memo)
        self.assertNotIn('SetFileAttributes(', memo)
        self.assertIn('FileActionsService.SetFileAttributes(', details)
        self.assertNotIn('FileMemoStore.Save(', details)
        self.assertNotIn('MemoLocalSnapshots', details)

    def test_two_distinct_docks_toggles_and_clean_exit(self):
        xaml = self.code('MainWindow.xaml')
        main = self.code('MainWindow.xaml.cs')
        self.assertIn('x:Name="FileDetails"', xaml)
        self.assertIn('x:Name="MemoPanel"', xaml)
        self.assertIn('x:Name="DetailsMenuItem"', xaml)
        self.assertIn('x:Name="MemoMenuItem"', xaml)
        self.assertIn('SetDetailsPanelVisible', main)
        self.assertIn('SetMemoVisible', main)
        self.assertIn('MemoPanel.ConfirmLeavingMemo()', main)
        self.assertIn('FileDetails.SelectFile(', main)
        self.assertIn('MemoPanel.SelectFile(', main)
        # Closing details alone must never trigger memo save/discard dialogs.
        method = main.split('private void SetDetailsPanelVisible(bool visible)',1)[1].split('private void SetDockPreview',1)[0]
        self.assertNotIn('ConfirmLeavingMemo', method)

    def test_session_migration_keeps_old_field_and_persists_new_independent_state(self):
        session = self.code('Services/SessionStore.cs')
        main = self.code('MainWindow.xaml.cs')
        self.assertIn('public bool InspectorVisible', session)
        for prop in ('MemoPanelVisible', 'DetailsPanelVisible', 'MemoPanelWidth', 'DetailsPanelWidth'):
            self.assertIn('public ', session)
            self.assertIn(prop, main)
        self.assertIn('session.LayoutVersion >= 23', main)
        self.assertIn('LayoutVersion = 25', main)  # R02 still persists R00 transfer-bar settings plus single-utility preference
        self.assertIn('MemoAuthor = MemoPanel.PreferredAuthor', main)
        self.assertNotIn('InspectorDetailRatio', main)

if __name__ == '__main__':
    unittest.main()
