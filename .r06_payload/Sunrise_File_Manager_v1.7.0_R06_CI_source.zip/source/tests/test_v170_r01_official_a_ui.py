"""v1.7.0 R01: screenshot-driven official A-layout regression. Static only; not a Windows WPF visual PASS."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re, unittest
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'Sunrise.FileManager'
X='{http://schemas.microsoft.com/winfx/2006/xaml}'
MAIN=(APP/'MainWindow.xaml').read_text('utf-8')
CODE=(APP/'MainWindow.xaml.cs').read_text('utf-8')
GALLERY=(APP/'Features/Workspace/MainWindow.SplitLayoutGallery.cs').read_text('utf-8')
PALETTE=(APP/'Services/ThemeManager.cs').read_text('utf-8')

class OfficialAWorkspaceUi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=ET.fromstring(MAIN)
        cls.nodes={e.attrib[X+'Name']:e for e in cls.root.iter() if X+'Name' in e.attrib}

    def test_old_transfer_toolbar_deleted_without_removing_actual_transfer_engine(self):
        for name in ('TransferToolbar','TransferBarButton','TransferCommandViewport','SourceSelector','DestinationSelector','CollisionSelector','TransferToolbarRow'):
            self.assertNotIn(name,MAIN)
        self.assertNotIn('TransferBarToggle_Click',CODE)
        self.assertIn('RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, source, target)',CODE)
        self.assertIn('RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, pane, pane)',CODE)
        for command in ('SwapPanes_Click','SyncPanes_Click'):
            self.assertIn(f'Click="{command}"',MAIN)

    def test_only_three_structural_rows_workspace_has_all_reclaimed_height(self):
        outer=next(e for e in self.root if e.tag.endswith('}Grid'))
        rows=next(e for e in outer if e.tag.endswith('}Grid.RowDefinitions'))
        self.assertEqual(len(rows),3)
        self.assertEqual(self.nodes['WorkspaceShell'].get('Grid.Row'),'1')
        status=next(e for e in outer if e.get('Grid.Row')=='2')
        self.assertFalse(any(c.tag.endswith(('}FileDetailsPanel','}FileMemoPanel','}FilePreviewPanel')) for c in status.iter()))

    def test_single_applies_immediately_without_gallery(self):
        self.assertEqual(self.nodes['OneButton'].get('Content'),'단일')
        self.assertNotIn('ShowSplitLayoutGallery(1, OneButton)',CODE)
        handler=CODE.split('private void One_Click(',1)[1].split('private void Two_Click(',1)[0]
        self.assertIn('ApplyLastLayoutForCount(1);',handler)
        self.assertIn('_openSplitGalleryMenu.IsOpen = false;',handler)

    def test_only_other_three_buttons_have_predefined_preset_dropdowns(self):
        for count in (2,3,4):
            self.assertIn(f'ShowSplitLayoutGallery({count},',CODE)
        self.assertIn('Placement = PlacementMode.Bottom',GALLERY)
        self.assertIn('if (CanChangeSplitLayout) ArrangePanels(normalized, requestedPreset);',GALLERY)
        self.assertEqual(len(re.findall(r'new\(SplitLayoutPreset\.\w+,\s*[1-4],\s*"', (APP/'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text())),14)

    def test_gallery_shows_one_label_one_thumbnail_with_extra_info_only_in_tooltip(self):
        self.assertIn('content.Children.Add(CreateSplitLayoutThumbnail',GALLERY)
        self.assertIn('content.Children.Add(title)',GALLERY)
        self.assertNotIn('labels.Children.Add(description)',GALLERY)
        self.assertIn('IsCheckable = false',GALLERY)
        self.assertIn('ToolTip = $"{choice.Description}\\n{fit.DisplayText}"',GALLERY)
        self.assertIn('MinHeight = 44',GALLERY)

    def test_right_rail_uses_vector_icon_not_font_emoji(self):
        rail=next(e for e in self.root.iter() if e.get('Grid.Column')=='3' and e.tag.endswith('}Border') and e.get('Background')=='{DynamicResource ThemeUtilityRail}')
        buttons=[e for e in rail.iter() if e.tag.endswith('}Button')]
        self.assertEqual(len(buttons),7)
        for button in buttons:
            self.assertIsNone(button.get('Content'))
            self.assertEqual(button.get('Style'),'{StaticResource UtilityRailIconButton}')
            self.assertTrue(button.get('AutomationProperties.Name'))
            self.assertTrue(button.get('ToolTip'))
            self.assertEqual(sum(e.tag.endswith('}Path') for e in button.iter()),1)
            self.assertEqual(sum(e.tag.endswith('}Viewbox') for e in button.iter()),1)

    def test_right_panel_controls_still_unique_and_not_in_pane(self):
        for component in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertEqual(sum(e.tag.endswith('}'+component) for e in self.root.iter()),1)
            pane=ET.parse(APP/'Controls/ExplorerPane.xaml').getroot()
            self.assertFalse(any(e.tag.endswith('}'+component) for e in pane.iter()))

    def test_right_rail_style_isolated_from_folder_tree_palette(self):
        self.assertIn('["ThemeUtilityRail"] = ("#EFF4F8", "#15344C")',PALETTE)
        self.assertIn('["ThemeUtilityRailHover"] = ("#DCEBF4", "#295976")',PALETTE)
        self.assertIn('["ThemeNavigationRail"] = ("#EFF4F8", "#506984")',PALETTE)
        self.assertIn('x:Key="UtilityRailIconButton"',MAIN)
        self.assertIn('ThemeUtilityRailHover',MAIN)
        self.assertIn('Condition Property="Tag" Value="True"', MAIN)
        self.assertIn('button.Tag = selected ? "True" : "False";', CODE)

    def test_old_transfer_settings_removed_but_legacy_json_tolerant(self):
        session=(APP/'Services/SessionStore.cs').read_text()
        for field in ('TransferSourceIndex','TransferDestinationIndex','TransferCollisionIndex','TransferBarExpanded'):
            self.assertNotIn('public int '+field,session)
            self.assertNotIn('public bool '+field,session)
        self.assertIn('JsonSerializer.Deserialize<AppSession>',session)
        self.assertIn('LayoutVersion',session)
        self.assertIn('InspectorVisible',session)

    def test_preview_builder_unchanged_in_source(self):
        self.assertTrue((ROOT.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').exists())
        self.assertIn('1.7.0',(ROOT.parent/'installer/RELEASE_VERSION.txt').read_text())

if __name__=='__main__':unittest.main()
