"""R02 official A workspaces: semantic layout/real command bindings, not styling-only placeholders."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest,re
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'Sunrise.FileManager'
ns='{http://schemas.microsoft.com/winfx/2006/xaml}'
MAIN=(APP/'MainWindow.xaml').read_text('utf-8')
CODE=(APP/'MainWindow.xaml.cs').read_text('utf-8')
SHELL=(APP/'Features/Workspace/MainWindow.OfficialAShell.cs').read_text('utf-8')
ROUTER=(APP/'Features/Explorer/ExplorerPane.OfficialAShell.cs').read_text('utf-8')
PALETTE=(APP/'Services/ThemeManager.cs').read_text('utf-8')

class OfficialAFullShell(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.root=ET.fromstring(MAIN)
  cls.named={e.get(ns+'Name'):e for e in cls.root.iter() if e.get(ns+'Name')}

 def test_three_distinct_functional_header_levels(self):
  header=self.named['OfficialAShellHeader']; self.assertTrue(header.tag.endswith('}Grid'))
  rows=next(e for e in header if e.tag.endswith('}Grid.RowDefinitions'))
  self.assertEqual([r.get('Height') for r in rows],['38','42','40'])
  for name in ('ShellFilesButton','ShellDocsButton','ShellAiButton','ShellToolsButton'):
   self.assertIn(name,self.named); self.assertTrue(self.named[name].get('Click'))
  self.assertIn('SetShellMode("Files");',CODE)

 def test_modes_change_only_actions_not_user_data(self):
  names=['ShellFilesActions','ShellDocumentsActions','ShellAiActions','ShellToolsActions']
  for name in names:self.assertIn(name,self.named)
  self.assertIn('HeaderCommandViewport.ScrollToHorizontalOffset(0)',SHELL)
  self.assertIn('ShellFilesActions.Visibility',SHELL)
  self.assertIn('ShellDocumentsActions.Visibility',SHELL)
  self.assertNotIn('NavigateTo(',SHELL)
  self.assertNotIn('SaveSession(',SHELL)

 def test_all_visible_shell_actions_have_real_existing_command_owners(self):
  buttons=[e for e in self.root.iter() if e.tag.endswith('}Button') and e.get('Click')=='ShellCommand_Click']
  self.assertGreaterEqual(len(buttons),12)
  for b in buttons:
   command=b.get('Tag')
   self.assertIsNotNone(command)
   self.assertRegex(ROUTER,rf'case "{re.escape(command)}": .+_Click\(this, args\); break;')
  self.assertIn('_panes[_activePane]?.ExecuteOfficialAShellCommand(command);',SHELL)
  self.assertIn('if (_working || _aiBusy || _activeRecycleJobs > 0) return;',SHELL)

 def test_separate_business_commands_and_controlled_expert_actions(self):
  self.assertEqual(self.named['AiToggleButton'].get('Click'),'AiToggle_Click')
  self.assertIn('Tag="Eiass" Click="ShellCommand_Click"',MAIN)
  self.assertIn('ExecuteEiassRename();',(APP/'Controls/ExplorerPane.xaml.cs').read_text())
  self.assertIn('Tag="Zip" Click="ShellCommand_Click"',MAIN)
  self.assertIn('Tag="Extract" Click="ShellCommand_Click"',MAIN)
  self.assertEqual(self.named['OneButton'].get('Click'),'One_Click')
  for name in ['TwoButton','ThreeButton','FourButton']:self.assertIn('▾',self.named[name].get('Content'))

 def test_central_workspace_right_panels_and_progress_unchanged(self):
  self.assertEqual(self.named['WorkspaceShell'].get('Grid.Row'),'1')
  self.assertEqual(len([e for e in self.root.iter() if e.tag.endswith('}FileDetailsPanel')]),1)
  self.assertEqual(len([e for e in self.root.iter() if e.tag.endswith('}FileMemoPanel')]),1)
  self.assertEqual(len([e for e in self.root.iter() if e.tag.endswith('}FilePreviewPanel')]),1)
  self.assertNotIn('TransferToolbar',MAIN)
  self.assertIn('Grid.Row="2" Background="{DynamicResource ThemeStatus}"',MAIN)

 def test_palette_has_dark_and_light_styles_scoped_to_shell(self):
  for k in ['ThemeShellBrand','ThemeShellBrandText','ThemeShellBrandMuted','ThemeShellSun','ThemeShellModeSurface','ThemeShellCommands']:
   self.assertIn(f'["{k}"]',PALETTE)
   self.assertIn(f'x:Key="{k}"',(APP/'App.xaml').read_text())
  self.assertEqual(self.named['HeaderCommandViewport'].get('VerticalScrollBarVisibility'),'Disabled')
  self.assertEqual(self.named['HeaderCommandViewport'].get('HorizontalScrollBarVisibility'),'Auto')

 def test_preserves_per_pane_full_feature_access_and_preview_builder(self):
  pane=(APP/'Controls/ExplorerPane.xaml').read_text()
  for key in ('EiassRename_Click','ConnectDrive_Click','PasswordExtract_Click','OcrRead_Click','MetadataEdit_Click','DetailColumn_Click','Recycle_Click'):
   self.assertIn(key,pane)
  self.assertTrue((ROOT.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').exists())

if __name__=='__main__':unittest.main()
