"""Canonical source-level audit for Windows-like file/folder/background context commands.
This is not a substitute for Windows Shell/COM/WPF runtime verification.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / 'Sunrise.FileManager/Controls/ExplorerPane.xaml').read_text('utf-8')
CORE = (ROOT / 'Sunrise.FileManager/Controls/ExplorerPane.xaml.cs').read_text('utf-8')
POLICY = (ROOT / 'Sunrise.FileManager/Features/Explorer/ExplorerPane.WindowsContextMenu.cs').read_text('utf-8')
TRANSFER = (ROOT / 'Sunrise.FileManager/Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs').read_text('utf-8')
RECYCLE = (ROOT / 'Sunrise.FileManager/Features/Explorer/ExplorerPane.RecycleBin.cs').read_text('utf-8')
SHELL = (ROOT / 'Sunrise.FileManager/Features/Explorer/ExplorerPane.WindowsIntegration.cs').read_text('utf-8')
TEMPLATES = (ROOT / 'Sunrise.FileManager/Features/Explorer/ExplorerPane.ShellNew.cs').read_text('utf-8')
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'
P = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'

class WindowsMenuContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = ET.fromstring(UI)
        cls.grid = next(e for e in cls.root.iter(P + 'DataGrid') if e.get(X + 'Name') == 'FilesGrid')
        cls.menu = next(e for e in cls.grid.iter(P + 'ContextMenu') if e.get(X + 'Name') == 'FilesContextMenu')
        cls.roots = [e for e in cls.menu if e.tag == P + 'MenuItem']

    def lookup(self, label):
        return next((e for e in self.roots if e.get('Header') == label), None)

    def test_primary_windows_commands_are_direct_and_wired(self):
        expected = {'열기':'ContextOpen_Click', '잘라내기':'ClipboardCut_Click',
                    '복사':'ClipboardCopy_Click', '붙여넣기':'ContextPaste_Click',
                    '이름 바꾸기':'Rename_Click', '삭제':'Recycle_Click',
                    'Windows 공유…':'WindowsShare_Click', '속성':'ContextProperties_Click'}
        for name, handler in expected.items():
            with self.subTest(command=name):
                item = self.lookup(name)
                self.assertIsNotNone(item)
                self.assertEqual(item.get('Click'), handler)
                self.assertIn('private ', CORE + POLICY + SHELL)

    def test_selection_and_blank_are_context_distinct(self):
        for label in ('새로 만들기','정렬 기준','그룹 기준','보기','새로 고침'):
            self.assertEqual(self.lookup(label).get('Tag'), 'blank')
        for label in ('열기','잘라내기','복사','이름 바꾸기','삭제'):
            self.assertNotEqual(self.lookup(label).get('Tag'), 'blank')
        self.assertIn('case "blank":', POLICY)
        self.assertIn('case "selected":', POLICY)
        self.assertIn('CompactContextMenuSeparators(menu);', POLICY)

    def test_folder_and_file_single_context(self):
        self.assertEqual(self.lookup('새 탭에서 열기').get('Tag'),'single-folder')
        self.assertEqual(self.lookup('연결 프로그램 선택…').get('Tag'),'single-file')
        self.assertIn('Directory.Exists(paths[0])', POLICY)
        self.assertIn('File.Exists(paths[0])', POLICY)

    def test_paste_into_selected_folder_reuses_transfer_engine(self):
        self.assertIn('ContextPaste_Click', POLICY)
        self.assertIn('await ExecuteClipboardPasteAsync(folder)', POLICY)
        self.assertIn('private async Task ExecuteClipboardPasteAsync(string? targetFolder = null)',TRANSFER)
        self.assertIn('PasteRequested?.Invoke(new(this, crossFolderPaths, folder, kind))',TRANSFER)
        self.assertIn('PasteRequested?.Invoke(new(this, movablePaths, folder, kind))',TRANSFER)
        self.assertIn('DuplicatePathsAsync(sameFolderPaths)', TRANSFER)
        self.assertIn('bool canPaste = writableFolder && containsFiles && (!selected || folder)', POLICY)

    def test_blank_right_click_clears_stale_paged_selection(self):
        section = CORE.split('private void FilesGrid_PreviewMouseRightButtonDown',1)[1].split('private void ContextOpen_Click',1)[0]
        self.assertIn('ClearSelection_Click(this, new RoutedEventArgs())',section)
        self.assertIn('if (!row.IsSelected)',section)
        self.assertIn('if (!IsRecycleBin && !IsThisPc)',section)
        self.assertIn('FilesGrid.SelectedItem = entry;',section)

    def test_original_registered_windows_shell_is_direct_top_level(self):
        self.assertEqual(self.lookup('Windows 확장 메뉴…').get('Click'),'WindowsMenu_Click')
        self.assertIn('WindowsShellContextMenu.Show(Window.GetWindow(this), paths)', SHELL)
        self.assertIn('hasCommonParent', POLICY)
        self.assertIn('paths.Count <= 1000', POLICY)

    def test_background_new_windows_registered_types_reuses_template_provider(self):
        new_menu = self.lookup('새로 만들기')
        self.assertIsNotNone(new_menu)
        labels = [e.get('Header') for e in new_menu if e.tag == P + 'MenuItem']
        self.assertIn('폴더',labels)
        self.assertIn('빈 파일',labels)
        self.assertIn('Windows 등록 문서 만들기',labels)
        self.assertIn('if (sender is not MenuItem menu) return;', TEMPLATES)
        self.assertIn('ShellNewTemplateService.Discover()',TEMPLATES)

    def test_background_sort_and_group_uses_existing_persistence(self):
        sort = self.lookup('정렬 기준')
        sorts = [x.get('Tag') for x in sort if x.tag == P+'MenuItem']
        for v in ('sort:Name','sort:ModifiedAt','sort:TypeName','sort:SizeBytes','order:asc','order:desc'):
            self.assertIn(v,sorts)
        self.assertIn('ApplyFilterAndSortAsync()',POLICY)
        self.assertIn('SettingsChanged?.Invoke()',POLICY)
        self.assertIn('GroupField_Click', UI)

    def test_protect_recycle_virtual_namespace(self):
        self.assertIn('if (IsRecycleBin)', RECYCLE)
        for key in ('RestoreRecycle_Click','PermanentDeleteRecycle_Click','EmptyRecycle_Click'):
            self.assertIn(key,RECYCLE)
        self.assertIn('FilesGrid.ContextMenu = menu;',RECYCLE)
        self.assertIn('IsRecycleBin || IsThisPc', POLICY)

    def test_this_pc_root_can_access_native_shell(self):
        self.assertIn('var shell = new MenuItem { Header = "Windows 확장 메뉴…" }', RECYCLE)
        self.assertIn('var properties = new MenuItem { Header = "속성"',RECYCLE)
        self.assertIn('IReadOnlyList<string> paths = IsThisPc',SHELL)

    def test_keep_all_sunrise_actions_and_right_dock_singletons(self):
        self.assertEqual(self.lookup('EIASS 문서명 설정…').get('Click'), 'EiassRename_Click')
        self.assertEqual(self.lookup('AI 정리·요약').get('Click'), 'SendToAi_Click')
        for action in ('EiassRename_Click','SendToAi_Click','PreviewToggle_Click','DetailsToggle_Click',
                       'MemoToggle_Click','ZipCompress_Click','TarCompress_Click','ZipExtract_Click',
                       'MetadataEdit_Click'):
            self.assertIn('Click="'+action+'"',UI)
        main = (ROOT / 'Sunrise.FileManager/MainWindow.xaml').read_text('utf-8')
        for component in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertEqual(main.count('<local:'+component), 1)

    def test_multi_item_properties_use_windows_shell_not_first_item(self):
        core = CORE.split('private void ContextProperties_Click',1)[1].split('private void OpenCmd_Click',1)[0]
        native = (ROOT / 'Sunrise.FileManager/Services/WindowsShellContextMenu.cs').read_text('utf-8')
        self.assertIn('if (selectedPaths.Count > 1)',core)
        self.assertIn('WindowsShellContextMenu.ShowProperties(Window.GetWindow(this), selectedPaths)',core)
        self.assertIn('ShowCore(owner, paths, propertiesOnly: true)',native)
        self.assertIn('Marshal.StringToHGlobalAnsi("properties")',native)

    def test_preview_and_installer_build_input_unchanged(self):
        self.assertTrue((ROOT.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').is_file())
        self.assertTrue((ROOT.parent/'BUILD_ON_WINDOWS_COMPANY.cmd').is_file())
        self.assertEqual(self.menu.get('Opened'), 'FilesContextMenu_Opened')

if __name__ == '__main__': unittest.main()
