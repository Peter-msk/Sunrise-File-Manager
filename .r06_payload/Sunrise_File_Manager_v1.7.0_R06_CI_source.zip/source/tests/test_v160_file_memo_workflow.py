"""v1.6.0 file workflow and memo safety source contract. Native execution requires Windows.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'


class ExplorerMemoIntegrationContracts(unittest.TestCase):
    def test_all_xaml_is_well_formed(self):
        for file in ROOT.rglob('*.xaml'):
            with self.subTest(file=file.name):
                ET.parse(file)

    def test_explorer_command_groups_and_columns(self):
        code = (ROOT/'Controls/ExplorerPane.xaml').read_text()
        # Only actual DataGrid columns, not homonymous context-menu entries.
        root = ET.fromstring(code)
        ns = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
        grid = next(e for e in root.iter(ns+'DataGrid') if e.get('{http://schemas.microsoft.com/winfx/2006/xaml}Name') == 'FilesGrid')
        cols = [e.get('Header') for e in grid.iter() if e.tag.endswith(('DataGridTemplateColumn','DataGridTextColumn','DataGridCheckBoxColumn'))]
        ordered = ['이름', '수정한 날짜', '유형', '크기']
        self.assertEqual(sorted(cols.index(name) for name in ordered), [cols.index(name) for name in ordered])
        self.assertIn('x:Name="AddressBox" Height="34"', code)
        self.assertIn('x:Name="SearchBox" Height="34"', code)
        self.assertIn('Style="{StaticResource ExplorerNavButton}"', code)

    def test_preview_is_standalone_rightmost_not_dialog(self):
        main = (ROOT/'MainWindow.xaml').read_text()
        tree = ET.fromstring(main)
        x = '{http://schemas.microsoft.com/winfx/2006/xaml}'
        named = {e.get(x+'Name'): e for e in tree.iter() if e.get(x+'Name')}
        shell = named['WorkspaceShell']
        self.assertEqual(shell.get('Grid.Row'), '1')
        for key in ('FileDetails', 'MemoPanel', 'PreviewPane'):
            self.assertIn(key, named)
            self.assertNotEqual(named[key].get('Grid.Row'), '2')
        for name in ('FileDetailsPanel', 'FileMemoPanel', 'FilePreviewPanel'):
            self.assertEqual(sum(e.tag.endswith('}'+name) for e in tree.iter()), 1)
        self.assertEqual(named['PreviewPane'].get('Grid.Column'), '2')
        self.assertIn('x:Name="MainPreviewButton"', main)
        preview = (ROOT/'Controls/FilePreviewPanel.xaml').read_text()
        memo = (ROOT/'Controls/FileMemoPanel.xaml').read_text()
        self.assertIn('x:Name="PreviewRegion"', preview)
        self.assertIn('x:Name="MemoEditor"', memo)
        code = (ROOT/'MainWindow.xaml.cs').read_text()
        self.assertIn('PreviewPane.SetPreviewVisible(visible)',code)
        self.assertIn('SyncDockPreview()',code)
        self.assertNotIn('new PreviewWindow',code)

    def test_organizer_has_guided_local_actions_and_approval(self):
        xaml = (ROOT/'Controls/AiCommandPanel.xaml').read_text()
        code = (ROOT/'Controls/AiCommandPanel.xaml.cs').read_text()
        for term in ('유형별 이동','확장자별 이동','날짜별 이동','연도별 이동','유형별 복사'):
            self.assertIn(f'Tag="{term}"',xaml)
        self.assertIn('Click="Plan_Click"',xaml)
        self.assertIn('Click="Execute_Click"',xaml)
        self.assertIn('IsEnabled="False"',xaml)
        self.assertIn('BeforeFileChange?.Invoke()', code)
        self.assertIn('UpdateSelectionSummary(', code)

    def test_rename_and_move_route_through_one_owner(self):
        actions = (ROOT/'Services/FileActionsService.cs').read_text()
        transfer = (ROOT/'Services/TransferService.cs').read_text()
        self.assertIn('MoveEntry(source, target)', actions)
        self.assertIn('FileMemoStore.MoveFileWithMemos(source, destination)', actions)
        self.assertIn('FileActionsService.MoveEntry(effectivePlan.Source, effectivePlan.Destination)',transfer)
        self.assertIn('TransferService.RunAsync([step.Source!.Path]', (ROOT/'Services/AiPlanService.cs').read_text())

    def test_relocation_rewrites_memo_payload_before_file_move(self):
        store=(ROOT/'Services/FileMemoStore.cs').read_text()
        section=store.split('public static void MoveFileWithMemos',1)[1].split('public static IReadOnlyList<MemoRecord> ListForFile',1)[0]
        self.assertLess(section.index('new MemoPayload(Path.GetFileName(destination)'),section.index('File.Move(source, destination);\n            movedFile = true;'))
        self.assertLess(section.index('File.Move(memo.Staged, memo.Destination)'),section.index('transferSnapshot.DeleteSource(destination'))
        self.assertIn('transferSnapshot.VerifySource()', section)
        self.assertIn('transferSnapshot.VerifyDestination(destination)', section)
        self.assertIn('MemoTransferSnapshot.DiscardOwnedCopy(memo.Destination, fingerprint)', section)
        self.assertIn('if (unreadable > 0)',section)
        self.assertIn('File.Exists(targetMemo)',section)
        self.assertIn('File.Move(destination, source)', section)

    def test_user_draft_protected_before_mutations(self):
        main=(ROOT/'MainWindow.xaml.cs').read_text()
        pane=(ROOT/'Controls/ExplorerPane.xaml.cs').read_text()
        self.assertIn('pane.BeforeFileChange', main)
        self.assertIn('MemoPanel.ConfirmLeavingMemo()', main)
        self.assertIn('BeforeFileChange?.Invoke() == false', pane)


if __name__=='__main__':unittest.main()
