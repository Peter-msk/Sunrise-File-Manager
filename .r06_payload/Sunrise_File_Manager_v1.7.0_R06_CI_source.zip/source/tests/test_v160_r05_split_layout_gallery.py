"""R05: deterministic tests for the layout-choice UX and preserved right dock."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'
NS = '{http://schemas.microsoft.com/winfx/2006/xaml}'

class LayoutGalleryContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main_xaml = ET.parse(ROOT / 'MainWindow.xaml').getroot()
        cls.main = (ROOT / 'MainWindow.xaml.cs').read_text('utf-8')
        cls.gallery = (ROOT / 'Features/Workspace/MainWindow.SplitLayoutGallery.cs').read_text('utf-8')
        cls.engine = (ROOT / 'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text('utf-8')
        cls.smoke = (ROOT.parent / 'tests/UiSmokeTests/SplitLayoutGalleryAudit.cs').read_text('utf-8')

    def named(self, name):
        return next(el for el in self.main_xaml.iter() if el.attrib.get(NS+'Name') == name)

    def test_buttons_open_galleries_not_rotate_layouts(self):
        for count, name, handler in ((2,'TwoButton','Two_Click'),(3,'ThreeButton','Three_Click'),(4,'FourButton','Four_Click')):
            self.assertEqual(self.named(name).attrib['Click'], handler)
            self.assertIn(f'private void {handler}(object sender, RoutedEventArgs e) => ShowSplitLayoutGallery({count}, {name});', self.main)
        self.assertIn('The count buttons now open an explicit layout gallery', self.main)

    def test_catalog_has_all_existing_14_choices_organized_by_count(self):
        records = re.findall(r'new\(SplitLayoutPreset\.\w+,\s*([1-4]),\s*"', self.engine)
        self.assertEqual([records.count(str(i)) for i in range(1,5)], [1,2,6,5])
        self.assertIn('WorkspaceSplitLayoutEngine.GetPresetsForCount(normalized)', self.gallery)
        self.assertIn('WorkspaceSplitLayoutEngine.BuildBlueprint(preset)', self.gallery)

    def test_opening_does_not_change_layout_and_selection_is_explicit(self):
        start=self.gallery.index('private void ShowSplitLayoutGallery')
        show=self.gallery[start:self.gallery.index('private FrameworkElement CreateSplitLayoutThumbnail',start)]
        self.assertNotIn('ArrangePanels(normalized, _lastPresetByCount', show)
        self.assertIn('if (CanChangeSplitLayout) ArrangePanels(normalized, requestedPreset);', show)
        self.assertIn('menu.IsOpen = true;', show)
        self.assertIn('IsCheckable = false', show)
        self.assertIn('if (selected) item.SetResourceReference(Control.BackgroundProperty, "Selected");', show)

    def test_graphical_preset_preview_is_generated_from_grid_blueprint(self):
        for token in ('blueprint.StarColumns', 'blueprint.StarRows', 'blueprint.Panes',
                      'Grid.SetRow(pane, placement.Row)', 'Grid.SetColumn(pane, placement.Column)',
                      'Grid.SetRowSpan(pane, placement.RowSpan)', 'Grid.SetColumnSpan(pane, placement.ColumnSpan)',
                      'Text = (placement.PaneIndex + 1).ToString()'):
            self.assertIn(token,self.gallery)

    def test_existing_shortcuts_reuse_last_choice_and_session(self):
        for count in range(1,5):
            self.assertIn(f'Key.D{count} or Key.NumPad{count}) {{ ApplyLastLayoutForCount({count});', self.main)
        self.assertIn('else if (CanRouteSplitShortcut(e))', self.main)
        self.assertIn('_lastPresetByCount[normalized]',self.gallery)
        self.assertIn('ArrangePanels(normalized, _lastPresetByCount[normalized])',self.gallery)
        self.assertIn('_lastPresetByCount[clampedCount] = targetPreset;',self.main)
        self.assertIn('ScheduleSessionSave();',self.main)

    def test_user_can_access_current_layout_via_settings(self):
        self.assertTrue(any(el.attrib.get('Header')=='현재 분할 배치 선택…' and el.attrib.get('Click')=='CurrentSplitLayoutGallery_Click' for el in self.main_xaml.iter()))

    def test_shared_right_hand_panels_still_single_and_not_in_footer(self):
        for typ in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertEqual(sum(el.tag.endswith('}'+typ) for el in self.main_xaml.iter()),1)
        shell=self.named('WorkspaceShell')
        self.assertEqual(shell.attrib.get('Grid.Row'),'1')
        for name, col in (('FileDetails','2'),('MemoPanel','4'),('PreviewPane','2')):
            self.assertEqual(self.named(name).attrib['Grid.Column'],col)

    def test_windows_ui_gate_covers_full_gallery_and_native_mouse(self):
        program=(ROOT.parent/'tests/UiSmokeTests/Program.cs').read_text('utf-8')
        native=(ROOT.parent/'tests/UiSmokeTests/NativeUiRegression.cs').read_text('utf-8')
        self.assertIn('--split-gallery-only',program)
        self.assertIn('await SplitLayoutGalleryAudit.RunAsync(window, output)',program)
        self.assertIn('Check(menu.IsOpen',self.smoke)
        self.assertIn('Check(workspace.Children.OfType<Grid>().Count() == before',self.smoke)
        self.assertIn('await ClickAsync(window, firstLayout);',native)

if __name__ == '__main__': unittest.main()
