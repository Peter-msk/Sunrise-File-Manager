using System.IO.Compression;
using System.Security.Cryptography;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;

public static class V150FeatureTests
{
    public static async Task RunAsync()
    {
        int passed = 0;
        void Check(bool value, string name) { if (!value) throw new Exception("V150 FAILED: " + name); passed++; Console.WriteLine("PASS V150: " + name); }
        void Reject(Action action, string name)
        {
            bool rejected = false;
            try { action(); } catch (Exception ex) when (ex is not OutOfMemoryException and not StackOverflowException) { rejected = true; }
            Check(rejected, name);
        }
        string samples = Path.Combine(AppContext.BaseDirectory, "Fixtures", "ExplorerSamples");
        string root = Path.Combine(Path.GetTempPath(), "SunriseV150_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
        string S(string name) => Path.Combine(samples, name);
        try
        {
            var expected = new Dictionary<string, string[]>
            {
                ["환경평가 예시.docx"] = ["DOCX_END_NEEDLE", "DOCX_HEADER_NEEDLE"],
                ["측정 예시.xlsx"] = ["XLSX_WATER_NEEDLE", "XLSX_SECOND_SHEET_NEEDLE", "55.2"],
                ["설명 예시.pptx"] = ["PPTX_LAST_SLIDE_NEEDLE", "PPTX_NOTES_NEEDLE"],
                ["all-sections.hwpx"] = ["HWPX_LAST_NEEDLE"],
                ["hwp5-uncompressed.hwp"] = ["HWP_LATE_NEEDLE"],
                ["hwp5-deflated.hwp"] = ["HWP_LATE_NEEDLE"],
                ["late-page.pdf"] = ["PDF_LATE_SAMPLE_NEEDLE"]
            };
            foreach (var pair in expected)
            {
                string path = S(pair.Key); byte[] hash = SHA256.HashData(File.ReadAllBytes(path));
                foreach (string word in pair.Value)
                {
                    Check(DocumentContentSearch.Find(path, word, default).Status == ContentSearchStatus.Match, pair.Key + " / " + word);
                    Check(AiDocumentSearchService.Filter([path], word, true, default).Matches.SequenceEqual([path]), "approved AI and Explorer agree: " + pair.Key);
                }
                Check(SHA256.HashData(File.ReadAllBytes(path)).SequenceEqual(hash), "document search leaves source bytes intact: " + pair.Key);
            }
            Reject(() => AiDocumentSearchService.Filter([S("late-page.pdf")], "PDF_LATE_SAMPLE_NEEDLE", false, default), "AI content read requires approval");
            Check(DocumentContentSearch.Find(S("hwp5-protected.hwp"), "HWP", default).Status == ContentSearchStatus.Unsupported, "protected HWP is excluded instead of partially searched");
            Check(DocumentContentSearch.Find(S("scanned-ocr.pdf"), "SUNRISE", default).Status == ContentSearchStatus.NoText, "image PDF remains no-text until explicit Windows OCR");
            var multi = DocumentContentSearch.FindMany(S("환경평가 예시.docx"), ["DOCX_END_NEEDLE", "DOCX_HEADER_NEEDLE", "ABSENT"], default);
            Check(multi.Words.SetEquals(["DOCX_END_NEEDLE", "DOCX_HEADER_NEEDLE"]), "single traversal tracks multiple keywords across document parts");
            string target = Path.Combine(root, "target"); Directory.CreateDirectory(target);
            var scope = AiScope.Capture(samples, [S("환경평가 예시.docx")], target, default);
            Check(AiContentClassifier.Create(scope, "뒤쪽=DOCX_END_NEEDLE", "copy", true, new(100, 256L * 1024 * 1024), default).Plan is not null, "AI rule classification sees late content");
            Check(AiContentClassifier.Create(scope, "뒤쪽=DOCX_END_NEEDLE\n머리말=DOCX_HEADER_NEEDLE", "copy", true, new(100, 256L * 1024 * 1024), default).Plan is null, "full-body multi-rule conflict requires review");
            Check(AiNaturalLanguageService.Parse("본문에 '물' 포함된 XLSX 파일 찾아줘").Extension == ".xlsx", "AI grammar admits XLSX body search");
            Check(AiNaturalLanguageService.Parse("본문에 '물' 포함된 HWP 파일 찾아줘").Extension == ".hwp", "AI grammar admits ordinary HWP body search");

            string shared = Path.Combine(root, "shared.xlsx");
            using (var zip = ZipFile.Open(shared, ZipArchiveMode.Create))
            {
                void Part(string name, string xml) { using var writer = new StreamWriter(zip.CreateEntry(name).Open()); writer.Write(xml); }
                Part("xl/sharedStrings.xml", "<sst><si><r><t>SHARED_</t></r><r><t>NEEDLE</t></r></si><si><t>UNUSED_NEEDLE</t></si></sst>");
                Part("xl/worksheets/sheet1.xml", "<worksheet><sheetData><row><c t='s'><v>0</v></c></row></sheetData></worksheet>");
            }
            Check(DocumentContentSearch.Find(shared, "SHARED_NEEDLE", default).Status == ContentSearchStatus.Match, "XLSX shared rich-text runs join within a cell");
            Check(DocumentContentSearch.Find(shared, "UNUSED_NEEDLE", default).Status == ContentSearchStatus.NoMatch, "unused XLSX shared strings never cause false matches");
            var token = new CancellationToken(true);
            Reject(() => DocumentContentSearch.Find(S("hwp5-deflated.hwp"), "x", token), "HWP search honors cancellation");
            string corrupt = Path.Combine(root, "corrupt.hwp"); byte[] bytes = File.ReadAllBytes(S("hwp5-uncompressed.hwp"));
            uint fat = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(76));
            uint dir = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(48));
            System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(checked((int)(fat + 1) * 512 + (int)dir * 4)), dir);
            File.WriteAllBytes(corrupt, bytes);
            Reject(() => DocumentContentSearch.Find(corrupt, "x", default), "cyclic HWP allocation chain is rejected");
            foreach (string fixture in new[] { "password-zipcrypto.zip", "password-aes256.zip" })
            {
                string destination = Path.Combine(root, fixture + ".out");
                Reject(() => ArchiveService.Extract(S(fixture), destination, default), "encrypted archive asks for password: " + fixture);
                Check(!Directory.Exists(destination), "missing password publishes no destination: " + fixture);
                Reject(() => ArchiveService.Extract(S(fixture), destination, default, "incorrect"), "incorrect password rejected: " + fixture);
                Check(!Directory.Exists(destination), "incorrect password leaves destination absent: " + fixture);
                ArchiveService.Extract(S(fixture), destination, default, "sunrise-test");
                Check(Directory.GetFiles(destination).Length == 1 && File.ReadAllText(Directory.GetFiles(destination)[0]).Contains(fixture.Contains("aes") ? "AES256_FIXTURE_NEEDLE" : "PASSWORD_FIXTURE_NEEDLE"), "correct password extracts actual expected bytes: " + fixture);
            }
            Reject(() => ArchiveService.Extract(S("unsafe-path.zip"), Path.Combine(root, "unsafe"), default, "sunrise-test"), "password extraction keeps path traversal protection");
            Check(ArchiveService.List(S("ordinary.zip"), default).Count == 2, "archive contents are listed without extraction");
            string subset = Path.Combine(root, "subset");
            ArchiveService.Extract(S("ordinary.zip"), subset, default, selectedKeys: new HashSet<string> { "nested/한글.txt" });
            Check(File.ReadAllText(Path.Combine(subset, "nested", "한글.txt")) == "ARCHIVE_SAMPLE_NEEDLE" && !Directory.Exists(Path.Combine(subset, "empty")), "selected extraction publishes only selected files and required parents");
            Reject(() => ArchiveService.Extract(S("ordinary.zip"), Path.Combine(root, "missing-key"), default, selectedKeys: new HashSet<string> { "absent" }), "missing selected archive entry prevents publication");
            Check(!Directory.Exists(Path.Combine(root, "missing-key")), "missing-key failure leaves no destination");
            Check(!File.Exists(Path.Combine(root, "escape.txt")) && !Directory.GetDirectories(root, ".sunrise-archive-*").Any(), "archive failures leave no escape or staging artifacts");
            var row = new FileEntry { Name = "보고서 10.pdf", FullPath = "report.pdf", IsDirectory = false, TypeName = "PDF", SizeBytes = 2 * 1048576, ModifiedAt = new DateTime(2026, 10, 22), CreatedAt = new DateTime(2025, 1, 1) };
            Check(ExplorerQuery.Parse("*.pdf").Matches(row), "wildcard file-name filter");
            Check(ExplorerQuery.Parse("ext:pdf,docx size:>=1MiB modified:>=2026-01-01").Matches(row), "extension, size and modified date combine");
            Check(ExplorerQuery.Parse("name:\"보고서 *.pdf\" created:<2026-01-01 kind:file").Matches(row), "quoted wildcard and creation date filter");
            Check(!ExplorerQuery.Parse("size:<1MB").Matches(row), "decimal MB and binary MiB units are explicit");
            foreach (string bad in new[] { "size:garbage", "modified:2026-02-30", "kind:unknown", "ext:", "size:999999999999999999999999999999999GB" })
                Reject(() => ExplorerQuery.Parse(bad), "invalid filter is rejected: " + bad);
            Check(ExplorerExtraActions.AttributesAfter(FileAttributes.Archive | FileAttributes.ReadOnly, FileAttributes.Hidden, true) == (FileAttributes.Archive | FileAttributes.ReadOnly | FileAttributes.Hidden), "hidden attribute preserves unrelated bits");
            Check(ExplorerExtraActions.AttributesAfter(FileAttributes.ReadOnly, FileAttributes.ReadOnly, false) == FileAttributes.Normal, "clearing last attribute restores Normal");
            Check(ExplorerExtraActions.AttributesAfter(FileAttributes.Normal, FileAttributes.Hidden, false) == FileAttributes.Normal, "clearing absent attribute retains Normal");
            Reject(() => ExplorerExtraActions.AttributesAfter(FileAttributes.Normal, FileAttributes.System, true), "attribute editor cannot change arbitrary flags");
            var page = await DirectoryScanner.ReadPageAsync(samples, null, "ext:xlsx,pptx", "Name", false, "All", true, default);
            Check(page.TotalEntries == 2 && page.Entries.Count == 2, "global folder page applies structured query");
            string csv = FileActionsService.ExportDirectoryListingToFile(root, page.Entries, "sample.csv");
            Check(File.ReadAllText(csv).Contains("측정 예시.xlsx") && File.ReadAllText(csv).Contains("설명 예시.pptx"), "CSV contains both filtered source entries");
            Console.WriteLine($"V150: {passed}/{passed} PASS; Windows OCR/shortcut/attributes/UI/signing/setup runtime PENDING");
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }
}
