using System.IO.Compression;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;

public static class V150R01Tests
{
    public static Task RunAsync()
    {
        int passed = 0;
        void Check(bool value, string name) { if (!value) throw new Exception("R01 FAIL: " + name); passed++; Console.WriteLine("PASS " + name); }
        string root = Path.Combine(Path.GetTempPath(), "SunriseFM_R01_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            string files = Path.Combine(root, "파일 모음"); Directory.CreateDirectory(files);
            string original = Path.Combine(files, "보고서1.txt"); File.WriteAllText(original, "original");
            var row = FileEntry.From(new FileInfo(original));
            Check(ExplorerQuery.IsStructured("extension:txt path:보고서"), "structured alias detection");
            Check(ExplorerQuery.Parse("extension:txt path:보고서").Matches(row), "path and extension predicates");
            Check(ExplorerQuery.Parse("type:file datemodified:>=2020-01-01").Matches(row), "type and date aliases");
            Check(!ExplorerQuery.Parse("extension:pdf").Matches(row), "negative extension query");
            string zip = Path.Combine(root, "압축.zip");
            using (var created = ZipFile.Open(zip, ZipArchiveMode.Create))
            {
                var entry = created.CreateEntry("a.txt");
                using var writer = new StreamWriter(entry.Open()); writer.Write("a");
            }
            string source = Path.Combine(root, "한글 자료.txt"); File.WriteAllText(source, "추가한 문서");
            ZipEditService.Apply(zip, ZipEditService.Operation.Add, "한글 자료.txt", source, CancellationToken.None);
            using (var added = ZipFile.OpenRead(zip)) Check(added.Entries.Count == 2, "ZIP entry added");
            ZipEditService.Apply(zip, ZipEditService.Operation.Replace, "a.txt", source, CancellationToken.None);
            using (var replaced = ZipFile.OpenRead(zip))
            using (var reader = new StreamReader(replaced.GetEntry("a.txt")!.Open())) Check(reader.ReadToEnd() == "추가한 문서", "ZIP entry replaced");
            ZipEditService.Apply(zip, ZipEditService.Operation.Remove, "a.txt", null, CancellationToken.None);
            using (var removed = ZipFile.OpenRead(zip)) Check(removed.GetEntry("a.txt") is null && removed.Entries.Count == 1, "ZIP entry removed");
            var oldLength = new FileInfo(zip).Length;
            try { ZipEditService.Apply(zip, ZipEditService.Operation.Add, "한글 자료.txt", source, CancellationToken.None); throw new Exception("duplicate was accepted"); }
            catch (IOException) { Check(new FileInfo(zip).Length == oldLength, "ZIP duplicate leaves original unchanged"); }
            using var canceled = new CancellationTokenSource(); canceled.Cancel();
            try { ZipEditService.Apply(zip, ZipEditService.Operation.Remove, "한글 자료.txt", null, canceled.Token); throw new Exception("cancel was ignored"); }
            catch (OperationCanceledException) { Check(true, "ZIP cancellation preserves original"); }
            string dest = Path.Combine(root, "대상"); Directory.CreateDirectory(dest);
            string ledger = Path.Combine(root, "journal");
            var plan = TransferRecoveryJournal.BeginAt([source], dest, TransferKind.Copy, ledger);
            Check(TransferRecoveryJournal.PendingAt(ledger).Count == 1, "recovery manifest persisted");
            Check(TransferRecoveryJournal.EligibleCopySources(plan).SequenceEqual([source]), "unchanged missing file eligible");
            File.AppendAllText(source, "changed");
            Check(TransferRecoveryJournal.EligibleCopySources(plan).Count == 0, "changed source fails closed");
            TransferRecoveryJournal.DiscardAt(plan, ledger);
            Check(TransferRecoveryJournal.PendingAt(ledger).Count == 0, "explicit cleanup deletes only journal");
            Check(!OperatingSystem.IsWindows() ? ShellNewTemplateService.Discover().Count == 0 : true,
                  "ShellNew discovery has no mandatory external dependency");
        }
        finally { Directory.Delete(root, recursive: true); }
        Console.WriteLine($"V150 R01: {passed}/{passed} PASS");
        return Task.CompletedTask;
    }
}
