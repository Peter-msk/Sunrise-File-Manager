using System.Formats.Tar;
using System.IO.Compression;
using Sunrise.FileManager.Services;

internal static class V140PriorityTests
{
    private static int _passed;
    private static void Check(bool condition, string name)
    {
        if (!condition) throw new Exception("FAILED: " + name);
        _passed++; Console.WriteLine("PASS: " + name);
    }
    private sealed class ProgressNow<T>(Action<T> callback) : IProgress<T> { public void Report(T item) => callback(item); }
    public static async Task RunAsync()
    {
        string root = Path.Combine(Path.GetTempPath(), "SunriseV140_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        string Folder(string name) { string path = Path.Combine(root, name); Directory.CreateDirectory(path); return path; }
        string Put(string folder, string name, string text) { string path = Path.Combine(folder, name); File.WriteAllText(path, text); return path; }
        Func<TransferConflict, CancellationToken, Task<CollisionDecision>> Decide(CollisionChoice choice) => (_, _) => Task.FromResult(new CollisionDecision(choice));
        try
        {
            string src = Folder("원본"), dst = Folder("대상");
            string source = Put(src, "보고서.txt", "new content"), target = Path.Combine(dst, "보고서.txt");
            int prompts = 0;
            var copied = await TransferService.RunAsync([source], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask,
                resolveConflict: (_, _) => { prompts++; return Task.FromResult(new CollisionDecision(CollisionChoice.Skip)); });
            Check(copied.Completed == 1 && prompts == 0 && File.ReadAllText(target) == "new content", "ordinary copy starts without collision prompt");
            File.WriteAllText(target, "old");
            var skip = await TransferService.RunAsync([source], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Skip));
            Check(skip.Skipped == 1 && File.ReadAllText(target) == "old", "skip preserves destination");
            var rename = await TransferService.RunAsync([source], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Rename));
            Check(rename.Completed == 1 && File.ReadAllText(Path.Combine(dst, "보고서 (1).txt")) == "new content", "rename retains both versions");
            var replaced = await TransferService.RunAsync([source], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Replace));
            Check(replaced.Completed == 1 && File.ReadAllText(target) == "new content" && File.ReadAllText(replaced.ReplacementBackups.Single()) == "old" && File.Exists(source), "replace publishes new bytes and preserves old destination backup");
            var same = await TransferService.RunAsync([source], src, TransferKind.Copy, null, default, CollisionPolicy.Ask);
            Check(same.Completed == 1 && File.Exists(Path.Combine(src, "보고서 (1).txt")), "same-folder copy produces a new name");
            var canceled = await TransferService.RunAsync([source], dst, TransferKind.Move, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Cancel));
            Check(canceled.Canceled && File.Exists(source), "cancel collision preserves source");
            string second = Put(src, "second.txt", "second" ); Put(dst, "second.txt", "old second");
            prompts = 0;
            await TransferService.RunAsync([source, second], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask,
                resolveConflict: (_, _) => { prompts++; return Task.FromResult(new CollisionDecision(CollisionChoice.Skip, true)); });
            Check(prompts == 1, "apply-to-all reuses one explicit decision within the operation");
            var moveReplace = await TransferService.RunAsync([second], dst, TransferKind.Move, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Replace));
            Check(moveReplace.Completed == 1 && !File.Exists(second) && File.ReadAllText(Path.Combine(dst, "second.txt")) == "second" && moveReplace.MovedPaths.Count == 0 && moveReplace.ReplacementBackups.Count == 1, "replacement move removes source only after publishing and does not record unsafe rename undo");
            string mergedSource = Folder("원본/병합"), mergedTarget = Folder("대상/병합");
            Put(mergedSource, "new.txt", "new"); Put(mergedSource, "conflict.txt", "source"); Put(mergedTarget, "conflict.txt", "target"); Put(mergedTarget, "existing.txt", "keep");
            string nested = Folder("원본/병합/nested"); Put(nested, "nested.txt", "nested");
            var merged = await TransferService.RunAsync([mergedSource], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Skip));
            Check(merged.Failed == 0 && File.ReadAllText(Path.Combine(mergedTarget, "new.txt")) == "new" && File.ReadAllText(Path.Combine(mergedTarget, "conflict.txt")) == "target" && File.Exists(Path.Combine(mergedTarget, "existing.txt")) && File.Exists(Path.Combine(mergedTarget, "nested/nested.txt")), "recursive merge preserves existing and skipped files while publishing new children");
            var mergeMove = await TransferService.RunAsync([mergedSource], dst, TransferKind.Move, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Rename));
            Check(mergeMove.Failed == 0 && File.Exists(Path.Combine(mergedSource, "conflict.txt")) == false && Directory.Exists(mergedSource) && mergeMove.MovedPaths.Count > 0, "merge move retains source directory for leaf-level undo");
            foreach (var pair in mergeMove.MovedPaths.Reverse()) FileActionsService.MoveEntry(pair.Destination, pair.Source);
            Check(File.Exists(Path.Combine(mergedSource, "new.txt")), "merged move leaf paths support ordinary undo");
            string partialSource = Folder("partial/source/group"), partialTarget = Folder("partial/destination/group");
            string partialContainer = Path.GetDirectoryName(partialTarget)!;
            Put(partialSource, "skip.txt", "source"); Put(partialTarget, "skip.txt", "destination"); Put(partialSource, "move.txt", "move");
            Put(Folder("partial/source/group/#memo"), "keep.marker", "source-owned metadata");
            var partial = await TransferService.RunAsync([partialSource], partialContainer, TransferKind.Move, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Skip));
            Check(partial.Skipped == 1 && partial.MovedPaths.Count == 1 && File.Exists(Path.Combine(partialSource, "skip.txt")) && File.Exists(Path.Combine(partialSource, "#memo/keep.marker")), "partial merge keeps skipped file metadata in its source folder");
            var undo = new ExplorerUndoService(_ => throw new Exception("unexpected recycle"));
            undo.RecordMovedItems(partial.MovedPaths.Select(p => (p.Source, p.Destination)).ToArray());
            Check(undo.UndoLast().Success && File.Exists(Path.Combine(partialSource, "move.txt")), "partial merge exposes completed leaf moves for undo even when root is skipped");
            string memoDir = Folder("대상/#memo");
            File.WriteAllText(FileMemoStore.MemoPath(target, new DateTime(2026, 10, 22), "tester"), "invalid memo fixture");
            var protectedMemo = await TransferService.RunAsync([source], dst, TransferKind.Copy, null, default, CollisionPolicy.Ask, resolveConflict: Decide(CollisionChoice.Replace));
            Check(protectedMemo.Failed == 1 && File.ReadAllText(target) == "new content", "unreadable destination memo blocks replacement");
            var control = new TransferControl(); control.Pause();
            var entered = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            using (var ct = new CancellationTokenSource())
            {
                Task<TransferResult> task = TransferService.RunAsync([source], Folder("pause"), TransferKind.Copy,
                    new ProgressNow<TransferProgress>(_ => entered.TrySetResult(true)), ct.Token, control: control);
                await entered.Task.WaitAsync(TimeSpan.FromSeconds(5));
                Check(!task.IsCompleted, "paused worker waits before changing files");
                ct.Cancel();
                Check((await task).Canceled, "cancel releases paused transfer without deadlock");
            }
            control.Resume();
            Check(!control.IsPaused, "resume clears operation pause state");
            string big = Path.Combine(src, "big.bin"); File.WriteAllBytes(big, new byte[2 * 1024 * 1024]);
            string cancelDest = Folder("cancel-copy");
            using (var ct = new CancellationTokenSource())
            {
                var result = await TransferService.RunAsync([big], cancelDest, TransferKind.Copy, new ProgressNow<TransferProgress>(p => { if (p.BytesDone > 0) ct.Cancel(); }), ct.Token);
                Check(result.Canceled && !File.Exists(Path.Combine(cancelDest, "big.bin")) && !Directory.EnumerateFileSystemEntries(cancelDest).Any() && File.Exists(big), "mid-copy cancellation removes staging and preserves source");
            }
            bool nestedRejected = false;
            try { await TransferService.RunAsync([mergedSource, Path.Combine(mergedSource, "new.txt")], dst, TransferKind.Copy, null, default); } catch (IOException) { nestedRejected = true; }
            Check(nestedRejected, "parent and nested selection rejected before mutation");
            string large = Folder("large");
            for (int i = 0; i < 20_050; i++) using (File.Create(Path.Combine(large, $"file{i}.txt"))) { }
            var listing = await DirectoryScanner.ReadAsync(large, default);
            Check(listing.Entries.Count == 20_050 && listing.Warning is null, "all 20,050 entries listed beyond the old fixed cap");
            string tree = Folder("search/deep"); Put(tree, "needle-name.txt", "plain"); Put(tree, "body.txt", new string('x', 4094) + "검색어본문");
            Put(Folder("search"), "not-match.txt", "none");
            var names = await ExplorerSearchService.SearchAsync(Path.GetDirectoryName(tree)!, "needle", ExplorerSearchScope.Descendants, true, default);
            Check(names.Entries.Count == 1 && names.Entries[0].Name == "needle-name.txt", "recursive name search finds nested files");
            var bodies = await ExplorerSearchService.SearchAsync(Path.GetDirectoryName(tree)!, "검색어본문", ExplorerSearchScope.Contents, true, default);
            Check(bodies.Entries.Count == 1 && bodies.Entries[0].Name == "body.txt", "content search matches text spanning stream chunks");
            string sql = ExplorerSearchService.BuildIndexSql(tree, "O'Brien");
            Check(sql.Contains("O''Brien") && sql.Contains("CONTAINS(System.Search.Contents") && sql.Contains("SCOPE="), "Windows index SQL escapes literals and scopes the query");
            string sessionPath = Path.Combine(root, "session-test.json");
            SessionStore.Save(new AppSession { Panels = [new PanelSession { SearchScope = "Contents", GroupField = "ParentFolder" }] }, sessionPath);
            var session = SessionStore.Load(sessionPath, out string? sessionWarning);
            Check(sessionWarning is null && session.Panels[0].SearchScope == "Contents" && session.Panels[0].GroupField == "ParentFolder", "search scope and grouping survive isolated session roundtrip");
            var cloud = Sunrise.FileManager.Models.FileEntry.DescribeCloudState((FileAttributes)0x400000);
            Check(cloud == "온라인 전용" && Sunrise.FileManager.Models.FileEntry.DescribeCloudState((FileAttributes)0x80000) == "항상 이 장치에 유지", "cloud file attributes are classified without fetching file contents");
            string payload = Folder("archives/input" ); Put(payload, "한글.txt", "archive bytes"); Directory.CreateDirectory(Path.Combine(payload, "empty"));
            string tar = ArchiveService.CompressTar([payload], Path.Combine(root, "generated.tar"), default);
            string unpacked = ArchiveService.Extract(tar, Path.Combine(root, "tar-result"), default);
            Check(File.ReadAllText(Path.Combine(unpacked, "input/한글.txt")) == "archive bytes" && Directory.Exists(Path.Combine(unpacked, "input/empty")), "TAR roundtrip preserves Unicode names, bytes and empty folders");
            string seven = ArchiveService.CompressSevenZip([payload], Path.Combine(root, "generated.7z"), default);
            unpacked = ArchiveService.Extract(seven, Path.Combine(root, "7z-result"), default);
            Check(File.ReadAllText(Path.Combine(unpacked, "input/한글.txt")) == "archive bytes" && Directory.Exists(Path.Combine(unpacked, "input/empty")), "7z roundtrip preserves Unicode names, bytes and empty folders");
            string zip = Path.Combine(root, "good.zip"); ZipFile.CreateFromDirectory(payload, zip);
            unpacked = ArchiveService.Extract(zip, Path.Combine(root, "zip-result"), default);
            Check(File.ReadAllText(Path.Combine(unpacked, "한글.txt")) == "archive bytes", "managed ZIP extraction preserves file contents");
            foreach (string fixtureName in new[] { "Rar_0.50.6.rar", "Rar5_solid_0.50.6.rar" })
            {
                string fixture = Path.Combine(AppContext.BaseDirectory, "Fixtures", fixtureName);
                string output = ArchiveService.Extract(fixture, Path.Combine(root, fixtureName + "-result"), default);
                using var archive = SharpCompress.Archives.ArchiveFactory.OpenArchive(fixture);
                int verified = 0;
                foreach (var entry in archive.Entries.Where(e => !e.IsDirectory))
                {
                    string file = Path.Combine(output, entry.Key!.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar));
                    byte[] bytes = File.ReadAllBytes(file);
                    uint crc = 0xffffffff;
                    foreach (byte b in bytes) { crc ^= b; for (int i = 0; i < 8; i++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xedb88320 : crc >> 1; }
                    if (bytes.LongLength != entry.Size || (uint)entry.Crc != ~crc) throw new Exception("RAR length/CRC mismatch: " + entry.Key);
                    verified++;
                }
                Check(verified > 0, "RAR fixture decoded with independent CRC verification: " + fixtureName);
            }
            string compressedTar = Path.Combine(root, "generated.tar.gz");
            using (var output = File.Create(compressedTar)) using (var gzip = new GZipStream(output, CompressionLevel.SmallestSize)) using (var input = File.OpenRead(tar)) input.CopyTo(gzip);
            string gzipResult = ArchiveService.Extract(compressedTar, Path.Combine(root, "gzip-result"), default);
            Check(File.ReadAllText(Path.Combine(gzipResult, "input/한글.txt")) == "archive bytes", "compressed TAR extraction handles GZip wrapper");
            foreach (string attack in new[] { "../escape.txt", "/absolute.txt", "file:stream.txt", "CON", "a/../../escape.txt", "trailing. " })
            {
                string bad = Path.Combine(root, Guid.NewGuid() + ".zip");
                using (var z = ZipFile.Open(bad, ZipArchiveMode.Create)) using (var w = new StreamWriter(z.CreateEntry(attack).Open())) w.Write("attack");
                string dest = Path.Combine(root, Guid.NewGuid().ToString()); bool rejected = false;
                try { ArchiveService.Extract(bad, dest, default); } catch (Exception ex) when (ex is IOException or ArgumentException) { rejected = true; }
                Check(rejected && !Directory.Exists(dest), "archive rejects unsafe path: " + attack);
            }
            string duplicate = Path.Combine(root, "duplicate.zip");
            using (var z = ZipFile.Open(duplicate, ZipArchiveMode.Create)) { z.CreateEntry("same.txt"); z.CreateEntry("SAME.txt"); }
            bool duplicateRejected = false;
            try { ArchiveService.Extract(duplicate, Path.Combine(root, "duplicate-result"), default); } catch (IOException) { duplicateRejected = true; }
            Check(duplicateRejected && !Directory.Exists(Path.Combine(root, "duplicate-result")), "archive case-insensitive duplicate names are rejected before publishing");
            bool selfRejected = false;
            try { ArchiveService.CompressTar([payload], Path.Combine(payload, "self.tar"), default); } catch (IOException) { selfRejected = true; }
            Check(selfRejected && !File.Exists(Path.Combine(payload, "self.tar")), "archive cannot recursively include its own output");
            string dottedTar = Path.Combine(root, "dotted.tar");
            using (var output = File.Create(dottedTar)) using (var writer = new TarWriter(output))
            {
                writer.WriteEntry(new PaxTarEntry(TarEntryType.Directory, "./"));
                using var bytes = new MemoryStream(System.Text.Encoding.UTF8.GetBytes("dotted root"));
                writer.WriteEntry(new PaxTarEntry(TarEntryType.RegularFile, "./folder/item.txt") { DataStream = bytes });
            }
            string dotted = ArchiveService.Extract(dottedTar, Path.Combine(root, "dotted-result"), default);
            Check(File.ReadAllText(Path.Combine(dotted, "folder/item.txt")) == "dotted root", "ordinary TAR dot-root prefixes are normalized safely");
            string linkTar = Path.Combine(root, "link.tar");
            using (var output = File.Create(linkTar)) using (var writer = new TarWriter(output)) writer.WriteEntry(new PaxTarEntry(TarEntryType.SymbolicLink, "link") { LinkName = "../outside" });
            bool linkRejected = false;
            try { ArchiveService.Extract(linkTar, Path.Combine(root, "link-result"), default); } catch (IOException) { linkRejected = true; }
            Check(linkRejected, "archive symlinks are rejected");
            Check(!Directory.EnumerateFileSystemEntries(root, ".sunrise-*", SearchOption.AllDirectories).Any(), "no staging artifacts remain after success, rejection or cancellation");
            Console.WriteLine($"V140: {_passed}/{_passed} PASS; Windows shell/share/cloud/property-handler runtime PENDING");
        }
        finally { Directory.Delete(root, true); }
    }
}
