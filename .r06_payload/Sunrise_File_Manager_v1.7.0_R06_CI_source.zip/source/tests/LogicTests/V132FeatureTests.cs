using System.Text.Json;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;
internal static class V132FeatureTests
{
    public static void Run()
    {
        int passed = 0;
        void Check(bool ok, string name) { if (!ok) throw new Exception("V132 FAILED: " + name); passed++; Console.WriteLine("PASS: V132 " + name); }
        bool Same(IEnumerable<int> a, params int[] b) => a.ToHashSet().SetEquals(b);
        Check(Same(MarqueeSelectionPolicy.Select([1,2], [3,4], false, false), 3,4), "plain rectangle replaces previous selection");
        Check(Same(MarqueeSelectionPolicy.Select([1,2], [2,3], true, false), 1,3), "Ctrl rectangle toggles against the initial selection");
        Check(Same(MarqueeSelectionPolicy.Select([1,2], [2,3], false, true), 1,2,3), "Shift rectangle adds rows to existing selection");
        Check(Same(MarqueeSelectionPolicy.Select([1,2], [], true, false), 1,2), "Ctrl shrink back to empty restores baseline");
        Check(Same(MarqueeSelectionPolicy.Select([1,2], [], false, false)), "empty rectangle clears plain selection");
        Check(Same(MarqueeSelectionPolicy.HitRows(0, 30, 30, 100), 0), "rectangle boundary does not include the next row");
        Check(Same(MarqueeSelectionPolicy.HitRows(29, 31, 30, 100), 0,1), "partial intersection selects both rows");
        Check(Same(MarqueeSelectionPolicy.HitRows(-50, 15, 30, 100), 0), "selection above viewport is clipped");
        Check(Same(MarqueeSelectionPolicy.HitRows(60, 1000, 30, 4), 2,3), "selection below list does not create invalid indices");
        Check(Same(MarqueeSelectionPolicy.HitRows(1000, 1200, 30, 4)), "blank body below all items selects no phantom file");
        Check(MarqueeSelectionPolicy.HitRows(3000, 3300, 30, 10000).SequenceEqual(Enumerable.Range(100,10)), "scrolled selection uses content positions for unrealized rows");
        Check(!MarqueeSelectionPolicy.HitRows(double.NaN, 30, 30, 2).Any(), "invalid rectangle coordinates fail closed");
        Check(NavigationPanelPolicy.ReservedWidth(true, false) == 272 && NavigationPanelPolicy.ReservedWidth(true, true) == 0 && NavigationPanelPolicy.ReservedWidth(false, false) == 0, "pinned navigation width stays fixed while hidden modes reclaim file area");
        Check(NavigationPanelPolicy.NormalizeWidth(340) == 340 && NavigationPanelPolicy.NormalizeWidth(double.NaN) == 272 &&
            NavigationPanelPolicy.NormalizeWidth(100) == NavigationPanelPolicy.MinimumWidth &&
            NavigationPanelPolicy.NormalizeWidth(800) == NavigationPanelPolicy.MaximumWidth,
            "resizable navigation width clamps unsupported values and retains legacy default");
        Check(NavigationPanelPolicy.ReservedWidth(true, false, 340) == 340 &&
            NavigationPanelPolicy.ReservedWidth(true, true, 340) == 0 &&
            NavigationPanelPolicy.FitWidth(340, 370, false) <= 248,
            "saved navigation width is per-pane and constrained by available split-pane size");
        Check(NavigationPanelPolicy.DrawerVisible(true, true, true) && !NavigationPanelPolicy.DrawerVisible(true, true, false), "auto-hide opens on reveal and closes on leave");
        Check(!NavigationPanelPolicy.DrawerVisible(false, true, true), "explicitly closed panel cannot reappear on hover");
        Check(SessionStore.CaptureDisplayOrder([-1,-1,-1,-1]).SequenceEqual([0,1,2,3]), "unopened AI result grid saves natural order instead of invalid -1 indices");
        Check(SessionStore.CaptureDisplayOrder([1,0,3,2]).SequenceEqual([1,0,3,2]), "valid user reordered AI columns persist unchanged");
        Check(SessionStore.CaptureDisplayOrder([0,0,2,3]).SequenceEqual([0,1,2,3]), "temporary duplicate display indices are normalised before exit");
        Check(SessionStore.CaptureColumnWidth("Pixel", double.NaN).Value == 1 && SessionStore.CaptureColumnWidth("Star", 6000).Value == 4000, "transient AI grid widths remain within session validation range");
        Check(SessionStore.CaptureDisplayOrder([-1,-1,-1,-1,-1]).SequenceEqual([0,1,2,3,4]),
            "inactive explorer pane columns get a valid default order on exit");
        Check(SessionStore.CaptureDisplayOrder([2,0,1,4,3]).SequenceEqual([2,0,1,4,3]),
            "explicit explorer column order is preserved without resetting user preferences");
        Check(SessionStore.CaptureColumnWidth("Pixel", double.PositiveInfinity).Value == 1 &&
            SessionStore.CaptureColumnWidth("Pixel", 9000).Value == 4000 &&
            SessionStore.CaptureScrollOffset(double.NaN) == 0 &&
            SessionStore.CaptureScrollOffset(double.NegativeInfinity) == 0 &&
            SessionStore.CaptureScrollOffset(-2) == 0 &&
            SessionStore.CaptureScrollOffset(42.5) == 42.5,
            "transient explorer column width and scroll offsets are safe to save");
        string folder = Path.Combine(Path.GetTempPath(), "Sunrise132_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            string desktop = Path.Combine(folder, "redirected-desktop"); Directory.CreateDirectory(desktop);
            string root = Path.GetPathRoot(folder)!;
            Check(ExplorerLocationService.Parent(root, desktop) == WindowsKnownLocations.ThisPc, "Up from drive root reaches This PC");
            Check(ExplorerLocationService.Parent(WindowsKnownLocations.ThisPc, desktop) == desktop, "Up from This PC reaches redirected Desktop");
            Check(ExplorerLocationService.Parent(desktop, desktop) is null, "Desktop is the navigation root");
            Check(ExplorerLocationService.Parent(WindowsKnownLocations.RecycleBin, desktop) == desktop, "Recycle Bin has the same Desktop parent");
            Check(ExplorerLocationService.Parent(Path.Combine(desktop, "child"), desktop) == desktop, "a Desktop subfolder still navigates to Desktop");
            Check(WindowsKnownLocations.Title(WindowsKnownLocations.ThisPc) == "내 PC" && WindowsKnownLocations.ExpandDisplayPath("내 PC") == WindowsKnownLocations.ThisPc, "This PC title and address roundtrip");
            var defaults = new PanelSession();
            Check(!defaults.ShowHidden && !defaults.ShowExtensions && !defaults.ShowCheckboxes && !defaults.ColorCoding, "all four first-run view settings default OFF");
            var path = Path.Combine(folder, "session.json");
            File.WriteAllText(path, "{\"Panels\":[{}]}");
            var missing = SessionStore.Load(path, out var warning);
            Check(warning is null && !missing.Panels[0].ShowHidden && !missing.Panels[0].ShowExtensions && !missing.Panels[0].ShowCheckboxes && !missing.Panels[0].ColorCoding, "missing legacy fields receive OFF defaults");
            File.WriteAllText(path, "{\"Panels\":[{\"ShowHidden\":true,\"ShowExtensions\":true,\"ShowCheckboxes\":true,\"ColorCoding\":true}]}");
            var savedOn = SessionStore.Load(path, out warning).Panels[0];
            Check(warning is null && savedOn.ShowHidden && savedOn.ShowExtensions && savedOn.ShowCheckboxes && savedOn.ColorCoding, "explicit saved ON choices override new defaults");
            var session = new AppSession
            {
                LayoutVersion = 22, UiScalePercent = 70, Theme = "Dark", VisiblePanels = 4, ActivePane = 3,
                WindowWidth = 1400, WindowHeight = 900, WindowLeft = 40, WindowTop = 30,
                InspectorVisible = false, DockPreviewVisible = true, InspectorWidth = 350, PreviewWidth = 380,
                PreviewFitWidth = false, PreviewZoom = 1.6, MemoAuthor = "메모 작성자",
                AiWindowVisible = true, AiWindowWidth = 1100, AiWindowHeight = 800, AiWindowLeft = 50, AiWindowTop = 60,
                AiWindowMaximized = true,
                AiSettings = new AiPanelSettings { Scope = 1, QuickAction = 7, Provider = 1, Collision = 1, DataGrade = 2,
                    ContentReadAllowed = true, EngineExpanded = true, HelpExpanded = true, Destination = folder, Command = "문서 정리",
                    PlanColumnSettings = [new() { Unit = "Star", Value = 2 }], PlanColumnOrder = [0] },
                LastSplitPresets = ["Single","Single","TwoColumns","ThreeTop1Bottom2","FourGrid2x2"],
                SplitRatios = new() { ["FourGrid2x2"] = new() { Columns = [300,700], Rows = [400,600] } },
                PinnedFolders = [desktop, Path.Combine(folder,"disconnected-pinned")],
                Panels = [new PanelSession { TreeVisible = true, TreeAutoHide = true, TreeWidth = 315, TabPaths = [WindowsKnownLocations.ThisPc, Path.Combine(folder,"disconnected")],
                    SelectedTabIndex = 1, TabSearchTexts = ["", "보고서"], SearchText = "보고서", SortField = "ModifiedAt", SortDescending = true,
                    CategoryFilter = "문서", ViewMode = "Tiles", ShowHidden = true, ShowExtensions = false, ShowCheckboxes = true, ColorCoding = false,
                    ColumnSettings = [new() { Unit = "Star", Value = 2 }, new() { Unit = "Pixel", Value = 270 }], ColumnOrder = [1,0],
                    FileVerticalOffset = 40, FileHorizontalOffset = 120, ExpandedTreePaths = [desktop], TreeScrollOffset = 55 }]
            };
            string expected = JsonSerializer.Serialize(session);
            SessionStore.Save(session, path);
            var restored = SessionStore.Load(path, out warning);
            Check(warning is null && JsonSerializer.Serialize(restored) == expected, "all declared preferences survive atomic save and reload without loss");
            Check(restored.Panels[0].TreeWidth == 315, "custom navigation drawer width survives restart");
            Check(restored.Panels[0].TabPaths[1].EndsWith("disconnected"), "unavailable folder path is retained instead of discarded");
            Check(restored.Panels[0].TabSearchTexts[1] == "보고서", "search is preserved separately for each open tab");
            Check(restored.Panels[0].ColumnSettings[0].Unit == "Star" && restored.Panels[0].ColumnOrder.SequenceEqual([1,0]), "column sizing modes and order survive restart");
            Check(restored.SplitRatios["FourGrid2x2"].Columns.SequenceEqual([300d,700d]), "user split proportions survive restart");
            Check(restored.AiSettings.Command == "문서 정리" && restored.AiSettings.Provider == 1 && restored.AiSettings.ContentReadAllowed, "AI options and input survive restart without an execution plan");
            // Reproduce close after switching from a visible pane to several never-shown panes.
            session.Panels = Enumerable.Range(0, 4).Select(i => new PanelSession
            {
                TreeWidth = i == 0 ? 480 : NavigationPanelPolicy.DefaultWidth,
                TabPaths = [WindowsKnownLocations.ThisPc],
                ColumnOrder = SessionStore.CaptureDisplayOrder(i == 0 ? new[] { 1, 0, 2, 3 } : new[] { -1, -1, -1, -1 }),
                ColumnSettings = [SessionStore.CaptureColumnWidth("Pixel", double.PositiveInfinity)]
            }).ToList();
            SessionStore.Save(session, path);
            var fourPanelRestored = SessionStore.Load(path, out var fourPanelWarning);
            Check(fourPanelWarning is null && fourPanelRestored.Panels.Count == 4 &&
                fourPanelRestored.Panels[0].TreeWidth == 480 &&
                fourPanelRestored.Panels[0].ColumnOrder.SequenceEqual([1,0,2,3]) &&
                fourPanelRestored.Panels[1].ColumnOrder.SequenceEqual([0,1,2,3]),
                "four-pane shutdown captures valid layouts even when secondary grids are uninitialized");
            // DEFECT-FM-SESSION-001: simulate a 1.3.5-style raw UI capture during update exit.
            // SaveUiSnapshot must repair only transient WPF values and preserve deliberate user choices.
            session.Panels[0].ColumnOrder = [1, 0, 3, 2];
            session.Panels[1].ColumnOrder = [-1, -1, -1, -1];
            session.Panels[1].ColumnSettings = [new() { Unit = "Pixel", Value = double.PositiveInfinity }];
            session.Panels[1].FileHorizontalOffset = double.NaN;
            session.Panels[1].TreeWidth = double.PositiveInfinity;
            session.AiSettings.PlanColumnOrder = [-1, -1, -1, -1];
            SessionStore.SaveUiSnapshot(session, path);
            var stableAfterUpdate = SessionStore.Load(path, out var updateWarning);
            Check(updateWarning is null && stableAfterUpdate.Panels[0].ColumnOrder.SequenceEqual([1,0,3,2]) &&
                stableAfterUpdate.Panels[1].ColumnOrder.SequenceEqual([0,1,2,3]) &&
                stableAfterUpdate.Panels[1].ColumnSettings[0].Value == 1 &&
                stableAfterUpdate.Panels[1].FileHorizontalOffset == 0 &&
                stableAfterUpdate.Panels[1].TreeWidth == NavigationPanelPolicy.DefaultWidth &&
                stableAfterUpdate.AiSettings.PlanColumnOrder.SequenceEqual([0,1,2,3]),
                "1.3.5-style invalid UI capture cannot block update exit while valid reorder survives");
            // Restore the valid-session fixture for all following tests.
            session.Panels = fourPanelRestored.Panels;
            session.AiSettings = restored.AiSettings;

            Check(restored.PreviewZoom == 1.6 && !restored.PreviewFitWidth, "preview zoom options survive restart");
            string configPath = Path.Combine(folder, "ollama.json");
            AiOllamaService.SaveConfig(new OllamaUserConfig { Model = "qwen2.5:1.5b", PreferredSetupModel = "qwen3:1.7b" }, configPath);
            var aiConfig = AiOllamaService.LoadConfig(configPath);
            Check(aiConfig.Model == "qwen2.5:1.5b" && aiConfig.PreferredSetupModel == "qwen3:1.7b", "setup model choice persists separately from active installed model");
            string before = File.ReadAllText(path);
            session.Panels[0].ColumnOrder = [1,1]; bool invalid = false;
            try { SessionStore.Save(session, path); } catch (ArgumentException) { invalid = true; }
            Check(invalid && File.ReadAllText(path) == before, "invalid preference writes preserve the prior complete session");
            Check(!Directory.EnumerateFiles(folder, "*.tmp").Any(), "preference write leaves no staging file");
        }
        finally { Directory.Delete(folder, true); }
        Console.WriteLine($"V132 FEATURE TESTS PASS: {passed}");
    }
}
