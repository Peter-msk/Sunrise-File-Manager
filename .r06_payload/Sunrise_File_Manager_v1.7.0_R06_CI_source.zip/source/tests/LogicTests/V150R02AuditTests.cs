using System.IO.Compression;
using Sunrise.FileManager.Services;

public static class V150R02AuditTests
{
    public static Task RunAsync()
    {
        int passed = 0;
        void Check(bool condition, string name)
        {
            if (!condition) throw new Exception("v1.5.0 R02 audit failure: " + name);
            passed++;
            Console.WriteLine("PASS " + name);
        }
        string root = Path.Combine(Path.GetTempPath(), "SunriseFM150_R02_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            string source = Path.Combine(root, "문서 파일.txt");
            File.WriteAllText(source, "safe payload 123");
            string archive = Path.Combine(root, "test.zip");
            using (var created = ZipFile.Open(archive, ZipArchiveMode.Create))
            {
                using var writer = new StreamWriter(created.CreateEntry("old.txt").Open());
                writer.Write("old payload");
            }
            string oldHash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(archive)));
            foreach (string unsafeName in new[] { "../escape.txt", "a//bad.txt", "CON.txt", "a\\b.txt", "/root.txt" })
            {
                try { ZipEditService.Apply(archive, ZipEditService.Operation.Add, unsafeName, source, CancellationToken.None); throw new Exception("unsafe name accepted: " + unsafeName); }
                catch (ArgumentException) { }
                catch (IOException) { }
                Check(oldHash == Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(archive))), "unsafe ZIP path rejected: " + unsafeName);
            }
            ZipEditService.Apply(archive, ZipEditService.Operation.Add, "nested/문서 파일.txt", source, CancellationToken.None);
            using (var read = ZipFile.OpenRead(archive))
            using (var stream = read.GetEntry("nested/문서 파일.txt")!.Open())
            using (var text = new StreamReader(stream))
                Check(text.ReadToEnd() == "safe payload 123", "ZIP added entry payload verified");
            ZipEditService.Apply(archive, ZipEditService.Operation.Replace, "old.txt", source, CancellationToken.None);
            using (var read = ZipFile.OpenRead(archive))
            using (var stream = read.GetEntry("old.txt")!.Open())
            using (var text = new StreamReader(stream))
                Check(text.ReadToEnd() == "safe payload 123", "ZIP replacement payload verified");
            ZipEditService.Apply(archive, ZipEditService.Operation.Remove, "old.txt", null, CancellationToken.None);
            using (var read = ZipFile.OpenRead(archive)) Check(read.GetEntry("old.txt") is null, "ZIP removal verified");
            string beforeCancel = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(archive)));
            using var cancel = new CancellationTokenSource(); cancel.Cancel();
            try { ZipEditService.Apply(archive, ZipEditService.Operation.Remove, "nested/문서 파일.txt", null, cancel.Token); throw new Exception("cancellation ignored"); }
            catch (OperationCanceledException) { }
            Check(beforeCancel == Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(archive))), "canceled ZIP unchanged");
            try { _ = ExplorerQuery.Parse("extension:txt name:\"열린 따옴표"); throw new Exception("unclosed query accepted"); }
            catch (ArgumentException) { Check(true, "unclosed structured query rejected"); }
            string target = Path.Combine(root, "복구 대상"); Directory.CreateDirectory(target);
            string ledger = Path.Combine(root, "recovery");
            var plan = TransferRecoveryJournal.BeginAt([source], target, TransferKind.Copy, ledger);
            Check(TransferRecoveryJournal.PendingAt(ledger).Count == 1, "transfer journal readable");
            Check(TransferRecoveryJournal.EligibleCopySources(plan).SequenceEqual([source]), "unchanged safe source eligible");
            string targetFile = Path.Combine(target, Path.GetFileName(source)); File.WriteAllText(targetFile, "never overwrite");
            Check(TransferRecoveryJournal.EligibleCopySources(plan).Count == 0, "existing destination never eligible");
            File.Delete(targetFile);
            File.AppendAllText(source, "new");
            Check(TransferRecoveryJournal.EligibleCopySources(plan).Count == 0, "modified source never eligible");
            TransferRecoveryJournal.DiscardAt(plan, ledger);
            string corruptName = "transfer-" + new string('a', 32) + ".json";
            File.WriteAllText(Path.Combine(ledger, corruptName), "{\"Id\":\"" + new string('a', 32) + "\",\"Kind\":999,\"Sources\":null}");
            Check(TransferRecoveryJournal.PendingAt(ledger).Count == 0, "corrupt or forged recovery plan ignored");
        }
        finally { Directory.Delete(root, recursive: true); }
        Console.WriteLine($"v1.5.0 R02 audit: {passed}/{passed} PASS");
        return Task.CompletedTask;
    }
}
