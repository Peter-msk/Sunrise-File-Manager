using System.IO.Compression;
using System.Text;
using System.Text.Json;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;

internal static class V141CorrectiveTests
{
    private static int _passed;
    private static void Check(bool value, string name)
    {
        if (!value) throw new Exception("V141 FAILED: " + name);
        Console.WriteLine("PASS V141: " + name); _passed++;
    }
    private sealed class Immediate<T>(Action<T> action) : IProgress<T> { public void Report(T value) => action(value); }
    private static void RawMemo(FileMemoStore.MemoRecord record, string file, string text)
    {
        byte[] data = JsonSerializer.SerializeToUtf8Bytes(new { FileName = Path.GetFileName(file), record.UserName, record.CreatedLocal, Text = text });
        using var output = File.Create(record.Path); output.Write("SUNRISE_MEMO_V1\n"u8);
        using var zip = new GZipStream(output, CompressionLevel.Optimal); zip.Write(data);
    }
    public static async Task RunAsync()
    {
        string root = Path.Combine(Path.GetTempPath(), "SunriseV141_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        string Folder(string name) { string p = Path.Combine(root, name); Directory.CreateDirectory(p); return p; }
        string Put(string folder, string name, string text) { string p = Path.Combine(folder, name); File.WriteAllText(p, text); return p; }
        try
        {
            string documents = Folder("documents");
            string pdf = Path.Combine(documents, "late.pdf");
            File.Copy(Path.Combine(AppContext.BaseDirectory, "Fixtures/FullSearch5pages.pdf"), pdf);
            Check(DocumentContentSearch.Find(pdf, "LATE_PDF_NEEDLE", default).Status == ContentSearchStatus.Match, "PDF page 5 is searched beyond preview boundary");
            File.Copy(Path.Combine(AppContext.BaseDirectory, "Fixtures/FullSearchNoText.pdf"), Path.Combine(documents, "blank.pdf"));
            Check(DocumentContentSearch.Find(Path.Combine(documents, "blank.pdf"), "needle", default).Status == ContentSearchStatus.NoText, "PDF without text is reported separately from no match");
            string docx = Path.Combine(documents, "late.docx");
            using (var archive = ZipFile.Open(docx, ZipArchiveMode.Create))
            {
                using (var writer = new StreamWriter(archive.CreateEntry("word/document.xml").Open()))
                    writer.Write("<w:document xmlns:w='word'><w:body><w:p><w:r><w:t>" + new string('a', 17000) + "</w:t><w:t>LATE_DOCX_NEEDLE</w:t><w:t>SPLIT</w:t><w:t>RUN</w:t></w:r></w:p></w:body></w:document>");
                using (var writer = new StreamWriter(archive.CreateEntry("word/header1.xml").Open())) writer.Write("<w:hdr xmlns:w='word'><w:p><w:r><w:t>HEADER_NEEDLE</w:t></w:r></w:p></w:hdr>");
            }
            Check(DocumentContentSearch.Find(docx, "LATE_DOCX_NEEDLE", default).Status == ContentSearchStatus.Match, "DOCX text beyond 16,000 characters is searched");
            Check(DocumentContentSearch.Find(docx, "SPLITRUN", default).Status == ContentSearchStatus.Match, "keyword spanning formatting runs is preserved");
            Check(DocumentContentSearch.Find(docx, "HEADER_NEEDLE", default).Status == ContentSearchStatus.Match, "DOCX header text is included");
            string hwpx = Path.Combine(documents, "late.hwpx");
            using (var archive = ZipFile.Open(hwpx, ZipArchiveMode.Create))
                for (int i = 0; i < 12; i++)
                { using var writer = new StreamWriter(archive.CreateEntry($"Contents/section{i}.xml").Open()); writer.Write($"<s><p><t>{(i == 11 ? "LAST_SECTION_NEEDLE" : "ordinary")}</t></p></s>"); }
            Check(DocumentContentSearch.Find(hwpx, "LAST_SECTION_NEEDLE", default).Status == ContentSearchStatus.Match, "HWPX sections beyond the first five are searched");
            var full = await ExplorerSearchService.SearchAsync(documents, "LATE_PDF_NEEDLE", ExplorerSearchScope.Contents, true, default);
            Check(full.Entries.Count == 1 && full.Entries[0].Name == "late.pdf", "Explorer content search uses the new full-document reader");
            Put(documents, "broken.pdf", "broken PDF fixture");
            var broken = await ExplorerSearchService.SearchAsync(documents, "UNSEEN", ExplorerSearchScope.Contents, true, default);
            Check(broken.Warning!.Contains("생략 1개"), "malformed PDF is counted as unreadable without aborting other documents");
            File.Delete(Path.Combine(documents, "broken.pdf"));
            Put(documents, "unsupported.bin", "unsupported");
            using (var sparse = File.Create(Path.Combine(documents, "too-large.pdf"))) sparse.SetLength(DocumentContentSearch.MaxDocumentBytes + 1);
            var exclusions = await ExplorerSearchService.SearchAsync(documents, "UNSEEN_NEEDLE", ExplorerSearchScope.Contents, true, default);
            Check(exclusions.Entries.Count == 0 && exclusions.Warning!.Contains("미지원 1개") && exclusions.Warning.Contains("일부 미검색 1개") && exclusions.Warning.Contains("텍스트 없음 1개"), "no-match, unsupported, size limit and no-text counts remain distinct");
            using (var ct = new CancellationTokenSource())
            {
                ct.Cancel(); bool canceled = false;
                try { await ExplorerSearchService.SearchAsync(documents, "x", ExplorerSearchScope.Contents, true, ct.Token); } catch (OperationCanceledException) { canceled = true; }
                Check(canceled, "canceled search exits through cancellation rather than no-match");
            }

            var date = new DateTime(2026, 10, 22, 9, 0, 0);
            string src = Put(Folder("memo/source"), "report.txt", "report"), dst = Put(Folder("memo/target"), "report.txt", "report");
            var record = FileMemoStore.Save(src, "original", date, "tester");
            var snapshot = MemoTransferSnapshot.Capture(src, [record]);
            RawMemo(record, src, "edited during transfer");
            bool changed = false;
            try { snapshot.CopyTo(dst, default); } catch (IOException) { changed = true; }
            Check(changed && File.Exists(src) && FileMemoStore.Read(record.Path, src).Text == "edited during transfer", "source memo changes abort cleanup and preserve newest source text");
            RawMemo(record, src, "original");
            snapshot = MemoTransferSnapshot.Capture(src, [record]); snapshot.CopyTo(dst, default);
            string destMemo = FileMemoStore.MemoPath(dst, date, "tester");
            var destinationRecord = FileMemoStore.Read(destMemo, dst); RawMemo(destinationRecord, dst, "edited target");
            bool destinationChanged = false;
            try { snapshot.DeleteSource(dst, () => { }, default); } catch (IOException) { destinationChanged = true; }
            Check(destinationChanged && File.Exists(src) && File.Exists(record.Path), "destination memo re-read prevents removal when target text changes");
            RawMemo(destinationRecord, dst, "original");
            using (var ct = new CancellationTokenSource())
            {
                bool canceled = false;
                try { snapshot.DeleteSource(dst, () => ct.Cancel(), ct.Token); } catch (OperationCanceledException) { canceled = true; }
                Check(canceled && File.Exists(src) && FileMemoStore.Read(record.Path, src).Text == "original" && !Directory.EnumerateFiles(Path.GetDirectoryName(src)!, ".sunrise-*", SearchOption.AllDirectories).Any(), "cancellation after staging restores original memo names and source file");
            }
            snapshot.DeleteSource(dst, () => { }, default);
            Check(!File.Exists(src) && !File.Exists(record.Path) && FileMemoStore.Read(destMemo, dst).Text == "original", "successful memo cleanup removes only verified staged originals");

            string movedSource = Put(Folder("memo/moved-source"), "moved.txt", "data");
            var movedMemo = FileMemoStore.Save(movedSource, "move memo", date, "tester");
            var movedSnapshot = MemoTransferSnapshot.Capture(movedSource, [movedMemo]);
            string movedTarget = Path.Combine(Folder("memo/moved-target"), "moved.txt");
            File.Move(movedSource, movedTarget); movedSnapshot.CopyTo(movedTarget, default);
            Put(Path.GetDirectoryName(movedSource)!, "moved.txt", "new independent source file");
            movedSnapshot.DeleteSource(movedTarget, () => { }, default, sourceAlreadyMoved: true);
            Check(File.ReadAllText(movedSource) == "new independent source file" && !File.Exists(movedMemo.Path), "cleanup after same-volume rename never deletes a newly recreated source file");

            string ownCopy = Put(Folder("memo/rollback"), "memo-copy.txt", "original copied memo");
            byte[] ownHash = System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(ownCopy));
            File.WriteAllText(ownCopy, "latest external edit");
            Check(!MemoTransferSnapshot.DiscardOwnedCopy(ownCopy, ownHash) && File.ReadAllText(ownCopy) == "latest external edit", "rollback retains a destination memo modified after publication");
            File.WriteAllText(ownCopy, "original copied memo");
            Check(MemoTransferSnapshot.DiscardOwnedCopy(ownCopy, ownHash) && !File.Exists(ownCopy), "rollback removes only an unchanged owned memo copy");

            string newSource = Put(Folder("memo/new-source"), "item.txt", "file"), newDest = Put(Folder("memo/new-target"), "item.txt", "file");
            var old = FileMemoStore.Save(newSource, "old", date, "tester");
            var added = MemoTransferSnapshot.Capture(newSource, [old]); added.CopyTo(newDest, default);
            bool preservedBoth = false;
            try { added.DeleteSource(newDest, () => RawMemo(old, newSource, "new concurrent source memo"), default); }
            catch (IOException) { preservedBoth = true; }
            Check(preservedBoth && File.Exists(newSource) && FileMemoStore.Read(old.Path, newSource).Text == "new concurrent source memo" && Directory.EnumerateFiles(Path.GetDirectoryName(old.Path)!, ".sunrise-memo-move-*.tmp").Count() == 1, "concurrent recreation retains newest memo and discloses staged old copy instead of overwriting");

            Check(Enumerable.Range(0, 16).All(i => ReparsePointPolicy.IsCloudTag(0x9000001Au + (uint)i * 0x1000)), "all sixteen documented cloud reparse tags are accepted");
            Check(!ReparsePointPolicy.IsCloudTag(0xA000000Cu) && !ReparsePointPolicy.IsCloudTag(0xA0000003u) && !ReparsePointPolicy.IsCloudTag(0x9000001Bu), "symlink, junction and unknown reparse tags stay blocked");
            string links = Folder("links"), normal = Put(links, "plain.txt", "normal");
            string symbolic = Path.Combine(links, "shortcut.txt");
            if (!OperatingSystem.IsWindows())
            {
                File.CreateSymbolicLink(symbolic, normal);
                var names = await ExplorerSearchService.SearchAsync(links, "shortcut", ExplorerSearchScope.Descendants, true, default);
                Check(ReparsePointPolicy.IsBlocked(symbolic) && names.Entries.Count == 0 && File.ReadAllText(normal) == "normal", "real portable symlink is skipped without following it");
                File.Delete(symbolic);
            }
            else Console.WriteLine("PENDING: actual cloud-provider hydration/cancellation must be verified on Windows.");

            string large = Folder("pages");
            for (int i = 0; i < 5005; i++) Put(large, $"file{i}.txt", new string('x', i % 100));
            var pages = new List<FileEntry>(); FileEntry? cursor = null;
            do
            {
                var page = await DirectoryScanner.ReadPageAsync(large, cursor, "", "Name", false, "All", true, default);
                Check(page.Entries.Count <= DirectoryScanner.PageSize && page.TotalEntries == 5005, "directory page is bounded while counting every matching entry");
                pages.AddRange(page.Entries); cursor = page.HasMore ? page.NextCursor : null;
            } while (cursor is not null);
            Check(pages.Count == 5005 && pages.Select(p => p.FullPath).Distinct().Count() == 5005 && pages[2].Name == "file2.txt", "cursor paging covers all files without duplicates in natural order");
            var filtered = await DirectoryScanner.ReadPageAsync(large, null, "file5004", "Name", false, "All", true, default);
            Check(filtered.Entries.Single().Name == "file5004.txt", "current-folder name search sees files beyond the first page");
            var bySize = await DirectoryScanner.ReadPageAsync(large, null, "", "SizeBytes", true, "All", true, default);
            Check(bySize.Entries[0].SizeBytes == 99 && bySize.Entries.SequenceEqual(FileListView.Apply(pages, "", "SizeBytes", true, default).Take(2000), EntryIdentity.Instance), "page selection and full view use identical global size-sort policy");
            var revealed = await DirectoryScanner.ReadPageAsync(large, null, "", "Name", false, "All", true, default, Path.Combine(large, "file4000.txt"));
            Check(revealed.Entries[0].Name == "file4000.txt", "file reveal can start at a target beyond the first page");

            string photos = Folder("photos"), child = Folder("photos/child");
            for (int i = 0; i < 6; i++) { string file = Put(i < 3 ? photos : child, $"image{i}.jpg", "image fixture"); File.SetLastWriteTimeUtc(file, new DateTime(2026, 1, 1).AddDays(i)); }
            var collection = await PhotoCollectionScanner.ReadAsync([photos, child], p => p.EndsWith(".jpg"), default, 3);
            Check(collection.Total == 6 && collection.Entries.Select(p => p.Name).SequenceEqual(new[] { "image5.jpg", "image4.jpg", "image3.jpg" }), "photo cap selects globally newest items and overlapping roots do not duplicate them");

            string transferSource = Folder("bytes/source"), transferTarget = Folder("bytes/target");
            string skip = Put(transferSource, "skip.bin", new string('x', 10000)); Put(transferTarget, "skip.bin", "old");
            string copy = Put(transferSource, "copy.bin", new string('c', 300000));
            TransferProgress? last = null;
            var outcome = await TransferService.RunAsync([skip, copy], transferTarget, TransferKind.Copy, new Immediate<TransferProgress>(p => last = p), default);
            Check(outcome.Completed == 1 && outcome.Skipped == 1 && last!.BytesTransferred == 300000 && last.BytesDone == 310000, "reported physical bytes exclude skipped file sizes");
            Console.WriteLine($"V141: {_passed}/{_passed} PASS; Windows provider/property/shell/DPI execution PENDING");
        }
        finally { Directory.Delete(root, true); }
    }
    private sealed class EntryIdentity : IEqualityComparer<FileEntry>
    {
        public static readonly EntryIdentity Instance = new();
        public bool Equals(FileEntry? a, FileEntry? b) => a?.FullPath == b?.FullPath;
        public int GetHashCode(FileEntry item) => item.FullPath.GetHashCode();
    }
}
