"""Deterministic synthetic samples, not user documents. Uses existing development libraries only."""
from pathlib import Path
import io,struct,zlib,zipfile,datetime,json,hashlib,hmac,re
from docx import Document
from openpyxl import Workbook
from pptx import Presentation
from pptx.util import Inches
from PIL import Image,ImageDraw
from reportlab.pdfgen.canvas import Canvas
R=Path(__file__).resolve().parent
STAMP=(2026,1,1,0,0,0)
def normalize(p):
 with zipfile.ZipFile(p) as z: rows=[(n,z.read(n)) for n in z.namelist()]
 rows=[(n,re.sub(rb'(<dcterms:(?:created|modified)[^>]*>).*?(</dcterms:(?:created|modified)>)',rb'\g<1>2026-01-01T00:00:00Z\g<2>',b) if n=='docProps/core.xml' else b) for n,b in rows]
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(rows):
   info=zipfile.ZipInfo(n,STAMP);info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
def put_zip(p,rows):
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in rows.items():z.writestr(zipfile.ZipInfo(n,STAMP),b)
 return p
(R/'한글 공백 파일 2.txt').write_text('EIA_SAMPLE_ALPHA\n수질·소음 예시 자료입니다. 실제 사업 자료가 아닙니다.\n',encoding='utf-8')
(R/'한글 공백 파일 10.txt').write_text('EIA_SAMPLE_BETA\n',encoding='utf-8')
(R/'empty.txt').write_bytes(b'')
(R/'unsupported.bin').write_bytes(b'\x00\x01fixture')
(R/'broken.pdf').write_bytes(b'Synthetic malformed PDF')
d=Document();d.add_heading('환경평가 예시 문서',0);d.add_paragraph('일반 검색·미리보기용 가상 예시입니다.');d.add_paragraph('A'*17000);d.add_paragraph('DOCX_END_NEEDLE');d.sections[0].header.paragraphs[0].text='DOCX_HEADER_NEEDLE';d.core_properties.created=d.core_properties.modified=datetime.datetime(2026,1,1);d.save(R/'환경평가 예시.docx');normalize(R/'환경평가 예시.docx')
w=Workbook();s=w.active;s.title='수질';s.append(['지점','BOD','결과']);s.append(['W-1',1.2,'XLSX_WATER_NEEDLE']);s.append(['W-2',2.1,'확인']);t=w.create_sheet('소음');t.append(['지점','측정값']);t.append(['N-1',55.2]);t['C2']='XLSX_SECOND_SHEET_NEEDLE';t['B3']='=SUM(B2,1)';w.properties.created=w.properties.modified=datetime.datetime(2026,1,1);w.save(R/'측정 예시.xlsx');normalize(R/'측정 예시.xlsx')
p=Presentation()
for i in range(3):
 slide=p.slides.add_slide(p.slide_layouts[1]);slide.shapes.title.text=f'예시 슬라이드 {i+1}';slide.placeholders[1].text='PPTX_LAST_SLIDE_NEEDLE' if i==2 else '가상 사업 설명';slide.notes_slide.notes_text_frame.text='PPTX_NOTES_NEEDLE' if i==1 else '예시 발표 노트'
p.core_properties.created=p.core_properties.modified=datetime.datetime(2026,1,1);p.save(R/'설명 예시.pptx');normalize(R/'설명 예시.pptx')
put_zip(R/'all-sections.hwpx',{'Contents/section0.xml':"<hp:sec xmlns:hp='urn:fixture'><hp:p><hp:t>첫 구역</hp:t></hp:p></hp:sec>",'Contents/section10.xml':"<hp:sec xmlns:hp='urn:fixture'><hp:p><hp:t>HWPX_LAST_NEEDLE</hp:t></hp:p></hp:sec>"})
# Minimal HWP 5 parser fixtures: not intended as a Hancom layout compatibility corpus.
END=0xfffffffe;FREE=0xffffffff

def record(tag,data):
 n=len(data)
 return struct.pack('<I',tag|(min(n,4095)<<20))+(struct.pack('<I',n) if n>=4095 else b'')+data

def make_hwp(path,compressed=False,flags_extra=0):
 header=bytearray(256);header[:17]=b'HWP Document File';struct.pack_into('<I',header,32,0x05000300);struct.pack_into('<I',header,36,(1 if compressed else 0)|flags_extra)
 sections=[]
 for txt in ['일반 HWP 예시\r','A'*19000+'HWP_LATE_NEEDLE\r']:
  raw=record(66,struct.pack('<IIHBBHHHI',len(txt),0,0,0,0,0,0,0,0))+record(67,txt.encode('utf-16le'))
  if compressed:
   c=zlib.compressobj(wbits=-15);raw=c.compress(raw)+c.flush()
  sections.append(raw)
 docinfo=record(16,struct.pack('<HHHHHHHIII',2,1,1,1,1,1,1,0,0,0))
 if compressed:
  c=zlib.compressobj(wbits=-15);docinfo=c.compress(docinfo)+c.flush()
 data=[('FileHeader',bytes(header)),('DocInfo',docinfo),('Section0',sections[0]),('Section1',sections[1])]
 sectors=[];fat={};mini=bytearray();mf=[];allocation={}
 def alloc(payload):
  start=len(sectors);count=(len(payload)+511)//512
  for i in range(count):
   sectors.append(payload[i*512:(i+1)*512].ljust(512,b'\0'));fat[start+i]=start+i+1 if i<count-1 else END
  return start if count else END
 for name,payload in data:
  if len(payload)<4096:
   start=len(mf);n=(len(payload)+63)//64
   for i in range(n):mini.extend(payload[i*64:(i+1)*64].ljust(64,b'\0'));mf.append(start+i+1 if i<n-1 else END)
  else:start=alloc(payload)
  allocation[name]=(start,len(payload))
 mini_start=alloc(mini);mini_length=len(mini)
 mfbytes=b''.join(struct.pack('<I',n) for n in mf);mf_start=alloc(mfbytes.ljust(((len(mfbytes)+511)//512)*512,b'\xff'))
 def entry(name,typ,start=END,length=0,left=FREE,right=FREE,child=FREE,color=1):
  b=bytearray(128);n=(name+'\0').encode('utf-16le');b[:len(n)]=n;struct.pack_into('<HBBIII',b,64,len(n),typ,color,left,right,child);struct.pack_into('<IQ',b,116,start,length);return bytes(b)
 entries=[entry('Root Entry',5,mini_start,mini_length,child=2),entry('BodyText',1,child=4),entry('DocInfo',2,*allocation['DocInfo'],left=1,right=3),entry('FileHeader',2,*allocation['FileHeader']),entry('Section0',2,*allocation['Section0'],right=5),entry('Section1',2,*allocation['Section1'],color=0)]
 directory_start=alloc(b''.join(entries));fat_count=1
 while fat_count!=(len(sectors)+fat_count+127)//128:fat_count=(len(sectors)+fat_count+127)//128
 fat_ids=list(range(len(sectors),len(sectors)+fat_count));fatwords=[fat.get(i,0xfffffffd if i in fat_ids else FREE) for i in range(fat_count*128)]
 for at in range(fat_count):sectors.append(b''.join(struct.pack('<I',v) for v in fatwords[at*128:(at+1)*128]))
 h=bytearray(512);h[:8]=bytes.fromhex('D0CF11E0A1B11AE1');struct.pack_into('<HHHHH',h,24,0x3e,3,0xfffe,9,6);struct.pack_into('<I',h,44,fat_count);struct.pack_into('<I',h,48,directory_start);struct.pack_into('<I',h,56,4096);struct.pack_into('<II',h,60,mf_start,(len(mfbytes)+511)//512);struct.pack_into('<II',h,68,END,0)
 for i in range(109):struct.pack_into('<I',h,76+4*i,fat_ids[i] if i<len(fat_ids) else FREE)
 path.write_bytes(bytes(h)+b''.join(sectors))
make_hwp(R/'hwp5-uncompressed.hwp');make_hwp(R/'hwp5-deflated.hwp',True);make_hwp(R/'hwp5-protected.hwp',True,2)
# Classic PKZIP encryption fixture, implemented independently of the app's archive reader.
table=[]
for i in range(256):
 c=i
 for _ in range(8):c=(c>>1)^0xedb88320 if c&1 else c>>1
 table.append(c)
def encrypted_zip(path):
 plain=b'PASSWORD_FIXTURE_NEEDLE\n';password=b'sunrise-test';crc=zlib.crc32(plain)&0xffffffff;keys=[0x12345678,0x23456789,0x34567890]
 def update(b):
  keys[0]=((keys[0]>>8)^table[(keys[0]^b)&255])&0xffffffff;keys[1]=((keys[1]+(keys[0]&255))*134775813+1)&0xffffffff;keys[2]=((keys[2]>>8)^table[(keys[2]^(keys[1]>>24))&255])&0xffffffff
 for b in password:update(b)
 cipher=bytearray()
 for b in bytes(range(11))+bytes([crc>>24])+plain:
  k=keys[2]|2;cipher.append(b^((k*(k^1))>>8)&255);update(b)
 name=b'secret.txt';flags=1;method=0;extra=b''
 local=struct.pack('<IHHHHHIIIHH',0x04034b50,20,flags,method,0,33,crc,len(cipher),len(plain),len(name),len(extra))+name+extra+bytes(cipher)
 central=struct.pack('<IHHHHHHIIIHHHHHII',0x02014b50,20,20,flags,method,0,33,crc,len(cipher),len(plain),len(name),len(extra),0,0,0,0,0)+name+extra
 path.write_bytes(local+central+struct.pack('<IHHHHIIH',0x06054b50,0,0,1,1,len(central),len(local),0))
 with zipfile.ZipFile(path) as z:assert z.read('secret.txt',pwd=password)==plain
encrypted_zip(R/'password-zipcrypto.zip')
# WinZip AE-2 AES-256: independent fixture using an already installed development library.
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
plain=b'AES256_FIXTURE_NEEDLE\n';salt=bytes(range(16));derived=hashlib.pbkdf2_hmac('sha1',b'sunrise-test',salt,1000,66)
ctr=Cipher(algorithms.AES(derived[:32]),modes.ECB()).encryptor();cipher=bytearray()
for i in range(0,len(plain),16):
 block=ctr.update((i//16+1).to_bytes(16,'little'));cipher.extend(a^b for a,b in zip(plain[i:i+16],block))
cipher=bytes(cipher);payload=salt+derived[64:66]+cipher+hmac.new(derived[32:64],cipher,'sha1').digest()[:10]
name=b'secret-aes.txt';extra=struct.pack('<HHH2sBH',0x9901,7,2,b'AE',3,0)
local=struct.pack('<IHHHHHIIIHH',0x04034b50,51,1,99,0,33,0,len(payload),len(plain),len(name),len(extra))+name+extra+payload
central=struct.pack('<IHHHHHHIIIHHHHHII',0x02014b50,51,51,1,99,0,33,0,len(payload),len(plain),len(name),len(extra),0,0,0,0,0)+name+extra
(R/'password-aes256.zip').write_bytes(local+central+struct.pack('<IHHHHIIH',0x06054b50,0,0,1,1,len(central),len(local),0))

put_zip(R/'ordinary.zip',{'nested/한글.txt':'ARCHIVE_SAMPLE_NEEDLE','empty/':''})
put_zip(R/'unsafe-path.zip',{'../escape.txt':'must not escape'})
image=Image.new('RGB',(1400,600),'white');draw=ImageDraw.Draw(image)
from PIL import ImageFont
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',42)
draw.text((60,80),'SUNRISE OCR SAMPLE 2026',fill='black',font=font);draw.text((60,160),'WATER QUALITY REPORT',fill='black',font=font);image.save(R/'ocr-sample.png')
c=Canvas(str(R/'scanned-ocr.pdf'),invariant=1);c.drawImage(str(R/'ocr-sample.png'),35,450,width=520,height=223);c.save()
c=Canvas(str(R/'late-page.pdf'),invariant=1)
for i in range(6):c.drawString(50,750,'PDF_LATE_SAMPLE_NEEDLE' if i==5 else f'Synthetic page {i+1}');c.showPage()
c.save()
rows=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(R.iterdir()) if p.is_file() and p.name not in ['sample_manifest.json','README.md','generate_samples.py']]
(R/'sample_manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(R/'README.md').write_text('''# 직접 만든 기능 점검 예시\n\n모두 가상 자료입니다. 실제 사업·사용자 문서를 포함하지 않습니다.\n\n- DOCX: 16,000자 뒤 DOCX_END_NEEDLE, 머리말 DOCX_HEADER_NEEDLE\n- XLSX: 두 시트의 XLSX_WATER_NEEDLE, XLSX_SECOND_SHEET_NEEDLE; 수식은 실행하지 않고 저장 값만 읽음\n- PPTX: 마지막 슬라이드 PPTX_LAST_SLIDE_NEEDLE, 발표자 노트 PPTX_NOTES_NEEDLE\n- HWPX: 뒤 section HWPX_LAST_NEEDLE (텍스트 파서 fixture)\n- HWP: 일반/Deflate 본문의 HWP_LATE_NEEDLE. 합성 파서 fixture이며 한컴 페이지 렌더링 호환 표본은 아님. protected는 지원 제외 확인용\n- PDF: 6쪽 PDF_LATE_SAMPLE_NEEDLE, scanned-ocr.pdf는 이미지 PDF\n- PNG: Windows OCR 수동 확인용 영문 이미지\n- password-zipcrypto.zip: 암호 sunrise-test / secret.txt의 PASSWORD_FIXTURE_NEEDLE. 시험 전용 공개 암호\n- unsafe-path.zip·broken.pdf: 오류 처리 시험용, 정상 결과로 처리하면 안 됨\n- 한글 공백 경로·빈 파일·2/10 자연 정렬·ZIP 왕복·미지원 파일 확인\n\n앱이나 회사 Windows 빌드에서 자동 실행하지 않습니다. 개발용 generator는 배포 앱에 포함하지 않습니다. 파일 내용·해시는 sample_manifest.json 참조.\n''',encoding='utf-8')
print('generated',len(rows),'synthetic sample files')
