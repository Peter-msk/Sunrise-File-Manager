# 직접 만든 기능 점검 예시

모두 가상 자료입니다. 실제 사업·사용자 문서를 포함하지 않습니다.

- DOCX: 16,000자 뒤 DOCX_END_NEEDLE, 머리말 DOCX_HEADER_NEEDLE
- XLSX: 두 시트의 XLSX_WATER_NEEDLE, XLSX_SECOND_SHEET_NEEDLE; 수식은 실행하지 않고 저장 값만 읽음
- PPTX: 마지막 슬라이드 PPTX_LAST_SLIDE_NEEDLE, 발표자 노트 PPTX_NOTES_NEEDLE
- HWPX: 뒤 section HWPX_LAST_NEEDLE (텍스트 파서 fixture)
- HWP: 일반/Deflate 본문의 HWP_LATE_NEEDLE. 합성 파서 fixture이며 한컴 페이지 렌더링 호환 표본은 아님. protected는 지원 제외 확인용
- PDF: 6쪽 PDF_LATE_SAMPLE_NEEDLE, scanned-ocr.pdf는 이미지 PDF
- PNG: Windows OCR 수동 확인용 영문 이미지
- password-zipcrypto.zip: 암호 sunrise-test / secret.txt의 PASSWORD_FIXTURE_NEEDLE. 시험 전용 공개 암호
- unsafe-path.zip·broken.pdf: 오류 처리 시험용, 정상 결과로 처리하면 안 됨
- 한글 공백 경로·빈 파일·2/10 자연 정렬·ZIP 왕복·미지원 파일 확인

앱이나 회사 Windows 빌드에서 자동 실행하지 않습니다. 개발용 generator는 배포 앱에 포함하지 않습니다. 파일 내용·해시는 sample_manifest.json 참조.
