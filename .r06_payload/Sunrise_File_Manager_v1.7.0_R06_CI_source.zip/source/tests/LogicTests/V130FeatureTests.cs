using System.Text.Json;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;
internal static class V130FeatureTests
{
    public static void Run()
    {
        void Check(bool ok, string name) { if (!ok) throw new Exception("V130 FAILED: " + name); Console.WriteLine("PASS: V130 " + name); }
        PcHardware Pc(double ram, double vram = 0, string medium = "SSD", double free = 100, int cores = 8) =>
            new("test CPU", cores, ram, ram * 0.8, [new("test GPU", vram)], [new("C:", medium, free, true)], "test-models");
        string Top(PcHardware pc) => HardwareModelAdvisor.Rank(pc).First(x => x.Fits).Model.Tag;
        Check(Top(Pc(4)) == "qwen3:0.6b", "4GB PC gets ultra-light model");
        Check(Top(Pc(8)) == "qwen3:1.7b", "8GB CPU PC gets lightweight model");
        Check(Top(Pc(16)) == "qwen3:4b-instruct", "16GB SSD PC gets balanced model");
        Check(Top(Pc(16, 0, "HDD")) == "qwen3:1.7b", "HDD CPU PC favors a smaller model");
        Check(Top(Pc(16, 8)) == "qwen3:8b", "8GB dedicated GPU is not truncated to 32-bit memory");
        Check(Top(Pc(32, 16)) == "qwen3:14b", "large GPU and sufficient RAM can use large model");
        Check(Top(Pc(8, 16)) == "qwen3:1.7b", "large GPU cannot bypass low system RAM");
        Check(HardwareModelAdvisor.Rank(Pc(32, 16, free: 2)).All(x => !x.Fits), "full model drive rejects all automatic recommendations");
        Check(HardwareModelAdvisor.Rank(Pc(0)).All(x => !x.Fits), "unknown RAM never claims a model is suitable");
        Check(Top(Pc(16, cores: 2)) == "qwen3:1.7b", "low-core CPU favors lightweight model");
        Check(HardwareModelAdvisor.Rank(Pc(16, free: 4)).First(x => x.Fits).Model.Tag == "qwen3:0.6b", "download and temporary-space budget downgrade selection");
        var unknownDisk = Pc(16) with { Drives = Array.Empty<StorageHardware>() };
        Check(HardwareModelAdvisor.Rank(unknownDisk).All(x => x.Reason.Contains("저장 공간 확인 불가")), "unknown storage is clearly qualified");
        Check(HardwareModelAdvisor.Rank(Pc(16) with { AvailableRamGb = 1 }).All(x => x.Reason.Contains("메모리를 확보")), "currently low free RAM is explained");
        Check(HardwareModelAdvisor.Describe(Pc(16, 8)).Contains("실제 지원 여부"), "GPU detection does not promise driver compatibility");
        Check(UiScalePolicy.Normalize(-1) == 80 && UiScalePolicy.Normalize(999) == 80, "invalid scale falls back to compact default");
        Check(UiScalePolicy.Choices.All(x => UiScalePolicy.Normalize(x) == x), "all offered scale values persist unchanged");
        string temp = Path.Combine(Path.GetTempPath(), "sunrise-scale-" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            File.WriteAllText(temp, "{}");
            Check(SessionStore.Load(temp, out _).UiScalePercent == 80, "old settings migrate to 80 percent");
            SessionStore.Save(new AppSession { UiScalePercent = 70 }, temp);
            Check(SessionStore.Load(temp, out _).UiScalePercent == 70, "scale survives settings save and restore");
            File.WriteAllText(temp, "{\"UiScalePercent\":999}");
            Check(SessionStore.Load(temp, out _).UiScalePercent == 80, "invalid stored scale does not discard other settings");
        }
        finally { File.Delete(temp); }
        using var qwen = JsonDocument.Parse(AiOllamaService.BuildGenerateJson(new { model = "qwen3:1.7b", options = new { temperature = 0.1 }, format = "json" }));
        Check(!qwen.RootElement.GetProperty("think").GetBoolean(), "Qwen reasoning disabled for structured file plans");
        Check(qwen.RootElement.GetProperty("options").GetProperty("num_ctx").GetInt32() == 4096 && qwen.RootElement.GetProperty("options").GetProperty("temperature").GetDouble() == 0.1, "bounded context preserves existing generation options");
        using var legacy = JsonDocument.Parse(AiOllamaService.BuildGenerateJson(new { model = "qwen2.5:1.5b" }));
        Check(!legacy.RootElement.TryGetProperty("think", out _), "legacy model request remains compatible");
        Check(new ExplorerTab(WindowsKnownLocations.RecycleBin).Title == "휴지통", "recycle tab has friendly name");
        Check(WindowsKnownLocations.IsRecycleBin("SHELL:RecycleBinFolder") && !WindowsKnownLocations.IsRecycleBin("shell:Other"), "only the supported virtual namespace is accepted");
        Check(WindowsKnownLocations.DisplayPath(WindowsKnownLocations.RecycleBin) == "휴지통" && WindowsKnownLocations.ExpandDisplayPath("휴지통") == WindowsKnownLocations.RecycleBin, "virtual address roundtrip");
        Console.WriteLine("V130 FEATURE TESTS PASS");
    }
}
