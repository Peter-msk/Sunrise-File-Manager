using System.IO.Compression;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;

internal static class V120SafetyTests
{
    internal static void Run()
    {
        string root = Path.Combine(Path.GetTempPath(), "SunriseV120_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        int count = 0;
        void Check(bool value, string name)
        {
            if (!value) throw new Exception("FAIL v1.3.2: " + name);
            Console.WriteLine("PASS v1.3.2: " + name); count++;
        }
        void Reject(Action action, string name)
        {
            try { action(); }
            catch (Exception ex) when (ex is IOException or InvalidDataException or ArgumentException)
            { Check(true, name); return; }
            throw new Exception("Invalid operation accepted: " + name);
        }
        try
        {
            string original = FileActionsService.CreateFile(root, "원본.txt", "원본 보존");
            Reject(() => FileActionsService.CreateFile(root, "원본.txt", "덮어쓰기"), "existing CreateFile never overwrites");
            Check(File.ReadAllText(original) == "원본 보존", "original content remains unchanged");
            var undo = new ExplorerUndoService(_ => throw new IOException("Simulated recycle failure"));
            undo.RecordCreated(original, "파일");
            var result = undo.UndoLast();
            Check(!result.Success && File.Exists(original), "recycle failure in undo cannot become permanent deletion");
            var entry = FileEntry.From(new FileInfo(original));
            string light = entry.NameForeground;
            entry.RefreshThemeColors(true);
            Check(entry.NameForeground != light, "model accepts explicit dark theme without WPF dependency");
            entry.RefreshThemeColors(false);
            Check(entry.NameForeground == light, "light theme restored without changing color contract");

            string dir = Path.Combine(root, "자료"); Directory.CreateDirectory(dir);
            File.WriteAllText(Path.Combine(dir, "a.txt"), "A");
            Reject(() => FileActionsService.CompressToZip([dir], Path.Combine(dir, "self.zip")), "compression cannot include its own output");
            Check(Directory.GetFiles(dir).Length == 1, "self-compression failure leaves source clean");
            string left = Path.Combine(root, "left", "동일이름");
            string right = Path.Combine(root, "right", "동일이름");
            Directory.CreateDirectory(left);
            Directory.CreateDirectory(right);
            File.WriteAllText(Path.Combine(left, "a.txt"), "left");
            File.WriteAllText(Path.Combine(right, "b.txt"), "right");
            string ambiguousZip = Path.Combine(root, "same-name.zip");
            Reject(() => FileActionsService.CompressToZip([left, right], ambiguousZip), "same-named archive roots rejected");
            Check(!File.Exists(ambiguousZip), "ambiguous archive cannot publish a ZIP");
            Reject(() => FileActionsService.CompressToZip([dir, Path.Combine(dir, "a.txt")], Path.Combine(root, "nested-selection.zip")),
                "parent and child cannot produce duplicate archive entries");
            Reject(() => FileActionsService.CompressToZip([original, original], Path.Combine(root, "repeat.zip")),
                "repeated source cannot produce duplicate archive entries");
            File.SetLastWriteTimeUtc(original, new DateTime(2025, 1, 2, 3, 4, 5, DateTimeKind.Utc));
            var duplicate = FileActionsService.DuplicateEntries([original]);
            Check(duplicate.Count == 1 && File.ReadAllText(duplicate[0]) == "원본 보존", "file duplication publishes complete content");
            Check(File.GetLastWriteTimeUtc(duplicate[0]) == File.GetLastWriteTimeUtc(original), "duplicate retains original modification timestamp");
            var duplicateDirectory = FileActionsService.DuplicateEntries([dir]);
            Check(File.ReadAllText(Path.Combine(duplicateDirectory[0], "a.txt")) == "A", "folder duplication publishes complete directory");
            using var cancelled = new CancellationTokenSource(); cancelled.Cancel();
            bool stopped = false;
            try { FileActionsService.DuplicateEntries([original], cancelled.Token); } catch (OperationCanceledException) { stopped = true; }
            Check(stopped, "pre-cancelled duplicate cannot publish");
            stopped = false;
            try { FileActionsService.CompressToZip([dir], Path.Combine(root, "cancel.zip"), cancelled.Token); } catch (OperationCanceledException) { stopped = true; }
            Check(stopped && !File.Exists(Path.Combine(root, "cancel.zip")), "cancelled compression leaves no ZIP");
            string good = FileActionsService.CompressToZip([dir], Path.Combine(root, "good.zip"));
            stopped = false;
            try { FileActionsService.ExtractZip(good, Path.Combine(root, "cancel-extract"), cancelled.Token); } catch (OperationCanceledException) { stopped = true; }
            Check(stopped && !Directory.Exists(Path.Combine(root, "cancel-extract")), "cancelled extraction leaves no destination");
            string expanded = FileActionsService.ExtractZip(good, Path.Combine(root, "정상 해제"));
            Check(File.ReadAllText(Path.Combine(expanded, "자료", "a.txt")) == "A", "staged ZIP extraction preserves Korean paths/content");
            Reject(() => FileActionsService.ExtractZip(good, expanded), "existing extraction output never overwritten");
            void BadZip(string label, Action<ZipArchive> build)
            {
                string zip = Path.Combine(root, label + ".zip");
                using (var archive = ZipFile.Open(zip, ZipArchiveMode.Create)) build(archive);
                string destination = Path.Combine(root, label);
                Reject(() => FileActionsService.ExtractZip(zip, destination), label);
                Check(!Directory.Exists(destination) && !Directory.EnumerateDirectories(root, label + ".sunrise-extract-*").Any(), label + " leaves no partial output/staging");
            }
            BadZip("parent_escape", z => z.CreateEntry("../outside.txt"));
            BadZip("drive_path", z => z.CreateEntry("C:/outside.txt"));
            BadZip("absolute_path", z => z.CreateEntry("/outside.txt"));
            BadZip("case_duplicate", z => { z.CreateEntry("A.txt"); z.CreateEntry("a.txt"); });
            BadZip("windows_device", z => z.CreateEntry("CON.txt"));
            BadZip("symlink", z => { var e = z.CreateEntry("link"); e.ExternalAttributes = unchecked((int)0xA1FF0000); });
            BadZip("entry_collision", z => { z.CreateEntry("file"); z.CreateEntry("file/child.txt"); });
            BadZip("too_many", z => { for (int i = 0; i <= 20_000; i++) z.CreateEntry("file" + i); });
            Check(!File.Exists(Path.Combine(root, "outside.txt")), "ZIP traversal never writes outside destination");
        }
        finally { Directory.Delete(root, true); }
        Console.WriteLine($"PASS: {count} v1.3.2 file safety checks");
    }
}
