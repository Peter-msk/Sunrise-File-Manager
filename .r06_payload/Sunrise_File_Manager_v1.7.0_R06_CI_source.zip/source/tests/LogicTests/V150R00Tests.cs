using Sunrise.FileManager.Services;

public static class V150R00Tests
{
    public static async Task RunAsync()
    {
        int count = 0;
        void Check(bool result, string name) { if (!result) throw new Exception("R00 FAILED: " + name); ++count; Console.WriteLine("PASS: " + name); }
        var state = new PagedSelectionSet();
        Check(state.Add(@"C:\한글\A.txt") && state.Add(@"c:\한글\a.TXT") && state.Count == 1, "path casing is equivalent");
        state.Add(@"C:\한글\B.txt");
        state.SyncVisible([@"C:\한글\A.txt", @"C:\한글\B.txt"], [@"C:\한글\B.txt"]);
        Check(!state.Contains(@"C:\한글\A.txt") && state.Count == 1, "visible deselection removes only that page");
        state.Add(@"D:\다른\off-page.txt");
        state.SyncVisible([@"C:\한글\B.txt"], Array.Empty<string>());
        Check(state.Count == 1 && state.Contains(@"D:\다른\off-page.txt"), "off-page selection survives page changes");
        Check(!state.ReplaceAll(Enumerable.Range(0, PagedSelectionSet.MaxSelection + 1).Select(i => $"item-{i}")) && state.Count == 1,
            "over-limit full selection does not replace existing choice");
        Check(state.ReplaceAll([@"C:\one", @"c:\ONE", @"D:\two"]) && state.Count == 2, "deduplicated complete result replaces snapshot");
        state.Clear(); Check(state.Count == 0, "navigation and explicit clear revoke all selected pages");
        string temp = Path.Combine(Path.GetTempPath(), "SunriseV150R00_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temp);
        try
        {
            for (int i = 0; i < 2105; ++i) File.WriteAllText(Path.Combine(temp, $"file_{i:D4}.txt"), "");
            var all = await DirectoryScanner.ReadMatchingPathsAsync(temp, "ext:txt", "All", true, 3000, CancellationToken.None);
            Check(all.Count == 2105 && all.Distinct(StringComparer.OrdinalIgnoreCase).Count() == 2105, "all matches exceed one listing page");
            Check((await DirectoryScanner.ReadMatchingPathsAsync(temp, "name:*.txt", "All", true, 3000, CancellationToken.None)).Count == 2105,
                "wildcard all-results selection matches listing query");
            bool rejected = false;
            try { await DirectoryScanner.ReadMatchingPathsAsync(temp, "", "All", true, 2000, CancellationToken.None); }
            catch (InvalidOperationException) { rejected = true; }
            Check(rejected, "over-limit query fails without partial selection");
            using var canceled = new CancellationTokenSource(); canceled.Cancel();
            bool wasCanceled = false;
            try { await DirectoryScanner.ReadMatchingPathsAsync(temp, "", "All", true, 3000, canceled.Token); }
            catch (OperationCanceledException) { wasCanceled = true; }
            Check(wasCanceled, "cancel honors caller token");
        }
        finally { Directory.Delete(temp, recursive: true); }
        Console.WriteLine($"V150 R00: {count}/{count} PASS");
    }
}
