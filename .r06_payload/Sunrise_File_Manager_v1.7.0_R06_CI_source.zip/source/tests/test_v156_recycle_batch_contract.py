"""Non-Windows source invariants only; does not substitute for Windows Shell QA."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1] / "Sunrise.FileManager"


class RecycleBatchContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native = (ROOT / "Services/RecycleBinNativeDelete.cs").read_text(encoding="utf-8")
        cls.service = (ROOT / "Services/RecycleBinService.cs").read_text(encoding="utf-8")
        cls.ui = (ROOT / "Features/Explorer/ExplorerPane.RecycleBin.cs").read_text(encoding="utf-8")
        cls.router = (ROOT / "Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs").read_text(encoding="utf-8")

    def test_one_native_operation_after_queuing(self):
        self.assertEqual(self.native.count("operation.PerformOperations()"), 1)
        self.assertIn("operation.DeleteItem(item, IntPtr.Zero)", self.native)
        self.assertIn("FOF_NOCONFIRMATION | FOF_NOERRORUI", self.native)
        self.assertNotIn('InvokeVerb("delete")', self.native)

    def test_recycle_item_identity_never_direct_file_delete(self):
        self.assertIn("SHGetIDListFromObject", self.native)
        self.assertIn("SHCreateItemWithParent", self.native)
        self.assertNotIn("File.Delete(", self.native)
        self.assertNotIn("Directory.Delete(", self.native)
        self.assertIn("ReadLiveIdentities(CancellationToken.None)", self.service)
        self.assertIn("PermanentlyDeleteAsync", self.service)

    def test_selected_and_whole_bin_are_distinct(self):
        self.assertIn("PermanentDeleteRecycle_Click", self.ui)
        self.assertIn("EmptyRecycle_Click", self.ui)
        self.assertIn("SHEmptyRecycleBin", self.service)
        self.assertIn("원래 위치로 복원", self.ui)
        self.assertIn("모든 항목 복원", self.ui)
        self.assertIn("Windows 휴지통에서 열기", self.ui)
        self.assertNotIn("selected.Length > 100", self.ui)

    def test_keyboard_and_cancel_preserved(self):
        self.assertIn("PermanentDeleteRecycle_Click(this, e)", self.router)
        self.assertIn("MessageBoxButton.YesNo", self.ui)
        self.assertIn("MessageBoxResult.Yes", self.ui)
        self.assertIn("FileActionCompleted?.Invoke()", self.ui)


if __name__ == "__main__":
    unittest.main()
