"""R07 requested UX contract: each split count opens its approved presets *below the button*.
Source checks only; Windows WPF actual rendering remains a separate dynamic gate.
"""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'
MAIN = (ROOT / 'MainWindow.xaml.cs').read_text('utf-8')
XAML = (ROOT / 'MainWindow.xaml').read_text('utf-8')
GALLERY = (ROOT / 'Features/Workspace/MainWindow.SplitLayoutGallery.cs').read_text('utf-8')
ENGINE = (ROOT / 'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text('utf-8')
SMOKE = (ROOT.parent / 'tests/UiSmokeTests/SplitLayoutGalleryAudit.cs').read_text('utf-8')
NS = '{http://schemas.microsoft.com/winfx/2006/xaml}'


class CompactPresetDropdownContract(unittest.TestCase):
    def test_single_is_immediate_while_other_three_buttons_open_below(self):
        root = ET.fromstring(XAML)
        one = next(node for node in root.iter() if node.attrib.get(NS + 'Name') == 'OneButton')
        self.assertEqual(one.attrib.get('Click'), 'One_Click')
        self.assertEqual(one.attrib.get('Content'), '단일')
        self.assertIn('ApplyLastLayoutForCount(1);', MAIN)
        self.assertNotIn('ShowSplitLayoutGallery(1, OneButton)', MAIN)
        for count, key, handler in [(2,'TwoButton','Two_Click'),(3,'ThreeButton','Three_Click'),(4,'FourButton','Four_Click')]:
            button = next(node for node in root.iter() if node.attrib.get(NS + 'Name') == key)
            self.assertEqual(button.attrib.get('Click'), handler)
            self.assertIn('▾', button.attrib.get('Content',''))
            self.assertIn(f'private void {handler}(object sender, RoutedEventArgs e) => ShowSplitLayoutGallery({count}, {key});', MAIN)
        for word in ('PlacementTarget = anchor','Placement = PlacementMode.Bottom','menu.IsOpen = true;'):
            self.assertIn(word, GALLERY)

    def test_approved_preset_inventory_unchanged(self):
        counts = re.findall(r'new\(SplitLayoutPreset\.\w+,\s*([1-4]),\s*"', ENGINE)
        self.assertEqual([counts.count(str(i)) for i in range(1,5)],[1,2,6,5])
        self.assertIn('GetPresetsForCount(normalized)', GALLERY)
        self.assertIn('BuildBlueprint(preset)', GALLERY)
        self.assertNotIn('new SplitPresetOption(',GALLERY)

    def test_compact_list_uses_only_diagram_and_short_label(self):
        self.assertIn('MinHeight = 44', GALLERY)
        self.assertIn('MinWidth = 212', GALLERY)
        self.assertIn('Height = 32', GALLERY)
        self.assertIn('content.Children.Add(CreateSplitLayoutThumbnail', GALLERY)
        self.assertIn('content.Children.Add(title)', GALLERY)
        self.assertNotIn('labels.Children.Add(description)', GALLERY)
        self.assertIn('ToolTip = $"{choice.Description}\\n{fit.DisplayText}"', GALLERY)
        self.assertIn('IsCheckable = false',GALLERY)

    def test_menu_open_does_not_change_layout_until_item_click(self):
        method=GALLERY.split('private void ShowSplitLayoutGallery',1)[1].split('private FrameworkElement CreateSplitLayoutThumbnail',1)[0]
        self.assertEqual(method.count('ArrangePanels('),1)
        self.assertIn('item.Click += (_, _) =>',method)
        self.assertIn('if (CanChangeSplitLayout) ArrangePanels(normalized, requestedPreset)',method)
        self.assertIn('IsCheckable = false',method)
        self.assertIn('menu.Opened +=',method)

    def test_only_one_right_panel_per_type_and_footer_stays_row3(self):
        root=ET.fromstring(XAML)
        for panel in ['FileDetailsPanel','FileMemoPanel','FilePreviewPanel']:
            self.assertEqual(sum(1 for n in root.iter() if n.tag.endswith('}'+panel)),1)
        for name in ['FileDetails','PreviewPane','MemoPanel']:
            node=next(n for n in root.iter() if n.attrib.get(NS+'Name')==name)
            self.assertNotEqual(node.attrib.get('Grid.Row'),'3')

    def test_native_windows_gate_updated_for_all_four_buttons(self):
        self.assertIn('new[] { 2, 3, 4 }',SMOKE)
        self.assertIn('menus=2/6/5, direct single',SMOKE)
        self.assertIn('PlacementMode.Bottom',SMOKE)
        self.assertIn('item.ToolTip?',SMOKE)

if __name__ == '__main__': unittest.main()
