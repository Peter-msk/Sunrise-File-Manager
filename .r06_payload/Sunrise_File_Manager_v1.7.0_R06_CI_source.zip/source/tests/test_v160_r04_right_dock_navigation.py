"""R04 deterministic source checks: right-only shared utilities and transient split-tree fit."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'
NS = '{http://schemas.microsoft.com/winfx/2006/xaml}'

class RightDockNavigationContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = ET.parse(ROOT / 'MainWindow.xaml').getroot()
        cls.explorer = ET.parse(ROOT / 'Controls/ExplorerPane.xaml').getroot()
        cls.policy = (ROOT / 'Services/NavigationPanelPolicy.cs').read_text('utf-8')
        cls.nav = (ROOT / 'Features/Explorer/ExplorerPane.NavigationDrawer.cs').read_text('utf-8')
        cls.pane = (ROOT / 'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        cls.session = (ROOT / 'Services/SessionStore.cs').read_text('utf-8')

    def named(self, tree, name):
        return next(e for e in tree.iter() if e.attrib.get(NS+'Name') == name)

    def test_right_utilities_share_one_instance_each(self):
        for typ in ('FileDetailsPanel', 'FileMemoPanel', 'FilePreviewPanel'):
            self.assertEqual(sum(e.tag.endswith('}'+typ) for e in self.main.iter()), 1)
            self.assertEqual(sum(e.tag.endswith('}'+typ) for e in self.explorer.iter()), 0)

    def test_docks_are_in_right_columns_not_footer(self):
        shell = self.named(self.main, 'WorkspaceShell')
        area = self.named(self.main, 'FileAreaShell')
        self.assertEqual(shell.attrib.get('Grid.Row'), '1')
        self.assertEqual(area.attrib.get('Grid.Column'), '0')
        self.assertEqual(self.named(self.main, 'FileDetails').attrib.get('Grid.Column'), '2')
        self.assertEqual(self.named(self.main, 'MemoPanel').attrib.get('Grid.Column'), '4')
        self.assertEqual(self.named(self.main, 'PreviewPane').attrib.get('Grid.Column'), '2')
        footer = next(e for e in self.main.iter() if e.attrib.get('Grid.Row')=='2')
        self.assertTrue(footer.tag.endswith('}Border'))
        for typ in ('FileDetailsPanel', 'FileMemoPanel', 'FilePreviewPanel'):
            self.assertFalse(any(e.tag.endswith('}'+typ) for e in footer.iter()))

    def test_pinned_tree_guarantees_file_area_budget(self):
        self.assertIn('public const double MinimumFileAreaBudget = 176;', self.policy)
        self.assertIn('paneWidth - RailWidth - (autoHide ? 35 : MinimumFileAreaBudget)', self.policy)
        self.assertIn('NavigationPanelPolicy.FitWidth(_navigationWidth, ActualWidth, _treeAutoHide)', self.nav)
        self.assertIn('ApplyResponsiveSubPanels(layout)', self.pane)

    def test_saved_tree_width_and_auto_hide_unchanged(self):
        self.assertIn('TreeWidth = NavigationPanelPolicy.NormalizeWidth(_navigationWidth)', self.pane)
        self.assertIn('TreeVisible = _treePreference', self.pane)
        self.assertIn('TreeAutoHide = _treeAutoHide', self.pane)
        self.assertIn('public const double DefaultWidth = 272;', self.policy)
        self.assertIn('public const double MinimumWidth = 145;', self.policy)
        self.assertIn('public const double RailWidth = 22;', self.policy)

    def test_native_right_dock_gate_is_available(self):
        test = (ROOT.parent / 'tests/UiSmokeTests/CurrentUiAudit.cs').read_text('utf-8')
        program = (ROOT.parent / 'tests/UiSmokeTests/Program.cs').read_text('utf-8')
        self.assertIn('RunRightDockAndTreeBudgetAsync', test)
        self.assertIn('ReferenceEquals(details.Parent, fileArea)', test)
        self.assertIn('--right-dock-only', program)

if __name__ == '__main__': unittest.main()
