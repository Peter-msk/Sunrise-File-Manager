"""R03: real pane XAML/host contracts; Windows interaction is a separate native gate."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT=Path(__file__).resolve().parents[1]/'Sunrise.FileManager'
NS='{http://schemas.microsoft.com/winfx/2006/xaml}'

class PaneDensityContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.xaml=(ROOT/'Controls/ExplorerPane.xaml').read_text('utf-8')
        cls.core=(ROOT/'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        cls.view=(ROOT/'Features/Explorer/ExplorerPane.ViewAndFiltering.cs').read_text('utf-8')
        cls.main=(ROOT/'MainWindow.xaml').read_text('utf-8')
        cls.root=ET.fromstring(cls.xaml)
        cls.nodes={e.attrib[NS+'Name']:e for e in cls.root.iter() if NS+'Name' in e.attrib}
    def test_split_density_reclaims_shell_rows_but_keeps_normal_mode(self):
        for token in ('TabRow.Height = new GridLength(dense ? 34 : 36)',
                      'BreadcrumbRow.Height = new GridLength(dense ? 24 : 28)',
                      'FooterRow.Height = new GridLength(dense ? 26 : 30)',
                      'AddressRow.Height = new GridLength(dense ? (layout.SearchBelow ? 68 : 38) : (layout.SearchBelow ? 80 : 42))'):
            self.assertIn(token,self.core)
        self.assertIn('ApplyCompactPaneDensity(layout)',self.core)
        self.assertNotIn('AddressRow.Height = new GridLength',self.view)
    def test_search_and_address_remain_usable_in_two_rows(self):
        for control in ('AddressBox','SearchBox','AddressHost','SearchHost','AddressInputRow','BackButton','ForwardButton','UpButton','RefreshNavButton','GoNavButton'):
            self.assertIn(control,self.nodes)
        self.assertIn('Grid.SetRow(SearchHost, layout.SearchBelow ? 1 : 0)',self.core)
        self.assertIn('SearchHost.Height = SearchBox.Height = dense ? 30 : 34',self.core)
        self.assertIn('button.MinHeight = dense ? 30 : 34',self.core)
    def test_breadcrumb_preserves_interaction_and_hidden_toggles_have_menu_route(self):
        self.assertIn('BreadcrumbCaption.Visibility = dense ? Visibility.Collapsed',self.core)
        self.assertIn('BreadcrumbScroll',self.nodes)
        self.assertIn('BreadcrumbPanel',self.nodes)
        for name in ('HiddenToggle','ExtensionsToggle','CheckboxesToggle','ColorFilterToggle'):
            self.assertIn(name,self.nodes)
        for caption in ('숨긴 항목','파일 확장명','항목 확인란','색상 구분'):
            self.assertIn(caption,self.xaml)
    def test_file_name_scroll_preserved_without_overwriting_saved_column_width(self):
        self.assertIn('FilesGrid.Columns[1].MinWidth = dense && ActualWidth < 640 ? 145 : 190;',self.core)
        self.assertIn('ScrollViewer.HorizontalScrollBarVisibility="Visible"',self.xaml)
        self.assertIn('ColumnSettings = FilesGrid.Columns.Select',self.core)
        self.assertIn('TreeVisible = _treePreference',self.core)
        self.assertNotIn('_treePreference = false;',self.core.split('private void ApplyCompactPaneDensity(',1)[1].split('private void ApplyCompactCommandBar',1)[0])
    def test_shared_right_panels_untouched_in_explorer(self):
        for typ in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertNotIn('<local:'+typ,self.xaml)
            self.assertEqual(self.main.count('<local:'+typ),1)
        self.assertIn('public void SetCompactMode(bool compact)',self.view)

if __name__=='__main__':unittest.main()
