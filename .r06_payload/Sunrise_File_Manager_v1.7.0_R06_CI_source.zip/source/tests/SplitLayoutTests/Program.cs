using Sunrise.FileManager.Services;

int passed = 0;
void Check(bool condition, string reason)
{
    if (!condition) throw new Exception(reason);
    passed++;
}
var presets = Enum.GetValues<SplitLayoutPreset>();
Check(presets.Length == 14, "Expected all 14 approved split layouts.");
// R06: the gallery must communicate when a proposed arrangement will scroll
// without ever excluding an approved layout or changing the minimum geometry.
foreach (SplitLayoutPreset preset in presets)
{
    var size = WorkspaceSplitLayoutEngine.GetMinimumWorkspaceSize(preset);
    var fits = WorkspaceSplitLayoutEngine.AssessViewportFit(preset, size.Width + 20, size.Height + 20);
    Check(fits.NeedsHorizontalScroll == false && fits.NeedsVerticalScroll == false,
        $"Fitting viewport incorrectly warned about scrolling: {preset}");
    var cramped = WorkspaceSplitLayoutEngine.AssessViewportFit(preset, size.Width - 20, size.Height - 20);
    Check(cramped.NeedsHorizontalScroll == true && cramped.NeedsVerticalScroll == true,
        $"Cramped viewport did not warn about both scroll directions: {preset}");
    var horizontal = WorkspaceSplitLayoutEngine.AssessViewportFit(preset, size.Width - 20, size.Height + 20);
    Check(horizontal.NeedsHorizontalScroll == true && horizontal.NeedsVerticalScroll == false,
        $"Horizontal overflow assessment incorrect: {preset}");
    var vertical = WorkspaceSplitLayoutEngine.AssessViewportFit(preset, size.Width + 20, size.Height - 20);
    Check(vertical.NeedsHorizontalScroll == false && vertical.NeedsVerticalScroll == true,
        $"Vertical overflow assessment incorrect: {preset}");
    var unknown = WorkspaceSplitLayoutEngine.AssessViewportFit(preset, 0, double.NaN);
    Check(unknown.NeedsHorizontalScroll is null && unknown.NeedsVerticalScroll is null &&
          unknown.DisplayText.Contains("확인 전", StringComparison.Ordinal),
        $"Unmeasured viewport was mistaken for a fitting viewport: {preset}");
}
var expectedCounts = new[] { 1, 2, 6, 5 };
foreach (int count in Enumerable.Range(1, 4))
{
    var options = WorkspaceSplitLayoutEngine.GetPresetsForCount(count);
    Check(options.Count == expectedCounts[count - 1], $"Preset catalog count {count}");
    var visited = new HashSet<SplitLayoutPreset>();
    var current = options[0].Preset;
    for (int index = 0; index < options.Count; index++)
    {
        Check(visited.Add(current), $"Preset cycle repeats early: {count}");
        current = WorkspaceSplitLayoutEngine.CycleNextPreset(count, current);
    }
    Check(current == options[0].Preset, $"Preset cycle did not close: {count}");
    Check(WorkspaceSplitLayoutEngine.ParsePresetName("99", count) == WorkspaceSplitLayoutEngine.GetDefaultPreset(count),
        $"Undefined numeric saved preset accepted: {count}");
    Check(WorkspaceSplitLayoutEngine.NormalizePresetForCount(count, (SplitLayoutPreset)99) == WorkspaceSplitLayoutEngine.GetDefaultPreset(count),
        $"Undefined enum accepted: {count}");
}
foreach (var preset in presets)
{
    var bp = WorkspaceSplitLayoutEngine.BuildBlueprint(preset);
    var size = WorkspaceSplitLayoutEngine.GetMinimumWorkspaceSize(preset);
    Check(bp.Panes.Count == bp.PanelCount, $"Pane count: {preset}");
    Check(bp.Panes.Select(p => p.PaneIndex).Order().SequenceEqual(Enumerable.Range(0, bp.PanelCount)), $"Pane IDs: {preset}");
    for (int row = 0; row < bp.StarRows; row++)
        for (int col = 0; col < bp.StarColumns; col++)
            Check(bp.Panes.Count(p => p.Row <= row * 2 && row * 2 < p.Row + p.RowSpan &&
                p.Column <= col * 2 && col * 2 < p.Column + p.ColumnSpan) == 1, $"Gap/overlap: {preset} {row}/{col}");
    foreach (var pane in bp.Panes)
    {
        Check(pane.Row >= 0 && pane.Column >= 0 && pane.Row + pane.RowSpan <= bp.StarRows * 2 - 1 &&
            pane.Column + pane.ColumnSpan <= bp.StarColumns * 2 - 1, $"Pane outside grid: {preset}");
        int columns = (pane.ColumnSpan + 1) / 2, rows = (pane.RowSpan + 1) / 2;
        Check(columns * WorkspaceSplitLayoutEngine.MinimumPaneWidth + (columns - 1) * WorkspaceSplitLayoutEngine.SplitterThickness >= 350,
            $"Pane clips ExplorerPane width: {preset}");
        Check(rows * WorkspaceSplitLayoutEngine.MinimumPaneHeight + (rows - 1) * WorkspaceSplitLayoutEngine.SplitterThickness >= 340,
            $"Pane has no usable file viewport: {preset}");
    }
    foreach (var viewport in new[] { (300d, 220d), (686d, 340d), (1010d, 600d), (1520d, 930d) })
    {
        double width = Math.Max(size.Width, viewport.Item1 - 2), height = Math.Max(size.Height, viewport.Item2 - 2);
        Check(width >= bp.StarColumns * 350 + (bp.StarColumns - 1) * 11, $"Horizontal extent clips panes: {preset}");
        Check(height >= bp.StarRows * 340 + (bp.StarRows - 1) * 11, $"Vertical extent clips panes: {preset}");
    }
    Console.WriteLine($"PASS layout {preset}: {bp.PanelCount} panes, minimum {size.Width}x{size.Height}");
}
int transitions = 0;
foreach (var before in presets)
    foreach (var after in presets)
    {
        int previous = WorkspaceSplitLayoutEngine.GetPanelCountForPreset(before), next = WorkspaceSplitLayoutEngine.GetPanelCountForPreset(after);
        foreach (int active in Enumerable.Range(0, previous))
            foreach (bool userNavigation in new[] { false, true })
            {
                var preservation = WorkspaceSplitLayoutEngine.ResolveShrinkPreservation(previous, next, active, userNavigation);
                bool shouldSwap = next < previous && active >= next && userNavigation;
                Check(preservation.ShouldSwap == shouldSwap, $"Active pane loss: {before}->{after}/{active}");
                Check(preservation.SurvivingSlotIndex >= 0 && preservation.SurvivingSlotIndex < next, $"Invalid surviving slot: {before}->{after}");
            }
        transitions++;
    }
foreach (int count in Enumerable.Range(1, 4))
    foreach (int active in Enumerable.Range(0, count))
        foreach (int destination in Enumerable.Range(-1, count + 2))
        {
            int target = WorkspaceSplitLayoutEngine.ResolveOppositePaneIndex(count, active, destination);
            Check(count == 1 ? target == -1 : target >= 0 && target < count && target != active, "Transfer target points to the source/hidden pane.");
        }
foreach (double width in new[] { 350d, 480d, 640d, 1024d })
    foreach (double requested in new[] { 145d, 272d, 520d })
    {
        double nav = NavigationPanelPolicy.FitWidth(requested, width, false);
        Check(nav + NavigationPanelPolicy.RailWidth + NavigationPanelPolicy.MinimumFileAreaBudget <= width,
            "Pinned navigation clips the 176-DIP file-list budget.");
        Check(nav >= NavigationPanelPolicy.MinimumWidth, "Navigation rail was improperly hidden or collapsed.");
        if (width >= NavigationPanelPolicy.MaximumWidth + NavigationPanelPolicy.RailWidth + NavigationPanelPolicy.MinimumFileAreaBudget)
            Check(nav == Math.Min(requested, NavigationPanelPolicy.MaximumWidth),
            "Wide pane did not restore the user's preferred navigation width.");
    }
Console.WriteLine($"PASS: {passed} assertions; {presets.Length} layouts; {transitions} ordered preset transitions; production C# logic executed.");
Console.WriteLine("PENDING: Windows WPF mouse/keyboard, actual DPI, installer and packaged startup.");
