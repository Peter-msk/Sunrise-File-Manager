"""R05: responsive command hierarchy and button typography, no command loss."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

APP=Path(__file__).resolve().parents[1]/'Sunrise.FileManager'
MAIN=(APP/'MainWindow.xaml').read_text('utf-8')
CODE=(APP/'Features/Workspace/MainWindow.CommandOverflow.cs').read_text('utf-8')
STYLES=(APP/'App.xaml').read_text('utf-8')
NS='{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
X='{http://schemas.microsoft.com/winfx/2006/xaml}'

class AdaptiveShellContract(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.root=ET.fromstring(MAIN)
  cls.named={e.get(X+'Name'):e for e in cls.root.iter() if e.get(X+'Name')}

 def test_top_bands_stay_one_line_and_return_height(self):
  header=self.named['OfficialAShellHeader']
  rows=next(e for e in header if e.tag==NS+'Grid.RowDefinitions')
  self.assertEqual([r.get('Height') for r in rows],['38','42','40'])
  self.assertEqual(self.named['HeaderCommandViewport'].get('VerticalScrollBarVisibility'),'Disabled')
  self.assertEqual(self.named['HeaderCommandsContainer'].tag,NS+'Grid')

 def test_settings_is_global_not_inside_command_surface(self):
  parent={child:node for node in self.root.iter() for child in node}
  settings=[e for e in self.root.iter() if e.tag==NS+'MenuItem' and '설정 · 기능' in e.get('Header','')]
  self.assertEqual(len(settings),1)
  node=settings[0]
  while node in parent:
   node=parent[node]
   self.assertNotEqual(node,self.named['HeaderCommandsContainer'])

 def test_single_more_menu_and_mode_selection(self):
  self.assertIn('HeaderMoreMenuRoot',self.named)
  self.assertIn('HeaderMoreHost',self.named)
  self.assertEqual(self.named['HeaderMoreHost'].get('Visibility'),'Collapsed')
  for mode in ('ShellFilesActions','ShellDocumentsActions','ShellAiActions','ShellToolsActions'):
   self.assertIn(mode,self.named)
  self.assertIn('QueueShellCommandOverflow();',(APP/'Features/Workspace/MainWindow.OfficialAShell.cs').read_text())

 def test_primary_limit_and_width_driven_overflow(self):
  for contract in ('Math.Min(6, buttons.Length)', 'HeaderCommandsContainer.ActualWidth - 112',
                   'while (count > 1 && used > maxWidth)', 'button.Measure(',
                   'original.Visibility = Visibility.Collapsed',
                   'HeaderMoreMenuRoot.Items.Add(menuItem)',
                   'HeaderMoreHost.Visibility = HeaderMoreMenuRoot.Items.Count > 0',
                   'HeaderMoreMenuRoot.Items.Clear()'):
   self.assertIn(contract,CODE)
  self.assertIn('HeaderCommandsContainer.SizeChanged += (_, _) => QueueShellCommandOverflow();', (APP/'MainWindow.xaml.cs').read_text())

 def test_more_routes_existing_click_and_permission_gate(self):
  self.assertIn('original.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent, original))',CODE)
  self.assertIn('new Binding(nameof(Button.IsEnabled)) { Source = original }',CODE)
  self.assertIn('case "Redo": Redo_Click(this, args); break;', (APP/'Features/Explorer/ExplorerPane.OfficialAShell.cs').read_text())
  self.assertNotIn('File.Delete(',CODE)

 def test_primary_file_commands_are_six_plus_three_more(self):
  buttons=[e for e in self.named['ShellFilesActions'] if e.tag==NS+'Button']
  tags=[e.get('Tag') for e in buttons]
  self.assertEqual(tags[:6],['NewFolder','Rename','Copy','Paste','Delete','Filter'])
  self.assertEqual(tags[6:],['Cut','Undo','Redo'])
  self.assertTrue(all(e.get('Click')=='ShellCommand_Click' for e in buttons))

 def test_typography_and_button_sizes_share_tokens(self):
  self.assertIn('<Setter Property="MinHeight" Value="32"/><Setter Property="Padding" Value="13,5"/>',STYLES)
  self.assertIn('<Setter Property="Margin" Value="0,0,6,0"/><Setter Property="FontSize" Value="13"/>',STYLES)
  for filename in ['FileDetailsPanel.xaml','FileMemoPanel.xaml','FilePreviewPanel.xaml','FolderTree.xaml']:
   root=ET.parse(APP/'Controls'/filename).getroot()
   for button in root.iter(NS+'Button'):
    height=button.get('MinHeight')
    if height is not None:
     self.assertGreaterEqual(float(height),28,(filename,button.get('Content')))
    fontsize=button.get('FontSize')
    if fontsize is not None:
     self.assertGreaterEqual(float(fontsize),12,(filename,button.get('Content')))

 def test_every_xaml_button_has_usable_explicit_dimensions(self):
  files=list(APP.rglob('*.xaml'))
  checked=0
  for file in files:
   doc=ET.parse(file).getroot()
   for button in doc.iter():
    if button.tag not in (NS+'Button',NS+'ToggleButton',NS+'RepeatButton'):
     continue
    checked+=1
    for field in ('MinHeight','Height'):
     value=button.get(field)
     if value is not None:
      self.assertGreaterEqual(float(value),28,(file.name,button.get('Content'),field,value))
    fontsize=button.get('FontSize')
    if fontsize is not None:
     self.assertGreaterEqual(float(fontsize),12,(file.name,button.get('Content'),fontsize))
  self.assertGreaterEqual(len(files),15)
  self.assertGreaterEqual(checked,150)

 def test_small_panel_rows_fit_their_buttons(self):
  details=(APP/'Controls/FileDetailsPanel.xaml').read_text('utf-8')
  memo=(APP/'Controls/FileMemoPanel.xaml').read_text('utf-8')
  preview=(APP/'Controls/FilePreviewPanel.xaml').read_text('utf-8')
  self.assertIn('<RowDefinition Height="30"/><RowDefinition Height="30"/>',details)
  self.assertIn('<RowDefinition Height="30"/><RowDefinition Height="30"/>',memo)
  self.assertIn('<RowDefinition Height="28"/><RowDefinition Height="28"/>',preview)

 def test_shared_panels_and_split_engines_untouched(self):
  for tag in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
   self.assertEqual(len([e for e in self.root.iter() if e.tag.endswith("}"+tag)]),1)
  self.assertIn('Click="One_Click"',MAIN)
  self.assertIn('Click="Two_Click"',MAIN)
  self.assertNotIn('TransferToolbar',MAIN)
  self.assertTrue((APP.parent.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').exists())

if __name__=='__main__': unittest.main()
