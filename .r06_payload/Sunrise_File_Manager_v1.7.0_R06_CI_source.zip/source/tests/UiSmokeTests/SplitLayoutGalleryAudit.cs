using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Sunrise.FileManager;
using Sunrise.FileManager.Controls;
using Sunrise.FileManager.Services;

// Optional Windows UI gate: the actual count buttons open a menu with exact
// canonical blueprints, and selection—not opening—changes the workspace.
internal static class SplitLayoutGalleryAudit
{
    internal static int Assertions { get; private set; }
    private static void Check(bool condition, string message)
    {
        Assertions++;
        if (!condition) throw new Exception(message);
    }

    internal static void SelectPreset(MainWindow window, int count, SplitLayoutPreset preset)
    {
        var button = (Button)window.FindName(count switch
        {
            1 => "OneButton", 2 => "TwoButton", 3 => "ThreeButton", _ => "FourButton"
        });
        button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        if (count == 1)
        {
            Check(preset == SplitLayoutPreset.Single, "Unexpected single-view preset.");
            return;
        }
        ContextMenu menu = button.ContextMenu ?? throw new Exception("Split gallery missing.");
        var entry = menu.Items.OfType<MenuItem>().Single(item => item.Tag is SplitLayoutPreset p && p == preset);
        entry.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        menu.IsOpen = false;
    }

    internal static async Task RunAsync(MainWindow window, string output)
    {
        window.Width = 1520;
        window.Height = 930;
        var workspace = (Grid)window.FindName("Workspace");
        // Single applies immediately; 2/3/4 open exactly their own dropdown.
        var firstButton = (Button)window.FindName("TwoButton");
        firstButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        var firstPopup = firstButton.ContextMenu ?? throw new Exception("Two-pane popup missing.");
        Check(firstPopup.IsOpen, "Two-pane presets did not open as a dropdown.");
        var fourButton = (Button)window.FindName("FourButton");
        fourButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        Check(!firstPopup.IsOpen, "Old dropdown remains stacked under another button.");
        Check(fourButton.ContextMenu?.IsOpen == true, "Four-pane dropdown did not replace prior menu.");
        fourButton.ContextMenu!.IsOpen = false;
        ((Button)window.FindName("OneButton")).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        Check(workspace.Children.OfType<Grid>().Count() == 1, "Single button must apply immediately.");
        foreach (int count in new[] { 2, 3, 4 })
        {
            var button = (Button)window.FindName(count switch { 1 => "OneButton", 2 => "TwoButton", 3 => "ThreeButton", _ => "FourButton" });
            foreach (var option in WorkspaceSplitLayoutEngine.GetPresetsForCount(count))
            {
                int before = workspace.Children.OfType<Grid>().Count();
                button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                ContextMenu menu = button.ContextMenu ?? throw new Exception("No gallery.");
                Check(menu.IsOpen, "Split-count click did not open the gallery.");
                if (option.Preset == WorkspaceSplitLayoutEngine.GetDefaultPreset(count))
                {
                    await window.Dispatcher.InvokeAsync(window.UpdateLayout, DispatcherPriority.ContextIdle);
                    NativeUiRegression.CaptureDesktop(Path.Combine(output, $"split-layout-gallery-{count}.png"));
                }
                Check(workspace.Children.OfType<Grid>().Count() == before, "Opening the gallery changed the visible pane count.");
                var catalog = WorkspaceSplitLayoutEngine.GetPresetsForCount(count);
                Check(menu.Items.Count == catalog.Count, $"Wrong gallery option count for {count}.");
                var entries = menu.Items.OfType<MenuItem>().ToArray();
                Check(entries.All(item => item.Header is StackPanel presentation &&
                    presentation.Children.OfType<Grid>().Count() == 1), "Layout preview is missing.");
                Check(entries.Select(item => (SplitLayoutPreset)item.Tag).SequenceEqual(catalog.Select(x => x.Preset)),
                    "Gallery diverged from production layout catalog.");
                Check(entries.All(item => ((Grid)((StackPanel)item.Header).Children[0]).Children.OfType<Border>().Count() == count),
                    "Blueprint thumbnails do not reflect pane count.");
                Check(entries.All(item => ((StackPanel)item.Header).Children.OfType<TextBlock>().Count() == 1),
                    "Dropdown should show a single concise name beside each diagram.");
                Check(entries.All(item => item.ToolTip?.ToString()?.Length > 0),
                    "Workspace-fit details must remain in the item tooltip.");
                Check(menu.Placement == System.Windows.Controls.Primitives.PlacementMode.Bottom && ReferenceEquals(menu.PlacementTarget, button),
                    "Dropdown must open immediately below the clicked count button.");
                var requested = entries.Single(item => item.Tag is SplitLayoutPreset p && p == option.Preset);
                requested.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
                menu.IsOpen = false;
                await window.Dispatcher.InvokeAsync(window.UpdateLayout, DispatcherPriority.ContextIdle);
                Check(workspace.Children.OfType<Grid>().Count() == count, $"Selection did not apply {count}-pane layout.");
                var choices = (ComboBox)window.FindName("SplitPresetSelector");
                Check(choices.SelectedItem is ComboBoxItem selected && selected.Tag is SplitLayoutPreset actual && actual == option.Preset,
                    "Selected gallery preset and saved layout state disagree.");
                Check(window.FindName("FileDetails") is FileDetailsPanel && window.FindName("MemoPanel") is FileMemoPanel &&
                    window.FindName("PreviewPane") is FilePreviewPanel, "The shared right-hand utilities were replaced.");
            }
        }
        // Operations must not re-parent an active working pane in mid-transfer.
        var workField = typeof(MainWindow).GetField("_working",
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
            ?? throw new Exception("Working-state field missing.");
        bool previousWorking = (bool)workField.GetValue(window)!;
        try
        {
            workField.SetValue(window, true);
            var button = (Button)window.FindName("FourButton");
            int before = workspace.Children.OfType<Grid>().Count();
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            ContextMenu busyMenu = button.ContextMenu ?? throw new Exception("Busy gallery missing.");
            Check(busyMenu.Items.OfType<MenuItem>().All(item => !item.IsEnabled),
                "Busy operations must disable every layout command.");
            busyMenu.IsOpen = false;
            ((Button)window.FindName("OneButton")).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            Check(workspace.Children.OfType<Grid>().Count() == before,
                "Split count changed during an active file operation.");
        }
        finally { workField.SetValue(window, previousWorking); }
        // The earlier presets must survive changes in the visible count.
        SelectPreset(window, 3, SplitLayoutPreset.ThreeRows);
        SelectPreset(window, 4, SplitLayoutPreset.FourColumns);
        SelectPreset(window, 3, SplitLayoutPreset.ThreeRows);
        var selector = (ComboBox)window.FindName("SplitPresetSelector");
        Check(selector.SelectedItem is ComboBoxItem { Tag: SplitLayoutPreset.ThreeRows }, "Last selected 3-pane layout was lost.");
        File.WriteAllText(Path.Combine(output, "SPLIT_LAYOUT_GALLERY_RESULT.txt"), $"PASS assertions={Assertions}, menus=2/6/5, direct single, and all 14 approved layouts selected; Windows WPF interactive.\n");
        Console.WriteLine($"SPLIT_LAYOUT_GALLERY_PASS assertions={Assertions}");
    }
}
