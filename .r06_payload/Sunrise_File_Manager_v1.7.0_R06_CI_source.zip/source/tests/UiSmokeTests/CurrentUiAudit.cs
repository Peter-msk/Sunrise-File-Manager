using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Sunrise.FileManager;
using Sunrise.FileManager.Controls;
using Sunrise.FileManager.Models;
using Sunrise.FileManager.Services;

internal static class CurrentUiAudit
{
    internal static int Assertions { get; private set; }
    private static void Check(bool value, string name) { Assertions++; if (!value) throw new Exception(name); }
    private static void Click(FrameworkElement owner, string name)
    {
        if (owner is MainWindow window && name is ("TwoButton" or "ThreeButton" or "FourButton"))
        {
            int count = name switch { "TwoButton" => 2, "ThreeButton" => 3, _ => 4 };
            SplitLayoutGalleryAudit.SelectPreset(window, count, WorkspaceSplitLayoutEngine.GetDefaultPreset(count));
            return;
        }
        ((Button)owner.FindName(name)).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
    }
    private static async Task Until(Func<bool> condition, string name)
    { var end = DateTime.UtcNow.AddSeconds(15); while (!condition() && DateTime.UtcNow < end) await Task.Delay(40); Check(condition(), name); }
    internal static async Task RunSharedPanelsAsync(MainWindow window, string root, string output)
    {
        window.Width = 1520;
        window.Height = 930;
        SplitLayoutGalleryAudit.SelectPreset(window, 4, SplitLayoutPreset.FourGrid2x2);
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var workspace = (Grid)window.FindName("Workspace");
        var panes = workspace.Children.OfType<Grid>()
            .SelectMany(host => host.Children.OfType<ExplorerPane>()).ToArray();
        Check(panes.Length == 4, "The workspace should contain four explorer panes.");
        // These controls must have ONE authoritative owner, outside the individual ExplorerPane.
        Check(Descendants<FileDetailsPanel>(window).Count() == 1, "Duplicated detail panel.");
        Check(Descendants<FileMemoPanel>(window).Count() == 1, "Duplicated memo panel.");
        Check(Descendants<FilePreviewPanel>(window).Count() == 1, "Duplicated preview panel.");
        Check(panes.All(p => p.FindName("DetailsPanel") is null), "Legacy per-pane details still allocated.");
        var details = (FileDetailsPanel)window.FindName("FileDetails");
        var memo = (FileMemoPanel)window.FindName("MemoPanel");
        var preview = (FilePreviewPanel)window.FindName("PreviewPane");
        if (details.Visibility != Visibility.Visible) Click(window, "RailDetailsButton");
        if (memo.Visibility != Visibility.Visible) Click(window, "RailMemoButton");
        if (preview.Visibility != Visibility.Visible) Click(window, "MainPreviewButton");
        string[] files = [Path.Combine(root, "보고서.txt"), Path.Combine(root, "검토 메모.md")];
        for (int i = 0; i < files.Length; ++i)
        {
            var pane = panes[i];
            await pane.RevealFileAsync(files[i]);
            pane.FocusFiles();
            await Until(() => details.CurrentFilePath == files[i] &&
                memo.CurrentFilePath == files[i] && preview.CurrentFilePath == files[i],
                $"The shared panels did not follow pane {i + 1}.");
            Check(((TextBlock)window.FindName("ActivePaneIndicator")).Text == $"창 {i + 1}/4",
                "Shared panel owner indicator incorrect.");
        }
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "four-pane-shared-right-panels.png"));
        SplitLayoutGalleryAudit.SelectPreset(window, 1, SplitLayoutPreset.Single);
        Check(Descendants<FileDetailsPanel>(window).Count() == 1 &&
              Descendants<FileMemoPanel>(window).Count() == 1 &&
              Descendants<FilePreviewPanel>(window).Count() == 1,
              "Reducing panes must not allocate more right-hand panels.");
        Console.WriteLine($"SHARED_PANEL_UI_AUDIT_PASS assertions={Assertions}");
    }

    // Explicitly opt into the one-panel mode; legacy concurrent view remains supported.
    // This test is native WPF evidence and must not be marked PASS on non-Windows hosts.
    internal static async Task RunCompactShellAsync(MainWindow window, string output)
    {
        window.Width = 1010;
        window.Height = 560;
        Click(window, "FourButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var rootGrid = (Grid)window.Content;
        Check(rootGrid.RowDefinitions[0].ActualHeight is >= 118 and <= 122, "Official A brand/mode/action header exceeded its three fixed, single-line rows.");
        Check(rootGrid.RowDefinitions.Count == 3, "Removed transfer toolbar unexpectedly consumed a grid row.");
        var command = (ScrollViewer)window.FindName("HeaderCommandViewport");
        var rail = (ScrollViewer)window.FindName("UtilityRailViewport");
        Check(command.VerticalScrollBarVisibility == ScrollBarVisibility.Disabled &&
              rail.VerticalScrollBarVisibility == ScrollBarVisibility.Auto,
              "The command/rail scroll directions were changed.");
        var details = (FileDetailsPanel)window.FindName("FileDetails");
        var memo = (FileMemoPanel)window.FindName("MemoPanel");
        var preview = (FilePreviewPanel)window.FindName("PreviewPane");
        Check(Descendants<FileDetailsPanel>(window).Count() == 1 &&
              Descendants<FileMemoPanel>(window).Count() == 1 &&
              Descendants<FilePreviewPanel>(window).Count() == 1,
              "Right panels were duplicated in the four-pane mode.");
        Click(window, "RailSingleUtilityButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        Check(memo.Visibility == Visibility.Visible && details.Visibility == Visibility.Collapsed,
              "One-panel mode should keep the user's memo and reclaim detail width.");
        Click(window, "RailPreviewButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        Check(preview.Visibility == Visibility.Visible && memo.Visibility == Visibility.Collapsed &&
              ((Grid)window.FindName("FileAreaShell")).ColumnDefinitions[4].Width.Value == 0,
              "Selecting preview should free the memo column and divider.");
        Click(window, "RailDetailsButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        Check(details.Visibility == Visibility.Visible && preview.Visibility == Visibility.Collapsed,
              "Selecting details should free the preview column.");
        Check(((Grid)window.FindName("WorkspaceShell")).ColumnDefinitions[2].Width.Value == 0,
              "A hidden preview left a nonzero width.");
        Click(window, "RailSingleUtilityButton");
        Click(window, "RailMemoButton");
        Check(details.Visibility == Visibility.Visible && memo.Visibility == Visibility.Visible,
              "Disabling the optional mode must retain independent simultaneous panels.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "r02-compact-single-auxiliary.png"));
        Console.WriteLine($"R02_COMPACT_SHELL_UI_AUDIT_PASS assertions={Assertions}");
    }

    // R03 native gate: verify the compact per-pane shell really returns height to
    // the file list in four-way split, then restores ordinary geometry in one-way.
    // R04 native UI gate: right-side utilities stay in the workspace row and
    // pinned folder trees yield enough width for a meaningful file list.
    internal static async Task RunRightDockAndTreeBudgetAsync(MainWindow window, string output)
    {
        window.Width = 1010;
        window.Height = 560;
        Click(window, "FourButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var outer = (Grid)window.Content;
        var shell = (Grid)window.FindName("WorkspaceShell");
        var fileArea = (Grid)window.FindName("FileAreaShell");
        var details = (FileDetailsPanel)window.FindName("FileDetails");
        var memo = (FileMemoPanel)window.FindName("MemoPanel");
        var preview = (FilePreviewPanel)window.FindName("PreviewPane");
        Check(Grid.GetRow(shell) == 1 && Grid.GetRowSpan(shell) == 1,
            "Auxiliary shell moved below the file workspace.");
        Check(Grid.GetColumn(fileArea) == 0 &&
              Grid.GetColumn(details) == 2 && Grid.GetColumn(memo) == 4 &&
              Grid.GetColumn(preview) == 2,
            "Detail/preview/memo ownership is not on the right side.");
        Check(ReferenceEquals(details.Parent, fileArea) &&
              ReferenceEquals(memo.Parent, fileArea) &&
              ReferenceEquals(preview.Parent, shell),
            "One of the right-hand utilities was reparented into a split pane or footer.");
        Check(Descendants<FileDetailsPanel>(window).Count() == 1 &&
              Descendants<FileMemoPanel>(window).Count() == 1 &&
              Descendants<FilePreviewPanel>(window).Count() == 1,
            "Multiple instances of a shared right-side utility.");
        var workspace = (Grid)window.FindName("Workspace");
        var panes = workspace.Children.OfType<Grid>()
            .SelectMany(host => host.Children.OfType<ExplorerPane>()).ToArray();
        Check(panes.Length == 4, "Four-pane workspace missing panes.");
        foreach (var pane in panes)
        {
            var nav = (ColumnDefinition)pane.FindName("TreeColumn");
            var rail = (ColumnDefinition)pane.FindName("TreeDividerColumn");
            Check(nav.ActualWidth + rail.ActualWidth + 164 <= pane.ActualWidth + 2,
                "Pinned tree consumed too much file-list width in a narrow split.");
        }
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "r04-right-dock-four-split.png"));
        Console.WriteLine($"R04_RIGHT_DOCK_TREE_UI_AUDIT_PASS assertions={Assertions}");
    }

    internal static async Task RunPaneDensityAsync(MainWindow window, string output)
    {
        window.Width = 1010;
        window.Height = 560;
        Click(window, "FourButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var workspace = (Grid)window.FindName("Workspace");
        var panes = workspace.Children.OfType<Grid>()
            .SelectMany(host => host.Children.OfType<ExplorerPane>()).ToArray();
        Check(panes.Length == 4, "Four-way workspace did not create four explorers.");
        foreach (ExplorerPane pane in panes)
        {
            var tab = (RowDefinition)pane.FindName("TabRow");
            var address = (RowDefinition)pane.FindName("AddressRow");
            var breadcrumb = (RowDefinition)pane.FindName("BreadcrumbRow");
            var footer = (RowDefinition)pane.FindName("FooterRow");
            var filename = ((DataGrid)pane.FindName("FilesGrid")).Columns[1];
            Check(tab.Height.Value == 34 && breadcrumb.Height.Value == 24 && footer.Height.Value == 26,
                "Split pane retains oversized tab/breadcrumb/footer rows.");
            Check(address.Height.Value is 38 or 68,
                "Split pane address/search geometry does not follow the viewport width.");
            Check(filename.MinWidth is 145 or 190,
                "Filename hard minimum is invalid.");
            Check(((DataGrid)pane.FindName("FilesGrid")).ActualHeight >= 100,
                "Split pane lost its file list to fixed chrome.");
            Check(pane.FindName("BreadcrumbScroll") is ScrollViewer,
                "Narrow pane lost clickable path navigation.");
        }
        Check(Descendants<FileDetailsPanel>(window).Count() == 1 &&
              Descendants<FileMemoPanel>(window).Count() == 1 &&
              Descendants<FilePreviewPanel>(window).Count() == 1,
              "Four panes allocated duplicate right utilities.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "r03-four-pane-density.png"));
        SplitLayoutGalleryAudit.SelectPreset(window, 1, SplitLayoutPreset.Single);
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var first = panes[0];
        Check(((RowDefinition)first.FindName("TabRow")).Height.Value == 36 &&
              ((RowDefinition)first.FindName("FooterRow")).Height.Value == 30 &&
              ((DataGrid)first.FindName("FilesGrid")).Columns[1].MinWidth == 190,
              "Ordinary pane geometry was not restored after four-way split.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "r03-single-pane-restored.png"));
        Console.WriteLine($"R03_PANE_DENSITY_UI_AUDIT_PASS assertions={Assertions}");
    }

    internal static async Task RunAsync(MainWindow window, string root, string output)
    {
        var workspace = (Grid)window.FindName("Workspace");
        var pane = workspace.Children.OfType<Grid>().SelectMany(h => h.Children.OfType<ExplorerPane>()).First();
        var files = (DataGrid)pane.FindName("FilesGrid");
        await Until(() => files.Items.Count == 3, "Initial folder list failed.");
        var inspector = (FileMemoPanel)window.FindName("MemoPanel");
        var details = (FileDetailsPanel)window.FindName("FileDetails");
        var preview = (FilePreviewPanel)window.FindName("PreviewPane");
        string report = Path.Combine(root, "보고서.txt");
        await pane.RevealFileAsync(report);
        Check(((TextBlock)details.FindName("DetailName")).Text == "보고서.txt", "Inspector did not follow file selection.");
        var memo = (TextBox)inspector.FindName("MemoEditor"); memo.Text = "Current UI audit memo";
        Click(inspector, "SaveButton");
        Check(FileMemoStore.ListForFile(report).Single().Text == memo.Text, "Memo UI save failed.");
        await Until(() => pane.SelectedFile?.FullPath == report, "Memo refresh lost the selected file.");
        await Task.Delay(650);
        Check(pane.SelectedFile?.FullPath == report, "Watcher refresh lost the selected file.");
        Click(window, "MainPreviewButton");
        await Until(() => preview.IsVisible && preview.CurrentFilePath == report, "Independent preview did not follow selection.");
        Click(window, "MemoToggleButton");
        Check(!inspector.IsVisible && details.IsVisible && preview.IsVisible, "Memo toggle changed detail/preview.");
        Click(window, "MemoToggleButton");
        Check(inspector.IsVisible && details.IsVisible && preview.IsVisible, "Memo cannot reopen independently.");
        var detailToggle = (MenuItem)window.FindName("DetailsMenuItem");
        detailToggle.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        Check(!details.IsVisible && inspector.IsVisible && preview.IsVisible, "Detail toggle changed memo/preview.");
        detailToggle.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        Check(details.IsVisible && inspector.IsVisible, "Details cannot reopen independently.");
        var search = (TextBox)pane.FindName("SearchBox"); search.Text = "보고서";
        await Until(() => files.Items.Count == 1, "Current folder search failed.");
        search.Text = ""; await Until(() => files.Items.OfType<FileEntry>().Any(f => f.Name == "검토 메모.md"), "Clearing search failed.");
        await pane.RevealFileAsync(report);
        Click(pane, "RenameButton");
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle); window.UpdateLayout();
        var entry = files.SelectedItem as FileEntry;
        Check(entry?.IsRenaming == true, "Inline rename did not open.");
        entry!.RenameDraft = "보고서_검증";
        var editor = Descendants<TextBox>(files).First(t => t.Name == "InlineRenameEditor" && t.IsVisible);
        editor.RaiseEvent(new KeyEventArgs(Keyboard.PrimaryDevice, PresentationSource.FromVisual(editor), Environment.TickCount, Key.Enter) { RoutedEvent = Keyboard.PreviewKeyDownEvent });
        string renamed = Path.Combine(root, "보고서_검증.txt");
        await Until(() => File.Exists(renamed), "Inline rename failed or extension was lost.");
        Check(FileMemoStore.ListForFile(renamed).Single().Text == "Current UI audit memo", "Inline rename lost memo.");
        Click(pane, "UndoButton");
        await Until(() => File.Exists(report) && ((Button)pane.FindName("RedoButton")).IsEnabled, "Inline rename Undo failed.");
        // Exercise the actual WIC preview decode through file selection.
        string image = Path.Combine(root, "preview.png");
        var pixels = new byte[64 * 1024 * 4];
        for (int i = 0; i < pixels.Length; i += 4) { pixels[i] = 64; pixels[i + 1] = (byte)((i / 256) % 255); pixels[i + 2] = 192; pixels[i + 3] = 255; }
        var bitmap = BitmapSource.Create(64, 1024, 96, 96, PixelFormats.Bgra32, null, pixels, 64 * 4);
        using (var stream = File.Create(image)) { var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap)); encoder.Save(stream); }
        await pane.RevealFileAsync(image);
        await Until(() => ((Image)preview.FindName("PreviewImage")).Source is BitmapSource, "WIC image preview failed.");
        Check(files.Items.Count == 5 && files.Items.OfType<FileEntry>().Any(f => f.Name == "검토 자료"), "Revealing an in-page file hid earlier folder entries.");
        var decoded = (BitmapSource)((Image)preview.FindName("PreviewImage")).Source;
        Check(decoded.PixelWidth <= 1000 && decoded.PixelHeight <= 1500, "Preview exceeded decode budget.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "current-preview-light.png"));
        ((ComboBox)window.FindName("ThemeSelector")).SelectedIndex = 2;
        await Task.Delay(150); Check(ThemeManager.IsDark, "Dark theme menu failed.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "current-preview-dark.png"));
        ((ComboBox)window.FindName("ThemeSelector")).SelectedIndex = 1;
        var scale = (ComboBox)window.FindName("UiScaleSelector");
        scale.SelectedItem = scale.Items.OfType<ComboBoxItem>().Single(x => (int)x.Tag == 125);
        await Task.Delay(150); Check(UiScaleService.Percent == 125, "125% application scale failed.");
        window.UpdateLayout(); Check(files.ActualHeight > 100, "125% application scale lost file viewport.");
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "current-scale-125.png"));
        scale.SelectedItem = scale.Items.OfType<ComboBoxItem>().Single(x => (int)x.Tag == 80);
        Click(window, "AiToggleButton");
        await Until(() => Application.Current.Windows.OfType<Window>().Any(w => w != window && w.IsVisible && w.Content is AiCommandPanel), "Current AI popup did not open.");
        var popup = Application.Current.Windows.OfType<Window>().Single(w => w != window && w.IsVisible && w.Content is AiCommandPanel);
        NativeUiRegression.CaptureDesktop(Path.Combine(output, "current-ai-popup.png")); popup.Close();
        Check(window.IsVisible && !popup.IsVisible, "Closing AI popup affected main workspace.");
        Console.WriteLine($"CURRENT_UI_AUDIT_PASS assertions={Assertions}");
    }
    private static IEnumerable<T> Descendants<T>(DependencyObject parent) where T : DependencyObject
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        { var child = VisualTreeHelper.GetChild(parent, i); if (child is T t) yield return t; foreach (var nested in Descendants<T>(child)) yield return nested; }
    }
}
