using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Sunrise.FileManager;
using Sunrise.FileManager.Controls;
using Sunrise.FileManager.Services;

/// <summary>
/// Windows-only runtime / screenshot acceptance for the actual official A workspace shell.
/// Does not run during the normal company build or claim PASS before being executed.
/// </summary>
internal static class OfficialAShellAudit
{
    internal static int Assertions { get; private set; }
    private static void Check(bool condition, string message)
    {
        Assertions++;
        if (!condition) throw new InvalidOperationException(message);
    }

    internal static async Task RunAsync(MainWindow window, string output)
    {
        window.Width = 1520;
        window.Height = 930;
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();

        var header = (Grid)window.FindName("OfficialAShellHeader");
        var work = (Grid)window.FindName("WorkspaceShell");
        var commands = (ScrollViewer)window.FindName("HeaderCommandViewport");
        Check(header.RowDefinitions.Count == 3, "Official A brand/mode/action bands missing.");
        Check(header.ActualHeight >= 100 && header.ActualHeight <= 118,
            "Official A shell command area overflowed its designed compact height.");
        Check(commands.VerticalScrollBarVisibility == ScrollBarVisibility.Disabled &&
              commands.HorizontalScrollBarVisibility == ScrollBarVisibility.Auto,
            "Context actions must remain a single horizontal row.");
        // R05: compact top section + adaptive overflow. A narrow width must
        // retain EVERY command through More without adding a second row.
        var more = (MenuItem)window.FindName("HeaderMoreMenuRoot");
        var moreHost = (Border)window.FindName("HeaderMoreHost");
        var fileCommands = (StackPanel)window.FindName("ShellFilesActions");
        window.Width = 1010;
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
        window.UpdateLayout();
        Check(header.ActualHeight <= 104.5, "Compact A shell did not return its vertical space.");
        Check(moreHost.Visibility == Visibility.Visible && more.Items.Count >= 3,
            "Narrow-width command overflow lost secondary file operations.");
        Check(fileCommands.Children.OfType<Button>().Count(b => b.Visibility == Visibility.Visible) <= 6,
            "The main command row kept too many always-visible file actions.");
        Check(more.Items.OfType<MenuItem>().Any(m => m.Header?.ToString() == "잘라내기") &&
              more.Items.OfType<MenuItem>().Any(m => m.Header?.ToString() == "실행 취소") &&
              more.Items.OfType<MenuItem>().Any(m => m.Header?.ToString() == "다시 실행"),
            "The overflow menu omitted a basic Windows file command.");
        Capture(window, Path.Combine(output, "official-a-r05-command-overflow-1010.png"));
        window.Width = 1520;
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
        window.UpdateLayout();
        Check(VisualTreeHelper.GetParent(header) is Grid, "Official A header not hosted by the main shell.");
        Check(Descendants<FileDetailsPanel>(work).Count() == 1 &&
              Descendants<FileMemoPanel>(work).Count() == 1 &&
              Descendants<FilePreviewPanel>(work).Count() == 1,
            "Each right-hand utility must have exactly one instance.");

        foreach (var (modeButton, visibleCommands, name) in new[]
        {
            ("ShellFilesButton", "ShellFilesActions", "files"),
            ("ShellDocsButton", "ShellDocumentsActions", "documents"),
            ("ShellAiButton", "ShellAiActions", "ai"),
            ("ShellToolsButton", "ShellToolsActions", "tools")
        })
        {
            ((Button)window.FindName(modeButton)).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
            window.UpdateLayout();
            foreach (var candidate in new[] { "ShellFilesActions", "ShellDocumentsActions", "ShellAiActions", "ShellToolsActions" })
                Check(((StackPanel)window.FindName(candidate)).Visibility == (candidate == visibleCommands ? Visibility.Visible : Visibility.Collapsed),
                    "Switching to " + name + " did not isolate the correct command band: " + candidate);
            Check(work.ActualHeight > 400, "Switching shell mode discarded the file workspace height.");
            Capture(window, Path.Combine(output, "official-a-" + name + ".png"));
        }

        // Layout choice is still controlled by the already validated 14-presets engine.
        SplitLayoutGalleryAudit.SelectPreset(window, 4, SplitLayoutPreset.FourGrid2x2);
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        Check(Descendants<ExplorerPane>(work).Count() == 4,
            "Four-pane file workspace was replaced by shell mode commands.");
        Check(Descendants<FileMemoPanel>(work).Count() == 1,
            "Four-pane layout unexpectedly duplicated the memo system.");
        // R03: each of the four panes has a single flyout owning the same six real
        // File/Edit/View/Favorites/Extras/Info menus. Do not burn 36 DIP on each row.
        foreach (var pane in Descendants<ExplorerPane>(work))
        {
            var menu = (Menu)pane.FindName("PaneClassicMenu");
            var button = (Button)pane.FindName("PaneMoreButton");
            var flyout = button.ContextMenu;
            var menuRow = (RowDefinition)pane.FindName("PaneMenuRow");
            Check(menuRow.ActualHeight == 0 && menu.Visibility == Visibility.Collapsed,
                "A compact explorer still consumes height with a repeated classic menu.");
            Check(button.Visibility == Visibility.Visible && flyout is not null &&
                  flyout.Items.OfType<MenuItem>().Count() == 6 && menu.Items.Count == 0,
                "The per-pane advanced flyout lost or duplicated original menu groups.");
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
            Check(flyout!.IsOpen, "The compact pane's expert menu did not open on click.");
            flyout.IsOpen = false;
        }
        Capture(window, Path.Combine(output, "official-a-four-pane.png"));
        SplitLayoutGalleryAudit.SelectPreset(window, 1, SplitLayoutPreset.Single);
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);
        window.UpdateLayout();
        var restored = Descendants<ExplorerPane>(work).First();
        Check(((RowDefinition)restored.FindName("PaneMenuRow")).ActualHeight == 36 &&
              ((Menu)restored.FindName("PaneClassicMenu")).Items.OfType<MenuItem>().Count() == 6 &&
              ((Button)restored.FindName("PaneMoreButton")).Visibility == Visibility.Collapsed &&
              ((Button)restored.FindName("PaneMoreButton")).ContextMenu.Items.Count == 0,
            "Returning to a single pane did not restore the original full expert menus.");
        Capture(window, Path.Combine(output, "official-a-single-pane-menu-restored.png"));
        Console.WriteLine($"OFFICIAL_A_SHELL_UI_AUDIT_PASS assertions={Assertions}");
    }

    private static IEnumerable<T> Descendants<T>(DependencyObject root) where T : DependencyObject
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is T match) yield return match;
            foreach (var nested in Descendants<T>(child)) yield return nested;
        }
    }

    private static void Capture(FrameworkElement window, string target)
    {
        int width = Math.Max(1, (int)Math.Ceiling(window.ActualWidth));
        int height = Math.Max(1, (int)Math.Ceiling(window.ActualHeight));
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(window);
        var png = new PngBitmapEncoder();
        png.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = File.Create(target);
        png.Save(file);
    }
}
