"""R02 source contract for A-layout compact shell; Windows runtime validation remains required."""
from pathlib import Path
import unittest
from xml.etree import ElementTree as ET

APP = Path(__file__).resolve().parents[1] / "Sunrise.FileManager"
X = "{http://schemas.microsoft.com/winfx/2006/xaml}"

class CompactShellContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.xaml = (APP/"MainWindow.xaml").read_text(encoding="utf-8")
        cls.code = (APP/"MainWindow.xaml.cs").read_text(encoding="utf-8")
        cls.session = (APP/"Services/SessionStore.cs").read_text(encoding="utf-8")
        root=ET.fromstring(cls.xaml)
        cls.named={e.attrib[X+"Name"]:e for e in root.iter() if X+"Name" in e.attrib}

    def test_single_row_header_and_no_reintroduced_transfer_bar(self):
        widget=self.named['HeaderCommandViewport']
        self.assertTrue(widget.tag.endswith('}ScrollViewer'))
        self.assertEqual(widget.get('VerticalScrollBarVisibility'),'Disabled')
        self.assertEqual(widget.get('HorizontalScrollBarVisibility'),'Auto')
        self.assertTrue(any(c.tag.endswith('}StackPanel') and c.get('Orientation')=='Horizontal' and c.get(X+'Name')=='ShellFilesActions' for c in widget.iter()))
        self.assertTrue(any(c.tag.endswith('}StackPanel') and c.get('Orientation')=='Horizontal' and c.get(X+'Name')=='ShellDocumentsActions' for c in widget.iter()))
        self.assertNotIn('TransferCommandViewport',self.named)
        self.assertNotIn('TransferToolbarRow',self.named)
        self.assertNotIn('TransferToolbar',self.xaml)

    def test_right_rail_always_scrollable_for_small_height(self):
        rail=self.named["UtilityRailViewport"]
        self.assertEqual(rail.get("VerticalScrollBarVisibility"),"Auto")
        for name in ("RailDetailsButton","RailMemoButton","RailPreviewButton","RailAiButton","RailSingleUtilityButton"):
            self.assertIn(name,self.named)
        self.assertEqual(self.named["RailSingleUtilityButton"].get("Click"),"SingleUtilityPanel_Click")

    def test_single_view_is_explicit_and_preserves_legacy_mode(self):
        self.assertIn('_singleUtilityPanel = session.LayoutVersion >= 25 && session.SingleUtilityPanel;',self.code)
        self.assertIn('private void SingleUtilityPanel_Click(',self.code)
        self.assertIn('if (_singleUtilityPanel)',self.code)
        self.assertIn('LayoutVersion = 25,',self.code)
        self.assertIn('SingleUtilityPanel = _singleUtilityPanel,',self.code)
        self.assertIn('SingleUtilityActive = _lastUtilityPanel,',self.code)
        self.assertIn('public bool SingleUtilityPanel { get; set; }',self.session)
        self.assertIn('public string SingleUtilityActive { get; set; }',self.session)
        self.assertEqual(self.named["SingleUtilityMenuItem"].get("Click"),"SingleUtilityPanel_Click")

    def test_switch_away_from_unsaved_memo_can_be_cancelled(self):
        details=self.code.split('private void SetDetailsPanelVisible(bool visible)',1)[1].split('private void SetDockPreview',1)[0]
        preview=self.code.split('private void SetDockPreview(bool visible)',1)[1].split('private void UpdateToolRailVisuals',1)[0]
        for body in (details,preview):
            self.assertIn('SetMemoVisible(false); if (_memoOpen) return;',body)
        memo=self.code.split('private void SetMemoVisible(bool visible)',1)[1].split('private void SetDetailsPanelVisible',1)[0]
        self.assertIn('MemoPanel.ConfirmLeavingMemo()',memo)
        for name in ("MemoDividerColumn","DetailsPanelDividerColumn","PreviewDividerColumn"):
            self.assertIn(f'{name}.Width = visible ? new GridLength(11) : new GridLength(0)',self.code)

    def test_still_exactly_one_right_panel_of_each_kind(self):
        main=ET.fromstring(self.xaml)
        for kind in ("FileDetailsPanel","FileMemoPanel","FilePreviewPanel"):
            self.assertEqual(sum(e.tag.endswith('}'+kind) for e in main.iter()),1)
        for text in ('FileDetails.SelectFile(_panes[_activePane].SelectedFile)',
                     'MemoPanel.SelectFile(_panes[_activePane].SelectedFile)',
                     'PreviewPane.SelectFile(_panes[_activePane].SelectedFile)'):
            self.assertIn(text,self.code)

if __name__ == '__main__': unittest.main()
