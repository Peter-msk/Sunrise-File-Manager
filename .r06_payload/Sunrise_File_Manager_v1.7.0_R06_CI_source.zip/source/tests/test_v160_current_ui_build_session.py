"""Active v1.6.0 installation-contract regression replacing retired R03/R10/CS0165 assertions.
These tests are source-level only; Windows WPF and Setup gates remain independent.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / 'source/Sunrise.FileManager'
NS = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'

class CurrentProductContracts(unittest.TestCase):
    def test_single_right_docks_and_footer_separation(self):
        main = ET.parse(APP/'MainWindow.xaml').getroot()
        named = {n.get(X+'Name'): n for n in main.iter() if n.get(X+'Name')}
        self.assertEqual(named['WorkspaceShell'].get('Grid.Row'), '1')
        self.assertEqual(named['FileAreaShell'].get('Grid.Column'),'0')
        for name, parent_type in [('FileDetails','FileDetailsPanel'),('MemoPanel','FileMemoPanel'),('PreviewPane','FilePreviewPanel')]:
            self.assertEqual(sum(n.tag.endswith('}'+parent_type) for n in main.iter()),1)
            self.assertNotEqual(named[name].get('Grid.Row'), '2')
        self.assertEqual(named['PreviewPane'].get('Grid.Column'),'2')
        self.assertEqual(named['FileDetails'].get('Grid.Column'),'2')
        self.assertEqual(named['MemoPanel'].get('Grid.Column'),'4')

    def test_ai_independent_and_right_docks_follow_active_file(self):
        code = (APP/'MainWindow.xaml.cs').read_text()
        for needle in ('SyncMemo();','SyncDetailsPanel();','SyncDockPreview();',
                       'FileDetails.SelectFile(', 'MemoPanel.SelectFile(', 'PreviewPane.SelectFile('):
            self.assertIn(needle,code)
        self.assertNotIn('SyncInspector()',code)
        self.assertIn('AiPanel.CloseRequested += HideAiWindow', code)
        self.assertIn('Grid.Column="3"', (APP/'MainWindow.xaml').read_text())

    def test_theme_and_navigation_scroll(self):
        tree = ET.parse(APP/'Controls/FolderTree.xaml').getroot()
        self.assertEqual(len([n for n in tree.iter(NS+'ScrollViewer') if n.get('VerticalScrollBarVisibility') == 'Auto']),1)
        self.assertEqual(len(list(tree.iter(NS+'TreeView'))),1)
        theme = (APP/'App.xaml').read_text()
        for name in ('ThemeMenuText','ThemeMenuPopup','ThemeMenuHover','ThemeMenuSeparator'):
            self.assertIn(name,theme)

    def test_session_safety_and_migration(self):
        session = (APP/'Services/SessionStore.cs').read_text()
        main = (APP/'MainWindow.xaml.cs').read_text()
        pane = (APP/'Controls/ExplorerPane.xaml.cs').read_text()
        for name in ('ActivePane','WindowWidth','WindowHeight','WindowLeft','WindowTop','IsMaximized',
                     'InspectorVisible','InspectorWidth','MemoPanelVisible','DetailsPanelVisible','MemoPanelWidth',
                     'DetailsPanelWidth','PreviewWidth','ColumnWidths','SearchText','SortField','ColumnOrder'):
            self.assertIn(name,session)
        for name in ('InspectorDetailRatio','PreviewHeight','public bool DetailsVisible','public bool PreviewVisible'):
            self.assertNotIn(name,session)
        self.assertIn('session.LayoutVersion >= 23',main)
        self.assertIn('TrySaveSession(showError: true)',main)
        self.assertIn('TrySaveSession(showError: false)',main)
        self.assertIn('TabPaths = _tabs.Select(tab => tab.CurrentPath)',pane)
        self.assertIn('_tabs.Add(new ExplorerTab(path)',pane)
        self.assertIn('MemoPanel.ConfirmLeavingMemo()',main)

    def test_undo_redo_work_off_ui_thread_with_balanced_cleanup(self):
        code=(APP/'Controls/ExplorerPane.xaml.cs').read_text()
        for operation in ('UndoLast','RedoLast'):
            self.assertIn(f'await Task.Run(_undoService.{operation})',code)
        self.assertGreaterEqual(code.count('BlockingFileActionChanged?.Invoke(true)'),2)
        self.assertGreaterEqual(code.count('BlockingFileActionChanged?.Invoke(false)'),2)
        self.assertIn('finally { SetFileActionsEnabled(true); BlockingFileActionChanged?.Invoke(false); }',code)

    def test_new_window_keeps_current_utility_mode(self):
        code=(APP/'Features/Workspace/MainWindow.MultiWindow.cs').read_text()
        self.assertIn('LayoutVersion = 25',code)
        self.assertIn('SingleUtilityPanel = _singleUtilityPanel',code)
        self.assertIn('SingleUtilityActive = _lastUtilityPanel',code)
        self.assertIn('MemoPanelVisible = _memoOpen',code)
        self.assertIn('DetailsPanelVisible = _detailsOpen',code)

    def test_memostore_move_is_commit_then_cleanup(self):
        memo=(APP/'Services/FileMemoStore.cs').read_text()
        section=memo.split('public static void MoveFileWithMemos',1)[1].split('public static IReadOnlyList<MemoRecord> ListForFile',1)[0]
        self.assertLess(section.index('transferSnapshot.VerifySource()'),section.index('File.Move(source, destination);\n            movedFile = true;'))
        self.assertLess(section.index('transferSnapshot.VerifyDestination(destination)'),section.index('transferSnapshot.DeleteSource(destination'))
        self.assertIn('MemoTransferSnapshot.DiscardOwnedCopy',section)
        self.assertIn('File.Move(destination, source)',section)
        self.assertIn('if (unreadable > 0)',section)
        self.assertIn('if (File.Exists(targetMemo) || Directory.Exists(targetMemo))',section)

    def test_active_build_is_installer_and_preserves_ollama(self):
        self.assertTrue((ROOT/'COMPANY_SOURCE_ONLY.flag').exists())
        self.assertTrue((ROOT/'BUILD_ON_WINDOWS_COMPANY.cmd').exists())
        self.assertTrue((ROOT/'BUILD_RELEASE_INSTALLER.cmd').exists())
        self.assertFalse((ROOT/'BUILD_RELEASE_ONEFILE.cmd').exists())
        self.assertFalse((ROOT/'BUILD_DEV_FULL_SOURCE.cmd').exists())
        self.assertIn('--company',(ROOT/'BUILD_ON_WINDOWS_COMPANY.cmd').read_text())
        self.assertTrue((ROOT/'INSTALL_OLLAMA.cmd').exists())
        self.assertTrue((APP/'Services/AiOllamaService.cs').exists())

    def test_active_split_preset_buttons_use_theme_resources(self):
        code=(APP/'MainWindow.xaml.cs').read_text()
        start=code.index('private void ArrangePanels(int count)')
        end=code.index('private void AddPane(',start)
        method=code[start:end]
        self.assertIn('var choices = new[] { OneButton, TwoButton, ThreeButton, FourButton }',method)
        self.assertIn('choices[i].SetResourceReference(Control.BackgroundProperty',method)
        self.assertIn('UpdateWorkspaceLayout();',method)
        self.assertIn('RefreshSplitPresetSelectorUi(',method)

if __name__ == '__main__': unittest.main()
