"""R06 screenshot-driven shell finish. Source/contrast contract, not a Windows visual PASS."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import unittest

APP = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'
UI = ET.parse(APP / 'MainWindow.xaml').getroot()
RES = ET.parse(APP / 'App.xaml').getroot()
MAIN = (APP / 'MainWindow.xaml').read_text('utf-8')
CODE = (APP / 'MainWindow.xaml.cs').read_text('utf-8')
SHELL = (APP / 'Features/Workspace/MainWindow.OfficialAShell.cs').read_text('utf-8')
COLORS = (APP / 'Services/ThemeManager.cs').read_text('utf-8')
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'
N = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'


def contrast(a, b):
    def light(c):
        rgb = [int(c[i:i+2], 16)/255 for i in (1, 3, 5)]
        rgb = [x/12.92 if x <= 0.04045 else ((x+0.055)/1.055)**2.4 for x in rgb]
        return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2]
    high, low = sorted((light(a), light(b)), reverse=True)
    return (high+.05)/(low+.05)


class LightDarkShellFinish(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.named = {e.attrib[X+'Name']: e for e in UI.iter() if X+'Name' in e.attrib}
        cls.styles = {e.attrib[X+'Key']:e for e in RES.iter() if e.tag == N+'Style' and X+'Key' in e.attrib}
        cls.palette = {
            m[0]:(m[1],m[2]) for m in re.findall(r'\["(Theme\w+)"\]\s*=\s*\("(#[0-9A-Fa-f]{6})",\s*"(#[0-9A-Fa-f]{6})"\)', COLORS)
        }

    def test_three_shell_row_heights_allow_control_clearance(self):
        header = self.named['OfficialAShellHeader']
        rows = next(x for x in header if x.tag == N+'Grid.RowDefinitions')
        self.assertEqual([float(r.get('Height')) for r in rows], [38,42,40])
        # Minimum 32/34 DIP controls have 3 DIP padding and single divider clearance.
        for height, min_button in [(38,32),(42,34),(40,32)]:
            self.assertGreaterEqual(height, min_button+4)

    def test_light_header_and_rail_are_bright_and_dark_stays_dark(self):
        for key in ('ThemeShellBrand','ThemeShellBrandText','ThemeShellBrandMuted',
                    'ThemeUtilityRail','ThemeUtilityRailText','ThemeUtilityRailHover'):
            self.assertIn(key, self.palette)
        light_header, dark_header = self.palette['ThemeShellBrand']
        light_rail, dark_rail = self.palette['ThemeUtilityRail']
        self.assertGreater(contrast(light_header, '#101D30'), 12)
        self.assertGreater(contrast(light_rail, '#15344C'), 11)
        self.assertLess(int(dark_header[1:3], 16), 60)
        self.assertLess(int(dark_rail[1:3], 16), 60)
        self.assertGreaterEqual(contrast(light_header, self.palette['ThemeShellBrandText'][0]), 7)
        self.assertGreaterEqual(contrast(dark_header, self.palette['ThemeShellBrandText'][1]), 7)
        self.assertGreaterEqual(contrast(light_rail, self.palette['ThemeUtilityRailText'][0]), 4.5)
        self.assertGreaterEqual(contrast(dark_rail, self.palette['ThemeUtilityRailText'][1]), 4.5)
        self.assertGreaterEqual(contrast(self.palette['ThemeUtilityRailHover'][0], self.palette['ThemeUtilityRailText'][0]), 4.5)
        self.assertGreaterEqual(contrast(self.palette['ThemeUtilityRailHover'][1], self.palette['ThemeUtilityRailText'][1]), 4.5)

    def test_startup_brushes_match_light_palette(self):
        brushes = {e.attrib[X+'Key']:e.get('Color') for e in RES.iter()
                   if e.tag == N+'SolidColorBrush' and X+'Key' in e.attrib}
        for key in ('ThemeShellBrand','ThemeShellBrandText','ThemeShellBrandMuted',
                    'ThemeShellModeSurface','ThemeUtilityRail','ThemeUtilityRailText','ThemeUtilityRailHover'):
            self.assertEqual(brushes[key], self.palette[key][0], key)
        self.assertIn('brush.Color = color;', COLORS)

    def test_toolbar_buttons_share_height_font_and_adequate_spacing(self):
        for name, height, pad, margin in (
            ('ShellModeButton',34,'15,5','0,0,8,0'),
            ('ShellCommandButton',32,'13,5','0,0,6,0'),
            ('ShellSplitButton',34,'14,5','0,0,7,0')):
            setters = {s.get('Property'):s.get('Value') for s in self.styles[name] if s.tag==N+'Setter'}
            self.assertEqual(setters['MinHeight'], str(height), name)
            self.assertEqual(setters['Padding'], pad, name)
            self.assertEqual(setters['Margin'],margin,name)
            self.assertEqual(setters['FontSize'],'13',name)
        self.assertEqual(self.named['UiScaleSelector'].get('Style'), '{StaticResource ShellHeaderScale}')
        self.assertEqual(self.named['HeaderThemeButton'].get('Style'), '{StaticResource ShellHeaderButton}')
        for name in ('OneButton','TwoButton','ThreeButton','FourButton'):
            self.assertEqual(self.named[name].get('Style'), '{StaticResource ShellSplitButton}')
        self.assertIn('button.Measure(new Size(double.PositiveInfinity, 40));',
                      (APP/'Features/Workspace/MainWindow.CommandOverflow.cs').read_text('utf-8'))

    def test_hover_does_not_destroy_selected_contrast(self):
        self.assertIn('x:Key="ShellSelectableButtonTemplate"', (APP/'App.xaml').read_text('utf-8'))
        self.assertIn('Condition Property="Tag" Value="True"', MAIN)
        self.assertIn('button.Tag = active ? "True" : "False";', SHELL)
        self.assertIn('choices[i].Tag = selected ? "True" : "False";', CODE)
        self.assertIn('button.Tag = selected ? "True" : "False";', CODE)
        self.assertIn('RailSingleUtilityButton.Tag = _singleUtilityPanel ? "True" : "False";', CODE)
        self.assertGreaterEqual(contrast('#12678D','#FFFFFF'),4.5)
        self.assertGreaterEqual(contrast('#73D4F2','#10293B'),4.5)

    def test_right_rail_is_theme_local_not_folder_tree(self):
        self.assertEqual(sum(e.tag.endswith('}FileDetailsPanel') for e in UI.iter()),1)
        self.assertEqual(sum(e.tag.endswith('}FileMemoPanel') for e in UI.iter()),1)
        self.assertEqual(sum(e.tag.endswith('}FilePreviewPanel') for e in UI.iter()),1)
        rail=next(e for e in UI.iter() if e.get('Grid.Column')=='3'
                  and e.get('Background')=='{DynamicResource ThemeUtilityRail}')
        self.assertEqual(sum(e.tag==N+'Button' for e in rail.iter()),7)
        self.assertIn('"#EFF4F8", "#506984"', COLORS) # unchanged nav rail
        self.assertNotIn('TransferToolbar', MAIN)

    def test_no_loss_of_existing_fourteen_splits_or_preview_build(self):
        engine=(APP/'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text('utf-8')
        self.assertEqual(len(re.findall(r'new\(SplitLayoutPreset\.\w+,\s*[1-4],\s*"',engine)),14)
        self.assertEqual(self.named['OneButton'].get('Click'),'One_Click')
        for name in ('TwoButton','ThreeButton','FourButton'):
            self.assertTrue(self.named[name].get('Click'))
        self.assertTrue((APP.parent.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').exists())

if __name__=='__main__': unittest.main()
