"""Final A-layout source contract checks. Dynamic Windows WPF gate is separate."""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'Sunrise.FileManager'
MAIN=(ROOT/'MainWindow.xaml.cs').read_text('utf-8')
XAML=(ROOT/'MainWindow.xaml').read_text('utf-8')
GALLERY=(ROOT/'Features/Workspace/MainWindow.SplitLayoutGallery.cs').read_text('utf-8')
ENGINE=(ROOT/'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text('utf-8')
PREVIEW=(ROOT/'Controls/FilePreviewPanel.xaml.cs').read_text('utf-8')
X='{http://schemas.microsoft.com/winfx/2006/xaml}'

class UiFinalContract(unittest.TestCase):
    def test_single_direct_and_three_dropdowns_owned_by_main_window(self):
        root=ET.fromstring(XAML)
        one=next(x for x in root.iter() if x.attrib.get(X+'Name')=='OneButton')
        self.assertEqual(one.attrib['Content'],'단일')
        self.assertIn('단일 화면 즉시 적용',one.attrib.get('AutomationProperties.Name',''))
        self.assertIn('ApplyLastLayoutForCount(1);',MAIN)
        for count,name in enumerate(['TwoButton','ThreeButton','FourButton'],2):
            button=next(x for x in root.iter() if x.attrib.get(X+'Name')==name)
            self.assertIn('배치 목록',button.attrib.get('AutomationProperties.Name',''))
            self.assertIn('▾',button.attrib['Content'])
            self.assertIn(f'ShowSplitLayoutGallery({count}, {name})',MAIN)
        self.assertIn('PlacementTarget = anchor',GALLERY)
        self.assertIn('Placement = PlacementMode.Bottom',GALLERY)
        self.assertEqual(len(re.findall(r'new\(SplitLayoutPreset\.\w+,\s*[1-4],\s*"',ENGINE)),14)

    def test_menu_does_not_stack_across_buttons_or_change_layout_on_open(self):
        self.assertIn('private ContextMenu? _openSplitGalleryMenu;',GALLERY)
        self.assertIn('_openSplitGalleryMenu.IsOpen = false;',GALLERY)
        self.assertIn('menu.Closed +=',GALLERY)
        self.assertIn('anchor.ContextMenu = null;',GALLERY)
        method=GALLERY.split('private void ShowSplitLayoutGallery',1)[1].split('private FrameworkElement CreateSplitLayoutThumbnail',1)[0]
        self.assertEqual(method.count('ArrangePanels('),1)
        self.assertIn('item.Click += (_, _) =>',method)

    def test_ctrl_1_preview_zoom_and_memo_editor_do_not_trigger_split(self):
        self.assertIn('private bool CanRouteSplitShortcut(KeyEventArgs e)',MAIN)
        self.assertIn('PreviewPane.IsKeyboardFocusWithin',MAIN)
        self.assertIn('MemoPanel.IsKeyboardFocusWithin',MAIN)
        self.assertIn('Keyboard.FocusedElement is TextBoxBase or PasswordBox',MAIN)
        self.assertIn('else if (CanRouteSplitShortcut(e))',MAIN)
        self.assertIn('Key.D1 or Key.NumPad1',MAIN)
        self.assertRegex(PREVIEW,r'Key\.D1 or Key\.NumPad1')

    def test_header_scroll_access_preserves_leftmost_split_buttons(self):
        root=ET.fromstring(XAML)
        stack=next(x for x in root.iter() if x.attrib.get('Orientation')=='Horizontal' and {k.attrib.get(X+'Name') for k in x.iter()} >= {'OneButton','TwoButton','ThreeButton','FourButton'})
        self.assertIsNotNone(stack)
        # All four controls remain reachable within the same horizontally scrollable mode bar.
        split_scroller=next(x for x in root.iter() if x.tag.endswith('}ScrollViewer') and any(k.attrib.get(X+'Name')=='OneButton' for k in x.iter()))
        self.assertEqual(split_scroller.attrib.get('HorizontalScrollBarVisibility'),'Auto')
        self.assertEqual(split_scroller.attrib.get('VerticalScrollBarVisibility'),'Disabled')
        viewport=next(x for x in root.iter() if x.attrib.get(X+'Name')=='HeaderCommandViewport')
        self.assertEqual(viewport.attrib.get('HorizontalScrollBarVisibility'),'Auto')
        self.assertEqual(viewport.attrib.get('VerticalScrollBarVisibility'),'Disabled')

    def test_right_utilities_single_instance_and_footer_only_progress(self):
        root=ET.fromstring(XAML)
        for control,name in [('FileDetailsPanel','FileDetails'),('FileMemoPanel','MemoPanel'),('FilePreviewPanel','PreviewPane')]:
            nodes=[n for n in root.iter() if n.tag.endswith('}'+control)]
            self.assertEqual(len(nodes),1)
            self.assertEqual(nodes[0].attrib.get(X+'Name'),name)
            self.assertNotEqual(nodes[0].attrib.get('Grid.Row'),'2')
        self.assertEqual(len(re.findall(r'<GridSplitter[^>]*x:Name="(?:DetailsPanelSplitter|MemoSplitter|PreviewColumnSplitter)"',XAML)),3)
        self.assertIn('Grid.Row="2" Background="{DynamicResource ThemeStatus}"',XAML)

    def test_feature_boundary_preserves_safe_memo_and_tabs(self):
        self.assertIn('MemoPanel.ConfirmLeavingMemo()',MAIN)
        self.assertIn('SyncMemo();',MAIN)
        self.assertIn('SyncDetailsPanel();',MAIN)
        self.assertIn('SyncDockPreview();',MAIN)
        self.assertIn('SetMemoVisible(false)',MAIN)
        self.assertIn('CaptureWorkspaceRatios();',MAIN)
        self.assertIn('RestoreWorkspaceRatios();',(ROOT/'Features/Workspace/MainWindow.PanelCoordination.cs').read_text('utf-8'))

if __name__=='__main__': unittest.main()
