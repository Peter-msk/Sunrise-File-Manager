"""R06 current source-level UI contract; native WPF behavior is tested separately on Windows.
These checks do not claim that a C# compilation or WPF visual test succeeded.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1] / 'Sunrise.FileManager'


class GalleryFitAndSafety(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine = (ROOT/'Features/Workspace/WorkspaceSplitLayoutEngine.cs').read_text('utf-8')
        cls.gallery = (ROOT/'Features/Workspace/MainWindow.SplitLayoutGallery.cs').read_text('utf-8')
        cls.main = (ROOT/'MainWindow.xaml.cs').read_text('utf-8')
        cls.ui = (Path(__file__).parent/'UiSmokeTests/SplitLayoutGalleryAudit.cs').read_text('utf-8')
        cls.logic = (Path(__file__).parent/'SplitLayoutTests/Program.cs').read_text('utf-8')
        cls.xaml = ET.parse(ROOT/'MainWindow.xaml').getroot()

    def test_fit_policy_uses_canonical_minimum_extent_not_window_width(self):
        self.assertIn('GetMinimumWorkspaceSize(preset)', self.engine)
        self.assertIn('availableWidth + 1', self.engine)
        self.assertIn('availableHeight + 1', self.engine)
        self.assertIn('double.IsFinite(availableWidth)', self.engine)
        self.assertIn('double.IsFinite(availableHeight)', self.engine)
        self.assertIn('WorkspaceViewport.ViewportWidth', self.gallery)
        self.assertIn('WorkspaceViewport.ViewportHeight', self.gallery)
        self.assertIn('WorkspaceSplitLayoutEngine.AssessViewportFit(', self.gallery)
        self.assertNotIn('SystemParameters.WorkArea.Width - ', self.gallery)

    def test_fit_feedback_does_not_disable_overflowing_approved_layouts(self):
        self.assertIn('가로·세로 스크롤 필요', self.engine)
        self.assertIn('가로 스크롤 필요', self.engine)
        self.assertIn('세로 스크롤 필요', self.engine)
        self.assertIn('창 크기 확인 전', self.engine)
        self.assertIn('ToolTip = $"{choice.Description}\\n{fit.DisplayText}"', self.gallery)
        self.assertIn('IsEnabled = canApply', self.gallery)
        self.assertNotIn('IsEnabled = !fit.NeedsHorizontalScroll', self.gallery)

    def test_busy_state_blocks_every_user_and_hidden_layout_route(self):
        self.assertIn('!_working && !_aiBusy && _activeRecycleJobs == 0', self.gallery)
        self.assertIn('if (!CanChangeSplitLayout) return;', self.gallery)
        self.assertIn('if (_layoutInitialized && !CanChangeSplitLayout) return;', self.main)
        self.assertIn('Keyboard.Modifiers != ModifierKeys.Control || !CanChangeSplitLayout', self.main)
        self.assertIn('else if (CanRouteSplitShortcut(e))', self.main)
        self.assertIn('if (CanChangeSplitLayout) ArrangePanels(normalized, requestedPreset);', self.gallery)
        self.assertIn('busyMenu.Items.OfType<MenuItem>().All(item => !item.IsEnabled)', self.ui)

    def test_focus_and_screen_readers_have_descriptions(self):
        self.assertIn('menu.Opened +=', self.gallery)
        self.assertIn('focus?.Focus();', self.gallery)
        self.assertIn('AutomationProperties.SetName(item,', self.gallery)
        self.assertIn('fit.DisplayText}', self.gallery)
        self.assertNotIn('labels.Children.Add(fitNote)', self.gallery)

    def test_all_fourteen_presets_covered_by_compiled_logic_suite(self):
        self.assertIn('foreach (SplitLayoutPreset preset in presets)', self.logic)
        for phrase in ('fits.NeedsHorizontalScroll == false',
                       'cramped.NeedsVerticalScroll == true',
                       'horizontal.NeedsVerticalScroll == false',
                       'vertical.NeedsHorizontalScroll == false',
                       'unknown.NeedsHorizontalScroll is null'):
            self.assertIn(phrase, self.logic)

    def test_shared_utilities_remain_right_of_workspace_and_footer_only_tracks_jobs(self):
        ns = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
        all_controls = list(self.xaml.iter())
        for name in ('FileDetailsPanel', 'FileMemoPanel', 'FilePreviewPanel'):
            self.assertEqual(sum(el.tag == '{clr-namespace:Sunrise.FileManager.Controls}'+name for el in all_controls),1)
        shell = next(el for el in all_controls if el.attrib.get('{http://schemas.microsoft.com/winfx/2006/xaml}Name') == 'WorkspaceShell')
        self.assertEqual(shell.attrib.get('Grid.Row'),'1')
        self.assertIn('Grid.Row="2"', (ROOT/'MainWindow.xaml').read_text('utf-8'))

if __name__ == '__main__': unittest.main()
