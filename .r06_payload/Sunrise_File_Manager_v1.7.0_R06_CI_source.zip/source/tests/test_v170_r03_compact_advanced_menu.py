"""Official A R03: move, don't duplicate, all per-pane expert commands in 2-4 splits."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'Sunrise.FileManager'
NS = '{http://schemas.microsoft.com/winfx/2006/xaml}'
UI = (APP / 'Controls/ExplorerPane.xaml').read_text('utf-8')
CORE = (APP / 'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
VIEW = (APP / 'Features/Explorer/ExplorerPane.ViewAndFiltering.cs').read_text('utf-8')
CODE = (APP / 'Features/Explorer/ExplorerPane.OfficialACompactMenu.cs').read_text('utf-8')

class OfficialACompactExpertMenu(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = ET.fromstring(UI)
        cls.named = {e.get(NS + 'Name'):e for e in cls.root.iter() if e.get(NS + 'Name')}

    def test_main_menu_remains_single_with_all_six_real_function_groups(self):
        menu = self.named['PaneClassicMenu']
        children = [e for e in menu if e.tag.endswith('}MenuItem')]
        self.assertEqual(len(children), 6)
        for name in ('FileCommandMenu','EditCommandMenu','EiassCommandMenuItem'):
            self.assertIn(name,self.named)
        for command in ('EiassRename_Click','ConnectDrive_Click','PasswordExtract_Click',
                        'OcrRead_Click','MetadataEdit_Click','DetailColumn_Click','Recycle_Click'):
            self.assertIn(command,UI)
        self.assertNotIn('Click=""',UI)

    def test_compact_flyout_located_in_tab_with_keyboard_automation_name(self):
        button = self.named['PaneMoreButton']
        self.assertEqual(button.get('Grid.Column'), '4')
        self.assertEqual(button.get('Click'), 'PaneMore_Click')
        self.assertEqual(button.get('Visibility'), 'Collapsed')
        self.assertIn('고급 명령', button.get('ToolTip'))
        self.assertEqual(self.named['PaneMoreContextMenu'].get('StaysOpen'), 'False')
        self.assertEqual(self.named['PaneMenuRow'].get('Height'), '36')

    def test_compact_uses_original_instances_and_restores_order_no_duplicates(self):
        self.assertIn('while (PaneClassicMenu.Items.Count > 0)', CODE)
        self.assertIn('PaneClassicMenu.Items.RemoveAt(0)', CODE)
        self.assertIn('PaneMoreContextMenu.Items.Add(command)', CODE)
        self.assertIn('while (PaneMoreContextMenu.Items.Count > 0)', CODE)
        self.assertIn('PaneMoreContextMenu.Items.RemoveAt(0)', CODE)
        self.assertIn('PaneClassicMenu.Items.Add(command)', CODE)
        self.assertIn('_advancedMenuInFlyout != compact', CODE)
        self.assertIn('PaneMoreContextMenu.IsOpen = false', CODE)
        self.assertNotIn('new MenuItem', CODE)

    def test_tab_reclaims_menu_height_for_all_multi_pane_arrangements(self):
        self.assertIn('PaneMenuRow.Height = new GridLength(compact ? 0 : 36)', CODE)
        self.assertIn('PaneClassicMenu.Visibility = compact ? Visibility.Collapsed : Visibility.Visible', CODE)
        self.assertIn('PaneMoreButton.Visibility = compact ? Visibility.Visible : Visibility.Collapsed', CODE)
        self.assertIn('ApplyCompactMenuMode(_compactMode)', CORE)
        self.assertIn('ApplyCompactMenuMode(compact)', VIEW)

    def test_no_change_to_existing_common_right_utilities_and_build(self):
        main = (APP / 'MainWindow.xaml').read_text('utf-8')
        for component in ('FileDetailsPanel','FileMemoPanel','FilePreviewPanel'):
            self.assertEqual(main.count('<local:'+component),1)
        self.assertTrue((ROOT.parent/'BUILD_PREVIEW_ON_WINDOWS.cmd').exists())
        self.assertTrue((ROOT.parent/'BUILD_ON_WINDOWS_COMPANY.cmd').exists())

if __name__ == '__main__': unittest.main()
