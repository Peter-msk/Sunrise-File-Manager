"""A-layout focused static regression. Does not claim Windows WPF runtime validation."""
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1] / "Sunrise.FileManager"
X = "{http://schemas.microsoft.com/winfx/2006/xaml}"


class LayoutAContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.xaml = (ROOT / "MainWindow.xaml").read_text(encoding="utf-8")
        cls.main = (ROOT / "MainWindow.xaml.cs").read_text(encoding="utf-8")
        cls.session = (ROOT / "Services/SessionStore.cs").read_text(encoding="utf-8")
        cls.tree = ET.fromstring(cls.xaml)
        cls.named = {node.attrib[X + "Name"]: node for node in cls.tree.iter() if X + "Name" in node.attrib}

    def test_right_utility_rail_is_actionable_and_independent(self):
        rail_labels = ["RailDetailsButton", "RailMemoButton", "RailPreviewButton", "RailAiButton"]
        for name in rail_labels:
            self.assertIn(name, self.named)
            self.assertIn("Click", self.named[name].attrib)
        for click in ["DetailsPanelToggle_Click", "MemoToggle_Click", "MainPreview_Click", "AiToggle_Click", "RecoveryJournal_Click", "FocusWorkspace_Click"]:
            self.assertRegex(self.xaml, f'Click="{click}"')
        self.assertIn('Grid.Column="3"', self.xaml)
        self.assertIn('Width="54"', self.xaml)

    def test_collapsed_panels_release_both_column_and_divider(self):
        for suffix, column in [("Memo", "MemoColumn"), ("Details", "DetailsPanelColumn"), ("Preview", "PreviewColumn")]:
            self.assertIn(f'{column}.Width = visible ? new GridLength', self.main)
        for name in ["MemoDividerColumn", "DetailsPanelDividerColumn", "PreviewDividerColumn"]:
            self.assertIn(f'{name}.Width = visible ? new GridLength(11) : new GridLength(0)', self.main)
        self.assertIn('if (_memoOpen) return; // User canceled', self.main)
        self.assertIn('MemoPanel.ConfirmLeavingMemo()', self.main)

    def test_legacy_transfer_toolbar_is_removed_and_file_operations_remain(self):
        self.assertNotIn('TransferToolbar',self.xaml)
        self.assertNotIn('TransferBarButton',self.xaml)
        self.assertNotIn('TransferToolbarRow',self.xaml)
        self.assertNotIn('TransferBarToggle_Click',self.main)
        self.assertIn('RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, source, target)',self.main)
        self.assertIn('RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, pane, pane)',self.main)
        self.assertIn('Click="SwapPanes_Click"',self.xaml)
        self.assertIn('Click="SyncPanes_Click"',self.xaml)

    def test_preserves_preexisting_panel_and_session_behavior(self):
        self.assertIn('session.LayoutVersion >= 23 ? session.MemoPanelVisible', self.main)
        self.assertIn('session.LayoutVersion >= 23 ? session.DetailsPanelVisible', self.main)
        self.assertIn('LayoutVersion = 25', self.main) # v1.6.0 R02 stores the optional single-utility preference
        self.assertIn('SetDetailsPanelVisible(_detailsOpen);', self.main)
        self.assertIn('SetMemoVisible(_memoOpen);', self.main)
        self.assertIn('SetDockPreview(_dockPreviewOpen);', self.main)
        self.assertNotIn('SourceSelector.Items.Add', self.main)
        self.assertIn('ApplyBlueprintToWorkspace(blueprint)', self.main)
        self.assertIn('WorkspaceSplitLayoutEngine.BuildBlueprint', self.main)

    def test_all_new_xaml_click_handlers_exist(self):
        code = self.main + '\n' + '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT / 'Features/Workspace').glob('MainWindow.*.cs'))
        for name in ['RailDetailsButton', 'RailMemoButton', 'RailPreviewButton', 'RailAiButton']:
            node = self.named[name]
            self.assertRegex(code, r'\b' + re.escape(node.get('Click','')) + r'\s*\(')
        for click in ['FocusWorkspace_Click', 'RecoveryJournal_Click']:
            self.assertRegex(code, r'\b' + click + r'\s*\(')


if __name__ == '__main__':
    unittest.main()
