using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Sunrise.FileManager;

/// <summary>
/// Official A-layout workspace command surface. UI modes change only the command
/// shortcuts. They never replace/clear files, tabs, selections or memo state.
/// A command always targets the single active ExplorerPane.
/// </summary>
public partial class MainWindow
{
    private string _shellMode = "Files";

    private void ShellFiles_Click(object sender, RoutedEventArgs e) => SetShellMode("Files");
    private void ShellDocuments_Click(object sender, RoutedEventArgs e) => SetShellMode("Documents");
    private void ShellAi_Click(object sender, RoutedEventArgs e) => SetShellMode("Ai");
    private void ShellTools_Click(object sender, RoutedEventArgs e) => SetShellMode("Tools");

    private void SetShellMode(string mode)
    {
        _shellMode = mode is "Documents" or "Ai" or "Tools" ? mode : "Files";
        ShellFilesActions.Visibility = _shellMode == "Files" ? Visibility.Visible : Visibility.Collapsed;
        ShellDocumentsActions.Visibility = _shellMode == "Documents" ? Visibility.Visible : Visibility.Collapsed;
        ShellAiActions.Visibility = _shellMode == "Ai" ? Visibility.Visible : Visibility.Collapsed;
        ShellToolsActions.Visibility = _shellMode == "Tools" ? Visibility.Visible : Visibility.Collapsed;
        foreach (var (button, id) in new[]
        {
            (ShellFilesButton, "Files"),
            (ShellDocsButton, "Documents"),
            (ShellAiButton, "Ai"),
            (ShellToolsButton, "Tools")
        })
        {
            bool active = _shellMode == id;
            button.SetResourceReference(Control.BackgroundProperty, active ? "ThemeSplitActive" : "ThemeShellModeSurface");
            button.SetResourceReference(Control.ForegroundProperty, active ? "ThemeSplitActiveText" : "TextPrimary");
            button.Tag = active ? "True" : "False";
            button.FontWeight = active ? FontWeights.Bold : FontWeights.SemiBold;
        }
        // Swapping panels must not retain a stale horizontal offset from another mode.
        HeaderCommandViewport.ScrollToHorizontalOffset(0);
        QueueShellCommandOverflow();
    }

    private void ShellCommand_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string command }) return;
        if (_working || _aiBusy || _activeRecycleJobs > 0) return;
        if (_activePane < 0 || _activePane >= _visiblePanels) return;
        _panes[_activePane]?.ExecuteOfficialAShellCommand(command);
    }
}
