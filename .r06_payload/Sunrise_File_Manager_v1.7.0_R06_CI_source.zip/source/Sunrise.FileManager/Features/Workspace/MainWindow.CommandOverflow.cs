using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Threading;

namespace Sunrise.FileManager;

/// <summary>
/// Owns the compact A-shell command bar. Only secondary shortcuts disappear from
/// the bar: every command stays accessible in the live overflow menu, using its
/// original Click handler. No file operation or per-pane command is reimplemented.
/// </summary>
public partial class MainWindow
{
    private bool _commandOverflowQueued;
    private bool _commandOverflowUpdating;

    private StackPanel CurrentShellActions => _shellMode switch
    {
        "Documents" => ShellDocumentsActions,
        "Ai" => ShellAiActions,
        "Tools" => ShellToolsActions,
        _ => ShellFilesActions
    };

    private void QueueShellCommandOverflow()
    {
        if (_commandOverflowQueued || Dispatcher.HasShutdownStarted || Dispatcher.HasShutdownFinished) return;
        _commandOverflowQueued = true;
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
        {
            _commandOverflowQueued = false;
            UpdateShellCommandOverflow();
        }));
    }

    private void UpdateShellCommandOverflow()
    {
        if (_commandOverflowUpdating || !IsLoaded || HeaderCommandsContainer.ActualWidth <= 0) return;
        _commandOverflowUpdating = true;
        try
        {
            var buttons = CurrentShellActions.Children.OfType<Button>().ToArray();
            if (buttons.Length == 0) return;

            // Measure intrinsic button widths, including previously collapsed
            // buttons. Restoring the old state before applying the final layout
            // keeps repeated resizing deterministic and never stores user widths.
            var widths = new double[buttons.Length];
            for (int i = 0; i < buttons.Length; i++)
            {
                var button = buttons[i];
                var before = button.Visibility;
                button.Visibility = Visibility.Visible;
                button.Measure(new Size(double.PositiveInfinity, 40));
                widths[i] = Math.Max(button.DesiredSize.Width, button.MinWidth) + 2;
                button.Visibility = before;
            }

            // Files: the first six high-frequency commands are candidates for
            // direct display. Cut/Undo/Redo are always available under More.
            int count = _shellMode == "Files" ? Math.Min(6, buttons.Length) : buttons.Length;
            double maxWidth = Math.Max(0, HeaderCommandsContainer.ActualWidth - 112);
            double used = widths.Take(count).Sum();
            while (count > 1 && used > maxWidth)
            {
                used -= widths[--count];
            }

            HeaderMoreMenuRoot.Items.Clear();
            for (int i = 0; i < buttons.Length; i++)
            {
                Button original = buttons[i];
                if (i < count)
                {
                    original.Visibility = Visibility.Visible;
                    continue;
                }
                original.Visibility = Visibility.Collapsed;
                var menuItem = new MenuItem
                {
                    Header = original.Content,
                    ToolTip = original.ToolTip,
                    Tag = original.Tag
                };
                menuItem.SetBinding(MenuItem.IsEnabledProperty,
                    new Binding(nameof(Button.IsEnabled)) { Source = original });
                // Raise the original control's Click route so native WPF command
                // owners keep the exact same permission and safety gates.
                menuItem.Click += (_, _) =>
                {
                    if (original.IsEnabled)
                        original.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent, original));
                };
                HeaderMoreMenuRoot.Items.Add(menuItem);
            }
            HeaderMoreHost.Visibility = HeaderMoreMenuRoot.Items.Count > 0
                ? Visibility.Visible : Visibility.Collapsed;
            HeaderCommandViewport.ScrollToHorizontalOffset(0);
        }
        finally
        {
            _commandOverflowUpdating = false;
        }
    }
}
