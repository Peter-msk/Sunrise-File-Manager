using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Sunrise.FileManager.Controls;

/// <summary>
/// Official A: one compact advanced-command flyout per explorer pane.
/// The original MenuItem instances (and all their bound event handlers) move intact;
/// no duplicated commands, lost submenus, or altered per-pane file-operation owner.
/// In a single pane the classic File/Edit/View menu is restored as before.
/// </summary>
public partial class ExplorerPane
{
    private bool _advancedMenuInFlyout;

    private void ApplyCompactMenuMode(bool compact)
    {
        if (PaneClassicMenu is null || PaneMoreButton is null || PaneMoreContextMenu is null)
            return;

        if (_advancedMenuInFlyout != compact)
        {
            // Never reparent menu items while a context menu is open.
            PaneMoreContextMenu.IsOpen = false;
            if (compact)
            {
                while (PaneClassicMenu.Items.Count > 0)
                {
                    var command = PaneClassicMenu.Items[0];
                    PaneClassicMenu.Items.RemoveAt(0);
                    PaneMoreContextMenu.Items.Add(command);
                }
            }
            else
            {
                while (PaneMoreContextMenu.Items.Count > 0)
                {
                    var command = PaneMoreContextMenu.Items[0];
                    PaneMoreContextMenu.Items.RemoveAt(0);
                    PaneClassicMenu.Items.Add(command);
                }
            }
            _advancedMenuInFlyout = compact;
        }

        PaneMenuRow.Height = new GridLength(compact ? 0 : 36);
        PaneClassicMenu.Visibility = compact ? Visibility.Collapsed : Visibility.Visible;
        PaneMoreButton.Visibility = compact ? Visibility.Visible : Visibility.Collapsed;
    }

    private void PaneMore_Click(object sender, RoutedEventArgs e)
    {
        if (!_advancedMenuInFlyout || PaneMoreContextMenu.Items.Count == 0)
            return;
        PaneMoreContextMenu.PlacementTarget = PaneMoreButton;
        PaneMoreContextMenu.Placement = PlacementMode.Bottom;
        PaneMoreContextMenu.IsOpen = true;
    }
}
