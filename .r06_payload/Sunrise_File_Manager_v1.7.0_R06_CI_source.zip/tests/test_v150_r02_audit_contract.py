"""Source-audit guards. These do not replace dotnet or Windows runtime validation."""
from pathlib import Path
import json
import unittest
from current_contract import CURRENT_VERSION
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'

class FinalSourceAudit(unittest.TestCase):
    def text(self, name):
        return (APP / name).read_text(encoding='utf-8')

    def test_transfer_recovery_no_local_parameter_shadow(self):
        s = self.text('Services/TransferRecoveryJournal.cs')
        self.assertIn('bool isDirectory = Directory.Exists(path);', s)
        self.assertNotIn('bool directory = Directory.Exists(path);', s)
        self.assertIn('plan.Kind is not (TransferKind.Copy or TransferKind.Move)', s)
        self.assertIn('HasBlockedAncestor(source.Path)', s)
        self.assertIn('HasBlockedAncestor(plan.Destination)', s)
        self.assertIn('plan.Sources is null', s)

    def test_zip_checks_cover_content_not_just_names(self):
        s = self.text('Services/ZipEditService.cs')
        for key in ('ArchiveService.List(original, token)', 'item.Encrypted',
                    'ValidateEntry(entry.FullName', 'GetHashAndReset()',
                    'SHA256.HashData(input)', 'File.Replace(staging, original, backup)',
                    'Operation.Remove', 'token.ThrowIfCancellationRequested()',
                    'FileActionsService.ValidateName(part)'):
            self.assertIn(key, s)
        self.assertNotIn('Process.Start(', s)

    def test_shellnew_does_not_follow_junction(self):
        s = self.text('Services/ShellNewTemplateService.cs')
        self.assertIn('parent = parent.Parent', s)
        self.assertIn('ReparsePointPolicy.IsBlocked(parent.FullName', s)

    def test_query_rejects_unclosed_quotes(self):
        self.assertIn('검색어의 따옴표가 닫히지 않았습니다.', self.text('Services/ExplorerQuery.cs'))

    def test_csharp_targeted_entrypoint(self):
        s = (ROOT / 'source/tests/LogicTests/Program.cs').read_text()
        self.assertIn('V150R02AuditTests.RunAsync()', s)
        self.assertIn('--v150-r02', s)
        self.assertTrue((ROOT / 'source/tests/LogicTests/V150R02AuditTests.cs').is_file())

    def test_xml_well_formed(self):
        paths = list(APP.rglob('*.xaml')) + list(APP.rglob('*.csproj'))
        for path in paths:
            with self.subTest(file=str(path.relative_to(ROOT))): ET.parse(path)

    def test_release_keeps_product_version(self):
        s = self.text('Sunrise.FileManager.csproj')
        self.assertIn(f'<Version>{CURRENT_VERSION}</Version>',s)

if __name__ == '__main__': unittest.main()
