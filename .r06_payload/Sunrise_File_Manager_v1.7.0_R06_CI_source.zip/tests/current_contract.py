"""Approved current source version; old tests retain their behavior checks without stale release pins."""
CURRENT_VERSION = '1.7.0'
