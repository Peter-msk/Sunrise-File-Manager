from current_contract import CURRENT_VERSION
"""Stage 3: very large folders, bounded navigation, legacy UI compatibility.

These tests inspect product code contracts; Windows WPF interaction and .NET
LogicTests require the actual Windows build and are not represented as PASS here.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'
P = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'

class Stage3LargeTree(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scanner=(APP/'Services/FolderTreeScanner.cs').read_text('utf-8')
        cls.control=(APP/'Controls/FolderTree.xaml.cs').read_text('utf-8')
        cls.feature=(APP/'Features/Navigation/FolderTree.QuickAccessAndDrives.cs').read_text('utf-8')
        cls.xaml=(APP/'Controls/FolderTree.xaml').read_text('utf-8')
        cls.logic=(ROOT/'source/tests/LogicTests/Program.cs').read_text('utf-8')

    def test_bounded_pages_not_silent_truncation(self):
        self.assertIn('public const int MaxChildFolders = 350;', self.scanner)
        self.assertIn('ReadPageAsync(string parent, string? afterPath, CancellationToken token)', self.scanner)
        self.assertIn('PriorityQueue<string, string>', self.scanner)
        self.assertIn('candidates.Count > MaxChildFolders + 1', self.scanner)
        self.assertIn('token.ThrowIfCancellationRequested()', self.scanner)
        self.assertNotIn('처음 {FolderTreeScanner.MaxChildFolders:N0}개만 표시', self.control)
        self.assertIn('AddLoadMoreItem(parent)', self.control)
        self.assertIn('다음 {FolderTreeScanner.MaxChildFolders:N0}개 폴더 보기', self.control)

    def test_later_siblings_reachable_by_explicit_location(self):
        self.assertIn('if (next is null)', self.control)
        self.assertIn('InsertSortedChild(node, next)', self.control)
        self.assertIn('Directory.Exists(current)', self.control)
        self.assertIn('FileAttributes.ReparsePoint', self.control)
        self.assertIn('LocateCurrent_Click', self.control)
        self.assertIn('_navigationVersion', self.control)

    def test_page_reuse_and_memory_cleanup(self):
        self.assertIn('_pageCursors[parent] = page.Paths[^1]', self.control)
        self.assertIn('parent.Items.Contains(holder)', self.control)
        self.assertIn('parent.Items.OfType<TreeViewItem>().Any', self.control)
        self.assertIn('HasPendingLoads(node)', self.control)
        self.assertIn('ForgetCachedSubtree(node)', self.control)
        self.assertIn('_pageCursors.Clear()', self.feature)

    def test_single_scroll_compact_density_and_large_arrow_are_preserved(self):
        root=ET.fromstring(self.xaml)
        sv=list(root.iter(P+'ScrollViewer'))
        self.assertEqual(len(sv),1)
        self.assertEqual(sv[0].get(X+'Name'),'NavigationScroll')
        self.assertIn('Margin="16,0,0,0"',self.xaml)
        self.assertIn('Width="40" Height="36"',self.xaml)
        self.assertIn('IsChecked="{Binding IsExpanded, RelativeSource={RelativeSource TemplatedParent}, Mode=OneWay}"',self.xaml)
        self.assertIn('x:Name="SelectedMarker"',self.xaml)
        self.assertIn('위치 찾기',self.xaml)
        self.assertIn('빠른 이동 · 기본 폴더',self.xaml)

    def test_runtime_logic_regression_for_375_folders(self):
        for text in ('Folder_0349', 'Folder_0350', 'Folder_0374',
                     'navigation pages cover all siblings exactly once',
                     'navigation page honors cancellation'):
            self.assertIn(text,self.logic)

    def test_version_and_notice_privacy_unchanged(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(), f'{CURRENT_VERSION}')
        notice=(ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for token in ('http://','https://','github.com','download_url','latest.json','release_url'):
            self.assertNotIn(token,notice)

if __name__=='__main__': unittest.main()
