"""Source-contract checks for R00 wiring; not a replacement for .NET/WPF runtime tests."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
PANE = ROOT / "source/Sunrise.FileManager"


class V150R00SourceContractTests(unittest.TestCase):
    def test_xaml_menu_handlers_resolve_in_pane_partials(self):
        xaml = (PANE / "Controls/ExplorerPane.xaml").read_text(encoding="utf-8")
        ET.fromstring(xaml)
        all_handlers = "\n".join(
            p.read_text(encoding="utf-8")
            for p in [PANE / "Controls/ExplorerPane.xaml.cs", *sorted((PANE / "Features/Explorer").glob("ExplorerPane.*.cs"))]
        )
        for method in ("SelectAllResults_Click", "DetailColumn_Click"):
            self.assertIn(f'Click="{method}"', xaml)
            self.assertIn(f"void {method}(", all_handlers)
        self.assertIn('x:Name="ColumnVisibilityMenu"', xaml)

    def test_selection_has_bounded_global_storage_and_ui_consumer(self):
        service = (PANE / "Services/PagedSelectionSet.cs").read_text(encoding="utf-8")
        controller = (PANE / "Controls/ExplorerPane.xaml.cs").read_text(encoding="utf-8")
        scanner = (PANE / "Services/DirectoryScanner.cs").read_text(encoding="utf-8")
        self.assertIn("MaxSelection = 20_000", service)
        self.assertIn("_pagedSelection.Snapshot()", controller)
        self.assertIn("_pagedSelection.Remove(removed.FullPath)", controller)
        self.assertIn("ReadMatchingPathsAsync", scanner)
        self.assertIn("if (paths.Count == limit) throw new InvalidOperationException", scanner)

    def test_column_session_contract_preserves_backward_compatibility(self):
        store = (PANE / "Services/SessionStore.cs").read_text(encoding="utf-8")
        pane = (PANE / "Controls/ExplorerPane.xaml.cs").read_text(encoding="utf-8")
        self.assertIn("public List<int> HiddenDetailColumns { get; set; } = [];", store)
        self.assertIn("HiddenDetailColumns = _hiddenDetailColumns.Order().ToList()", pane)
        self.assertIn("state?.HiddenDetailColumns", pane)
        self.assertIn("panel.HiddenDetailColumns.Distinct().Count()", store)

    def test_logic_program_using_directives_first(self):
        file = (ROOT / "source/tests/LogicTests/Program.cs").read_text(encoding="utf-8")
        self.assertTrue(file.lstrip().startswith("using "))
        self.assertIn('if (args.Contains("--v150-r00", StringComparer.Ordinal))', file)
        self.assertIn("await V150R00Tests.RunAsync()", file)


if __name__ == "__main__":
    unittest.main()
