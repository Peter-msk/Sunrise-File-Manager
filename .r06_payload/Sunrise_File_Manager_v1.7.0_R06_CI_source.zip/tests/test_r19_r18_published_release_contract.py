"""Observed v1.1.0 feed snapshot consistency; online asset availability is a separate PENDING/FAIL gate."""
from pathlib import Path
import json, unittest, re
R=Path(__file__).resolve().parents[1]
ASSET="Sunrise_File_Manager_1.1.0_Setup.exe"
HASH="e4cb0a8367bbbba3abb84b7705d2046eeaafc87d775f08531ed622fbbac5be47"
SIZE=51469576
BASE="https://github.com/Peter-msk/Sunrise-File-Manager/releases"
class PublishedReleaseContract(unittest.TestCase):
    def test_runtime_enforces_explicit_enablement_and_release_path(self):
        code=(R/'source/Sunrise.FileManager/Services/SunriseReleaseService.cs').read_text('utf-8')
        self.assertIn('UpdateConfigured && IsApprovedDownload(this)',code)
        self.assertIn('"update_endpoint_configured"',code)
        self.assertIn('releases/download/v{release.Version}/{release.FileName}',code)
        self.assertIn('IncrementalHash.CreateHash(HashAlgorithmName.SHA256)',code)
    def test_future_build_cannot_overwrite_published_feed(self):
        g=(R/'build-tools/Sunrise.FileManager.ReleaseMetadata/Program.cs').read_text('utf-8')
        self.assertNotIn('publicationMatched',g)
        self.assertNotIn('var publishedRecord',g)
        self.assertIn('update_endpoint_configured = true',g)
        self.assertIn('public_distribution_validated = false',g)
        self.assertNotIn('[Path.Combine(root, "latest.json")]',g)
        self.assertNotIn('[Path.Combine(root, "notice.txt")]',g)
        build=(R/'BUILD_RELEASE_INSTALLER.cmd').read_text('ascii')
        self.assertIn('Published feed preserved',build)
if __name__=='__main__': unittest.main()
