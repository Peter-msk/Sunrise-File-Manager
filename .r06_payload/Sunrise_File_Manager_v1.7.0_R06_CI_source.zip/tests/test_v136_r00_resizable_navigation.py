"""Static contract tests for v1.3.6 R00; Windows WPF visual interactions need runtime verification."""
import re
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
S = Path(__file__).resolve().parents[1] / 'source/Sunrise.FileManager'
X = '{http://schemas.microsoft.com/winfx/2006/xaml}Name'
class V136ResizableNavigation(unittest.TestCase):
    def content(self, name): return (S/name).read_text('utf-8')
    def test_thumb_resize_wired_for_pinned_and_auto_hide(self):
        root=ET.parse(S/'Controls/ExplorerPane.xaml').getroot()
        thumb=next(e for e in root.iter() if e.get(X)=='NavigationResizeThumb')
        self.assertTrue(thumb.tag.endswith('Thumb'))
        self.assertEqual(thumb.get('DragDelta'),'NavigationResize_Delta')
        self.assertEqual(thumb.get('DragStarted'),'NavigationResize_Started')
        self.assertEqual(thumb.get('DragCompleted'),'NavigationResize_Completed')
        code=self.content('Features/Explorer/ExplorerPane.NavigationDrawer.cs')
        self.assertIn('TreeColumn.Width = new GridLength(',code)
        self.assertIn('NavigationDrawer.Width = drawerWidth',code)
        self.assertIn('NavigationPanelPolicy.FitWidth(_navigationWidth',code)
        self.assertIn('_navigationResizing',code)
        self.assertIn('SettingsChanged?.Invoke()',code)
    def test_pane_width_saved_restored_and_validated(self):
        pane=self.content('Controls/ExplorerPane.xaml.cs')
        store=self.content('Services/SessionStore.cs')
        policy=self.content('Services/NavigationPanelPolicy.cs')
        self.assertIn('TreeWidth = NavigationPanelPolicy.NormalizeWidth(_navigationWidth)',pane)
        self.assertIn('state?.TreeWidth ?? NavigationPanelPolicy.DefaultWidth',pane)
        self.assertIn('public double TreeWidth { get; set; } = NavigationPanelPolicy.DefaultWidth;',store)
        self.assertIn('!double.IsFinite(panel.TreeWidth)',store)
        self.assertIn('MinimumWidth = 145',policy)
        self.assertIn('MaximumWidth = 520',policy)
    def test_navigation_closes_inactive_branches_without_losing_active(self):
        tree=self.content('Controls/FolderTree.xaml.cs')
        nav=self.content('Features/Explorer/ExplorerPane.NavigationAndWatcher.cs')
        self.assertIn('CollapseInactiveBranches(string? activePath)',tree)
        self.assertIn('node.IsExpanded = false',tree)
        self.assertIn('IsPathAncestorOf(path, active)',tree)
        self.assertIn('++_navigationVersion',tree)
        self.assertIn('!string.Equals(_lastTreeLocation, path',nav)
        self.assertIn('CollapseInactiveBranches(_skipNavigationTreeReveal ? null : path)',nav)
        self.assertIn('RestoreExpandedPathsAsync(state.ExpandedTreePaths, state.TreeScrollOffset, activePath)',self.content('Controls/ExplorerPane.xaml.cs'))
    def test_shift_wheel_only_moves_horizontal_grid_viewport(self):
        code=self.content('Controls/ExplorerPane.xaml.cs')
        method=code.split('private void FilesGrid_PreviewMouseWheel(',1)[1].split('private void FilesGrid_PreviewKeyDown',1)[0]
        self.assertIn('ModifierKeys.Control',method)
        self.assertIn('ModifierKeys.Shift',method)
        self.assertIn('GetFilesScrollViewer()',method)
        self.assertIn('ScrollToHorizontalOffset',method)
        self.assertIn('scroll.ScrollableWidth <= 0',method)
        self.assertNotIn('ScrollToVerticalOffset',method)
    def test_no_unrequested_contract_changes(self):
        notice=self.content('Features/Explorer/ExplorerPane.NavigationDrawer.cs')
        self.assertNotIn('latest.json',notice)
        self.assertNotIn('download_url',notice)
if __name__ == '__main__': unittest.main()
