from current_contract import CURRENT_VERSION
"""Source-level contracts; actual WPF interaction must be tested on Windows."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'source/Sunrise.FileManager'
P='{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'

class InlineRenameContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.xaml=(APP/'Controls/ExplorerPane.xaml').read_text('utf-8')
        cls.pane=(APP/'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        cls.editor=(APP/'Features/Explorer/ExplorerPane.InlineRename.cs').read_text('utf-8')
        cls.policy=(APP/'Services/FileRenameNamePolicy.cs').read_text('utf-8')
        cls.model=(APP/'Models/FileEntry.cs').read_text('utf-8')

    def test_row_editor_not_dialog_for_single_entry(self):
        root=ET.fromstring(self.xaml)
        columns=list(root.iter(P+'DataGridTemplateColumn'))
        self.assertTrue(any(c.get('Header')=='이름' and c.get('SortMemberPath')=='Name' for c in columns))
        self.assertIn('x:Name="InlineRenameEditor"',self.xaml)
        self.assertIn('PreviewKeyDown="InlineRenameEditor_PreviewKeyDown"',self.xaml)
        self.assertIn('LostKeyboardFocus="InlineRenameEditor_LostKeyboardFocus"',self.xaml)
        self.assertIn('BeginInlineRename(selection[0]);',self.pane)
        self.assertNotIn('new NameInputDialog("이름 변경"',self.pane)
        self.assertIn('new BatchRenameDialog',self.pane)

    def test_extension_display_setting_controls_rename_text(self):
        self.assertIn('_renameShowsExtension = _showExtensions;',self.editor)
        self.assertIn('FileRenameNamePolicy.EditorText(entry.Name, entry.IsDirectory, _renameShowsExtension)',self.editor)
        self.assertIn('FileRenameNamePolicy.ResolveFullName(entry.Name, entry.IsDirectory, showingExtension, draft)',self.editor)
        self.assertIn('Path.GetExtension(currentName)',self.policy)
        self.assertIn('Path.GetFileNameWithoutExtension(currentName)',self.policy)
        self.assertIn('FileActionsService.ValidateName(editedText + suffix)',self.policy)
        self.assertIn('public bool IsRenaming',self.model)
        self.assertIn('public string RenameDraft',self.model)

    def test_enter_escape_and_extension_change_guard(self):
        self.assertIn('e.Key == Key.Enter',self.editor)
        self.assertIn('e.Key == Key.Escape',self.editor)
        self.assertIn('FinishInlineRename(false)',self.editor)
        self.assertIn('확장자 변경 확인',self.editor)
        self.assertIn('_undoService.RecordRename(',self.editor)
        self.assertIn('BeforeFileChange?.Invoke()',self.editor)
        self.assertIn('if (_renamingEntry is not null) return;',self.pane)

    def test_no_wire_or_version_change(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(),f'{CURRENT_VERSION}')
        self.assertIn('ShowExtensions = _showExtensions',self.pane)
        self.assertIn('entry.ShowExtension = _showExtensions',self.pane)
        notice=(ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for text in ('http://','https://','download_url','github.com','latest.json'):
            self.assertNotIn(text,notice)

if __name__=='__main__': unittest.main()
