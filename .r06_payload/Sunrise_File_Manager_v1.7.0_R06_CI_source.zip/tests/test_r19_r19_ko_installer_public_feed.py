"""R19: Korean-only installer UI and customer-facing public metadata."""
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN = ("개발", "소스", "SDK", "빌드", "검증", "내부", "정적", "GitHub Actions", "SHA-256", "Sunrise Control", "R18", "R19", "PENDING", "WPF")

class UserFacingReleaseTest(unittest.TestCase):
    def test_korean_inno_ui(self):
        iss=(ROOT/'installer/SunriseFileManager.iss').read_text('utf-8')
        self.assertIn('Name: "korean"; MessagesFile: "compiler:Languages\\Korean.isl"',iss)
        self.assertNotIn('Name: "english";',iss)
        self.assertIn('SignedUninstaller=yes',iss)
        self.assertIn('PrivilegesRequired=lowest',iss)
        self.assertIn('DefaultDirName={localappdata}',iss)
    def test_future_build_release_notes_are_customer_facing(self):
        gen=(ROOT/'build-tools/Sunrise.FileManager.ReleaseMetadata/Program.cs').read_text('utf-8')
        self.assertIn('release_notes = releaseNotes + "."',gen)
        self.assertNotIn('게시된 설치파일과 해시·크기 일치.',gen)
        self.assertNotIn('현재 로컬 빌드는 공개 설치파일과 일치하지 않아',gen)
        self.assertIn('NOTICE_BODY_{version}.txt', gen)
    def test_no_unsafe_distribution_changes(self):
        publish=(ROOT/'BUILD_RELEASE_ONEDIR.cmd').read_text('ascii')
        self.assertIn('set \"SELF_CONTAINED=true\"',publish)
        self.assertIn('-p:PublishTrimmed=false',publish)
        self.assertIn('PdfPig', (ROOT/'source/Sunrise.FileManager/Sunrise.FileManager.csproj').read_text('utf-8'))

if __name__=='__main__':unittest.main()
