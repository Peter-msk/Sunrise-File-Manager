from current_contract import CURRENT_VERSION
"""v1.3.8 R00 tree density regression; actual Windows DPI/UI requires packaged runtime."""
import re
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'source/Sunrise.FileManager'
X='{http://schemas.microsoft.com/winfx/2006/xaml}'
P='{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'

class CompactFolderTreeContract(unittest.TestCase):
    def setUp(self):
        self.tree=(APP/'Controls/FolderTree.xaml').read_text('utf-8')
        self.app=(APP/'App.xaml').read_text('utf-8')
        self.code=(APP/'Features/Navigation/FolderTree.QuickAccessAndDrives.cs').read_text('utf-8')

    def test_navigation_tree_owns_its_local_visual_style(self):
        root=ET.fromstring(self.tree)
        resources=next(e for e in root if e.tag==P+'UserControl.Resources')
        style=[e for e in resources if e.tag==P+'Style' and e.get('TargetType')=='TreeViewItem']
        self.assertEqual(len(style),1)
        self.assertNotIn('<Style TargetType="TreeViewItem">',self.app)
        self.assertIn('<ControlTemplate TargetType="TreeViewItem">',self.tree)

    def test_compact_depth_keeps_large_arrow_click_target(self):
        self.assertIn('<ItemsPresenter x:Name="ItemsHost" Grid.Row="1" Margin="16,0,0,0"/>',self.tree)
        self.assertNotIn('Margin="42,0,0,0"',self.tree)
        arrow=re.search(r'<ToggleButton x:Name="ExpandToggle".*?</ToggleButton>',self.tree,re.S)
        self.assertIsNotNone(arrow)
        self.assertIn('Width="40" Height="36"',arrow.group())
        self.assertIn('Mode=OneWay}',arrow.group())
        self.assertIn('TreeViewItem.ExpandedEvent', (APP/'Controls/FolderTree.xaml.cs').read_text('utf-8'))

    def test_folder_name_is_single_line_scrollable_with_full_name_tooltip(self):
        self.assertIn('TextWrapping = TextWrapping.NoWrap', self.code)
        # Current user contract: full folder names must contribute to scroll extent.
        self.assertIn('TextTrimming = TextTrimming.None', self.code)
        header = re.search(r'new TextBlock \{ Text = title,.*?\}\);', self.code).group()
        self.assertNotIn('MaxWidth', header)
        self.assertNotIn('CharacterEllipsis', header)
        self.assertIn('ToolTip = title',self.code)
        self.assertIn('ToolTip = path',self.code)
        # Drive capacity and its visual gauge are not removed by folder density changes.
        self.assertIn('root.ToolTip = drive.RootDirectory.FullName',self.code)
        self.assertIn('new ProgressBar',self.code)

    def test_selection_has_theme_semantic_indicator_and_does_not_block_arrow(self):
        self.assertIn('x:Name="SelectedMarker"',self.tree)
        self.assertIn('Background="{DynamicResource Accent}"',self.tree)
        self.assertIn('IsHitTestVisible="False"',self.tree)
        self.assertIn('TargetName="SelectedMarker" Property="Visibility" Value="Visible"',self.tree)
        self.assertIn('TargetName="TreeRow" Property="Background" Value="{DynamicResource Selected}"',self.tree)

    def test_no_release_or_behavioral_version_changes(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(),f'{CURRENT_VERSION}')
        self.assertIn('PathChosen?.Invoke(path)',(APP/'Controls/FolderTree.xaml.cs').read_text('utf-8'))
        self.assertIn('CollapseInactiveBranches', (APP/'Controls/FolderTree.xaml.cs').read_text('utf-8'))
        notice=(ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for token in ('download_url','latest.json','github.com','https://'):
            self.assertNotIn(token,notice)

if __name__=='__main__': unittest.main()
