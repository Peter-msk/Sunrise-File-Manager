"""Root-layout guards; the executable C# split suite tests production geometry."""
from pathlib import Path
import unittest

APP = Path(__file__).resolve().parents[1] / 'source/Sunrise.FileManager'


class AllSplitViewportContract(unittest.TestCase):
    def test_workspace_and_track_minimums_have_the_same_owner(self):
        shell = (APP / 'MainWindow.xaml.cs').read_text()
        tracks = (APP / 'Features/Workspace/MainWindow.PanelCoordination.cs').read_text()
        self.assertIn('GetMinimumWorkspaceSize(_splitPreset)', shell)
        self.assertIn('Math.Max(minimum.Width, viewportWidth - 2)', shell)
        self.assertIn('Math.Max(minimum.Height, viewportHeight - 2)', shell)
        self.assertIn('WorkspaceSplitLayoutEngine.MinimumPaneWidth', tracks)
        self.assertIn('WorkspaceSplitLayoutEngine.MinimumPaneHeight', tracks)
        self.assertNotIn('blueprint.StarColumns >= 3 ? 185', tracks)
        self.assertNotIn('blueprint.StarRows >= 3 ? 150', tracks)

    def test_workspace_reflow_uses_viewport_size_not_scroll_position(self):
        shell = (APP / 'MainWindow.xaml.cs').read_text()
        self.assertIn('if (e.ViewportWidthChange != 0 || e.ViewportHeightChange != 0) UpdateWorkspaceLayout();', shell)
        self.assertIn('WorkspaceViewport.ViewportWidth > 1', shell)
        self.assertIn('WorkspaceViewport.ViewportHeight > 1', shell)
        self.assertNotIn('if (e.HorizontalChange != 0)', shell)


if __name__ == '__main__':
    unittest.main()
