from current_contract import CURRENT_VERSION
"""Regression for DEFECT-FM-SESSION-001, strict validation, update and version contracts."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source' / 'Sunrise.FileManager'

class V137SessionExit(unittest.TestCase):
    def test_ui_capture_and_final_save_guard(self):
        pane = (APP / 'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        window = (APP / 'MainWindow.xaml.cs').read_text('utf-8')
        store = (APP / 'Services/SessionStore.cs').read_text('utf-8')
        self.assertIn('ColumnOrder = SessionStore.CaptureDisplayOrder(FilesGrid.Columns.Select(column => column.DisplayIndex))', pane)
        self.assertIn('SessionStore.SaveUiSnapshot(new AppSession', window)
        self.assertIn('internal static void SaveUiSnapshot(AppSession snapshot, string path)', store)
        self.assertIn('panel.ColumnOrder = CaptureDisplayOrder(panel.ColumnOrder)', store)
        self.assertIn('snapshot.AiSettings.PlanColumnOrder = CaptureDisplayOrder(', store)
        self.assertIn('Save(snapshot, path);', store)
        self.assertIn('Validate(session);', store)
        self.assertIn('File.Move(temp, path, overwrite: true)', store)
        self.assertIn('if (_persistSession && !TrySaveSession(showError: true))', window)

    def test_v135_fault_attested_and_recurring_gate_documented(self):
        defect = (ROOT/'docs/DEFECT_REGISTRY.md').read_text('utf-8')
        self.assertIn('DEFECT-FM-SESSION-001', defect)
        self.assertIn('v1.3.5', defect)
        self.assertIn('DisplayIndex=-1', defect)
        self.assertIn('v1.3.5→v1.3.7', defect)
        self.assertIn('Windows', defect)

    def test_version_contract_and_release_notice_privacy(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text('ascii').strip(), f'{CURRENT_VERSION}')
        self.assertIn(f'<Version>{CURRENT_VERSION}</Version>', (APP/'Sunrise.FileManager.csproj').read_text('utf-8'))
        self.assertIn(f'public const string Version = "{CURRENT_VERSION}";', (APP/'Services/SunriseControlService.cs').read_text('utf-8'))
        self.assertIn(f'Sunrise File Manager {CURRENT_VERSION}', (APP/'MainWindow.xaml').read_text('utf-8'))
        notice = (ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        self.assertNotIn('https://', notice)
        self.assertNotIn('http://', notice)
        self.assertNotIn('github.com/', notice)
        self.assertNotIn('download_url', notice)
        self.assertIn('1.3.6.1.5.5.7.3.3', (ROOT/'source/build-tools/Sunrise.Signing/Program.cs').read_text('utf-8'))

if __name__ == '__main__': unittest.main()
