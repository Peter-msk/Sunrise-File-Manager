from current_contract import CURRENT_VERSION
"""v1.3.3 source-level regressions; native WPF visual/execution tests remain pending."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'
NS = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'

class V133Fixes(unittest.TestCase):
    def test_light_navigation_rail_owns_distinct_palette_and_dark_stays_unchanged(self):
        theme = (APP / 'Services/ThemeManager.cs').read_text()
        self.assertIn('["ThemeNavigationRail"] = ("#EFF4F8", "#506984")', theme)
        self.assertIn('["ThemeNavigationRailText"] = ("#315B7A", "#EFF7FF")', theme)
        xaml = (APP / 'Controls/ExplorerPane.xaml').read_text()
        self.assertIn('x:Name="TreeDivider"', xaml)
        self.assertIn('Background="{DynamicResource ThemeNavigationRail}"', xaml)
        self.assertIn('Foreground" Value="{DynamicResource ThemeNavigationRailText}"', xaml)
        self.assertNotIn('x:Name="TreeDivider" Panel.ZIndex="30" Background="{DynamicResource ThemeSplitter}"',xaml)

    def test_tree_expand_arrow_has_large_forty_pixel_target(self):
        a = (APP / 'Controls/FolderTree.xaml').read_text()
        match = re.search(r'<ToggleButton x:Name="ExpandToggle".*?</ToggleButton>', a, re.S)
        self.assertIsNotNone(match)
        toggle = match.group(0)
        self.assertIn('Width="40" Height="36"', toggle)
        self.assertIn('IsChecked="{Binding IsExpanded, RelativeSource={RelativeSource TemplatedParent}, Mode=OneWay}"', toggle)
        self.assertIn('Cursor="Hand"', toggle)
        self.assertIn('RotateTransform Angle="90"', toggle)
        self.assertIn('Name="ArrowHitTarget" Background="Transparent"', toggle)

    def test_separators_are_unclipped_in_menu_and_popup(self):
        app = ET.parse(APP / 'App.xaml').getroot()
        style = next(x for x in app.iter(NS+'Style') if x.get(X+'Key') == 'SunriseMenuSeparator')
        self.assertIn(('Height', '12'), [(s.get('Property'),s.get('Value')) for s in style])
        line = next(x for x in style.iter(NS+'Border') if x.get('Background') == '{DynamicResource ThemeMenuSeparator}')
        self.assertEqual(line.get('Height'), '2')
        self.assertEqual(line.get('HorizontalAlignment'), 'Stretch')
        self.assertEqual(line.get('RenderOptions.EdgeMode'), 'Aliased')
        self.assertIn('BasedOn="{StaticResource SunriseMenuSeparator}"', (APP / 'App.xaml').read_text())
        self.assertGreaterEqual((APP / 'MainWindow.xaml').read_text().count('<Separator/>'), 4)

    def test_unopened_ai_grid_order_normalized_before_save(self):
        ai = (APP / 'Controls/AiCommandPanel.xaml.cs').read_text()
        model = (APP / 'Services/SessionStore.cs').read_text()
        closing = (APP / 'MainWindow.xaml.cs').read_text()
        self.assertIn('PlanColumnOrder = SessionStore.CaptureDisplayOrder(PlanGrid.Columns.Select(x => x.DisplayIndex))', ai)
        self.assertIn('PlanColumnSettings = PlanGrid.Columns.Select(x => SessionStore.CaptureColumnWidth(', ai)
        self.assertIn('Enumerable.Range(0, order.Length).ToList()', model)
        self.assertIn('double.IsFinite(value) ? Math.Clamp(value, 0, 4000) : 1', model)
        self.assertIn('SessionStore.SaveUiSnapshot(new AppSession', closing)
        self.assertIn('if (_persistSession && !TrySaveSession(showError: true))', closing)

    def test_release_version_is_consistent_without_publishing(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(), f'{CURRENT_VERSION}')
        for p in ['source/Sunrise.FileManager/Sunrise.FileManager.csproj',
                  'source/Sunrise.FileManager/MainWindow.xaml',
                  'source/Sunrise.FileManager/Services/SunriseControlService.cs']:
            self.assertIn(f'{CURRENT_VERSION}', (ROOT/p).read_text())
        self.assertTrue((ROOT/'release/NOTICE_BODY_1.3.3.txt').is_file())
        import json
        self.assertNotEqual(json.loads((ROOT/'latest.json').read_text())['latest_version'], CURRENT_VERSION)

if __name__ == '__main__': unittest.main()
