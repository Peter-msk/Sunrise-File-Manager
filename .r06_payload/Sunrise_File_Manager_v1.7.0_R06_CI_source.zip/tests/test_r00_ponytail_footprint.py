from current_contract import CURRENT_VERSION
"""R00 additive tests: source/publish contract, native Windows gate still required."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]

class R00PonytailFootprint(unittest.TestCase):
    def test_self_contained_wpf_dependency_and_full_resources_preserved(self):
        official=(ROOT/'BUILD_RELEASE_ONEDIR.cmd').read_text(encoding='utf-8')
        self.assertIn('set \"SELF_CONTAINED=true\"', official)
        self.assertIn('-p:PublishTrimmed=false', official)
        self.assertIn('-p:PublishReadyToRun=false', official)
        for essential in ('hostfxr.dll','coreclr.dll','PresentationFramework.dll'):
            self.assertIn(essential,official)
        self.assertNotIn('SatelliteResourceLanguages=',official)
        project=(ROOT/'source/Sunrise.FileManager/Sunrise.FileManager.csproj').read_text(encoding='utf-8')
        self.assertIn('<UseWPF>true</UseWPF>',project)
        self.assertIn('<PublishTrimmed>false</PublishTrimmed>',project)
        self.assertNotIn('<InvariantGlobalization>true</InvariantGlobalization>',project)
        self.assertNotIn('SatelliteResourceLanguages',project)
        ET.fromstring(project)

    def test_symbols_only_removed_from_disposable_release_staging(self):
        official=(ROOT/'BUILD_RELEASE_ONEDIR.cmd').read_text(encoding='utf-8')
        self.assertIn('-p:DebugType=none',official)
        self.assertIn('-p:DebugSymbols=false',official)
        self.assertIn('for /r "%STAGE%\\app" %%P in (*.pdb) do (',official)
        self.assertIn('del /q /f "%%~fP"',official)
        self.assertNotIn('*.dll) do',official)
        self.assertNotIn('*.resources.dll) do',official)
        dev=(ROOT/'BUILD_DEV_EXE.cmd').read_text(encoding='utf-8')
        self.assertIn('-p:DebugType=none',dev)
        self.assertNotIn('PublishSingleFile=true',official)
        self.assertIn('Compression=lzma2', (ROOT/'installer/SunriseFileManager.iss').read_text())

    def test_zip_archive_prevents_collisions_without_changing_format(self):
        fs=(ROOT/'source/Sunrise.FileManager/Features/FileSystem/FileActionsService.ArchiveAndShell.cs').read_text()
        self.assertIn('var rootNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)',fs)
        self.assertIn('selectedFolders.Contains(parent)',fs)
        self.assertIn('string[] selected = sourcePaths.Select(Path.GetFullPath).ToArray()',fs)
        self.assertIn('ZipFile.Open(tempZip, ZipArchiveMode.Create)',fs)
        native=(ROOT/'source/tests/LogicTests/V120SafetyTests.cs').read_text()
        for case in ('same-named archive roots rejected', 'parent and child cannot produce duplicate archive entries',
                     'repeated source cannot produce duplicate archive entries'):
            self.assertIn(case,native)

    def test_unchanged_official_identity_and_update_contract(self):
        installer=(ROOT/'installer/SunriseFileManager.iss').read_text()
        self.assertIn('AppId={{5305DEB7-62CF-4ED7-8A5B-8B605AD7090A}',installer)
        self.assertIn('PrivilegesRequired=lowest',installer)
        self.assertIn('Source: "{#ReleaseSource}\\*"',installer)
        self.assertIn('DefaultDirName={localappdata}\\Programs\\Sunrise File Manager',installer)
        self.assertEqual(f'{CURRENT_VERSION}',(ROOT/'installer/RELEASE_VERSION.txt').read_text().strip())

    def test_windows_company_cmd_line_endings_intact(self):
        for name in ('BUILD_RELEASE_ONEDIR.cmd','BUILD_DEV_EXE.cmd','BUILD_ON_WINDOWS_COMPANY.cmd'):
            payload=(ROOT/name).read_bytes()
            self.assertIn(b'\r\n',payload,name)
            self.assertNotIn(b'\n',payload.replace(b'\r\n',b''),name)

if __name__=='__main__':unittest.main()
