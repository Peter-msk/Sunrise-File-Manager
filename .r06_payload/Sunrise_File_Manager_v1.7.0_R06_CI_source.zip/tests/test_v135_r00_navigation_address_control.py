"""v1.3.5 R00 scope-isolated navigation and merged status entry contracts.

These source checks do not replace compiled Windows WPF click/input smoke tests.
"""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source' / 'Sunrise.FileManager'

class R00NavigationAddressAndControl(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pane_xaml = (APP / 'Controls/ExplorerPane.xaml').read_text('utf-8')
        cls.pane_code = (APP / 'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        cls.nav_code = (APP / 'Features/Explorer/ExplorerPane.NavigationAndWatcher.cs').read_text('utf-8')
        cls.shell_xaml = (APP / 'MainWindow.xaml').read_text('utf-8')
        cls.shell_code = (APP / 'MainWindow.xaml.cs').read_text('utf-8')

    def test_wpf_markup_parses(self):
        for rel in ('Controls/ExplorerPane.xaml', 'MainWindow.xaml'):
            ET.parse(APP / rel)

    def test_empty_double_click_uses_position_hit_test_and_marquee_fallback(self):
        x, c = self.pane_xaml, self.pane_code
        self.assertIn('MouseDoubleClick="FilesGrid_MouseDoubleClick"', x)
        self.assertIn('PreviewMouseLeftButtonDown="FilesGrid_PreviewMouseLeftButtonDown"', x)
        self.assertIn('IsBlankViewportPoint(point)', c)
        self.assertIn('VisualTreeHelper.HitTest(FilesGrid, point)', c)
        self.assertIn('GetDoubleClickTime()', c)
        self.assertIn('GetSystemMetrics(36)', c)
        self.assertIn('GetSystemMetrics(37)', c)
        self.assertIn('secondBlankClick', c)
        self.assertIn('EndMarquee();', c)
        self.assertIn('Up_Click(this, e);', c)
        self.assertIn('if (BeginMarquee(e)) return;', c)
        self.assertLess(c.index('if (blank && (e.ClickCount >= 2 || secondBlankClick))'), c.index('if (BeginMarquee(e)) return;'))

    def test_dbl_click_does_not_capture_files_rows_headers_or_scroll_bars(self):
        c = self.pane_code
        for name in ('DataGridRow', 'DataGridColumnHeader', 'ScrollBar', 'Thumb', 'RepeatButton'):
            self.assertIn(name, c)
        self.assertIn('if (row?.Item is FileEntry entry)', c)
        self.assertIn('if (entry.IsDirectory) TryNavigate(entry.FullPath)', c)
        self.assertIn('else OpenOriginal(entry)', c)

    def test_address_input_kept_with_expandable_tree_popup(self):
        x, c = self.pane_xaml, self.pane_code
        for name in ('AddressBox', 'AddressHost', 'AddressDropButton', 'AddressPopup', 'AddressPopupContent'):
            self.assertIn('x:Name="'+name+'"', x)
        self.assertNotIn('AddressSuggestions', x)
        for name in ('AddressBox_PreviewMouseLeftButtonUp', 'AddressDropButton_Click'):
            self.assertIn(name, x)
            self.assertIn('void '+name+'(', c + self.nav_code)
        self.assertIn('new FolderTree { Focusable = true }', self.nav_code)
        self.assertIn('tree.PathChosen += NavigateFromAddressTree;', self.nav_code)
        self.assertIn('tree.QuickPathChosen += NavigateFromAddressTree;', self.nav_code)
        self.assertIn('TryNavigate(path, revealInTree: false);', self.nav_code)
        self.assertIn('if (e.Key == Key.F4', c)
        self.assertIn('e.Key == Key.Escape', c)
        self.assertIn('e.Key == Key.Enter', c)
        self.assertIn('TryNavigate(requested)', c)

    def test_shortcut_navigation_does_not_expand_drive_ancestors(self):
        tree = (APP / 'Controls/FolderTree.xaml.cs').read_text('utf-8')
        quick = (APP / 'Features/Navigation/FolderTree.QuickAccessAndDrives.cs').read_text('utf-8')
        drawer = (APP / 'Features/Explorer/ExplorerPane.NavigationDrawer.cs').read_text('utf-8')
        self.assertIn('public event Action<string>? QuickPathChosen;', tree)
        self.assertIn('CancelAutomaticReveal()', tree)
        self.assertIn('QuickPathChosen?.Invoke(path)', quick)
        self.assertIn('QuickPathChosen?.Invoke(folder)', quick)
        self.assertIn('CollapseInactiveBranches(_skipNavigationTreeReveal ? null : path)', self.nav_code)
        self.assertIn('if (newLocation && !_skipNavigationTreeReveal && !WindowsKnownLocations.IsVirtual(path)', self.nav_code)

    def test_drive_expand_click_area_and_double_click(self):
        style = (APP / 'Controls/FolderTree.xaml').read_text('utf-8')
        tree = (APP / 'Controls/FolderTree.xaml.cs').read_text('utf-8')
        self.assertIn('Width="40" Height="36"', style)
        self.assertIn('void FolderItems_PreviewMouseLeftButtonDown(', tree)
        self.assertIn('item.IsExpanded = !item.IsExpanded;', tree)

    def test_footer_has_one_combined_entry_with_both_services_preserved(self):
        x, c = self.shell_xaml, self.shell_code
        self.assertEqual(x.count('Header="공지사항 · 버전 정보"'), 1)
        self.assertEqual(x.count('Header="업데이트 확인"'), 1)
        self.assertIn('private void Notice_Click(object sender, RoutedEventArgs e) => OpenControlWindow()', c)
        self.assertIn('private void UpdateCheck_Click(object sender, RoutedEventArgs e) => OpenControlWindow()', c)
        self.assertIn('new SunriseControlWindow(_controlPolicy)', c)
        # Both legacy settings menu entry points intentionally remain reachable.
        self.assertIn('Header="공지사항 · 버전 정보" Click="Notice_Click"', x)
        self.assertIn('Header="업데이트 확인" Click="UpdateCheck_Click"', x)

if __name__ == '__main__':
    unittest.main()
