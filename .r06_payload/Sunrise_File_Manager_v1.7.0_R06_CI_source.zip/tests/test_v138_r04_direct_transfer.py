"""Source-level regression for Explorer-style routine transfers; Windows WPF execution is separate."""
import unittest
from current_contract import CURRENT_VERSION
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'

class DirectTransferContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (APP / 'MainWindow.xaml.cs').read_text('utf-8')
        cls.clipboard = (APP / 'Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs').read_text('utf-8')
        cls.delete = (APP / 'Features/Explorer/ExplorerPane.FileOperations.cs').read_text('utf-8')
        cls.engine = (APP / 'Services/TransferService.cs').read_text('utf-8')

    def test_no_routine_copy_move_confirmation(self):
        begin = self.main.index('private async Task RunTransferAsync(')
        working = self.main.index('        _working = true;', begin)
        prefix = self.main[begin:working]
        self.assertNotIn('MessageBox.Show', prefix)
        self.assertNotIn('MessageBoxButton.YesNo', prefix)
        self.assertIn('MemoPanel.ConfirmLeavingMemo()', prefix) # unsaved content guard
        self.assertIn('CollisionPolicy.Ask', prefix)

    def test_common_transfer_path_covers_paste_and_drop_without_deprecated_toolbar(self):
        self.assertNotIn('TransferBarToggle_Click', self.main)
        self.assertIn('await RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, source, target);', self.main)
        self.assertIn('await RunTransferAsync(request.Paths, request.TargetFolder, request.Kind, pane, pane);', self.main)
        self.assertIn('PasteRequested?.Invoke(new(this, crossFolderPaths, folder, kind));', self.clipboard)
        self.assertIn('PasteRequested?.Invoke(new(this, movablePaths, folder, kind));', self.clipboard)

    def test_copy_move_safety_retained(self):
        self.assertIn('TransferService.RunAsync(paths, target, kind, progress, cancellation.Token, collision,', self.main)
        self.assertIn('result.Errors.Count > 0', self.main)
        self.assertIn('CopyAtomicallyAsync(', self.engine)
        self.assertIn('MoveAcrossVolumesAsync(', self.engine)
        self.assertIn('CollisionPolicy.Skip', self.engine)
        self.assertIn('public enum CollisionPolicy { Skip, Rename, Ask }', self.engine)
        self.assertIn('VerifySourceUnchanged(plan)', self.engine)
        self.assertIn('CancelJobButton.IsEnabled = true;', self.main)

    def test_delete_confirmation_both_modes(self):
        self.assertIn('"휴지통 이동 확인", MessageBoxButton.YesNo', self.delete)
        self.assertIn('"영구 삭제 확인 (Shift+Delete)", MessageBoxButton.YesNo', self.delete)
        self.assertIn('이 작업은 되돌릴 수 없습니다.', self.delete)

    def test_copy_move_errors_are_not_hidden(self):
        self.assertIn('"파일 작업 결과", MessageBoxButton.OK, MessageBoxImage.Warning', self.main)
        self.assertIn('"파일 작업 제한", MessageBoxButton.OK, MessageBoxImage.Warning', self.main)
        self.assertIn('JobStatus.Text = $"{action} 작업 준비 중";', self.main)

    def test_release_version_and_public_notice_stable(self):
        self.assertEqual((ROOT / 'installer/RELEASE_VERSION.txt').read_text().strip(), CURRENT_VERSION)
        notice = (ROOT / f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for marker in ('http://', 'https://', 'download_url', 'github.com', 'latest.json'):
            self.assertNotIn(marker, notice)

if __name__ == '__main__': unittest.main()
