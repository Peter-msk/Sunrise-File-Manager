"""UI wiring checks; actual Windows mouse/theme/DPI behavior remains a separate gate."""
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
APP=Path(__file__).resolve().parents[1]/'source/Sunrise.FileManager'
N={'w':'http://schemas.microsoft.com/winfx/2006/xaml/presentation'}
X='{http://schemas.microsoft.com/winfx/2006/xaml}Name'
class V132NavigationSessionContracts(unittest.TestCase):
    def text(self,name): return (APP/name).read_text()
    def test_all_first_run_display_options_are_off(self):
        root=ET.parse(APP/'Controls/ExplorerPane.xaml').getroot()
        for name in ['HiddenToggle','ExtensionsToggle','CheckboxesToggle','ColorFilterToggle']:
            self.assertEqual(next(x for x in root.iter() if x.get(X)==name).get('IsChecked'),'False')
        cs=self.text('Controls/ExplorerPane.xaml.cs')
        for key in ['ShowHidden','ShowExtensions','ShowCheckboxes','ColorCoding']:
            self.assertIn('state?.'+key+' ?? false',cs)
    def test_quick_folder_icons_are_embedded_and_labels_retained(self):
        root=ET.parse(APP/'Controls/FolderTree.xaml').getroot()
        for key in ['Home','Desktop','Downloads','Documents','Pictures','Music','Videos','RecycleBin','ThisPc']:
            button=next(x for x in root.iter() if x.tag.endswith('Button') and x.get('Tag')==key)
            self.assertIsNotNone(button.find('.//w:Image',N))
            self.assertIsNotNone(button.find('.//w:TextBlock',N))
        self.assertGreaterEqual(len(root.findall('./w:UserControl.Resources/w:DrawingImage',N)),9)
    def test_navigation_has_resizable_width_and_edge_controls(self):
        root=ET.parse(APP/'Controls/ExplorerPane.xaml').getroot()
        drawer=next(x for x in root.iter() if x.get(X)=='NavigationDrawer')
        self.assertEqual(drawer.get('Width'),'272') # legacy first-run default, now user-resizable
        self.assertFalse(any(x.get(X)=='TreeDivider' and x.tag.endswith('GridSplitter') for x in root.iter()))
        for name in ['NavigationToggleButton','NavigationAutoHideButton']:
            self.assertTrue(any(x.get(X)==name for x in root.iter()))
        code=self.text('Features/Explorer/ExplorerPane.NavigationDrawer.cs')
        self.assertIn('new DoubleAnimation',code)
        self.assertIn('NavigationPanelPolicy.FitWidth(_navigationWidth',code)
        self.assertIn('_navigationMenuOpen || _navigationResizing || NavigationDrawer.IsMouseCaptureWithin',code)
    def test_marquee_is_distinct_from_item_drag_and_cleans_up(self):
        pane=self.text('Controls/ExplorerPane.xaml.cs')
        marquee=self.text('Features/Explorer/ExplorerPane.MarqueeSelection.cs')
        self.assertIn('if (BeginMarquee(e)) return;',pane)
        self.assertIn('if (UpdateMarquee(e)) return;',pane)
        self.assertIn('PreviewMouseLeftButtonUp += FinishMarquee',pane)
        self.assertIn('LostMouseCapture +=',pane)
        self.assertIn('e.Key == Key.Escape',pane)
        self.assertIn('FilesGrid.Columns.IndexOf(column) <= 1',marquee)
        self.assertIn('MarqueeSelectionPolicy.HitRows',marquee)
        self.assertIn('scroll?.LineDown()',marquee)
        self.assertIn('drawing.PushClip',marquee)
        self.assertIn('DragDrop.DoDragDrop(FilesGrid',pane)
    def test_file_rows_own_chrome_without_touching_other_grids(self):
        root=ET.parse(APP/'Controls/ExplorerPane.xaml').getroot()
        resources=root.find('.//w:DataGrid.Resources',N)
        self.assertIsNotNone(resources)
        self.assertTrue(any(x.get('TargetType')=='DataGridRow' for x in resources))
        self.assertTrue(any(x.get('TargetType')=='DataGridCell' for x in resources))
        self.assertIn('RowHeaderWidth="0"',self.text('Controls/ExplorerPane.xaml'))
    def test_menu_separator_has_unclipped_layout_slot(self):
        root=ET.parse(APP/'App.xaml').getroot()
        key='{http://schemas.microsoft.com/winfx/2006/xaml}Key'
        style=next(x for x in root.iter() if x.get(key)=='SunriseMenuSeparator')
        height=next(x for x in style if x.get('Property')=='Height')
        self.assertEqual(height.get('Value'),'12')
        line=next(x for x in style.iter() if x.tag.endswith('Border'))
        self.assertEqual(line.get('Height'),'2')
        self.assertEqual(line.get('HorizontalAlignment'),'Stretch')
        self.assertEqual(line.get('VerticalAlignment'),'Center')
        self.assertIn('BasedOn="{StaticResource SunriseMenuSeparator}"',self.text('App.xaml'))
    def test_new_tab_and_parent_use_location_policy(self):
        pane=self.text('Controls/ExplorerPane.xaml.cs')
        self.assertIn('NewTab_Click(object sender, RoutedEventArgs e) => OpenTabAt(WindowsKnownLocations.ThisPc)',pane)
        self.assertIn('ExplorerLocationService.Parent(_activeTab.CurrentPath, WindowsKnownLocations.Resolve("Desktop"))',pane)
        nav=self.text('Features/Explorer/ExplorerPane.NavigationAndWatcher.cs')
        self.assertIn('IsThisPc ? await ExplorerLocationService.ReadThisPcAsync',nav)
        self.assertNotIn('SearchBox.Text = string.Empty;',nav)
    def test_saved_unavailable_tabs_and_search_are_preserved(self):
        pane=self.text('Controls/ExplorerPane.xaml.cs')
        self.assertNotIn('if (WindowsKnownLocations.Exists(path)) _tabs.Add',pane)
        self.assertIn('TabSearchTexts = _tabs.Select',pane)
        self.assertIn('ColumnSettings = FilesGrid.Columns.Select',pane)
        self.assertIn('ColumnOrder = SessionStore.CaptureDisplayOrder(FilesGrid.Columns.Select(column => column.DisplayIndex))',pane)
        self.assertIn('ExpandedTreePaths = NavigationTree.GetExpandedPaths()',pane)
    def test_all_main_preferences_are_saved_and_restored(self):
        save=self.text('MainWindow.xaml.cs')
        restore=self.text('Features/Workspace/MainWindow.Preferences.cs')
        for key in ['SplitRatios','LastSplitPresets','AiSettings','AiWindowVisible','PreviewFitWidth','PreviewZoom','MemoAuthor']:
            self.assertIn(key+' =',save)
            self.assertIn('session.'+key,restore)
        self.assertIn('if (_persistSession && !TrySaveSession(showError: true)) { e.Cancel = true; return; }',save)
    def test_restoring_ai_does_not_restore_an_execution_plan(self):
        cs=self.text('Controls/AiCommandPanel.xaml.cs')
        body=cs[cs.index('public void RestorePreferences'):cs.index('private void CloseAiPanel_Click')]
        self.assertIn('_suppressProviderPrompt = true',body)
        self.assertIn('_plan = null; _planContext = null; ExecuteButton.IsEnabled = false;',body)
        self.assertIn('finally { _suppressProviderPrompt = false; }',body)
if __name__=='__main__': unittest.main()
