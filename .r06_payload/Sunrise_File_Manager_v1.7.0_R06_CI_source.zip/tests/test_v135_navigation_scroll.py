"""v1.3.5 navigation horizontal offset isolation source checks.

Runtime interaction must be validated on Windows with UiSmokeTests.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'

class NavigationHorizontalScrollContract(unittest.TestCase):
    def test_outer_workspace_blocks_child_auto_pan_but_not_manual_scroll(self):
        shell = (APP / 'MainWindow.xaml.cs').read_text()
        xaml = (APP / 'MainWindow.xaml').read_text()
        self.assertIn('Workspace.AddHandler(FrameworkElement.RequestBringIntoViewEvent', shell)
        self.assertIn('if (!ReferenceEquals(e.OriginalSource, Workspace)) e.Handled = true;', shell)
        self.assertIn('x:Name="WorkspaceViewport"', xaml)
        self.assertIn('HorizontalScrollBarVisibility="Auto"', xaml)

    def test_tree_highlight_scrolls_vertical_only(self):
        tree = (APP / 'Controls/FolderTree.xaml.cs').read_text()
        self.assertNotIn('node.BringIntoView();', tree)
        self.assertIn('(headerRow ?? selectedNode).TransformToAncestor(NavigationScroll)', tree)
        self.assertIn('NavigationScroll.ScrollToVerticalOffset', tree)
        self.assertIn('version != _navigationVersion', tree)

    def test_folder_navigation_resets_file_list_after_layout(self):
        nav = (APP / 'Features/Explorer/ExplorerPane.NavigationAndWatcher.cs').read_text()
        filter_code = (APP / 'Features/Explorer/ExplorerPane.ViewAndFiltering.cs').read_text()
        model = (APP / 'Controls/ExplorerPane.xaml.cs').read_text()
        self.assertIn('bool newLocation = !string.Equals(_lastListingPath, path, StringComparison.OrdinalIgnoreCase)', nav)
        self.assertIn('if (newLocation && !_initializing)', nav)
        self.assertIn('_restoreViewportPending = false;', nav)
        self.assertIn('GetFilesScrollViewer()?.ScrollToHorizontalOffset(0);', nav)
        self.assertIn('_savedVerticalOffset = currentScroll.VerticalOffset;', nav)
        self.assertIn('_savedHorizontalOffset = currentScroll.HorizontalOffset;', nav)
        self.assertIn('DispatcherPriority.ContextIdle', filter_code)
        self.assertIn('_horizontalResetListingGeneration != listingGeneration', filter_code)
        self.assertIn('GetFilesScrollViewer()?.ScrollToHorizontalOffset(0);', filter_code)
        self.assertIn('private string? _lastListingPath;', model)

    def test_mouse_back_uses_same_folder_loader(self):
        code = (APP / 'Controls/ExplorerPane.xaml.cs').read_text()
        self.assertIn('e.ChangedButton == MouseButton.XButton1', code)
        self.assertIn('Back_Click(this, e);', code)
        self.assertIn('if (_activeTab?.Back() == true) { HasUserNavigated = true; _skipNavigationTreeReveal = false; _ = LoadFolderAsync(); }', code)

    def test_windows_ui_smoke_contains_navigation_case(self):
        smoke = (ROOT / 'source/tests/UiSmokeTests/Program.cs').read_text()
        self.assertIn('V135-folder-back-horizontal-scroll-stability', smoke)
        self.assertIn('pane.SyncToFolder(nestedFolder)', smoke)
        self.assertIn('pane.FindName("BackButton")', smoke)
        self.assertIn('workspaceViewport.HorizontalOffset', smoke)
        self.assertIn('fileScroll.HorizontalOffset', smoke)

if __name__ == '__main__':
    unittest.main()
