"""v1.3.5 targeted source-contract checks. Windows runtime smoke is separate."""
import unittest
from current_contract import CURRENT_VERSION
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'source/Sunrise.FileManager'
class V134Regression(unittest.TestCase):
    def test_cross_drive_route_and_source_guard(self):
        src=(APP/'Services/TransferService.cs').read_text()
        self.assertIn('MoveAcrossVolumesAsync(effectivePlan',src)
        self.assertIn('CopyAtomicallyAsync(plan, onBytes, token, control)',src)
        self.assertIn('VerifySourceUnchanged(plan)',src)
        snapshot=(APP/'Services/MemoTransferSnapshot.cs').read_text()
        self.assertIn('File.Delete(_source)', snapshot)
        move = src[src.index('private static async Task MoveAcrossVolumesAsync'):src.index('private static void VerifySourceUnchanged')]
        self.assertLess(move.index('await CopyAtomicallyAsync(plan, onBytes, token, control)'),move.index('VerifySourceUnchanged(plan)'))
        self.assertIn('memoSnapshot.DeleteSource(plan.Destination, () => VerifySourceUnchanged(plan), token)',move)
        self.assertLess(snapshot.index('VerifyDestination(destination);'),snapshot.index('File.Delete(_source)'))
        self.assertNotIn('이동은 동일 드라이브에서만 지원합니다',src)
        self.assertIn('memoSnapshot.CopyTo(plan.Destination, token)',src)
        self.assertIn('FileMemoStore.Save(destination', snapshot)
    def test_normal_drive_move_and_undo_keep_owner(self):
        transfer=(APP/'Services/TransferService.cs').read_text()
        actions=(APP/'Services/FileActionsService.cs').read_text()
        main=(APP/'MainWindow.xaml.cs').read_text()
        self.assertIn('FileActionsService.MoveEntry(effectivePlan.Source, effectivePlan.Destination)',transfer)
        self.assertIn('TransferService.IsDifferentVolume(source, destination)',actions)
        self.assertIn('FileMemoStore.MoveFileWithMemos(source, destination)',actions)
        self.assertIn('result.MovedPaths',main)
    def test_natural_filename_sort_in_both_panes(self):
        compare=(APP/'Services/FileListView.cs').read_text()
        scan=(APP/'Services/DirectoryScanner.cs').read_text()
        tree=(APP/'Services/FolderTreeScanner.cs').read_text()
        self.assertIn('StrCmpLogicalW',compare)
        self.assertIn('NaturalNameComparer.Instance.Compare(a.Name, b.Name)',compare)
        self.assertIn('NaturalNameComparer.Instance.Compare(a.Name, b.Name)',scan)
        self.assertIn('NaturalNameComparer.Instance.Compare(Path.GetFileName(a)',tree)
    def test_clipboard_dword_formats(self):
        pane=(APP/'Features/Explorer/ExplorerPane.ClipboardAndDragDrop.cs').read_text()
        self.assertIn('MemoryStream stream when stream.Length >= 4',pane)
        self.assertIn('byte[] bytes when bytes.Length >= 4',pane)
        self.assertIn('BitConverter.ToInt32(effectBytes, 0) & 2',pane)
    def test_version_aligned(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(),CURRENT_VERSION)
        self.assertIn(f'<Version>{CURRENT_VERSION}</Version>',(APP/'Sunrise.FileManager.csproj').read_text())
if __name__=='__main__': unittest.main()
