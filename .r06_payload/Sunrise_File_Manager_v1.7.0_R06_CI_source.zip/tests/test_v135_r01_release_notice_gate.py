from current_contract import CURRENT_VERSION
"""v1.3.5 R01 notice input and release metadata exit status contracts.
Static checks only; Windows signing and actual build remain separate gates.
"""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ReleaseNoticeGateR01(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cmd = (ROOT / 'BUILD_RELEASE_INSTALLER.cmd').read_text(encoding='ascii')
        cls.metadata = (ROOT / 'build-tools/Sunrise.FileManager.ReleaseMetadata/Program.cs').read_text(encoding='utf-8')
        cls.version = (ROOT / 'installer/RELEASE_VERSION.txt').read_text(encoding='utf-8').strip()


    def test_notice_gate_precedes_expensive_build_stages(self):
        s = self.cmd
        self.assertIn(r'set "NOTICE_TEMPLATE=%ROOT%\release\NOTICE_BODY_%SFM_APP_VERSION%.txt"', s)
        self.assertIn('if not exist "%NOTICE_TEMPLATE%" (', s)
        self.assertIn('VERSION_PROBLEM=VERSION_NOTICE_MISSING', s)
        self.assertIn('VERSION_PROBLEM=VERSION_NOTICE_EMPTY', s)
        self.assertLess(s.index('VERSION_PROBLEM=VERSION_NOTICE_MISSING'),
                        s.index(r'call "%ROOT%\BUILD_RELEASE_ONEDIR.cmd"'))
        self.assertLess(s.index('VERSION_PROBLEM=VERSION_NOTICE_MISSING'),
                        s.index('R15_inno_compile.log'))

    def test_nonzero_metadata_cli_exit_cannot_reach_artifact_check(self):
        s = self.cmd
        cli = '"%SUNRISE_DOTNET_RESOLVED%" "%METADATA_DLL%" "%ROOT%" "%FINAL_SETUP%" "%SFM_APP_VERSION%"'
        a = s.index(cli)
        b = s.index('set "FAILED_STAGE=RELEASE_ARTIFACT_VERIFY"', a)
        self.assertIn('if not "%ERRORLEVEL%"=="0" (', s[a:b])
        self.assertIn('goto :fail_metadata', s[a:b])
        self.assertNotIn('if errorlevel 1 (', s[a:b])

    def test_invalid_notice_exception_returns_normal_failure(self):
        s = self.metadata
        self.assertIn('Version-specific release notice missing:', s)
        self.assertIn('error is IOException or InvalidDataException', s)
        self.assertIn('Console.Error.WriteLine("[RELEASE METADATA ERROR] "', s)
        self.assertIn('return 1;', s)

    def test_existing_public_feed_and_signing_contracts_unchanged(self):
        s = self.cmd
        self.assertIn('"%SIGNTOOL%" verify /pa /v "%UNSIGNED_SETUP%"', s)
        self.assertIn('R15_SIGNED_SETUP_SHA256.txt', s)
        self.assertIn('REM Never overwrite committed latest.json or notice.txt on local builds.', s)
        self.assertIn('COMPANY_LOGIC_TESTS=SKIPPED', s)
        self.assertNotIn('release/NOTICE_BODY_1.3.5', (ROOT / 'latest.json').read_text(encoding='utf-8'))

    def test_build_cmd_remains_crlf_ascii(self):
        b = (ROOT / 'BUILD_RELEASE_INSTALLER.cmd').read_bytes()
        self.assertTrue(b.isascii())
        self.assertIn(b'\r\n', b)
        self.assertNotIn(b'\n', b.replace(b'\r\n', b''))


if __name__ == '__main__':
    unittest.main()
