"""Source-only checks for default bundled-runtime installer and future-native separation.
No Windows execution, networking, signing keys, project fixtures, or user files touched.
"""
import json
from pathlib import Path
import unittest
from current_contract import CURRENT_VERSION

ROOT=Path(__file__).resolve().parents[1]

class DualTrackDistribution(unittest.TestCase):
    def test_official_company_entry_is_self_contained_by_default(self):
        s=(ROOT/'BUILD_ON_WINDOWS_COMPANY.cmd').read_text('ascii')
        t=(ROOT/'BUILD_RELEASE_INSTALLER.cmd').read_text('ascii')
        self.assertIn('if not defined SUNRISE_LIGHTWEIGHT set "SUNRISE_LIGHTWEIGHT=0"',s)
        self.assertIn('if not defined SUNRISE_LIGHTWEIGHT set "SUNRISE_LIGHTWEIGHT=0"',t)
        self.assertIn('BUILD_RELEASE_INSTALLER.cmd',s)
        self.assertNotIn('set "SUNRISE_LIGHTWEIGHT=1"',s)
        self.assertIn('SELF_CONTAINED_DOTNET10_DESKTOP_X64',t)
        self.assertIn('LIGHTWEIGHT=%SUNRISE_LIGHTWEIGHT%',t)

    def test_publisher_bundles_runtime_and_guards_missing_files(self):
        s=(ROOT/'BUILD_RELEASE_ONEDIR.cmd').read_text('ascii')
        self.assertIn('set "SELF_CONTAINED=true"',s)
        self.assertIn('--self-contained %SELF_CONTAINED%',s)
        self.assertIn('if "%SUNRISE_LIGHTWEIGHT%"=="1" (',s)
        for name in ('hostfxr.dll','coreclr.dll','PresentationFramework.dll'):
            self.assertIn('app\\'+name,s)
        self.assertIn(':fail_bundled_runtime',s)

    def test_setup_size_policy_only_restricts_opt_in_lightweight(self):
        s=(ROOT/'BUILD_RELEASE_INSTALLER.cmd').read_text('ascii')
        self.assertIn('if "%SUNRISE_LIGHTWEIGHT%"=="1" for %%F',s)
        self.assertIn('GTR 10000000 goto :fail_lightweight_size',s)
        self.assertIn('SETUP_BYTES=%%~zF',s)
        self.assertNotIn('if "%SUNRISE_LIGHTWEIGHT%"=="0" for %%F',s)
        self.assertIn('RUNTIME_PAYLOAD_INCOMPLETE',s)

    def test_installer_runtime_check_only_for_legacy_mode(self):
        s=(ROOT/'installer/SunriseFileManager.iss').read_text('utf-8')
        self.assertIn('#if Lightweight == "1"\nfunction HasDesktopRuntimeInView',s)
        self.assertIn('#endif',s)
        self.assertIn('Source: "{#ReleaseSource}\\*"',s)
        self.assertIn('SignedUninstaller=yes',s)
        self.assertIn('AppMutex=Local\\SunriseFileManagerCEF',s)

    def test_c_track_not_misrepresented_as_delivered(self):
        m=json.loads((ROOT/'RELEASE_STATUS.json').read_text('utf-8'))
        self.assertEqual(m['source_version'],CURRENT_VERSION)
        self.assertEqual(m['package_kind'], 'installer')
        self.assertTrue(m['default_self_contained'])
        self.assertIn('PENDING',m['release_qualification'])

    def test_script_ascii_crlf_preserved(self):
        for n in ('BUILD_ON_WINDOWS_COMPANY.cmd','BUILD_RELEASE_INSTALLER.cmd','BUILD_RELEASE_ONEDIR.cmd'):
            b=(ROOT/n).read_bytes()
            self.assertTrue(b.isascii(),n)
            self.assertNotIn(b'\n',b.replace(b'\r\n',b''),n)

if __name__=='__main__': unittest.main()
