"""Execute the metadata CLI with synthetic fixtures, never real signing or publishing.

Run after building ReleaseMetadata and UpdateTests; accepts the installed .NET host.
The fixture's signature logs are synthetic prerequisites, not Windows signing proof.
"""
from current_contract import CURRENT_VERSION
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://github.com/Peter-msk/Sunrise-File-Manager'
DOTNET = None


class ReleaseMetadataBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='Sunrise metadata 한글 ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in ['installer', 'release', 'build-logs', 'dist']:
            (self.root / name).mkdir()
        self.version = CURRENT_VERSION
        self.feed_sentinel = b'{"unchanged_public_feed":true}\n'
        (self.root / 'latest.json').write_bytes(self.feed_sentinel)
        (self.root / 'notice.txt').write_bytes(b'Existing public notice\n')
        (self.root / 'build-logs/R15_verify_setup.log').write_text('SYNTHETIC TEST PREREQUISITE ONLY\n')
        (self.root / 'build-logs/R14_signing_certificate.txt').write_text(
            'THUMBPRINT=' + 'A' * 40 + '\nSUBJECT=CN=Sunrise Group\n')
        self.configure(self.version)

    def configure(self, version):
        self.version = version
        (self.root / 'installer/RELEASE_VERSION.txt').write_text(version + '\n')
        (self.root / f'release/NOTICE_BODY_{version}.txt').write_text(
            f'Sunrise File Manager {version} metadata fixture.\n', encoding='utf-8')
        self.setup = self.root / 'dist' / f'Sunrise_File_Manager_{version}_Setup.exe'
        self.setup.write_bytes(b'SYNTHETIC NON-EXECUTABLE TEST DATA\n' + b'A' * 1_000_000)

    def generate(self, version=None, setup=None, success=True):
        dll = ROOT / 'build-tools/Sunrise.FileManager.ReleaseMetadata/bin/Release/net10.0/Sunrise.FileManager.ReleaseMetadata.dll'
        result = subprocess.run([DOTNET, str(dll), str(self.root), str(setup or self.setup), version or self.version],
                                capture_output=True, text=True, encoding='utf-8', timeout=30)
        if success:
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.root / 'latest.json').read_bytes(), self.feed_sentinel)
        self.assertEqual((self.root / 'notice.txt').read_bytes(), b'Existing public notice\n')
        return result

    def bundle(self):
        directory = self.root / 'dist/release-metadata'
        expected_name = self.setup.name
        latest = json.loads((directory / 'latest.json').read_text())
        release = json.loads((directory / 'release_info.json').read_text())
        manifest = json.loads((directory / 'sunrise_file_manager_product_manifest.json').read_text())
        expected_download = f'{BASE}/releases/download/v{self.version}/{expected_name}'
        expected_release = f'{BASE}/releases/tag/v{self.version}'
        digest = hashlib.sha256(self.setup.read_bytes()).hexdigest()
        for value in [latest, release]:
            self.assertIs(value['update_endpoint_configured'], True)
            self.assertEqual(value['download_url'], expected_download)
            self.assertEqual(value['release_url'], expected_release)
            self.assertEqual(value['sha256'], digest)
        self.assertEqual(latest['version'], self.version)
        self.assertEqual(latest['latest_version'], self.version)
        self.assertEqual(latest['download_file_name'], expected_name)
        self.assertEqual(latest['file_size_bytes'], self.setup.stat().st_size)
        self.assertEqual(release['installer_size_bytes'], latest['file_size_bytes'])
        self.assertEqual(release['publication_status'], 'LOCAL_SIGNED_BUILD_PENDING_PUBLICATION')
        self.assertIs(manifest['distribution']['public_distribution_validated'], False)
        self.assertEqual(manifest['artifacts']['sha256'], digest)
        self.assertEqual(manifest['distribution']['proposed_release_page'], expected_release)
        guide = (directory / 'UPLOAD_TO_GITHUB.txt').read_text(encoding='utf-8')
        self.assertIn(expected_download, guide)
        self.assertIn('latest.json은 마지막', guide)
        self.assertEqual({p.name for p in directory.iterdir()}, {
            'latest.json', 'notice.txt', 'release_info.json', 'sunrise_file_manager_product_manifest.json',
            'UPLOAD_TO_GITHUB.txt', 'SIGNATURE_VERIFY_RESULT.txt'})
        return latest

    def read_with_runtime(self):
        dll = ROOT / 'source/tests/UpdateTests/bin/Release/net10.0/UpdateTests.dll'
        result = subprocess.run([DOTNET, str(dll), '--read-generated-release',
                                 str(self.root / 'dist/release-metadata/latest.json')],
                                capture_output=True, text=True, encoding='utf-8', timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def test_new_build_without_publication_record_has_complete_enabled_feed(self):
        self.generate()
        self.bundle()

    def test_old_publication_cannot_disable_new_build(self):
        (self.root / 'release/PUBLISHED_RELEASE.json').write_text(json.dumps({
            'version': '1.1.0', 'publication_status': 'UPSTREAM_FEED_TARGET_UNAVAILABLE',
            'sha256': '0' * 64, 'file_size_bytes': 1}))
        self.generate()
        self.bundle()

    def test_malformed_historical_record_does_not_block_generation(self):
        (self.root / 'release/PUBLISHED_RELEASE.json').write_text('{broken old snapshot')
        self.generate()
        self.bundle()

    def test_future_version_urls_follow_version_and_filename(self):
        self.configure('9.8.7')
        self.generate()
        self.bundle()
        self.assertTrue(self.read_with_runtime()['CanDownload'])

    def test_same_version_rebuild_refreshes_hash_and_size_without_disabling(self):
        self.generate()
        previous = self.bundle()
        with self.setup.open('ab') as output:
            output.write(b'Rebuilt installer bytes')
        self.generate()
        rebuilt = self.bundle()
        self.assertNotEqual(previous['sha256'], rebuilt['sha256'])
        self.assertNotEqual(previous['file_size_bytes'], rebuilt['file_size_bytes'])

    def test_configured_feed_still_respects_runtime_version_comparison(self):
        self.generate()
        self.bundle()
        parsed = self.read_with_runtime()
        self.assertEqual(parsed['Version'], CURRENT_VERSION)
        self.assertFalse(parsed['CanDownload'])  # An equal version must not prompt another update.

    def test_version_mismatch_fails_before_metadata_writes(self):
        self.generate(version='1.3.3', success=False)
        self.assertFalse((self.root / 'dist/release-metadata').exists())

    def test_wrong_installer_filename_fails(self):
        other = self.setup.with_name('Wrong_Setup.exe')
        self.setup.rename(other)
        self.generate(setup=other, success=False)
        self.assertFalse((self.root / 'dist/release-metadata').exists())

    def test_missing_signature_stage_evidence_fails(self):
        (self.root / 'build-logs/R15_verify_setup.log').unlink()
        self.generate(success=False)
        self.assertFalse((self.root / 'dist/release-metadata').exists())

    def test_invalid_signer_evidence_fails(self):
        (self.root / 'build-logs/R14_signing_certificate.txt').write_text('THUMBPRINT=bad\nSUBJECT=Other\n')
        self.generate(success=False)
        self.assertFalse((self.root / 'dist/release-metadata').exists())

    def test_missing_notice_preserves_existing_generated_bundle(self):
        self.generate()
        directory = self.root / 'dist/release-metadata'
        previous = {p.name: p.read_bytes() for p in directory.iterdir()}
        (self.root / f'release/NOTICE_BODY_{self.version}.txt').unlink()
        self.generate(success=False)
        self.assertEqual(previous, {p.name: p.read_bytes() for p in directory.iterdir()})

    def test_small_or_missing_installer_cannot_generate_enabled_feed(self):
        self.setup.write_bytes(b'not a release artifact')
        self.generate(success=False)
        self.setup.unlink()
        self.generate(success=False)
        self.assertFalse((self.root / 'dist/release-metadata').exists())


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--dotnet', required=True)
    options = parser.parse_args()
    DOTNET = options.dotnet
    unittest.main(argv=[__file__], verbosity=2)
