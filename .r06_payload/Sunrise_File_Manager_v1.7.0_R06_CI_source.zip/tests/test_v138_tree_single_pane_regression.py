from current_contract import CURRENT_VERSION
"""v1.3.8 regression guards; Windows WPF runtime interaction remains pending."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'

class V138TreeAndSelection(unittest.TestCase):
    def test_tree_isexpanded_is_single_source_of_truth(self):
        app = (APP/'Controls/FolderTree.xaml').read_text('utf-8')
        tree = (APP/'Controls/FolderTree.xaml.cs').read_text('utf-8')
        self.assertIn('Mode=OneWay}', app)
        self.assertNotIn('Mode=TwoWay}', app.split('x:Name="ExpandToggle"')[1].split('</ToggleButton>')[0])
        self.assertIn('new RoutedEventHandler(FolderExpander_Click)',tree)
        self.assertIn('item.IsExpanded = !item.IsExpanded;',tree)
        self.assertIn('++_navigationVersion; // Invalidate pending reveal AND its queued scroll callback.',tree)
        self.assertIn('FolderItems_PreviewMouseLeftButtonDown',tree)
        self.assertNotIn('FolderItems_MouseDoubleClick',tree)
    def test_all_panes_pointer_selection_retain_manual_horizontal_offset(self):
        code = (APP/'Controls/ExplorerPane.xaml.cs').read_text('utf-8')
        self.assertIn('if (row?.Item is FileEntry) PreservePointerSelectionHorizontalOffset();',code)
        self.assertNotIn('if (!_compactMode && row?.Item is FileEntry)',code)
        self.assertIn('int listingGeneration = _listingGeneration;',code)
        self.assertIn('DispatcherPriority.ContextIdle',code)
        self.assertIn('Math.Clamp(previousOffset, 0, scroll.ScrollableWidth)',code)
        self.assertIn('if ((Keyboard.Modifiers & ModifierKeys.Shift) == 0 || e.Delta == 0) return;',code)
    def test_release_version_and_notice(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(),f'{CURRENT_VERSION}')
        notice=(ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for private in ('https://','download_url','release_url','latest.json','github.com'):
            self.assertNotIn(private, notice)
        ET.parse(APP/'App.xaml')
        ET.parse(APP/'Controls/ExplorerPane.xaml')

if __name__ == '__main__': unittest.main()
