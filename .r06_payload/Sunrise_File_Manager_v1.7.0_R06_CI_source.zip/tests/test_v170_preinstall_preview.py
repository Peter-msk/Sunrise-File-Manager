"""v1.7.0 R00: signed install-free preview + default installer build contract.
Windows signing, executable creation and native launch are separate dynamic gates.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENTRY = (ROOT / 'BUILD_ON_WINDOWS_COMPANY.cmd').read_text('ascii')
INSTALLER = (ROOT / 'BUILD_RELEASE_INSTALLER.cmd').read_text('ascii')
ONEDIR = (ROOT / 'BUILD_RELEASE_ONEDIR.cmd').read_text('ascii')
PREVIEW = (ROOT / 'BUILD_PREVIEW_ON_WINDOWS.cmd').read_text('ascii')
PACKAGE = (ROOT / 'build-tools/PackageSignedPreview.cmd').read_text('ascii')

class SignedPreinstallPreview(unittest.TestCase):
    def test_default_installer_includes_preview(self):
        self.assertIn('SUNRISE_LIGHTWEIGHT=0', ENTRY)
        self.assertIn('BUILD_RELEASE_INSTALLER.cmd" --company --no-pause', ENTRY)
        self.assertIn('PackageSignedPreview.cmd" "%APP_DIR%" "%SFM_APP_VERSION%"', INSTALLER)
        self.assertIn('PREVIEW_EXE=', INSTALLER)
        self.assertIn('PREVIEW_ZIP=', INSTALLER)
        self.assertLess(INSTALLER.index('call "%ROOT%\\BUILD_RELEASE_ONEDIR.cmd"'),
                        INSTALLER.index('PackageSignedPreview.cmd" "%APP_DIR%"'))
        self.assertLess(INSTALLER.index('PackageSignedPreview.cmd" "%APP_DIR%"'),
                        INSTALLER.index('R15_inno_compile.log'))

    def test_preview_only_has_no_installer_requirement(self):
        self.assertIn('set "SUNRISE_LIGHTWEIGHT=0"', PREVIEW)
        self.assertIn('BUILD_RELEASE_ONEDIR.cmd" --company --no-pause --installer-payload', PREVIEW)
        self.assertIn('PackageSignedPreview.cmd"', PREVIEW)
        self.assertNotIn('BUILD_RELEASE_INSTALLER.cmd', PREVIEW)
        self.assertNotIn('ISCC.exe', PREVIEW)
        self.assertNotIn('dotnet test', PREVIEW.lower())

    def test_existing_signing_and_control_cannot_be_bypassed(self):
        for mandatory in ('EnsureSunriseGroupSigning.cmd', '"%SIGNTOOL%" sign',
                          '"%SIGNTOOL%" verify /pa /v', 'SUNRISE_CERT_THUMBPRINT'):
            self.assertIn(mandatory, ONEDIR)
        for forbidden in ('Add-MpPreference', 'certutil -addstore Root', 'SUNRISE_SKIP_CONTROL',
                          'SKIP_SIGNATURE', 'DisableRealtimeMonitoring'):
            self.assertNotIn(forbidden, PREVIEW + PACKAGE + INSTALLER)
        self.assertIn('fc /b "%SOURCE_APP%\\Sunrise.FileManager.exe"', PACKAGE)
        self.assertIn('fc /b "%SOURCE_APP%\\Sunrise.FileManager.dll"', PACKAGE)
        self.assertNotIn('signtool sign', PACKAGE.lower())

    def test_direct_exe_is_at_preview_root_with_full_runtime(self):
        self.assertIn('Sunrise_File_Manager_%APP_VERSION%_Preview', PACKAGE)
        self.assertIn('"%FINAL%\\Sunrise.FileManager.exe"', PACKAGE)
        self.assertIn('"%SOURCE_APP%" "%STAGE%" /E', PACKAGE)
        self.assertIn('hostfxr.dll coreclr.dll PresentationFramework.dll', PACKAGE)
        self.assertIn('Sunrise.FileManager.runtimeconfig.json', PACKAGE)
        self.assertIn('tar.exe -a -c -f "%ZIP_STAGE%" -C "%STAGE%" .', PACKAGE)
        self.assertIn('README_PREVIEW.txt', PACKAGE)
        self.assertNotIn('start ""', PACKAGE)

    def test_previous_preview_preserved_on_package_failure(self):
        self.assertLess(PACKAGE.index('set "FAILED_STAGE=ZIP"'), PACKAGE.index('set "FAILED_STAGE=COMMIT"'))
        self.assertLess(PACKAGE.index('move "%FINAL%" "%BACKUP%"'), PACKAGE.index('move "%STAGE%" "%FINAL%"'))
        self.assertIn(':restore\n', PACKAGE.replace('\r\n','\n'))
        self.assertIn('move "%BACKUP%" "%FINAL%"', PACKAGE)
        self.assertIn('if errorlevel 8 goto :fail', PACKAGE)
        self.assertIn('if errorlevel 1 goto :fail_preview', INSTALLER)

    def test_preview_artifact_is_not_published_update_metadata(self):
        self.assertNotIn('latest.json', PACKAGE)
        self.assertNotIn('notice.txt', PACKAGE)
        self.assertNotIn('Sunrise_Control', PACKAGE)
        self.assertIn('COMPANY_SOURCE_ONLY.flag', PREVIEW)
        self.assertNotIn('update_endpoint_configured', PACKAGE)
        self.assertIn('release-metadata', INSTALLER)

    def test_cmds_ascii_crlf(self):
        for file in ('BUILD_ON_WINDOWS_COMPANY.cmd','BUILD_RELEASE_INSTALLER.cmd',
                     'BUILD_PREVIEW_ON_WINDOWS.cmd','build-tools/PackageSignedPreview.cmd'):
            with self.subTest(file=file):
                data=(ROOT / file).read_bytes()
                self.assertTrue(data.isascii())
                self.assertIn(b'\r\n',data)
                self.assertNotIn(b'\n',data.replace(b'\r\n', b''))

if __name__ == '__main__':
    unittest.main()
