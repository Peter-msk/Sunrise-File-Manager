"""Targeted source guard for the exact R14 WPF compile diagnostic (CS0103)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
FILE = ROOT / "source/Sunrise.FileManager/Features/Explorer/ExplorerPane.PagedSelection.cs"

class WpfCompileFix(unittest.TestCase):
    def test_exception_namespace_in_paged_selection(self):
        content = FILE.read_text(encoding="utf-8")
        self.assertIn("using System.IO;", content)
        self.assertIn("ex is IOException or UnauthorizedAccessException", content)

    def test_release_build_preserves_failure_diagnostics(self):
        r14 = (ROOT / "BUILD_RELEASE_ONEDIR.cmd").read_text(encoding="utf-8-sig")
        r15 = (ROOT / "BUILD_RELEASE_INSTALLER.cmd").read_text(encoding="utf-8-sig")
        self.assertIn("R14_compiler_errors.log", r14)
        self.assertIn("PAYLOAD_SUBSTAGE", r15)
        self.assertIn(":fail_wpf_publish", r14)

if __name__ == "__main__":
    unittest.main()
