"""Source-level smoke only. These checks never assert Windows runtime success."""
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "source/Sunrise.FileManager"


def read(name):
    return (APP / name).read_text(encoding="utf-8")


class V150R01Contract(unittest.TestCase):
    def test_xml_entrypoints(self):
        ET.parse(APP / "MainWindow.xaml")
        ET.parse(APP / "Controls/ExplorerPane.xaml")
        ET.parse(APP / "Sunrise.FileManager.csproj")
        ET.parse(ROOT / "source/tests/LogicTests/LogicTests.csproj")

    def test_shellnew_is_inert_and_linked(self):
        c = read("Services/ShellNewTemplateService.cs")
        self.assertIn('Registry.ClassesRoot', c)
        self.assertIn('GetValue("Command")', c)
        self.assertIn('GetValue("Handler")', c)
        self.assertIn('FileMode.CreateNew', c)
        self.assertIn('Path.GetFileName(fileName) != fileName', c)
        self.assertNotIn('Process.Start(', c)
        self.assertIn('ShellNewTemplates_Opened', read("Controls/ExplorerPane.xaml"))
        self.assertIn('ShellNewTemplate_Click', read("Features/Explorer/ExplorerPane.ShellNew.cs"))

    def test_multiwindow_not_multi_process(self):
        c = read("App.xaml.cs")
        self.assertIn('OpenAdditionalWindow(', c)
        self.assertIn('RegisterWorkspace(main)', c)
        self.assertIn('if (remaining.Length == 0) Shutdown()', c)
        self.assertIn('Count() > 1', c)
        self.assertIn('MainWindow(session)', c)
        self.assertIn('Panels = [pane]', read("Features/Workspace/MainWindow.MultiWindow.cs"))
        self.assertIn('private readonly bool _persistSession;', read('MainWindow.xaml.cs'))
        self.assertIn('Ctrl+Shift+W', read('MainWindow.xaml'))

    def test_recycle_is_shell_only_and_confirmed(self):
        ui = read('Features/Explorer/ExplorerPane.RecycleBin.cs')
        shell = read('Services/RecycleBinService.cs')
        self.assertIn('PermanentDeleteRecycle_Click', ui)
        self.assertIn('MessageBoxButton.YesNo', ui)
        self.assertIn('PermanentlyDeleteAsync', ui)
        self.assertIn('RecycleBinNativeDelete.Delete(', shell)
        self.assertNotIn('InvokeVerb("delete")', shell)
        self.assertIn('requestedKeys.Contains(Key(', shell)
        self.assertIn('20,000개 이하', shell)
        self.assertNotIn('File.Delete(', shell)

    def test_search_subset_uses_canonical_query(self):
        c = read('Services/ExplorerQuery.cs')
        scanner = read('Services/ExplorerSearchService.cs')
        self.assertIn('public static bool IsStructured(', c)
        for token in ['case "path"', 'case "extension"', 'case "is"', 'case "datemodified"']:
            self.assertIn(token, c)
        self.assertIn('ExplorerQuery.Parse(query)', scanner)
        self.assertIn('metadataFilter.Matches(', scanner)
        self.assertIn('if (ExplorerQuery.IsStructured(query)) throw', scanner)

    def test_zip_staging_and_bounds(self):
        c = read('Services/ZipEditService.cs')
        for token in ['512L * 1024 * 1024', 'MaxEntries', 'File.Replace(staging, original, backup)',
                      'ZipFile.OpenRead(staging)', 'token.ThrowIfCancellationRequested()',
                      'Path.GetFullPath(archivePath)', 'ReparsePointPolicy.IsBlocked']:
            self.assertIn(token, c)
        self.assertNotIn('Process.Start', c)
        self.assertIn('ZipEditService.Apply(', read('Controls/ArchiveContentsWindow.cs'))
        self.assertIn('browser.WasModified', read('Features/Explorer/ExplorerPane.ExtraActions.cs'))

    def test_recovery_is_bounded_not_automatic_move(self):
        c = read('Services/TransferRecoveryJournal.cs')
        self.assertIn('sources.Count is < 1 or > 1000', c)
        self.assertIn('Directory.GetFiles(directory, "transfer-*.json").Length >= 20', c)
        self.assertIn('plan.Kind != TransferKind.Copy', c)
        self.assertIn('source.Directory', c)
        self.assertIn('info.Length != source.Size', c)
        self.assertIn('FileMode.CreateNew', c)
        self.assertIn('TransferRecoveryJournal.Begin(', read('MainWindow.xaml.cs'))
        self.assertIn('TransferRecoveryJournal.Finish(', read('MainWindow.xaml.cs'))
        ui = read('Features/Workspace/MainWindow.RecoveryJournal.cs')
        self.assertIn('MessageBoxButton.YesNo', ui)
        self.assertIn('TransferKind.Copy', ui)
        self.assertNotIn('TransferKind.Move,', ui)

    def test_regression_runner_includes_test(self):
        c = (ROOT / 'source/tests/LogicTests/Program.cs').read_text()
        self.assertIn('--v150-r01', c)
        self.assertIn('await V150R01Tests.RunAsync()', c)
        for dependency in ['ZipEditService.cs', 'ShellNewTemplateService.cs', 'TransferRecoveryJournal.cs']:
            self.assertIn(dependency, (ROOT / 'source/tests/LogicTests/LogicTests.csproj').read_text())

if __name__ == '__main__':
    unittest.main()
