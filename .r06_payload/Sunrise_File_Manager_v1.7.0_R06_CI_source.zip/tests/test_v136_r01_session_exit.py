from current_contract import CURRENT_VERSION
"""Regression contract for v1.3.6 R01 WPF explorer session capture."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source' / 'Sunrise.FileManager'

class SessionExitRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.explorer = (APP/'Controls/ExplorerPane.xaml.cs').read_text(encoding='utf-8')
        cls.session = (APP/'Services/SessionStore.cs').read_text(encoding='utf-8')

    def test_inactive_grid_display_index_normalized(self):
        self.assertIn('ColumnOrder = SessionStore.CaptureDisplayOrder(FilesGrid.Columns.Select(column => column.DisplayIndex))', self.explorer)
        self.assertNotIn('ColumnOrder = FilesGrid.Columns.Select(column => column.DisplayIndex).ToList()', self.explorer)
        self.assertIn('Enumerable.Range(0, order.Length).ToList()', self.session)
        self.assertIn('ColumnOrder = SessionStore.CaptureDisplayOrder(i == 0 ? new[] { 1, 0, 2, 3 } : new[] { -1, -1, -1, -1 })', (ROOT/'source/tests/LogicTests/V132FeatureTests.cs').read_text(encoding='utf-8'))

    def test_invalid_geometry_normalized_only_at_ui_capture(self):
        self.assertIn('TreeWidth = NavigationPanelPolicy.NormalizeWidth(_navigationWidth)', self.explorer)
        self.assertIn('ColumnSettings = FilesGrid.Columns.Select(column => SessionStore.CaptureColumnWidth(', self.explorer)
        self.assertIn('TreeScrollOffset = SessionStore.CaptureScrollOffset(', self.explorer)
        self.assertIn('FileVerticalOffset = SessionStore.CaptureScrollOffset(', self.explorer)
        self.assertIn('FileHorizontalOffset = SessionStore.CaptureScrollOffset(', self.explorer)
        self.assertIn('double.IsFinite(value) ? Math.Clamp(value, 0, 1_000_000_000) : 0', self.session)

    def test_validation_and_error_handling_still_enforced(self):
        self.assertIn('throw new ArgumentException("파일 목록 열 순서 설정 값이 올바르지 않습니다.")', self.session)
        self.assertIn('panel.ColumnOrder.Distinct().Count() != panel.ColumnOrder.Count', self.session)
        self.assertIn('File.Move(temp, path, overwrite: true)', self.session)
        self.assertIn('if (_persistSession && !TrySaveSession(showError: true))', (APP/'MainWindow.xaml.cs').read_text(encoding='utf-8'))
        self.assertIn('MaxLength="1000"', (APP/'Controls/ExplorerPane.xaml').read_text(encoding='utf-8'))

    def test_no_version_or_update_contract_changes(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text(encoding='utf-8').strip(), f'{CURRENT_VERSION}')
        self.assertIn(f'<Version>{CURRENT_VERSION}</Version>', (APP/'Sunrise.FileManager.csproj').read_text(encoding='utf-8'))
        self.assertTrue((ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').is_file())

if __name__ == '__main__':
    unittest.main()
