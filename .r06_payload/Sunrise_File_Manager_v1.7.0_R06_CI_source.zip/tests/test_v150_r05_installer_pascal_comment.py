"""Regression for the actual R04 ISCC line 86 / 'BEGIN' expected failure.

Source-only check; does not compile Setup or access document fixtures.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


def invalid_code_comments(script):
    in_code = False
    failures = []
    for number, line in enumerate(script.splitlines(), 1):
        text = line.strip()
        if re.fullmatch(r"\[[^\]]+\]", text):
            in_code = text.lower() == "[code]"
        elif in_code and re.match(r";\s*[A-Za-z]", text):
            failures.append(number)
    return failures


class InstallerPascalComments(unittest.TestCase):
    def test_installer_has_no_ini_style_prose_in_pascal_code(self):
        script = (ROOT / 'installer/SunriseFileManager.iss').read_text('utf-8')
        self.assertEqual(invalid_code_comments(script), [],
                         'Use Pascal // comments in [Code], not INI ; comments')

    def test_detector_rejects_original_failure(self):
        script = (ROOT / 'installer/SunriseFileManager.iss').read_text('utf-8')
        fixed = '// Only the optional legacy lightweight build may require a shared runtime.'
        self.assertEqual(script.count(fixed), 1)
        original = script.replace(fixed, ';' + fixed[2:])
        self.assertEqual(invalid_code_comments(original), [86])

    def test_setup_comments_and_pascal_statements_are_allowed(self):
        self.assertEqual(invalid_code_comments(
            '[Setup]\n; Normal setup comment\nAppName=Example\n[Code]\n'
            '// Pascal comment\nfunction Ready: Boolean;\nbegin\n'
            "  Result := True;\nend;\n"), [])


if __name__ == '__main__':
    unittest.main()
