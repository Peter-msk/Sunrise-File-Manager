"""Supplementary source contracts; Windows runtime verification is separate."""
import unittest, xml.etree.ElementTree as ET
from pathlib import Path
APP = Path(__file__).resolve().parents[1] / 'source/Sunrise.FileManager'
NS = {'w':'http://schemas.microsoft.com/winfx/2006/xaml/presentation'}
class V130Contracts(unittest.TestCase):
    def text(self,p): return (APP/p).read_text()
    def test_alignment_and_type_header(self):
        root=ET.parse(APP/'Controls/ExplorerPane.xaml').getroot()
        columns=root.findall('.//w:DataGrid.Columns/*',NS)
        self.assertEqual(columns[0].get('Header'),'구분')
        for c in columns[3:]:
            self.assertEqual(c.get('ElementStyle'),'{StaticResource CenteredFileCell}')
            self.assertEqual(c.get('HeaderStyle'),'{StaticResource CenteredFileHeader}')
    def test_theme_menu_template_and_no_icon_gutter(self):
        x=self.text('App.xaml')
        self.assertIn('<ControlTemplate TargetType="ContextMenu">',x)
        self.assertNotIn('ContentSource="Icon"',x)
        self.assertNotIn('MenuCheck',x)
        self.assertIn('x:Name="IconColumn" Width="0"',x)
    def test_scrollbar_system_dimensions(self):
        root=ET.parse(APP/'App.xaml').getroot()
        resources=root[0]
        key='{http://schemas.microsoft.com/winfx/2006/xaml}Key'
        for name in ['VerticalScrollBarWidthKey','HorizontalScrollBarHeightKey']:
            self.assertEqual(next(x for x in resources if name in x.get(key,'')).text,'6')
    def test_inspector_close_uses_existing_memo_guard(self):
        self.assertIn('Click="CloseMemo_Click"',self.text('Controls/FileMemoPanel.xaml'))
        self.assertIn('MemoPanel.CloseRequested += () => SetMemoVisible(false)',self.text('MainWindow.xaml.cs'))
        self.assertIn('MemoPanel.ConfirmLeavingMemo()',self.text('MainWindow.xaml.cs'))
    def test_ai_selector_visible_and_header_contrast(self):
        root=ET.parse(APP/'Controls/OllamaSetupDialog.xaml').getroot()
        selector=next(x for x in root.iter() if x.get('{http://schemas.microsoft.com/winfx/2006/xaml}Name')=='ModelSelector')
        self.assertNotIn('Width',selector.attrib)
        self.assertIn('Foreground="White"',self.text('Controls/OllamaSetupDialog.xaml'))
        self.assertNotIn('SelectModelItem(report.ActiveModel)',self.text('Controls/OllamaSetupDialog.xaml.cs'))
    def test_known_folders_and_internal_recycle(self):
        navigation=self.text('Features/Navigation/FolderTree.QuickAccessAndDrives.cs')
        self.assertIn('WindowsKnownLocations.Resolve(key)',navigation)
        self.assertNotIn('Process.Start',navigation)
        self.assertIn('SHGetKnownFolderPath',self.text('Services/WindowsKnownLocations.cs'))
        pane=self.text('Controls/ExplorerPane.xaml.cs')
        self.assertIn('if (IsRecycleBin || IsThisPc) return Array.Empty<string>();',pane)
        self.assertIn('WindowsKnownLocations.IsVirtual(CurrentLocation) ? null',pane)
        self.assertIn('IsVirtual = true',self.text('Services/RecycleBinService.cs'))
    def test_virtual_columns_do_not_leak_into_normal_views(self):
        view=self.text('Features/Explorer/ExplorerPane.ViewAndFiltering.cs')
        self.assertIn('IsRecycleBin && spec.ShowAllDetailColumns ? Visibility.Visible : Visibility.Collapsed',view)
        self.assertIn('Math.Min(7, FilesGrid.Columns.Count)',view)
        nav=self.text('Features/Explorer/ExplorerPane.NavigationAndWatcher.cs')
        swapped=nav[nav.index('private void RefreshSwappedPaneUi()'):nav.index('private void AttachFolderWatcher')]
        self.assertIn('ConfigureRecycleBinView();',swapped)
    def test_new_model_requests_are_bounded(self):
        self.assertIn('body["think"] = false',self.text('Services/AiOllamaService.cs'))
        self.assertIn('options["num_ctx"] = 4096',self.text('Services/AiOllamaService.cs'))
if __name__=='__main__': unittest.main()
