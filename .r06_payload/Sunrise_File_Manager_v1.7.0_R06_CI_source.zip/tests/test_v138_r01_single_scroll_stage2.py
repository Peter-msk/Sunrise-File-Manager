from current_contract import CURRENT_VERSION
"""Stage-2 regression: one shared navigation scroll only, explicit current location.

Native WPF mouse and layout are subject to the pending Windows dynamic gate.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'source/Sunrise.FileManager'
NS='{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'

class SingleScrollStage2(unittest.TestCase):
    def setUp(self):
        self.xaml=(APP/'Controls/FolderTree.xaml').read_text(encoding='utf-8')
        self.cs=(APP/'Controls/FolderTree.xaml.cs').read_text(encoding='utf-8')

    def test_one_navigation_scroll_keeps_all_sections_together(self):
        root=ET.fromstring(self.xaml)
        sv=list(root.iter(NS+'ScrollViewer'))
        self.assertEqual(len(sv),1)
        self.assertEqual(sv[0].get('{http://schemas.microsoft.com/winfx/2006/xaml}Name'),'NavigationScroll')
        self.assertEqual(sv[0].get('HorizontalScrollBarVisibility'), 'Auto')
        self.assertEqual(sv[0].get('VerticalScrollBarVisibility'), 'Auto')
        self.assertEqual(sv[0].get('PanningMode'), 'Both')
        self.assertIn('빠른 이동 · 기본 폴더',self.xaml)
        self.assertIn('즐겨찾기 고정 폴더',self.xaml)
        self.assertIn('FolderItems',self.xaml)
        self.assertNotIn('QuickAccessScroll',self.xaml)
        self.assertNotIn('QuickSectionToggle',self.xaml)
        self.assertNotIn('NavigationSections',self.xaml)
        self.assertIn('ScrollViewer.VerticalScrollBarVisibility="Disabled"',self.xaml)

    def test_current_location_is_explicit_without_changing_quick_access_behavior(self):
        self.assertIn('x:Name="LocateCurrentButton"',self.xaml)
        self.assertIn('Click="LocateCurrent_Click"',self.xaml)
        self.assertIn('private async void LocateCurrent_Click',self.cs)
        self.assertIn('CollapseInactiveBranches(path);',self.cs)
        self.assertIn('await HighlightPathAsync(path);',self.cs)
        self.assertIn('if (!Directory.Exists(path)) return;',self.cs)
        self.assertIn('QuickPathChosen?.Invoke(path)', (APP/'Features/Navigation/FolderTree.QuickAccessAndDrives.cs').read_text('utf-8'))
        self.assertIn('CollapseInactiveBranches(_skipNavigationTreeReveal ? null : path)', (APP/'Features/Explorer/ExplorerPane.NavigationAndWatcher.cs').read_text('utf-8'))

    def test_deep_folders_scroll_header_row_not_expanded_descendant_height(self):
        self.assertIn('selectedNode.Template.FindName("TreeRow", selectedNode)',self.cs)
        self.assertIn('double height = headerRow is { ActualHeight: > 0 } ? headerRow.ActualHeight : 38.0',self.cs)
        self.assertNotIn('double bottom = top + selectedNode.ActualHeight',self.cs)
        self.assertIn('(headerRow ?? selectedNode).TransformToAncestor(NavigationScroll)',self.cs)
        self.assertIn('NavigationScroll.ScrollToVerticalOffset(Math.Clamp(centered, 0, NavigationScroll.ScrollableHeight))',self.cs)
        self.assertNotIn('selectedNode.BringIntoView()',self.cs)
        self.assertIn('version != _navigationVersion',self.cs)

    def test_stage1_density_remains_and_drive_toggle_is_not_rewritten(self):
        self.assertIn('Margin="16,0,0,0"',self.xaml)
        self.assertIn('Width="40" Height="36"',self.xaml)
        self.assertIn('Mode=OneWay}',self.xaml)
        self.assertIn('item.IsExpanded = !item.IsExpanded;',self.cs)

    def test_release_and_public_notice_unchanged(self):
        self.assertEqual((ROOT/'installer/RELEASE_VERSION.txt').read_text().strip(),f'{CURRENT_VERSION}')
        notice=(ROOT/f'release/NOTICE_BODY_{CURRENT_VERSION}.txt').read_text('utf-8').lower()
        for forbidden in ('download_url','latest.json','https://','github.com','release_url'):
            self.assertNotIn(forbidden,notice)

if __name__=='__main__': unittest.main()
