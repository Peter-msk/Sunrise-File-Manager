"""Source guards for the reported blank/drifting file list after single -> split.

The opt-in Windows scenario checks real extent/offset/label geometry; these
guards do not claim Windows runtime success.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'source/Sunrise.FileManager'
X = '{http://schemas.microsoft.com/winfx/2006/xaml}'
P = '{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'


class FileViewportRegression(unittest.TestCase):
    def test_file_grid_reserves_horizontal_control_and_keeps_row_virtualization(self):
        root = ET.parse(APP / 'Controls/ExplorerPane.xaml').getroot()
        grid = next(node for node in root.iter(P + 'DataGrid') if node.get(X + 'Name') == 'FilesGrid')
        self.assertEqual(grid.get('ScrollViewer.HorizontalScrollBarVisibility'), 'Visible')
        self.assertEqual(grid.get('EnableColumnVirtualization'), 'False')
        self.assertEqual(grid.get('EnableRowVirtualization'), 'True')

    def test_viewer_is_resolved_from_current_tree_after_reparent(self):
        code = (APP / 'Features/Explorer/ExplorerPane.MarqueeSelection.cs').read_text()
        self.assertIn('GetFilesScrollViewer() => VisualChild<ScrollViewer>(FilesGrid)', code)
        self.assertNotIn('_filesScrollViewer', code)

    def test_layout_refresh_is_event_driven_and_session_restore_wins(self):
        core = (APP / 'Controls/ExplorerPane.xaml.cs').read_text()
        refresh = (APP / 'Features/Explorer/ExplorerPane.FileViewport.cs').read_text()
        view = (APP / 'Features/Explorer/ExplorerPane.ViewAndFiltering.cs').read_text()
        self.assertIn('FilesGrid.Loaded += (_, _) => QueueFileViewportLayoutRefresh()', core)
        self.assertIn('FilesGrid.SizeChanged += (_, _) => QueueFileViewportLayoutRefresh()', core)
        self.assertIn('QueueFileViewportLayoutRefresh(resetHorizontal: modeChanged)', view)
        self.assertIn('if (_fileViewportRefreshQueued) return;', refresh)
        self.assertIn('if (_restoreViewportPending) TryRestoreFileViewport();', refresh)
        self.assertIn('FilesGrid.InvalidateMeasure()', refresh)
        self.assertIn('scroll.InvalidateScrollInfo()', refresh)
        self.assertNotIn('ScrollChanged +=', refresh)
        self.assertNotIn('new DispatcherTimer', refresh)

    def test_windows_scenario_measures_both_reused_panes(self):
        scenario = (ROOT / 'source/tests/UiSmokeTests/FileScrollRegression.cs').read_text()
        self.assertIn('"OneButton", "TwoButton", "OneButton", "TwoButton"', scenario)
        self.assertIn('scroll.ScrollableWidth < 100', scenario)
        self.assertIn('scroll.ComputedHorizontalScrollBarVisibility', scenario)
        self.assertIn('label.TransformToAncestor(grid)', scenario)
        self.assertIn('scroll.HorizontalOffset - stableOffset', scenario)


if __name__ == '__main__':
    unittest.main()
