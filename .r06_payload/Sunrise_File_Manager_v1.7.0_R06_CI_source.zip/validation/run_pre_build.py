"""Source-only PRE_BUILD_CHECK; never invoked by the Windows company builder.

Uses generated test fixtures. Does not install/run Setup or approve Windows release.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def inputs():
    selected = []
    for path in ROOT.rglob('*'):
        if not path.is_file() or '_wpftmp.' in path.name or set(path.relative_to(ROOT).parts) & {'.git', 'bin', 'obj', '__pycache__', 'logs', 'dist', 'build-logs'}:
            continue
        rel = path.relative_to(ROOT).as_posix()
        if path.suffix in {'.cs', '.csproj', '.xaml', '.cmd', '.iss', '.manifest', '.py'} or '/Fixtures/' in rel or rel in {
            'installer/RELEASE_VERSION.txt', 'global.json', 'source/global.json', 'latest.json', 'notice.txt', 'release/PUBLISHED_RELEASE.json'}:
            selected.append({'path': rel, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    return sorted(selected, key=lambda x: x['path'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dotnet', default=shutil.which('dotnet'))
    args = parser.parse_args()
    if not args.dotnet:
        print('PENDING: .NET 10 SDK required for source execution checks.')
        return 2
    logs = ROOT / 'validation/logs'
    logs.mkdir(exist_ok=True)
    commands = [
        ('python_contracts', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v']),
        ('packaging_contracts', [sys.executable, 'tests/verify_packaging_contract.py']),
        ('ui_source_contracts', [sys.executable, '-m', 'unittest', 'discover', '-s', 'source/tests', '-p', 'test_ui_contract.py', '-v']),
        ('update_behaviors', [args.dotnet, 'run', '--project', 'source/tests/UpdateTests/UpdateTests.csproj', '--configuration', 'Release']),
        ('portable_logic', [args.dotnet, 'run', '--project', 'source/tests/LogicTests/LogicTests.csproj', '--configuration', 'Release', '--', '--portable']),
        ('v150_features', [args.dotnet, 'source/tests/LogicTests/bin/Release/net10.0/LogicTests.dll', '--v150-features']),
        ('v141_corrective', [args.dotnet, 'source/tests/LogicTests/bin/Release/net10.0/LogicTests.dll', '--v141-corrective']),
        ('v140_priority', [args.dotnet, 'source/tests/LogicTests/bin/Release/net10.0/LogicTests.dll', '--v140-priority']),
        ('wpf_cross_compile', [args.dotnet, 'build', 'source/Sunrise.FileManager/Sunrise.FileManager.csproj', '--configuration', 'Release', '-p:EnableWindowsTargeting=true', '-v:minimal']),
        ('metadata_compile', [args.dotnet, 'build', 'build-tools/Sunrise.FileManager.ReleaseMetadata/Sunrise.FileManager.ReleaseMetadata.csproj', '--configuration', 'Release', '-p:UseAppHost=false', '-v:minimal']),
        ('metadata_behaviors', [sys.executable, 'tests/release_metadata_behavior.py', '--dotnet', args.dotnet]),
    ]
    before = inputs()
    results = []
    env = dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT='1', DOTNET_NOLOGO='1')
    with tempfile.TemporaryDirectory(prefix='SunriseV120Profile_') as profile:
        if os.name != 'nt':
            env['XDG_DATA_HOME'] = profile
        for name, command in commands:
            try:
                run = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding='utf-8', errors='replace', timeout=240, check=False)
                code, output = run.returncode, run.stdout
            except subprocess.TimeoutExpired as error:
                code, output = 124, str(error)
            (logs / (name + '.log')).write_text(output, encoding='utf-8')
            result = {'name': name, 'status': 'PASS' if code == 0 else 'FAIL', 'exit_code': code,
                      'command': [Path(command[0]).name, *command[1:]], 'log': f'validation/logs/{name}.log'}
            pending = [line for line in output.splitlines() if line.startswith('PENDING:')]
            if pending:
                result['excluded_windows_cases'] = pending
            if name in {'python_contracts', 'ui_source_contracts', 'metadata_behaviors'}:
                match = re.search(r'Ran (\d+) tests?', output)
                result['case_count'] = int(match[1]) if match else None
            elif name in {'update_behaviors', 'portable_logic', 'v150_features', 'v141_corrective', 'v140_priority'}:
                result['assertion_count'] = sum(line.startswith('PASS') and ':' in line and not re.match(r'PASS: \d+ ', line)
                                                for line in output.splitlines())
            results.append(result)
            print(f'{result["status"]}: {name}')
    after = inputs()
    stable = before == after
    passed = stable and all(x['status'] == 'PASS' for x in results)
    report = {'product': 'Sunrise File Manager', 'source_version': (ROOT / 'installer/RELEASE_VERSION.txt').read_text(encoding='utf-8').strip(), 'profile': 'PRE_BUILD_CHECK',
              'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
              'source_status': 'SOURCE_VALIDATED' if passed else 'SOURCE_CHECK_FAILED', 'inputs_stable': stable,
              'environment': {'os': sys.platform, 'dotnet_sdk': '10.0.100 used for this checkpoint'},
              'gates': results, 'inputs': after,
              'windows_dynamic': 'PENDING', 'windows_signing_installer_upgrade': 'PENDING',
              'public_distribution': 'NOT_PUBLISHED_BY_THIS_TASK; Windows runtime/sign/install validation pending; published feed snapshot retained',
              'reuse': 'REUSED_PASS only while the recorded gate inputs remain unchanged; Windows builder does not rerun these tests.'}
    (ROOT / 'validation/PRE_BUILD_RESULT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
