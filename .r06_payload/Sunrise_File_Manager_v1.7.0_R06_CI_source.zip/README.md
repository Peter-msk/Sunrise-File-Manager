# Sunrise File Manager v1.7.0 R06 — 라이트 테마·상단 버튼 마감 (2026-10-25)

라이트 모드에서 지나치게 어둡던 브랜드 헤더와 우측 공용 아이콘 레일을 밝은 청회색으로 조정하고 다크 모드의 남색 체계는 유지했습니다. 상단 3행은 **38/42/40 DIP**, 업무·명령·분할 버튼은 각각 **34/32/34 DIP**로 정리하고 버튼 간 간격과 텍스트 패딩을 확보했습니다. 활성 업무·분할·공용 패널 버튼은 hover에서도 대비가 유지되도록 선택 상태 템플릿을 보완했습니다.

**소스 검증 PASS, Windows WPF/Preview 실행 및 서명 Setup 검증 PENDING.** 기존 14개 분할 배치·오른쪽 공용 패널 3개·Preview 빌드·사용자 메모/설정/업데이트 계약은 유지합니다. 상세: `docs/V170_R06_LIGHT_THEME_SHELL_BUTTON_FINISH.md`.

---
이하 R05 및 과거 리비전 이력입니다.

# Sunrise File Manager v1.7.0 R05 — 공식 A안 적응형 상단 명령·버튼 품질 (2026-10-25)

상단 헤더의 설정 위치와 높이를 정리하고 파일관리 기본 6개 명령 이외의 작업을 `⋯ 더보기`로 수납했습니다. 너비 부족 시 업무별 명령은 자동으로 More 메뉴로 이동하며, 원래 실행 처리기를 그대로 호출합니다. 라이트/다크 캡처를 바탕으로 앱 XAML 15개/버튼 158개를 전수 감사해 크기·폰트 균형과 패널 행 클리핑을 보완했습니다.

**상태: Python 448/448 PASS, XAML 15/15 PASS, Windows WPF/Preview/Setup/서명 PENDING.** 메모·파일 엔진·공용 우측 3패널·14분할·Preview 빌드 보존. 상세: `docs/V170_R05_ADAPTIVE_COMMAND_BAR_AND_BUTTON_AUDIT.md`. 공개 업데이트 및 GitHub/Drive 변경 없음.

---
이하 이전 R04 기록입니다.

# Sunrise File Manager v1.7.0 R04 — Windows 기본 우클릭 메뉴 복구 (2026-10-25)

파일·폴더 우클릭에 Windows 기본 잘라내기·복사·붙여넣기·이름 바꾸기·삭제 및 Windows 공유·확장 메뉴·속성을 직접 표시합니다. 파일 목록 빈 공간은 새로 만들기·붙여넣기·정렬·보기·새로 고침 등 별도 명령으로 구분하며, 휴지통 메뉴와 기존 Sunrise AI/EIASS 기능은 유지합니다.

**배포 상태: Windows WPF 및 네이티브 Shell 실기검증 대기인 전체 소스 후보.** Windows 실행과 다중 속성 COM/Preview/Setup/서명은 PENDING. 상세 `docs/V170_R04_WINDOWS_CONTEXT_MENU_PARITY.md`, `RELEASE_STATUS.json` 참고.

---
이하 이전 R03 이력입니다.

# Sunrise File Manager v1.7.0 R03 — 공식 A안 다중 분할 메뉴 공간 확보 (2026-10-25)

2~4분할에서 중복되던 탐색창별 36 DIP 클래식 메뉴 행을 접고, **각 탭 오른쪽의 `⋯ 고급 명령` 버튼으로 동일 메뉴를 재사용**합니다. 단일 화면에서는 기존 메뉴가 그대로 보입니다. 원래 File/Edit/View/Favorites/Extras/Info 메뉴 항목과 클릭 처리기는 삭제하거나 복제하지 않으며, 분할 변경 시에도 독립 탐색·파일 작업/메모/Preview/Control/설치 빌드를 유지합니다.

**검증:** Python 425/425 PASS, XAML 15/15 구조 PASS. Windows 실제 WPF 컴파일·ContextMenu 조작·DPI/Preview/서명/Setup **PENDING**. `docs/V170_R03_OFFICIAL_A_COMPACT_EXPERT_MENUS.md` 참고.

---

# Sunrise File Manager v1.7.0 R02 — 공식 A안 메인 셸 및 업무별 도구 구현 (2026-10-25)

공식 A안의 **남색 브랜드 헤더 / 파일 관리·문서/EIASS·AI·압축/도구 모드 / 업무별 명령 한 행 / 상단 분할 제어 / 중앙 파일 작업공간 / 우측 공용 패널 / 하단 작업 상태**를 실제 WPF 소스에 반영했습니다. 모드 단축 명령은 활성 ExplorerPane의 기존 작업 처리기에 연결되며, 14개 분할 배치, 고정 전송 막대 제거, 공용 상세/미리보기/메모 각 1개, Preview 전용/설치형 빌드 계약은 유지합니다.

**검증 범위:** Python 420/420 PASS, XAML 15개 구조 검사 PASS. Windows WPF 실제 빌드/렌더링/Preview·서명/Setup **PENDING**. 기존 분할창별 탐색 메뉴를 단일 전역 트리로 이전하는 작업은 기능 보존 위험으로 진행하지 않았습니다. `docs/V170_R02_OFFICIAL_A_FULL_SHELL.md` 참고.

---

# Sunrise File Manager v1.7.0 R01 — 공식 A안 UI·분할 목록 수정

실제 실행 화면에서 재출현한 분할 전송 고정 도구를 제거했습니다. `단일`은 즉시 전환, 2·3·4분할은 기존 2·6·5개 배치를 그림+간결한 한 줄로 표시합니다. 우측 기능 레일은 글자 대신 7개 독립 벡터 아이콘(툴팁/접근성 이름 포함), 공식 A안 남색 팔레트를 독립 적용합니다. 실제 파일 드래그·클립보드·메모/미리보기/상세정보·AI·Control 및 v1.7.0 Preview 빌드 기능은 유지합니다.

**검증:** Python 413/413 PASS, XAML XML 15/15 PASS. Windows WPF 실제 컴파일·실기·서명/Setup은 PENDING. 상세: `docs/V170_R01_OFFICIAL_A_UI_RECONCILIATION.md`.

---

# Sunrise File Manager v1.7.0 R00 — 설치 전 Preview 자동 생성 (2026-10-25)

v1.7.0 프로그램 기능과 UI는 변경하지 않았습니다. Windows 회사 빌드에서 정식 Setup과 함께 설치 없이 실행 가능한 **서명된 Preview 폴더·ZIP**을 기본 생성합니다. 또한 `BUILD_PREVIEW_ON_WINDOWS.cmd`로 Setup을 빌드하지 않고 실행용 Preview만 생성할 수 있습니다.

- 기본 회사 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`
  - `dist/Sunrise_File_Manager_1.7.0_Preview/Sunrise.FileManager.exe`
  - `dist/Sunrise_File_Manager_1.7.0_Preview.zip`
  - `dist/Sunrise_File_Manager_1.7.0_Setup.exe`
- 미리실행 전용 빌드: `BUILD_PREVIEW_ON_WINDOWS.cmd` (Inno Setup 불필요, 그룹서명과 .NET 10 SDK 필요).
- Preview는 self-contained Windows x64 OneDir입니다. EXE 하나만 복사해서는 실행할 수 없으며 폴더 전체를 유지해야 합니다. 런타임 설치는 요구하지 않습니다.
- 회사 서명 및 기존 Sunrise Control/업데이트 정책 유지; Preview와 설치형에 쓰이는 앱 바이너리는 동일합니다.
- 설치 없이 실행은 가능하지만 **선택한 실제 파일에 대한 작업은 실제로 적용**됩니다. 설치본과 설정 데이터가 공유될 수 있어 테스트 파일로 먼저 확인해야 합니다.
- 버전은 **1.7.0 유지**, 릴리즈 리비전만 `R00`. 원격 공개 feed와 기존 Setup 배포는 변경하지 않았습니다.
- **Windows 동적 빌드·서명·Preview 실행 검증 PENDING**. 현재 전달물은 빌드 경로를 반영한 소스 후보입니다.

---
이하 이전 릴리즈 이력입니다.

# Sunrise File Manager v1.7.0 — 기존 R09 동일 기능 버전 승격 (2026-10-25)

- **부모 기준본**: `Sunrise_File_Manager_v1.6.0_R09.zip` / SHA-256 `ff757ccfba4fe763da527269a93e395e847e88ec63397c061925eb3f57b548fa`.
- Windows x64 설치형 기존 기능·UI·세션 스키마(`LayoutVersion=25`)·파일/메모 처리 코드 보존. 제품/설치/Control/어셈블리/창 제목 버전만 **1.7.0**으로 동기화.
- 기본 회사 빌드 `BUILD_ON_WINDOWS_COMPANY.cmd`, 예정 산출물 `dist/Sunrise_File_Manager_1.7.0_Setup.exe`.
- `release/NOTICE_BODY_1.7.0.txt`는 신규 버전의 로컬 릴리즈 문구 원본. 공개 `latest.json`, `notice.txt`, `release/PUBLISHED_RELEASE.json` 및 GitHub·Drive 게시 내용은 변경하지 않음.
- **Windows WPF 빌드·설치·서명·실기 UI 확인은 PENDING**. 아래 1.6.0 문단은 해당 버전의 역사적 기록임.

---

## v1.6.0 R09 — 구형 계약·사용되지 않는 상태 정리 및 현재 기능 회귀 복구 (2026-10-25)

- 부모: `Sunrise_File_Manager_v1.6.0_R08.zip` (SHA-256 `334173f543bb6c3c9748b6fc10bca52f53e3702fb9fe222c0f7d19f68570f3e4`). 설치형 제품 버전 `1.6.0`은 유지하며 R09는 소스 정리 리비전이다.
- 12 FAIL/4 ERROR 원인이 된 과거 통합 Inspector·OneFile·버전 미지정·과거 패널 geometry 검사를 현재의 **파일/메모 무결성·시각 구조·현행 회사 빌드·세션 안전성** 검증으로 대체했다.
- 오래된 개별 화면 미리보기/상세정보 설정, 사용하지 않는 InspectorDetailRatio와 관련 코드 및 폐기된 빌드 계약 스크립트를 제거했다. 이전 `InspectorVisible`, `InspectorWidth`는 기존 사용자 세션 이전에 실제 필요하여 유지한다. JSON의 삭제된 필드는 로드 시 무시하여 사용자 세션 자체는 보존한다.
- 코드 결함 보완: 새 독립 창 생성 시 `LayoutVersion=25`, `SingleUtilityPanel`, `SingleUtilityActive`를 전달하여 기존 우측 패널 표시 선호를 유지한다. 상세정보 요청 이벤트도 `DetailsRequested`로 소유권을 바로잡았다.
- 전체 Python 실행: `source/tests` **117/117 PASS**, 루트 `tests` **279/279 PASS**, **합계 396/396 PASS**. 루트의 과거 1.1.0 릴리즈·공지 문자열 등 무효화된 검사 10개는 삭제했고 PASS 숫자에 포함하지 않는다. 기존 R08 루트 289건/34 FAIL+4 ERROR는 정리 전 이력이다.
- 기존 메모 이동·Undo/Redo 동작은 이미 C# LogicTests에 시나리오가 존재하며 제품 엔진 원본 바이트를 그대로 보존했다. 이번 환경에서는 .NET SDK/Windows가 없어 **C# 컴파일·C# 로직 실행·Windows UI/Setup/서명 PENDING**. Source PASS를 Windows PASS로 승격하지 않는다.
- 세부: `docs/V160_R09_CURRENT_CONTRACT_CLEANUP.md`. GitHub/Drive/원격 업데이트 피드·기존 공개 배포본은 수정하지 않았다.

# Sunrise File Manager v1.6.0 R08 — A안 UI 소스 마무리

기존 14개 분할 배치 메뉴를 각 버튼 바로 아래에서 선택하는 방식을 유지하면서 좁은 창의 상단 메뉴 접근, 연속 드롭다운 중복 방지, 메모/미리보기 단축키 충돌을 보완했습니다. 상세정보·미리보기·메모는 오른쪽 공용 패널 각각 하나씩 사용합니다.

**상태: Windows UI 컴파일·실기·DPI·설치·서명 PENDING인 소스 후보**이며, 공식 배포 업데이트와 공지는 변경하지 않았습니다. `docs/V160_R08_UI_FINAL_HARDENING.md`를 참조하세요.

---

# Sunrise File Manager v1.6.0 R07 — 기본 분할 배치 드롭다운 (2026-10-25)

`단일 ▾` / `2분할 ▾` / `3분할 ▾` / `4분할 ▾`을 누르면 해당 버튼 바로 아래에 이미 설정된 분할 배치 1/2/6/5개가 작은 도면·이름과 함께 나열됩니다. 사용자는 항목을 클릭하여 즉시 적용할 수 있습니다. 목록을 여는 것만으로 화면은 바뀌지 않습니다. 기존 키보드 단축키, 우측 공용 패널 및 파일 처리 엔진은 유지합니다.

**현행 상태: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING.** Windows WPF 컴파일·실제 메뉴/설치/그룹 서명은 수행하지 않았습니다. 원격 배포 채널은 변경하지 않았습니다. 상세 `docs/V160_R07_COMPACT_PRESET_DROPDOWN.md`.

---

# Sunrise File Manager v1.6.0 R06 — 분할 배치 미리보기·안전성 보완 (2026-10-25)

2·3·4분할 배치 그림 목록에서 **현재 파일 작업영역에 충분히 들어가는지**, 그렇지 않으면 **어느 방향의 스크롤이 필요한지**를 배치 적용 전에 안내합니다. 파일 전송·AI 작업·휴지통 진행 중에는 작업 파일 및 분할창 상태 보호를 위해 배치 변경을 제한하며, 완료 후 다시 선택할 수 있습니다. 14개 배치·세션·단축키·우측 공용 3패널은 그대로 유지합니다.

**Windows 동적 검증 전 전체 소스 후보입니다.** Windows WPF 컴파일·실제 UI/DPI·Setup 설치·서명은 PENDING. 공개 업데이트/공지 변경 없음. 상세 `docs/V160_R06_GALLERY_FIT_AND_TRANSACTION_SAFETY.md`.

---

# Sunrise File Manager v1.6.0 R05 — 분할 배치 직접 선택 (2026-10-25)

상단 `2분할 ▾` / `3분할 ▾` / `4분할 ▾`에서 지원하는 레이아웃 **2/6/5개**를 배치 그림·설명으로 보여주고, 사용자가 하나를 직접 선택하도록 변경했습니다. 메뉴를 여는 것만으로 기존 레이아웃이 변경되지 않습니다. Ctrl+1~4는 마지막으로 선택한 해당 분할 수의 배치를 즉시 엽니다. 우측 공용 상세정보·미리보기·메모는 각각 한 개만 유지하며, 파일 엔진·설치 빌드·Control·업데이트 계약은 변경하지 않았습니다.

**상태: Windows WPF 실컴파일/실행 및 Setup 검증 대기 중인 소스 후보.** `docs/V160_R05_SPLIT_LAYOUT_GALLERY.md`, `RELEASE_STATUS.json` 참고. 원격 공지와 릴리즈 피드는 변경하지 않았습니다.

---
이하 R04 이전 이력입니다.

# Sunrise File Manager v1.6.0 R04 — 우측 공용 패널 고정 / 분할 탐색 트리 폭 최적화 (2026-10-24)

미리보기·상세정보·메모는 **하단이 아니라 파일 작업공간의 오른쪽**에 종류별 한 개씩 배치되며, 1~4분할의 활성 파일만 보여줍니다. R04에서는 좁은 분할창의 고정 탐색 트리 표시 폭만 일시적으로 제한해 파일 목록에 더 많은 가로 공간을 확보했습니다. 사용자의 저장된 탐색 트리 너비, 자동 숨김, 열 너비, 메모 및 현재 버전의 모든 파일 기능은 보존합니다.

Windows .NET 10 WPF·실제 DPI·설치/서명 동작은 별도 PENDING인 소스 후보입니다. 관련 `docs/V160_R04_RIGHT_DOCK_NAVIGATION_BUDGET.md`와 `RELEASE_STATUS.json`을 확인하세요.

---
아래는 R03 이전 이력입니다.

# Sunrise File Manager v1.6.0 R03 — A안 다중 분할 내부 밀도 개선 (2026-10-24)

2~4분할에서 파일 목록에 반환되는 세로 공간을 늘리고, 단일창으로 복귀하면 원래 레이아웃을 복원합니다. 검색·주소·탭·경로·파일명·스크롤·메뉴/단축키·고정 탐색 트리는 유지합니다. 우측 상세정보·미리보기·메모는 각 1개 공용 패널입니다. Windows WPF·설치·서명 미검증 `SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING` 소스 후보이며 배포 승인본이 아닙니다.

검증과 변경 경계: `docs/V160_R03_PANE_DENSITY_A_LAYOUT.md`, `RELEASE_STATUS.json`. 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`. 공개 업데이트/공지 미변경.

---
이하 R02 이전의 변경 내역입니다.

# Sunrise File Manager v1.6.0 R02 — A안 공간 최적화 (2026-10-24)

- 상단 명령과 2~4분할 전송바를 한 행 가로 스크롤 UI로 변경하여 작은 창에서 작업공간 높이 낭비를 억제했습니다. 우측 도구 레일은 세로 스크롤을 지원합니다.
- `우측 패널 하나씩 보기`는 사용자가 직접 켜는 선택 모드입니다. 기존 동시 표시 허용은 기본 그대로 유지하며, 다른 패널로 전환할 때 미저장 메모 확인을 거칩니다.
- 상세정보·미리보기·메모는 1~4분할에서 MainWindow 공용 컨트롤 각 1개이며 원본·세션 데이터·Control·업데이트 wire·회사 빌드 CMD는 유지합니다.
- **현재 자격: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING.** Windows WPF 컴파일·실제 화면·설치/서명 검증 미실행. `docs/V160_R02_COMPACT_A_WORKSPACE.md`, `RELEASE_STATUS.json` 참고.

---

# Sunrise File Manager v1.6.0 R01 — 4분할 공용 우측 패널 (2026-10-24)

- 부모 기준: `Sunrise_File_Manager_v1.6.0_R00.zip` / SHA-256 `5cfc58d2ba7b2013f797dceb93a7bb1912bb5d8675d259f296fecf8a402a8a2d`.
- `1~4개 ExplorerPane` + MainWindow의 **FileDetailsPanel 1개 / FilePreviewPanel 1개 / FileMemoPanel 1개**. 분할창별 숨은 상세정보 패널 코드를 제거하고 선택한 활성 창에 공용 패널을 동기화했습니다.
- 활성 분할창 표시(`창 N/4`) 및 분할별 제목 강조, 4→1 축소 또는 상태 교환 전 미저장 메모 확인, 구버전 패널 상태 필드 직렬화만 유지.
- 문서/AI/EIASS/파일엔진/휴지통/업데이트/서명/설치 형식은 기존 버전 그대로. 공식 회사 빌드의 소스 테스트 중복 수행 금지 유지.
- **현재 자격: SOURCE_CANDIDATE_WINDOWS_DYNAMIC_PENDING**. Windows 실기 검증을 통과했다고 주장하지 않습니다. 상세 내용은 `docs/V160_R01_SHARED_RIGHT_PANELS.md`, `RELEASE_STATUS.json`을 확인하십시오.

---

# Sunrise File Manager v1.6.0 R00 — A안 기본 파일 작업공간 UI (2026-10-24)

- **기준**: `Sunrise_File_Manager_v1.6.0.zip` / SHA-256 `25d3b1ad459ea38ab44651fe2ed8adaa2f19a6a3978bd4069bb1bdae23f48eb7`.
- **상태**: 수정된 Windows 설치형 전체 소스 후보. Windows .NET 10 실제 컴파일·실행·설치 및 Sunrise Group 서명은 `PENDING`이며 공식 UI 승인 상태가 아닙니다.
- **변경 핵심**: 좌측 탐색과 1~4분할 작업 영역을 우선 확보. 첫 설치시 상세정보·메모는 닫힌 상태로 시작하며 이전 세션의 저장된 열림 상태는 그대로 복원. 오른쪽 폭 68 DIP 기능 레일에서 상세정보/메모/미리보기/AI/복구 기록/작업 집중을 실행. 분할 2~4개에서 원본·대상 전송 바를 표시하고 사용자가 접을 수 있으며 해당 상태를 세션 v24로 저장. 닫힌 보조 패널의 너비·분할선은 0으로 반환. 메모 미저장 확인 취소 시 '작업 집중'이 추가 패널을 닫지 않음.
- **변경하지 않은 것**: 14개 분할 배치, 분할별 탭·트리·메뉴·키보드 경로, 메모 데이터·AI 승인·EIASS·휴지통·검색·문서처리·기본 파일 엔진, Control/업데이트 wire, 설치 파일명, 회사 CMD.
- **빌드**: Windows에서 `BUILD_ON_WINDOWS_COMPANY.cmd` 실행; 원래 제품 버전 1.6.0을 유지하는 R00 작업본이므로 예정 결과 `dist/Sunrise_File_Manager_1.6.0_Setup.exe`. 정식 릴리즈로 게시하지 마십시오.
- **검증**: `docs/V160_R00_A_WORKSPACE_UI.md` 및 `validation/v160_a/RESULTS.json` 참고. 기능별 정적 테스트는 실제 Windows 화면 승인이 아닙니다.

---

# Sunrise File Manager v1.6.0 — 메모·상세정보 독립 시스템 (2026-10-24)

메모와 상세정보를 각각 `FileMemoPanel`과 `FileDetailsPanel`로 분리했습니다. 별도 메뉴·닫기·상태·너비·모듈을 가지며 필요한 패널만 열 수 있습니다. 메모는 원본 `#memo/*.sunmemo` 형식, 암호화 이력, 저장, AI 요약, 미저장 확인을 유지합니다. 상세정보는 파일 속성·용량·해시만 담당합니다.

**상태: Windows 동적 검증 대기 중인 전체 소스 후보.** 회사 빌드 CMD `BUILD_ON_WINDOWS_COMPANY.cmd`의 예정 출력은 `dist/Sunrise_File_Manager_1.6.0_Setup.exe`입니다. Windows .NET 10 컴파일·실제 화면·Setup 서명 검증은 수행하지 않았습니다. 공개 latest.json/notice.txt는 기존 공개본 그대로입니다. `RELEASE_STATUS.json`, `docs/V160_MEMO_DETAILS_SEPARATION.md`를 확인하세요.

---
이하 이전 버전 이력입니다.

# Sunrise File Manager v1.5.6 — 휴지통 일괄 삭제 개선 (2026-10-24)

휴지통의 다중 항목을 선택한 뒤 Delete/Shift+Delete 또는 우클릭 영구 삭제를 실행하면 **선택 전체에 대해 확인을 한 번만** 요청하도록 Windows Shell 일괄 작업 경로를 변경했습니다. '선택 복원', '전체 복원', '영구 삭제', '휴지통 비우기', '속성', '모두 선택', '새로 고침', 'Windows 휴지통에서 열기'를 제공합니다. 휴지통 삭제는 일반 파일 경로에 직접 적용하지 않고 Shell 네임스페이스를 이용하며, 작업 후 삭제 완료 개수를 다시 확인합니다.

**배포 상태: Windows 실기 미검증 소스 후보.** 정적 계약 검사와 패키지 무결성 확인은 완료했으나 Windows 컴파일, 실제 다중 삭제 확인창 횟수, 설치형 Setup 생성/서명/설치 검증은 `PENDING`입니다. 기존 v1.5.5 Windows 실행 PASS를 v1.5.6의 PASS로 승계하지 않습니다.

설치형 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd` → `dist/Sunrise_File_Manager_1.5.6_Setup.exe` (Windows/서명 검증 후 배포). 회사 기존 설정·메모·Control·업데이트 wire·7개 그룹 우클릭 메뉴·드라이브 첫 접기 계약은 유지합니다. 현재 검증 상태는 `RELEASE_STATUS.json`, 상세 변경사항은 `docs/V156_RECYCLE_BIN_BATCH_AND_NATIVE.md`를 참조하세요.

---
이하 이전 릴리즈 이력입니다.


# Sunrise File Manager v1.5.4 — 최종 코드 감사·안정화 (2026-10-23)

- 감사 기준: 이 대화에서 최종 전달한 `Sunrise_File_Manager_v1.5.3.zip`.
- 일반 파일 일괄 이름 변경의 중간 실패 시 원래 이름과 메모를 복구한다. 파일/폴더 혼합 변경은 전체 계획을 먼저 검사한다.
- 실행 취소·다시 실행 중 창 종료와 추가 파일 변경을 제한하고, 처리 완료 후 정상 종료할 수 있도록 한다.
- 이름 충돌 등으로 실패한 일반 Undo/Redo 항목은 이력을 보존하여 재시도한다.
- 같은 폴더의 메모 저장·감시자 새로고침에서 선택을 복원하며, 필터·탭·위치 변경과 구분한다. 선택한 문서의 미리보기를 유지한다.
- 파일 위치 찾기로 목록 앞부분이 생략되는 문제를 수정했다. 첫 2,000행 안에서는 전체 첫 페이지를 유지하고, 그 밖의 파일은 이전 위치로 돌아갈 수 있는 커서로 표시한다. 2,005개 파일 경계 사례와 작은 폴더 전체 목록을 검증했다.
- 제품·Control·창 제목·설치 버전은 1.5.4, Assembly/FileVersion은 1.5.4.0이다.
- 기존 회사 빌드 진입점은 `BUILD_ON_WINDOWS_COMPANY.cmd`이며, 회사 빌드에 문서 테스트를 추가하지 않았다.
- Windows VM에서 컴파일 0 경고/0 오류, EIASS·복구 117개·현행 UI 22개·기본 파일 작업 5개 항목 및 14개 분할 배치가 통과했다. 회사용 CMD로 Setup 생성 후 실제 설치·실행·종료·제거도 확인했다.
- Windows 실행 검증의 최종 결과와 범위는 `RELEASE_STATUS.json` 및 `validation/v154`를 따른다.

---
이하 이전 버전의 개발·검증 기록이다.

# Sunrise File Manager v1.5.3 — EIASS 제출용 문서명 설정 (2026-10-23)

- PDF 선택 → **편집 → EIASS 제출용 문서명 설정…** (우클릭 메뉴에서도 사용).
- 평가 구분·말머리, 4/5자리 목차번호, 시작 번호·간격, 제목 직접 수정, 위·아래 순서 조정, 금지 문자 정리, 변경 전 미리보기를 지원한다.
- 목차 파일(PDF/DOCX/HWPX/HWP/TXT) 또는 한 줄에 제목 하나씩 직접 입력하여 순서를 맞출 수 있다. 번호 없는 목차도 지원하며 유일하게 일치하는 제목만 자동 연결한다. 미일치·중복은 수동 확인 후 적용한다. 스캔 목차 OCR은 제공하지 않는다.
- 사후환경영향조사·약식평가 최종보고서는 말머리를 생략하고, 기후변화영향평가는 이름을 유지한다. PDF 외 선택 항목은 제외하며 확장자와 내용은 보존한다.
- 이름 교환과 메모 동반 이동을 지원하는 2단계 변경, 실패 시 원래 이름 복구, Ctrl+Z 실행 취소·Ctrl+Y 다시 실행을 연결했다. 중복 번호·중복 대상·기존 파일 덮어쓰기는 차단한다.
- 제품·Control·창 제목·설치 버전: **1.5.3** / Assembly·FileVersion: **1.5.3.0**. 기본 빌드에서 문서 검증을 실행하지 않는다.
- 목표 출력: `dist/Sunrise_File_Manager_1.5.3_Setup.exe`. 빌드 진입점: `BUILD_ON_WINDOWS_COMPANY.cmd`.
- Windows VM에서 Release 빌드 0 경고/0 오류, 새 기능 검증 100개 항목이 통과했다. 900×640 최소 창 크기와 말머리 편집·실제 마우스 조작도 확인했다. 변경 기능 검증 결과는 `validation/v153` 및 `RELEASE_STATUS.json`을 참조한다. 서명된 Setup 설치 검증은 대기 중이다.

---
이하 이전 버전의 개발·검증 기록이다.

# Sunrise File Manager v1.5.2 — 버전 승격 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R03.zip`, SHA256 `2706b3f21195ab7ff5be14b9aa587e54cd04d66d4abb527c25e967ac5bccc64a`.
- Windows VM에서 통과한 1.5.1 R03의 동작을 유지하고 제품·Control·창 제목·설치 버전을 1.5.2, Assembly/FileVersion을 1.5.2.0으로 동기화했다.
- 기존 14개 배치·실제 마우스 98회 클릭/72회 드래그 검증은 동작 코드가 같으므로 REUSED_PASS로 승계한다. 첨부 화면과 로그는 당시 1.5.1 실행 기록이다.
- 이번 검증: 버전 소유자 일치 PASS, 설치 버전 계약 검사 7개 PASS, Windows 대상 WPF 교차 컴파일 경고 0·오류 0.
- 목표 출력: `dist/Sunrise_File_Manager_1.5.2_Setup.exe`. 회사 빌드 진입점은 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`.
- 설치파일 생성·서명·설치·업데이트는 미검증/PENDING이다. 공개 latest.json/notice.txt와 원격 배포는 갱신하지 않았다.

---

# Sunrise File Manager v1.5.1 R03 — Windows 분할·스크롤 실행 검증 (2026-10-23)

- Windows Server 2025 가상 머신의 활성 데스크톱에서 WPF 화면을 실제 실행했다. 해상도 1920×1080, Windows DPI 100%, 앱 배율 90%.
- 1~4분할 14가지 배치의 표시·스크롤·폴더 이동·탭·크기 변경·분할 경계 검사 PASS.
- 실제 OS 마우스 입력 98회 클릭·72회 드래그, 8회 분할 선택·18개 창 검사 PASS. 파일 목록과 좌측 트리의 가로 막대 양 끝 이동, 폴더 더블클릭/뒤로/앞으로/상위 이동 PASS.
- 최종 실행: https://github.com/Peter-msk/Sunrise-File-Manager/actions/runs/39915493146 / commit `697c6ae8a5fb7c0f785cb3b5991f47431d92a7d5`.
- 제품 소스는 R02와 동일하다. R03에서는 실제 Windows 실행을 막던 검사 호스트 초기화 문제를 수정하고 네이티브 입력·화면 증적을 추가했다.
- 회사 기본 빌드에는 검사·문서 읽기를 추가하지 않았다. 기존 `CHECK_SPLITS_ON_WINDOWS.cmd`로 선택 실행한다.
- 범위: Windows VM의 해당 UI 시나리오 PASS. 설치형 Setup 생성·서명·설치·업데이트 및 사용자 PC/다른 DPI 전체 검증은 별도 PENDING.
- 기록과 화면: `docs/V151_R03_WINDOWS_UI_VERIFICATION.md`, `validation/windows-ui-r03/`.

---

아래는 이전 리비전 시점의 이력이다. 과거의 Windows UI PENDING 표기는 위 R03 검증 범위에 한해 대체된다.

# Sunrise File Manager v1.5.1 R02 — 1~4분할 전체 배치 점검·보완 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R01.zip` / SHA256 `54cb9eb81ca89f892903ba7bdbf22b0c0509842d90e0131b642c8b6f6c52e409`.
- 범위: 단일 1개, 2분할 2개, 3분할 6개, 4분할 5개 = 14개 배치와 196개 배치 간 전환.
- 보완: 350×340 DIP 트랙 최소 크기와 배치별 작업영역 extent를 통일, 실제 viewport 기준 측정, 고정 탐색창의 테두리/여백 16 DIP 누락 반영, 잘못된 숫자 preset 복원 차단.
- 실행 결과: Windows 대상 앱 및 WPF 검증 프로젝트 교차 컴파일 각각 경고 0·오류 0. 실제 production C# 분할/보존 로직 2,821 assertions PASS. 관련 Python 32 tests + XML 16개 PASS.
- **Windows 실제 클릭·키보드·표시·서명·설치·packaged 실행은 미수행/PENDING**. 교차 컴파일과 로직 실행을 Windows 조작 완료로 간주하지 않음.
- 선택 검증: `CHECK_SPLITS_ON_WINDOWS.cmd` (기본 빌드에 연결하지 않음).
- 상세 및 증적: `docs/V151_R02_ALL_SPLIT_AUDIT.md`, `validation/logs/R02_*`.

---

# Sunrise File Manager v1.5.1 R01 — 파일 목록 밀림·분할 후 가로 스크롤 보완 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1_R00.zip` / SHA256 `59cb9b76586cd0b42b1941b0d568f59725a680ca07d9c1b92f44a2f0cc8f5850`.
- 사용자 첨부 영상·이미지에서 중앙 파일 목록의 열/가로 위치 이탈 및 단일→2분할 후 첫 창 가로 막대 부재 관찰.
- 분할 창도 포인터 선택 가로 위치 보호, 내부 ScrollViewer 장기 캐시 제거, 재부착·크기/분할 변경 후 1회 범위 재계산.
- 파일 목록만 열 가상화 해제(행 가상화 유지), 가로 막대 상시 표시. R00 좌측 폴더 트리 가로 스크롤 및 R05 설치 오류 수정 유지.
- 변경 관련 Python 소스 검사 30 PASS, 앱 XML 14개 파싱 PASS. Windows 실제 재현 검증·WPF 빌드·서명·설치 PENDING.
- 실제 WPF 범위/좌우 이동/유휴 위치 안정성/이름 geometry 검사를 `--file-scroll-only` 선택 경로에 추가. 이 환경에서 실행하지 않았고 기본 빌드에 연결하지 않음.
- 상세: `docs/V151_R01_FILE_VIEWPORT_SPLIT_SCROLL_FIX.md`.

---

# Sunrise File Manager v1.5.1 R00 — 좌측 탐색창 가로 스크롤 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.1.zip`, SHA256 `84bc4cd6c81190ca286e010886b2c31807d89ba81f33c2b5c719a7ffd553b05d`.
- 좌측 탐색창: 가로 스크롤바 Auto, 긴 폴더/드라이브명 1줄 전체 너비, Shift+휠 좌우 이동. 일반 휠 세로 이동 및 Ctrl 예약 유지.
- 상단 빠른 이동·고정/위치 찾기 조작부는 표시 폭을 유지. 기존 단일 세로 스크롤·트리 지연 로딩·창 너비 조절·자동 숨김 유지.
- 제품 버전 1.5.1 유지. 동일 버전 첫 수정 전달본 `Sunrise_File_Manager_v1.5.1_R00.zip`.
- 변경 관련 소스 검사 32 tests PASS, 앱 XML 및 변경 범위 확인 PASS. Windows WPF 빌드/서명/실제 스크롤·시각 검증 PENDING.
- R05 설치 주석 수정 유지. 상세: `docs/V151_R00_NAVIGATION_HORIZONTAL_SCROLL.md`.

---

# Sunrise File Manager v1.5.1 — 현재 전달본 (2026-10-23)

- 기준: `Sunrise_File_Manager_v1.5.0_R05.zip` (SHA256 `d2064543dd3bfd9178b754fa3afc0e2cdd5a96fc2ce3f559eb8c36d51f5baa53`).
- 제품/Control/창 제목/설치 버전 `1.5.1`, AssemblyVersion/FileVersion `1.5.1.0`으로 동기화.
- R05의 Inno Setup `[Code]` 86행 주석 수정 포함. 기본 self-contained 설치형 및 회사 빌드 문서 테스트 미실행 유지.
- 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd`; 목표 출력 `dist/Sunrise_File_Manager_1.5.1_Setup.exe`.
- 버전 관련 10 tests + 기존 패키징 18 checks PASS; 버전 일치·XML 확인 PASS. Windows 빌드/서명/설치/실행 PENDING.
- 기존 원격 latest.json/notice.txt와 게시 상태를 변경하지 않음. 아래 과거 버전 기록과 `BUILD_TEST_ENVIRONMENT.txt`, `validation/PRE_BUILD_RESULT.json`은 과거 증적.
- 상세 인수인계: `docs/V151_VERSION_HANDOVER.md`.

---

아래는 이전 버전의 변경 이력입니다.

# Sunrise File Manager v1.5.0 R04 — 투트랙 배포 정책 / 설치형 기본 변경

**Track A — 공식 설치형(이번 변경):** `BUILD_ON_WINDOWS_COMPANY.cmd`는 기본적으로 **.NET 10 Desktop Runtime x64를 포함한 self-contained Setup EXE**를 만듭니다. 최종 사용자 PC에 별도 .NET Desktop Runtime 설치나 자동 다운로드가 필요하지 않습니다. 사용자에게는 서명된 Setup 한 개를 배포하며, 프로그램 파일/런타임 DLL은 설치 폴더에 포함됩니다. 설치파일의 10MB 제한은 실행환경 포함형에 적용하지 않습니다.

**Track C — 향후 별도 포터블형:** Q-Dir과 유사한 **C++/Win32 네이티브** 설계로 별도 개발합니다. 현재 R04에 C++ 전환 코드 또는 완성된 네이티브 포터블 EXE는 없습니다. 앞으로 설치형과 포터블형 중 사용자 선택을 제공하되, 양쪽의 기능 검증·서명·업데이트 호환성을 각각 관리합니다. 구체적 설계: `docs/V150_R04_DUAL_TRACK_DISTRIBUTION.md`.

- 회사 공식 빌드: `BUILD_ON_WINDOWS_COMPANY.cmd` (기본 Track A, `SUNRISE_LIGHTWEIGHT=0`).
- 구형 경량 진단 옵션만 필요한 개발자는 CMD에서 `set "SUNRISE_LIGHTWEIGHT=1"` 후 빌드할 수 있으나, 이 결과물은 공유 Runtime을 요구하므로 기본 사용자 배포형이 아닙니다.
- .NET **SDK**는 빌드 PC에서만 필요합니다. 최종 사용자에게 SDK를 설치하도록 요구하지 않습니다.
- R03의 P1/P2/P3 소스, Authenticode 서명 순서, 제품 버전 1.5.0, Inno AppId, 업데이트/사용자 데이터 계약은 그대로 유지합니다.
- 본 환경에서는 Windows .NET/Setup을 실행할 수 없어 WPF 컴파일·서명·실기 동작은 **PENDING**입니다. 설치파일 크기도 Windows 빌드에서 실측해야 합니다.

---

# Sunrise File Manager v1.5.0 R02 — 이전 소스 감사 이력

**제품 버전은 1.5.0으로 고정**하며 R02는 같은 버전의 소스 수정 리비전입니다. P1(Windows 템플릿·다중 창), P2(휴지통 선택 삭제·속성 검색), P3(ZIP 변경·전송 복구 기록)는 구현 경로가 존재하지만 완전한 Windows Explorer 동등성은 주장하지 않습니다.

- R01 기준본에서 실제 확인된 전송 복구 코드 선언 충돌, ZIP 수정 검증 범위, 손상 복구 기록·연결 경로·검색식 처리, 제품 문서의 과대 표시를 보완했습니다.
- `docs/V150_R02_FINAL_AUDIT.md`는 완료·부분·OS 의존·미구현·Windows 검증 대기를 나누어 기록합니다.
- Python 정적/계약 회귀 272개 및 106개 하위 검사는 통과. 신규 C# 직접 로직 테스트, .NET 빌드, Authenticode, Windows GUI/DPI 및 Setup 용량 검증은 **실행 대기**입니다.

---

# Sunrise File Manager 1.5.0

Windows x64용 다중 분할 파일 관리자입니다. 문서 검색과 일상적인 탐색 작업을 확장하고 경량 설치형 빌드를 추가했습니다.

- 일반 검색과 승인한 AI 검색·규칙 분류에서 지원 본문 전체를 검색합니다. XLSX 셀, PPTX 슬라이드·발표자 노트, 일반 HWP 5를 추가했습니다.
- 현재 폴더에서 이름 와일드카드·확장자·크기·작성/수정일을 조합해 필터링합니다.
- 바로가기 만들기/붙여넣기, 숨김·읽기 전용 변경, 전체 결과 CSV 내보내기를 제공합니다.
- 암호 압축 해제, 압축 내용 보기·선택 파일 해제, Windows에 설치된 OCR로 이미지·PDF 텍스트 읽기를 추가했습니다.
- 예시 파일은 `source/tests/LogicTests/Fixtures/ExplorerSamples/`, Windows 기능별 비교는 `docs/WINDOWS_EXPLORER_GAP_MATRIX.md`에 있습니다. 일부 형식·기능은 명시적 제한이 있습니다.

`BUILD_ON_WINDOWS_COMPANY.cmd`는 기본 경량 설치형 빌드입니다. 대상 PC에 .NET 10 Desktop Runtime x64가 필요하며 자동으로 내려받지 않습니다. 실행환경을 포함하려면 CMD에서 `set SUNRISE_LIGHTWEIGHT=0` 후 같은 빌드 파일을 실행합니다. 경량 배포 폴더 ZIP 실측은 약 9.71MB이며, 압축 해제한 앱 파일은 약 34.81MB입니다. 실제 서명 Setup 크기와 Windows 설치·실행은 아직 확인이 필요합니다.

전체 구현·검증 범위와 남은 제한은 `CURRENT_SOURCE.md`를 참조하세요. 기존 사용자 설정과 단일 빌드 진입점을 유지합니다.

---

아래는 이전 버전의 개발 이력입니다.

# Sunrise File Manager 1.4.1

Windows x64용 다중 분할 파일 관리자입니다. 이번 버전은 기존 탐색 기능의 검색 범위와 대량 목록 처리, 작업 응답성을 보완합니다.

- PDF 전체 페이지와 DOCX·HWPX의 지원 본문을 순차 검색하고, 미지원·크기 제한·텍스트 없음·읽기 불가를 구분합니다.
- 일반 폴더는 전체 항목에 정렬·필터를 적용해 2,000행씩 표시합니다. 이전/다음 페이지와 페이지 밖 파일 위치 찾기를 제공합니다. 모두 선택과 목록 내보내기는 현재 페이지에 적용합니다.
- 사진 모음은 전체 대상 폴더에서 최신 20,000개를 선정하며, 최근 관련 폴더는 관련 파일 개수로 표시합니다.
- 메모 동반 이동, 클라우드 파일 호환성·다운로드 취소 요청, 전송 속도 계산과 속성 창 응답성을 보완했습니다.

지원 형식·크기·작업 한계와 검증 결과는 `CURRENT_SOURCE.md`를 참조하세요. 소스 교차 컴파일과 변경영향 로직 검증은 완료했으며 Windows 최종 실행·설치·서명은 별도 확인이 필요합니다. 기존 `BUILD_ON_WINDOWS_COMPANY.cmd`를 사용합니다.

---

아래는 이전 버전의 개발 이력입니다.

# Sunrise File Manager 1.4.0

Windows x64용 다중 분할 파일 관리자입니다. 이번 소스 전달본은 탐색기 기능 차이표의 중요도 순으로 15개 영역을 확장했습니다.

- 파일 충돌 비교·건너뛰기·새 이름·명시적 바꾸기, 같은 이름의 폴더 내용 병합
- 하위 폴더 이름·지원 문서 본문·Windows 인덱스 검색과 종류·날짜·크기·상위 폴더 그룹화
- Windows 확장 메뉴·공유, 최근 파일·자주 사용한 폴더·라이브러리·네트워크 위치
- ZIP·TAR·7z 생성, ZIP·TAR·7z·RAR 및 지원 압축 TAR 해제
- 전송 일시 중지·재개·평균 처리 속도·남은 시간, 20,000개 일반 목록 제한 해제
- 사진 모아보기, OneDrive 계정 폴더·클라우드 파일 상태·오프라인/온라인 전용 전환
- Windows 속성 처리기를 통한 제목·설명·태그·작성자·평점 편집

메뉴 진입 경로와 제한·검증 결과는 `CURRENT_SOURCE.md`를 참조하세요. **소스 컴파일 및 변경영향 로직 검증과 Windows 최종 실행 검증은 구분합니다.** Windows 설치형 빌드의 진입점은 `BUILD_ON_WINDOWS_COMPANY.cmd`이며, 이 소스 검증에서 이미 통과한 검사를 Windows 빌드에서 반복하지 않는 기존 정책을 유지합니다.

---

아래 내용은 이전 버전의 개발 이력입니다.

> **v1.3.8 R04:** 파일 복사·잘라내기·붙여넣기·일반 이동/드래그에 대한 반복 승인 팝업 제거. 진행률·취소·충돌 건너뛰기/번호 변경은 유지하며, Delete/Shift+Delete 삭제 확인과 미저장 메모 보호는 유지합니다. Windows 실기 검증은 별도입니다.

> **v1.3.8 R03 소스 수정:** 단일 파일/폴더 이름 변경 F2를 목록 내 직접 편집으로 전환하고, 탐색창 확장자 표시 설정과 편집/파일명 보존 동작을 일치시켰습니다. 다중 파일 일괄 이름 변경은 기존 창을 유지합니다. Windows 최종 실행검증은 별도입니다.

# Sunrise File Manager 1.3.8

## v1.3.8 R02 — 3차 대량 폴더 탐색 안정화

- 폴더가 350개를 초과해도 나머지가 사라지지 않도록 `다음 350개 폴더 보기…`로 탐색을 이어갈 수 있습니다.
- `위치 찾기`는 첫 페이지 밖의 깊은 폴더도 해당 경로를 확인해 표시하도록 보완했습니다.
- 이전에 열었던 사용하지 않는 폴더 트리의 메모리를 정리하되 **빠른 이동부터 드라이브 트리까지 단일 스크롤**은 그대로 유지합니다.
- 상세 및 실기 검증 매트릭스: `docs/V138_R02_STAGE3_LARGE_TREE.md`; Windows 동적 검증은 PENDING입니다.


## v1.3.8 R01 — 2차 탐색 편의 (좌측 스크롤 분리 없음)

- 사용자 지시에 따라 빠른 이동·즐겨찾기·드라이브·폴더 트리의 **단일 스크롤 구조를 그대로 유지**합니다.
- `이 PC (드라이브 및 폴더)` 제목 옆 `위치 찾기`로 현재 폴더를 트리에서 명시적으로 찾을 수 있습니다.
- 펼쳐진 하위 폴더 전체 높이가 아닌 **선택된 폴더 행**을 기준으로 세로 위치를 안정화했습니다.
- 이미 수동으로 접은 경로를 이전 비동기 작업이 다시 열지 않으며, 퀵 폴더 이동은 실제 C: 경로를 자동 확장하지 않습니다.
- 자세한 사항: `docs/V138_R01_SINGLE_SCROLL_STAGE2.md`. Windows 실기 동적 검증은 PENDING입니다.

## v1.3.8 R00 — 폴더 트리 UI 밀도 1차 개선

- 깊은 폴더 계층의 들여쓰기 폭을 축소(42→16 DIP)하고 긴 폴더명은 한 줄 말줄임·전체 이름 툴팁으로 표시합니다.
- 선택 폴더에 테마 강조 표시선을 추가했습니다. 드라이브 화살표의 기존 40×36 DIP 클릭 영역·펼침 상태·드라이브 용량 표시는 유지합니다.
- UI 스타일을 탐색 트리 컴포넌트 소유로 격리했습니다. 사용자 설정/업데이트/파일 동작 계약은 변경하지 않았습니다.
- 상세: `docs/V138_R00_COMPACT_FOLDER_TREE_UI.md`. Windows 실제 WPF 시각 검증은 PENDING입니다.

## v1.3.8 드라이브 트리·단일 화면 가로 스크롤 보완

- 드라이브의 시각적 펼침/접힘과 실제 상태를 한 기준으로 통합하여 첫 클릭부터 정확히 전환합니다. 이전에 시작한 비동기 경로 표시가 다시 펼치지 않도록 무효화합니다.
- 단일 화면에서 파일을 마우스로 선택해도 DataGrid의 자동 가로 이동 때문에 현재 스크롤 위치가 바뀌지 않게 보완합니다. 기존 수동 스크롤, 다른 분할 화면, 파일 작업 및 AI·메모 기능은 유지합니다.
- 수정 내역: `docs/V138_TREE_TOGGLE_AND_SINGLE_PANE_SCROLL.md` / 반복 오류: `docs/DEFECT_REGISTRY.md`.
- Windows .NET/WPF 실제 빌드·마우스 UI Gate는 PENDING입니다.


## v1.3.7 안정화 — 업데이트 종료 시 설정 저장 재발 방지

- v1.3.5에서 v1.3.6으로 업데이트 시 발생했던 `탐색기 설정 값이 올바르지 않습니다`는 **업데이트 이전에 실행 중인 v1.3.5의 종료·세션 저장 경로**에서 발생할 수 있었음을 확인했습니다.
- v1.3.7은 기존 v1.3.6 R01 캡처 보호를 유지하며, **실제 UI 세션 저장 경계에서 한 번 더 정상화**해 향후 동일 회귀를 방지합니다. 저장 실패 원인을 숨기거나 사용자 기존 데이터를 삭제하지 않습니다.
- v1.3.5 실행파일 자체는 v1.3.7 소스로 사후 변경할 수 없습니다. 이전 버전에서 업데이트가 종료 오류로 막힌다면 작업 저장을 확인하고 수동 설치 경로를 사용해야 합니다.
- 결함 상세와 재발 방지 기준: `docs/DEFECT_REGISTRY.md` 및 `docs/V137_UPDATE_EXIT_SESSION.md`.
- 공지사항에는 다운로드 URL, 내부 배포 주소 또는 보안 정보를 넣지 않습니다.

# Sunrise File Manager 1.3.6

Sunrise Group 공식 Windows 10/11 x64 파일 관리 프로그램의 전체 소스입니다. 최대 4분할 탐색기와 탭, 검색, 미리보기, 파일 메모, 선택형 로컬 AI를 제공합니다.

## 1.3.6 R00 변경 (탐색창 너비·확장 상태·가로 휠)

- 탐색창은 기본 272 DIP에서 시작하며, 오른쪽 가장자리를 드래그하면 145~520 DIP 범위에서 폭을 조절합니다. 좁은 분할 화면에서는 파일 목록이 남도록 표시 폭을 자동 제한합니다.
- 탐색창 자동 숨김 중에도 가장자리에 마우스를 올려 펼친 상태에서 오른쪽 경계를 드래그하여 폭을 조절합니다. 탐색기별 선택 너비는 사용자 세션에 보존됩니다.
- 다른 폴더로 이동할 때 이전 폴더의 불필요한 드라이브/하위 트리 확장을 자동으로 접습니다. 동일 폴더 새로고침은 기존 펼침 상태를 유지합니다.
- 파일 목록에서 **Shift + 마우스 휠**은 가로 스크롤, Ctrl + 마우스 휠은 기존 보기 조절, 일반 마우스 휠은 세로 스크롤로 유지합니다.
- 제품/설치 버전은 1.3.6을 유지하며 동일 버전의 첫 수정 소스는 R00으로 구분합니다. Windows 동적 UI 검증은 별도입니다.

## 1.3.6 변경 (탐색 트리·빠른 이동·마우스 조작)

- 주소표시줄 클릭 또는 드롭다운 버튼 사용 시 경로 문자열 나열 대신, 기본 폴더·즐겨찾기·드라이브를 펼쳐 탐색하는 트리형 목록이 표시됩니다. 직접 경로 입력/Enter/F4 유지.
- 빠른 이동 및 기본 폴더는 해당 폴더의 내용으로 즉시 이동하며, 좌측 트리에 실제 C: 사용자 경로를 자동으로 펼치지 않습니다. 드라이브와 일반 폴더를 직접 탐색할 때만 트리가 확장됩니다.
- 드라이브 확장 화살표 클릭 영역을 40×36 DIP로 확장하고, 드라이브 이름 더블클릭으로 펼침/접힘을 지원합니다.
- 파일 목록의 빈 배경을 빠르게 두 번 클릭하면 기존 상위 폴더 이동을 실행합니다. 행·헤더·스크롤바·드래그 선택은 보호합니다.
- 공지사항에는 프로그램 다운로드 URL/내부 배포 주소를 기재하지 않습니다.
- .NET 10/WPF 실제 Windows UI·설치파일 검증은 별도 PENDING입니다.

## 1.3.5 R01 변경 (설치파일 생성 안정화)

- 버전별 공지 파일 누락으로 설치파일 생성 후 빌드가 중단되던 문제를 수정했습니다.
- 파일이 준비되지 않은 경우 빌드 초기에 안내하므로 불필요한 재빌드를 방지합니다.
- 제품 버전과 기존 파일 탐색·전송·AI 기능은 변경하지 않았습니다.

## 1.3.5 R00 변경 (탐색 편의 기능 추가)

- 파일 목록의 **빈 공간을 마우스 왼쪽 버튼으로 두 번 클릭**하면 상위 폴더로 이동합니다. 파일·폴더 항목 더블클릭과 헤더·스크롤바 조작은 기존대로 유지합니다.
- 주소표시줄 클릭 또는 펼침 화살표를 누르면 현재·상위·최근 방문·주요 폴더·드라이브 경로 목록이 표시됩니다. 경로 직접 입력/Enter 기능도 유지합니다.
- 우측 하단의 공지사항과 업데이트 바로가기 버튼을 **`공지사항 및 업데이트` 1개**로 통합했습니다. 두 기능이 들어 있는 Control 창과 설정 메뉴의 기존 경로는 유지합니다.
- 제품 버전은 1.3.5 그대로이며, 동일 버전의 첫 수정 패키지를 R00로 구분합니다. Windows 실제 빌드·마우스 동작검증은 별도 PENDING입니다.

## 1.3.5 변경 (폴더 이동 시 가로 스크롤 위치 오류 수정)

- 폴더 더블클릭, 마우스 뒤로/앞으로, 상위 이동, 탭 전환 시 파일 목록의 가로 스크롤을 왼쪽에서 시작하도록 수정했습니다.
- 선택된 폴더를 탐색 트리에 강조할 때 바깥 분할 탐색기 전체가 오른쪽으로 밀리지 않도록 개선했습니다.
- 같은 폴더 새로고침은 사용자의 가로·세로 스크롤 위치를 복원하며, 가로 스크롤을 사용자가 직접 이동하는 기능은 유지합니다.
- 이전 세션의 파일 목록 위치는 최초 시작 시에만 복원하고, 새로운 폴더까지 이전 위치가 전파되지 않게 합니다.

## 1.3.4 변경 (파일 이동·숫자 정렬 개선)

- 서로 다른 드라이브 간 파일·폴더 복사, 잘라내기·붙여넣기, 드래그 이동을 지원합니다. 복사가 완료된 후 원본을 정리합니다.
- 파일명에 숫자가 들어 있는 경우 Windows 탐색기식 순서로 정렬합니다(예: 1, 2, 3, 10, 11).
- 이동 실행 취소의 실제 대상 이름을 기억하고, 대용량 실행 취소 중에도 화면이 응답하도록 개선했습니다.
- 원본 또는 대상의 Windows 접근 권한이 없는 경우 자동으로 권한을 우회하지 않으며, 원본을 보호하고 원인을 안내합니다.

## 1.3.3 변경 (R00 소스 감사·배포 경량화)

- 기존 기능·설정·호환 유지, 파일 압축 시 중복 경로가 포함되는 입력을 사전 거부합니다.
- 공식 Windows 배포에서 진단 전용 PDB를 제외하여 설치 후 디스크 사용량을 줄이는 경량화 조치를 적용합니다.
- .NET/WPF 필수 런타임 및 모든 언어 리소스를 유지하여 별도 .NET 설치 없는 실행 방식을 보존합니다.
- 실제 설치 용량은 Windows 빌드·설치 결과로 확인해야 합니다.

## 1.3.2 변경

- 최초 실행 기본값: 숨긴 항목 표시, 파일 확장명 표시, 항목 확인란, 색상 구분 모두 끔. 기존에 저장한 사용자 선택은 유지합니다.
- 좌측 빠른 이동 아이콘 복원. 1.3.2 당시 탐색 패널은 272 DIP 고정 너비였으나, 1.3.6 R00부터 너비 조절을 지원합니다. 긴 드라이브 이름은 줄바꿈합니다.
- 좌측 경계 버튼으로 탐색 패널 열기·닫기. 자동 숨김을 켜면 경계에 마우스를 올릴 때 펼쳐지고 벗어나면 접힙니다.
- 빈 영역에서 좌클릭 드래그로 사각형 다중 선택. Ctrl 선택 반전, Shift 선택 추가, 화면 가장자리 자동 스크롤을 지원합니다.
- 새 탭은 내 PC로 시작합니다. 상위 이동은 드라이브 → 내 PC → 바탕화면까지 이어집니다.
- 탭·열린 폴더·검색어·보기 옵션·열 너비와 순서·분할 비율·도킹·AI 선택 등 사용자 설정을 저장하고 재시작 시 복원합니다. 연결이 끊긴 드라이브의 탭도 유지합니다.
- 파일 행의 테마와 다른 기본 장식 경로를 제거하고 메뉴 구분선의 레이아웃을 수정했습니다.
- 1.3.0의 UI 배율, Known Folder 이동, 내부 휴지통, AI 모델 추천 및 빌드 JSON 자동 구성 개선을 유지합니다.

## Windows 빌드

.NET 10 SDK, Inno Setup, Windows SDK 빌드 도구가 있는 Windows x64 PC에서 `BUILD_ON_WINDOWS_COMPANY.cmd`를 실행합니다. 결과는 `dist/Sunrise_File_Manager_1.3.6_Setup.exe`입니다. 기존 회사 빌드는 소스 시험·업무 문서 시험을 추가로 실행하지 않습니다. Ollama는 프로그램 빌드나 기본 탐색 기능에 필수가 아닙니다.

## 빌드 후 업데이트 파일

최종 빌드의 `dist/release-metadata/latest.json`과 `release_info.json`에 버전별 URL과 `update_endpoint_configured: true`가 자동 입력됩니다. SHA256과 파일 크기도 실제 빌드한 Setup 기준으로 생성합니다. JSON을 수동 수정할 필요가 없습니다.

해당 버전의 GitHub 릴리스에 Setup을 먼저 올리고 다운로드를 확인한 뒤, 같은 폴더의 `notice.txt`와 `latest.json`을 게시합니다. `latest.json`은 마지막으로 게시합니다. 저장소 루트의 동명 파일은 과거 공개 채널 스냅샷이므로 새 빌드 결과와 구분합니다.

## 검증 상태

8개 소스 검증 게이트가 통과했습니다. 결과는 `validation/PRE_BUILD_RESULT.json`에 있습니다. 이 전달물은 소스 패키지이며 실제 Windows 화면·마우스 입력·DPI·장치 조회·휴지통 복원·서명된 설치·이전 버전 갱신 검증은 PENDING입니다. 설치파일 게시 및 원격 업데이트 정보 변경은 수행하지 않았습니다.

개발 기준은 `CURRENT_SOURCE.md`, `docs/FILE_MANAGER_CURRENT_CONTRACT.md`, `docs/V132_NAVIGATION_AND_SESSION.md`입니다. V130·V120·R번호 문서는 해당 시점의 기록입니다.
